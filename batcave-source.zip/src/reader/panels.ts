import type { ReaderView, PanelEdits } from '../models';

import { sameRegion, type PageQuality } from './page-quality';
export type Rect = [number, number, number, number];
export interface PanelPage { width: number; height: number; kind: 'story' | 'cover' | 'text'; frames: Rect[] }
export interface PanelMap { version: 1; sha256: string; pageCount: number; pages: PanelPage[]; detector?: 'inkwell-v1' }
export interface PanelStep { page: number; panel: number; part: number; parts: number; bounds: Rect; focus: Rect; overview?: 'before' | 'after'; viewPart?: number }
export const YEAR_ONE_HASH = '08e14cafe1d4e5063beae4d0a46b47ffb17201db6f5560bc6089a3d12432b1b5';

export function parsePanelMap(value: unknown, hash: string, count: number): PanelMap {
  const m = value as Partial<PanelMap> | null;
  if (!m || m.version !== 1 || m.sha256 !== hash || m.pageCount !== count || !Array.isArray(m.pages) || m.pages.length !== count)
    throw Error('Разметка кадров не соответствует этому PDF.');
  for (const p of m.pages) {
    if (!p || !Number.isFinite(p.width) || !Number.isFinite(p.height) || p.width <= 0 || p.height <= 0 || !['story', 'cover', 'text'].includes(p.kind) || !Array.isArray(p.frames) || !p.frames.length || p.frames.length > 100)
      throw Error('Повреждена разметка кадров.');
    for (const r of p.frames)
      if (!Array.isArray(r) || r.length !== 4 || r.some(n => !Number.isFinite(n)) || r[0] < 0 || r[1] < 0 || r[2] <= 0 || r[3] <= 0 || r[0] + r[2] > 1.00002 || r[1] + r[3] > 1.00002)
        throw Error('Некорректные границы кадра.');
  }
  return m as PanelMap;
}

export async function loadPanelMap(hash: string, count: number, signal?: AbortSignal): Promise<PanelMap | undefined> {
  // Match content, never a filename or a title. A different edition cannot
  // silently receive this edition's coordinates. No PDF leaves the device.
  if (hash !== YEAR_ONE_HASH || count !== 99) return undefined;
  const response = await fetch(`${import.meta.env.BASE_URL}panels/year-one.json`, { signal });
  if (!response.ok) throw Error('Не удалось загрузить разметку кадров. Откройте приложение с интернетом один раз.');
  return parsePanelMap(await response.json(), hash, count);
}

// One navigation stop per real frame. Dimensions and direction stay in the
// signature for existing callers; neither can create synthetic close views.
export function panelSteps(map: PanelMap, _rtl = false, first = false, last = false, _width = 375, _height = 812, options: { edits?: PanelEdits; quality?: Map<number, PageQuality>; crop?: boolean } = {}): PanelStep[] {
  const steps: PanelStep[] = [];
  map.pages.forEach((page, p) => {
    const quality = options.quality?.get(p);
    const full: Rect = options.crop && quality ? quality.crop : [0, 0, 1, 1];
    const edits = options.edits?.fingerprint === map.sha256 ? options.edits.frames.filter(e => e.page === p) : [];
    const kept = page.frames.flatMap((bounds, panel) => {
      const edit = edits.find(e => e.panel === panel);
      if (edit?.hidden || (!edit && (quality?.blank.includes(panel) || quality?.duplicate.includes(panel)))) return [];
      return [{ bounds, panel, edit }];
    });
    if (!kept.length) { steps.push({page:p,panel:0,part:0,parts:1,bounds:full,focus:full,overview:'before'}); return; }
    const onlyFull = kept.length === 1 && sameRegion(kept[0].edit?.bounds ?? kept[0].bounds, quality?.crop ?? full);
    if (first && !onlyFull && page.kind !== 'cover') steps.push({ page: p, panel: 0, part: 0, parts: 1, bounds: full, focus: full, overview: 'before' });
    kept.forEach(({ bounds, panel }) => {
      steps.push({ page: p, panel, part: 0, parts: 1, bounds, focus: bounds, viewPart: 0 });
    });
    if (last && !onlyFull && page.kind !== 'cover') steps.push({ page: p, panel: page.frames.length - 1, part: 0, parts: 1, bounds: full, focus: full, overview: 'after' });
  });
  return steps;
}

export function findPanelStep(steps: PanelStep[], page: number, saved?: ReaderView): number {
  const valid = saved?.mode === 'panels' && saved.page === page;
  if (valid) {
    const exact = steps.findIndex(s => s.page === page && s.panel === (saved.panel ?? 0) && (saved.viewPart === undefined ? s.part === (saved.part ?? 0) : s.viewPart === saved.viewPart) && s.overview === saved.overview);
    if (exact !== -1) return exact;
    const samePanel = steps.map((s, i) => ({ s, i })).filter(({ s }) => s.page === page && s.panel === (saved.panel ?? 0) && !s.overview);
    if (samePanel.length) return samePanel[Math.min(saved.part ?? 0, samePanel.length - 1)].i;
  }
  if (valid && !saved.overview) {
    const next = steps.findIndex(s => s.page === page && !s.overview && s.panel >= (saved.panel ?? 0));
    if (next !== -1) return next;
    const previous = steps.map((s,i) => s.page === page && !s.overview ? i : -1).filter(i => i >= 0).at(-1) ?? -1;
    if (previous !== -1) return previous;
  }
  return Math.max(0, steps.findIndex(s => s.page === page));
}

export function panelCamera(focus: Rect, ratio: number, width: number, height: number, zoom = 1, pan = { x: 0, y: 0 }) {
  const baseWidth = 1000, baseHeight = baseWidth * ratio;
  const [x,y,w,h] = focus;
  const scale = Math.min(Math.max(1,width-24) / (w*baseWidth), Math.max(1,height-24) / (h*baseHeight)) * zoom;
  return { scale, x: (width-w*baseWidth*scale)/2 - x*baseWidth*scale + pan.x, y: (height-h*baseHeight*scale)/2 - y*baseHeight*scale + pan.y, width: baseWidth, height: baseHeight, viewportWidth: width, viewportHeight: height };
}

// Reading zoom is a horizontal inspection of the complete frame, even when
// the current automatic stop or edited view shows only part of it. Keep both
// vertical edges visible so a balloon cannot be stranded above/below the view.
export function horizontalInspection(bounds: Rect, base: ReturnType<typeof panelCamera>, zoom: number, requestedPan = 0) {
  const { width, height, viewportWidth: vw, viewportHeight: vh } = base;
  const [x, y, w, h] = bounds;
  const availableWidth = Math.max(1, vw - 24), availableHeight = Math.max(1, vh - 24);
  const scale = Math.min(base.scale * Math.max(1, zoom), availableHeight / (h * height),
    // Keep the entire horizontal range reachable within the existing saved
    // ReaderView coordinate range; backups remain compatible.
    (availableWidth + vw * 1.8) / (w * width));
  const limit = Math.min(vw * .9, Math.max(0, (w * width * scale - availableWidth) / 2));
  const pan = { x: Math.max(-limit, Math.min(limit, requestedPan)), y: 0 };
  const camera = { ...base, scale,
    x: (vw - w * width * scale) / 2 - x * width * scale + pan.x,
    y: (vh - h * height * scale) / 2 - y * height * scale };
  return { camera, pan, limit };
}
