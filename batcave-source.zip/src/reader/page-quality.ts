import type { Rect } from './panels';

export interface Pixels { width: number; height: number; data: Uint8ClampedArray }
export interface PageQuality { crop: Rect; blank: number[]; duplicate: number[]; emptyViews: Record<number, number[]> }
const full = (): Rect => [0, 0, 1, 1];

// Sample a bounded thumbnail once, never during an animation. The original
// canvas and source bytes stay intact; all coordinates remain page-relative.
export function samplePage(canvas: HTMLCanvasElement): Pixels {
  const small = document.createElement('canvas');
  const scale = Math.min(1, 900 / Math.max(canvas.width, canvas.height));
  small.width = Math.max(1, Math.round(canvas.width * scale));
  small.height = Math.max(1, Math.round(canvas.height * scale));
  const ctx = small.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(canvas, 0, 0, small.width, small.height);
  const pixels = ctx.getImageData(0, 0, small.width, small.height);
  small.width = small.height = 0;
  return pixels;
}

// A footer is removed only when a framed illustration is followed by a
// narrow white gutter with TWO matching grey marks: a centred folio and a
// right-aligned scan credit. This is deliberately not a generic text eraser.
export function footerBoundary(p: Pixels): number | undefined {
  const {width: w, height: h, data} = p;
  let edge = -1;
  for (let y = Math.floor(h*.85); y < h; y++) {
    let ink = 0;
    for (let x=0;x<w;x++) {
      const i=(y*w+x)*4;
      if (Math.min(data[i],data[i+1],data[i+2]) < 232) ink++;
    }
    if (ink/w >= .55) edge=y;
  }
  if (edge < 0 || edge > h*.98) return;
  // JPEG/downsampling creates a few pale rows along a printed lower border.
  // Only advance past these rows, never through a separate caption or picture.
  for (let start=edge+1; start<=Math.min(h-1,edge+6); start++) {
    let center=0,right=0,noise=0,count=0,invalid=false;
    let minY=h,maxY=-1,centerMin=w,centerMax=-1,rightMin=w,rightMax=-1;
    for (let y=start;y<h && !invalid;y++) for(let x=0;x<w;x++) {
      const i=(y*w+x)*4;
      const lo=Math.min(data[i],data[i+1],data[i+2]), hi=Math.max(data[i],data[i+1],data[i+2]);
      if (lo>=225) continue;
      const isCenter=x>=w*.45 && x<=w*.55, isRight=x>=w*.75;
      // A folio may have darker digits; scan credits themselves are light grey.
      if (hi-lo>24 || lo<(isCenter?65:125)) { invalid=true;break; }
      count++; minY=Math.min(minY,y);maxY=Math.max(maxY,y);
      if(isCenter){center++;centerMin=Math.min(centerMin,x);centerMax=Math.max(centerMax,x);}
      else if(isRight){right++;rightMin=Math.min(rightMin,x);rightMax=Math.max(rightMax,x);}
      else noise++;
    }
    if(invalid || noise>3 || center<8 || right<30 || count>w*(h-start)*.22) continue;
    if(maxY-minY>h*.035 || centerMax-centerMin>w*.05 || rightMax-rightMin<w*.10) continue;
    return start;
  }
}

export function outerMargins(p: Pixels): Rect {
  const { width: w, height: h, data } = p;
  const bottomLimit = footerBoundary(p) ?? h;
  const paper = new Uint8Array(w*bottomLimit), seen=new Uint8Array(paper.length);
  for(let n=0;n<paper.length;n++) {
    const i=n*4,lo=Math.min(data[i],data[i+1],data[i+2]),hi=Math.max(data[i],data[i+1],data[i+2]);
    paper[n]=lo>=232 && hi-lo<=18 ? 1 : 0;
  }
  // A few pale scanner specks at the physical page edge should not anchor a
  // 30-pixel margin. Keep dark ink, coloured marks and every larger component.
  for(let n=0;n<paper.length;n++) {
    const x=n%w,y=Math.floor(n/w);
    if(paper[n] || seen[n] || (x>w*.05 && x<w*.95 && y>h*.05 && y<h*.95)) continue;
    const group=[n];seen[n]=1;let light=true,large=false;
    for(let j=0;j<group.length;j++) {
      const m=group[j],mx=m%w,i=m*4;
      const lo=Math.min(data[i],data[i+1],data[i+2]),hi=Math.max(data[i],data[i+1],data[i+2]);
      light &&= lo>=180 && hi-lo<=18;
      for(const next of [m-w,m+w,...(mx>0?[m-1]:[]),...(mx<w-1?[m+1]:[])]) {
        if(next>=0 && next<paper.length && !paper[next] && seen[next]===2) large=true;
        if(next>=0 && next<paper.length && !paper[next] && !seen[next]) {
          seen[next]=1;group.push(next);
        }
      }
      if(group.length>6 || large){large=true;break;}
    }
    if(light && !large) for(const m of group) paper[m]=1;
    else for(const m of group) seen[m]=2;
  }
  const white = (x: number,y: number) => paper[y*w+x]===1;
  const row = (y: number) => { for (let x = 0; x < w; x++) if (!white(x, y)) return false; return true; };
  const col = (x: number, top: number, bottom: number) => { for (let y = top; y <= bottom; y++) if (!white(x, y)) return false; return true; };
  let top = 0, bottom = bottomLimit - 1, left = 0, right = w - 1;
  while (top < bottomLimit && row(top)) top++;
  if (top === bottomLimit) return full();
  while (bottom > top && row(bottom)) bottom--;
  // The excluded footer cannot hold the side borders open either.
  while (left < right && col(left,top,bottom)) left++;
  while (right > left && col(right,top,bottom)) right--;
  // Half a thumbnail pixel covers resampling uncertainty without the old
  // two-pixel white rim. Keep the complete ink boundary and all internal gaps.
  const pad=.5;
  top = Math.max(0, top-pad); bottom = Math.min(bottomLimit-1,bottom+pad);
  left = Math.max(0,left-pad); right = Math.min(w-1,right+pad);
  if (right-left < w*.35 || bottom-top < h*.35) return full();
  return [left/w,top/h,(right-left+1)/w,(bottom-top+1)/h];
}

// Ignore only a thin boundary: a blank rectangle may have its own printed
// border. Even a small patch of text or art inside keeps the frame.
export function emptyRegion(p: Pixels, r: Rect, dark = false, inset = .08): boolean {
  const x0 = Math.max(0, Math.ceil((r[0] + r[2] * inset) * p.width));
  const y0 = Math.max(0, Math.ceil((r[1] + r[3] * inset) * p.height));
  const x1 = Math.min(p.width, Math.floor((r[0] + r[2] * (1 - inset)) * p.width));
  const y1 = Math.min(p.height, Math.floor((r[1] + r[3] * (1 - inset)) * p.height));
  if ((x1 - x0) * (y1 - y0) < 80) return false;
  let white = 0, black = 0, count = 0;
  const marks: number[] = [];
  for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
    const i = (y * p.width + x) * 4, lo = Math.min(p.data[i], p.data[i + 1], p.data[i + 2]), hi = Math.max(p.data[i], p.data[i + 1], p.data[i + 2]);
    white += lo >= 232 ? 1 : 0; black += hi <= 27 ? 1 : 0; count++;
    if (lo < 232 && marks.length < 13) marks.push(y*p.width+x);
  }
  if (count - white <= 2 || (dark && count - black <= 2)) return true;
  // Isolated scanner dust is not a panel. A connected 4-pixel stroke or more
  // than 12 marked pixels keeps even tiny lettering and white drawings.
  if (count - white > 12) return false;
  const todo = new Set(marks);
  while (todo.size) {
    const seed = todo.values().next().value!; todo.delete(seed);
    const group = [seed];
    for (let i=0; i<group.length; i++) {
      const n=group[i], x=n%p.width;
      for (const next of [n-p.width,n+p.width,...(x>0?[n-1]:[]),...(x<p.width-1?[n+1]:[])])
        if (todo.delete(next)) group.push(next);
      if (group.length >= 4) return false;
    }
  }
  return true;
}

export function sameRegion(a: Rect, b: Rect): boolean {
  const overlap = Math.max(0, Math.min(a[0] + a[2], b[0] + b[2]) - Math.max(a[0], b[0])) * Math.max(0, Math.min(a[1] + a[3], b[1] + b[3]) - Math.max(a[1], b[1]));
  return overlap / Math.max(a[2] * a[3], b[2] * b[3]) > .96;
}

export function emptyCloseView(p: Pixels, r: Rect): boolean {
  if (emptyRegion(p, r, true, .12)) return true;
  // A close view of a solid black cloak can contain thin blue strips at its
  // sides, so it is not literally monochrome. Preserve any white lettering
  // and any appreciable central detail; never drop the full-frame view.
  const counts = (inset: number) => {
    let black = 0, white = 0, n = 0;
    for (let y = Math.ceil((r[1]+r[3]*inset)*p.height); y < Math.min(p.height,(r[1]+r[3]*(1-inset))*p.height); y++)
      for (let x = Math.ceil((r[0]+r[2]*inset)*p.width); x < Math.min(p.width,(r[0]+r[2]*(1-inset))*p.width); x++) {
        const i=(y*p.width+x)*4, lo=Math.min(p.data[i],p.data[i+1],p.data[i+2]), hi=Math.max(p.data[i],p.data[i+1],p.data[i+2]);
        black += hi < 35 ? 1 : 0; white += lo > 205 ? 1 : 0; n++;
      }
    return {black:black/Math.max(1,n),white:white/Math.max(1,n),n};
  };
  const whole=counts(.04), middle=counts(.22);
  return whole.n > 150 && whole.black > .8 && middle.black > .97 && whole.white < .0005;
}

export function inspectPage(p: Pixels, frames: Rect[]): PageQuality {
  const blank = frames.flatMap((r, i) => emptyRegion(p, r) || emptyMarginStripe(p, r) ? [i] : []);
  const duplicate = frames.flatMap((r, i) => frames.slice(0, i).some((q, j) => !blank.includes(j) && sameRegion(r, q)) ? [i] : []);
  return { crop: outerMargins(p), blank, duplicate, emptyViews: {} };
}

export function emptyMarginStripe(p: Pixels, r: Rect): boolean {
  // A very thin detector box at the page edge may cover both white paper and
  // a straight black gutter. Restrict this rule to edge strips, never scenes.
  if (!((r[2] < .08 && (r[0] < .025 || r[0]+r[2] > .975)) ||
    (r[3] < .08 && (r[1] < .025 || r[1]+r[3] > .975)))) return false;
  const x0=Math.ceil((r[0]+r[2]*.12)*p.width), x1=Math.floor((r[0]+r[2]*.88)*p.width);
  const y0=Math.ceil((r[1]+r[3]*.12)*p.height), y1=Math.floor((r[1]+r[3]*.88)*p.height);
  if (x1-x0 < 8 || y1-y0 < 8) return false;
  const axis = (vertical: boolean) => {
    let complex=0, transitions=0, previous=-1;
    const rows=vertical?x1-x0:y1-y0, columns=vertical?y1-y0:x1-x0;
    for(let a=0;a<rows;a++) {
      let white=0,black=0;
      for(let b=0;b<columns;b++) {
        const x=vertical?x0+a:x0+b, y=vertical?y0+b:y0+a, i=(y*p.width+x)*4;
        const lo=Math.min(p.data[i],p.data[i+1],p.data[i+2]),hi=Math.max(p.data[i],p.data[i+1],p.data[i+2]);
        white+=lo>=232?1:0;black+=hi<=65?1:0;
      }
      if(Math.max(white,black)/columns < .98) { complex++;continue; }
      const color=white>black?1:0;
      if(previous!==-1 && previous!==color) transitions++;
      previous=color;
    }
    return complex<=Math.max(1,Math.floor(rows*.02)) && transitions<=3;
  };
  return axis(false) || axis(true);
}

export function cropCanvas(canvas: HTMLCanvasElement) {
  const r = outerMargins(samplePage(canvas));
  if (r.every((v, i) => Math.abs(v - full()[i]) < .001)) return;
  const copy = document.createElement('canvas');
  const x=Math.max(0,Math.floor(r[0]*canvas.width)), y=Math.max(0,Math.floor(r[1]*canvas.height));
  const right=Math.min(canvas.width,Math.ceil((r[0]+r[2])*canvas.width));
  const bottom=Math.min(canvas.height,Math.ceil((r[1]+r[3])*canvas.height));
  copy.width=right-x; copy.height=bottom-y;
  copy.getContext('2d')!.drawImage(canvas,x,y,copy.width,copy.height,0,0,copy.width,copy.height);
  canvas.width = copy.width; canvas.height = copy.height;
  canvas.getContext('2d')!.drawImage(copy, 0, 0);
  copy.width = copy.height = 0;
}
