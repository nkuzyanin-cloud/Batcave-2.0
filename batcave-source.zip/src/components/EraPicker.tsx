import { useEffect, useRef } from 'react';
import { ERAS, type EraId } from '../eras';
export function EraPicker({value,onChange}:{value:EraId;onChange:(era:EraId)=>void}) {
  const ref=useRef<HTMLDetailsElement>(null);
  useEffect(()=>{
    const outside=(e:PointerEvent)=>{if(e.target instanceof Node && !ref.current?.contains(e.target) && ref.current) ref.current.open=false;};
    const escape=(e:KeyboardEvent)=>{if(e.key==='Escape' && ref.current?.open){ref.current.open=false;ref.current.querySelector('summary')?.focus();e.preventDefault();}};
    document.addEventListener('pointerdown',outside);document.addEventListener('keydown',escape);
    return ()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape);};
  },[]);
  return <details ref={ref} className="era-picker">
    <summary aria-label="Выбрать эру">{ERAS.find(e=>e.id===value)?.title}</summary>
    <div className="era-options" role="listbox" aria-label="Эры Бэтмена">
      {ERAS.map(e=><button key={e.id} role="option" aria-selected={e.id===value} onClick={()=>{onChange(e.id);if(ref.current){ref.current.open=false;ref.current.querySelector('summary')?.focus();}}}>{e.title}</button>)}
    </div>
  </details>;
}
