import { type Comic, stats } from './models';

export interface Achievement {
  id: string;
  name: string;
  hint: string;
  kind: 'stories' | 'pages' | 'library' | 'paper';
  goal: number;
  value: number;
  earned: boolean;
}

export function achievements(comics: Comic[]): Achievement[] {
  const s = stats(comics);
  const goals: Array<[string, string, string, Achievement['kind'], number, number]> = [
    ['first', 'Первая история', 'Прочитать первый комикс', 'stories', 1, s.done],
    ['pages-100', '100 страниц', 'Прочитать 100 страниц', 'pages', 100, s.pages],
    ['library-5', 'Своя библиотека', 'Добавить 5 цифровых комиксов', 'library', 5, s.digital],
    ['stories-5', 'Пять историй', 'Прочитать 5 комиксов', 'stories', 5, s.done],
    ['stories-10', 'Десять историй', 'Прочитать 10 комиксов', 'stories', 10, s.done],
    ['stories-25', 'Знаток историй', 'Прочитать 25 комиксов', 'stories', 25, s.done],
    ['pages-500', '500 страниц', 'Прочитать 500 страниц', 'pages', 500, s.pages],
    ['pages-1000', 'Тысяча страниц', 'Прочитать 1000 страниц', 'pages', 1000, s.pages],
    ['paper-1', 'Первая на полке', 'Добавить первый бумажный экземпляр', 'paper', 1, s.paper],
    ['paper-10', 'Коллекционер', 'Собрать 10 бумажных экземпляров', 'paper', 10, s.paper],
  ];
  return goals.map(([id, name, hint, kind, goal, value]) => ({
    id, name, hint, kind, goal, value: Math.min(goal, value), earned: value >= goal,
  }));
}
