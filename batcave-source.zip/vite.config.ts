import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  base: './',
  plugins: [react()],
  resolve: { conditions: ['onnxruntime-web-use-extern-wasm','module','browser','development|production'] },
  worker: { format: 'es' },
  build: { target: 'es2022', chunkSizeWarningLimit: 900 },
  server: { host: '0.0.0.0' },
});
