import {copyFileSync,mkdirSync,existsSync} from 'node:fs';
mkdirSync('public/panel-ai',{recursive:true});
for(const name of ['ort-wasm-simd-threaded.mjs','ort-wasm-simd-threaded.wasm'])
  copyFileSync(`node_modules/onnxruntime-web/dist/${name}`,`public/panel-ai/${name}`);
if(!existsSync('public/panel-ai/best.onnx')) throw Error('Missing bundled Inkwell panel model');
