import { describe, it, expect } from 'vitest';
import { outerMargins, footerBoundary, type Pixels } from '../../src/reader/page-quality';

function page(): Pixels {
  const p={width:400,height:600,data:new Uint8ClampedArray(400*600*4).fill(255)};
  box(p,20,20,360,540,[20,60,120]);
  return p;
}
function box(p:Pixels,x:number,y:number,w:number,h:number,rgb:number[]) {
  for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++)p.data.set([...rgb,255],(yy*p.width+xx)*4);
}
function footer(p:Pixels) {
  box(p,197,580,6,8,[150,150,150]);
  for(let x=312;x<396;x+=8)box(p,x,580,4,8,[150,150,150]);
}
describe('outer paper crop and scan footer',()=>{
  it('removes paired grey scan credit and folio below a broad panel',()=>{
    const p=page();footer(p);
    expect(footerBoundary(p)).toBe(560);
    const [x,y,w,h]=outerMargins(p);
    expect(x).toBeCloseTo(19.5/400);expect(y).toBeCloseTo(19.5/600);
    expect(x+w).toBeCloseTo(380.5/400);expect(y+h).toBeCloseTo(560/600);
  });
  it('keeps separate dark dialogue even beside a scan credit',()=>{
    const p=page();footer(p);box(p,25,572,150,8,[20,20,20]);
    expect(footerBoundary(p)).toBeUndefined();
    const r=outerMargins(p);expect(r[1]+r[3]).toBeGreaterThan(588/600);
  });
  it('keeps colored artwork outside the panel and footer',()=>{
    const p=page();footer(p);box(p,100,571,10,15,[180,100,60]);
    expect(footerBoundary(p)).toBeUndefined();
  });
  it('does not treat a number or a right caption alone as a footer',()=>{
    const p=page();box(p,197,580,6,8,[150,150,150]);
    expect(footerBoundary(p)).toBeUndefined();
    const q=page();box(q,312,580,80,8,[150,150,150]);
    expect(footerBoundary(q)).toBeUndefined();
  });
  it('does not crop black-background pages or full-bleed artwork',()=>{
    const p=page();box(p,0,0,400,600,[0,0,0]);footer(p);
    expect(footerBoundary(p)).toBeUndefined();expect(outerMargins(p)).toEqual([0,0,1,1]);
  });
  it('keeps internal white gutters and narrow panel wings',()=>{
    const p=page();box(p,20,180,360,5,[255,255,255]);box(p,20,185,60,180,[255,255,255]);
    const r=outerMargins(p);expect(r[0]).toBeCloseTo(19.5/400);expect(r[2]).toBeCloseTo(361/400);
    expect(p.data[(200*400+30)*4]).toBe(255);
  });
  it('ignores isolated pale edge dust but keeps dark and larger lettering',()=>{
    const p=page();box(p,390,2,2,2,[215,214,213]);expect(outerMargins(p)[1]).toBeCloseTo(19.5/600);
    const q=page();box(q,390,2,2,2,[40,40,40]);expect(outerMargins(q)[1]).toBeLessThan(2/600);
    const t=page();box(t,390,2,3,3,[215,214,213]);expect(outerMargins(t)[1]).toBeLessThan(2/600);
  });
  it('does not erase pale components connected to meaningful ink',()=>{
    const p=page();box(p,391,0,1,19,[215,214,213]);box(p,390,19,2,2,[40,40,40]);
    expect(outerMargins(p)[1]).toBe(0);
  });
  it('returns the full page for blank and unusually tiny content',()=>{
    const p=page();p.data.fill(255);expect(outerMargins(p)).toEqual([0,0,1,1]);
    box(p,190,290,10,10,[0,0,0]);expect(outerMargins(p)).toEqual([0,0,1,1]);
  });
  it('never mutates source pixels',()=>{
    const p=page();footer(p);const original=p.data.slice();outerMargins(p);expect(p.data).toEqual(original);
  });
});
