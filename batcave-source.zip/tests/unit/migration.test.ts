import 'fake-indexeddb/auto';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
vi.mock('pdfjs-dist', () => ({
  GlobalWorkerOptions: {},
  PDFDataRangeTransport: class {},
  getDocument: vi.fn(),
}));
import { initialCatalog, isUntouchedLegacySeed } from '../../src/data/catalog';
import { blankComic, defaultSettings } from '../../src/models';
import { dbPromise, initialize, allComics, getAsset, getSettings } from '../../src/storage/db';
describe('Conservative migration to an empty archive', () => {
  // Fixture timestamp signatures must not depend on CPU load during the test.
  beforeEach(() => { vi.spyOn(Date, 'now').mockReturnValue(1728000000000); });
  afterEach(() => vi.restoreAllMocks());
  it('recognizes only untouched reserved seed records', () => {
    for (const c of initialCatalog()) expect(isUntouchedLegacySeed(c)).toBe(true);
    const c = initialCatalog()[0];
    for (const changed of [
      { ...c, id: 'user-book' },
      { ...c, note: 'Mine' },
      { ...c, updatedAt: c.updatedAt + 2000 },
      { ...c, photoId: 'photo' },
      { ...c, completed: true },
      { ...c, rating: 3 },
      { ...c, pageCount: 2 },
      { ...c, unknownFutureField: true },
    ])
      expect(isUntouchedLegacySeed(changed)).toBe(false);
  });
  it('keeps originals, progress, settings, photos and edited metadata and runs only once', async () => {
    const db = await dbPromise;
    const seeds = initialCatalog();
    const imported = {
      ...seeds[0],
      pageCount: 4,
      page: 2,
      visited: [0, 2],
      seconds: 128,
      lastOpened: 1,
      digital: {
        assetId: 'original',
        name: 'my.pdf',
        size: 10,
        format: 'pdf' as const,
        fingerprint: 'a'.repeat(64),
      },
    };
    const edited = { ...seeds[1], note: 'Была на моей полке', photoId: 'my-photo' };
    const uncertain = { ...seeds[2], updatedAt: seeds[2].updatedAt + 1000 };
    const user = { ...blankComic('Моя книга'), physical: 'yes' as const, rating: 5 };
    const tx = db.transaction(['comics', 'assets', 'config'], 'readwrite');
    for (const c of [...seeds.slice(3), imported, edited, uncertain, user])
      await tx.objectStore('comics').put(c);
    await tx.objectStore('assets').put({ id: 'original', blob: new Blob(['original']) });
    await tx.objectStore('assets').put({ id: 'my-photo', blob: new Blob(['photograph']) });
    await tx.objectStore('config').put(true, 'initialized');
    await tx
      .objectStore('config')
      .put({ ...defaultSettings, direction: 'rtl', motion: 'off' }, 'settings');
    await tx.done;
    await initialize();
    const remaining = await allComics();
    expect(remaining).toHaveLength(4);
    for (const expected of [imported, edited, uncertain, user])
      expect(remaining.find((c) => c.id === expected.id)).toEqual(expected);
    expect(await (await getAsset('original'))!.blob.text()).toBe('original');
    expect(await (await getAsset('my-photo'))!.blob.text()).toBe('photograph');
    expect((await getSettings()).direction).toBe('rtl');
    expect((await getSettings()).motion).toBe('off');
    // A record restored from a user's backup later must not be auto-cleaned again.
    await db.put('comics', seeds[3]);
    await initialize();
    expect(await db.get('comics', seeds[3].id)).toEqual(seeds[3]);
  });
});
