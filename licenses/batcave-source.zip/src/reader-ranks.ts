import {stats,type Comic} from './models';
import type {Achievement,AchievementState,MedalTier} from './achievements';
export const readerRanks = [
 {tier:'bronze',name:'Бронза',pages:1000,stories:5,hours:8},
 {tier:'silver',name:'Серебро',pages:6000,stories:30,hours:50},
 {tier:'gold',name:'Золото',pages:30000,stories:150,hours:250},
 {tier:'platinum',name:'Платина',pages:100000,stories:500,hours:830},
] as const;
export function readerRankAwards(comics:Comic[],state?:AchievementState):Achievement[] {
 const s=stats(comics);
 const savedIndex=readerRanks.reduce((max,r,i)=>state?.earned.some(a=>a.id===`rank-${r.tier}`)?i:max,-1);
 return readerRanks.map((r,art)=>{
  const id=`rank-${r.tier}`,saved=state?.earned.find(a=>a.id===id);
  const ratio=Math.min(s.pages/r.pages,s.done/r.stories,s.seconds/(r.hours*3600));
  const earned=art<=savedIndex||ratio>=1;
  return {id,name:r.name,tier:r.tier,kind:'special',goal:1,value:earned?1:Math.max(0,ratio),earned,art,
   hint:`${r.pages.toLocaleString('ru-RU')} страниц · ${r.stories} комиксов · ${r.hours} ч`,earnedAt:saved?.at,legacy:saved?.legacy};
 });
}
export const rankArt=(tier:MedalTier)=>({bronze:new URL('./assets/ranks/bronze.webp',import.meta.url).href,silver:new URL('./assets/ranks/silver.webp',import.meta.url).href,gold:new URL('./assets/ranks/gold.webp',import.meta.url).href,platinum:new URL('./assets/ranks/platinum.webp',import.meta.url).href})[tier];
