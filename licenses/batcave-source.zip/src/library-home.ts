import { type Comic } from './models';
import { comicUniverse, STANDALONE_ID, type Universe } from './universes';

// Explicit opt-out for new standalone records. Missing IDs retain legacy Batman ownership.
export { STANDALONE_ID } from './universes';
export function standaloneComics(comics: Comic[]) {
  return comics.filter(c => c.universeId === STANDALONE_ID);
}
export function continueReading(comics: Comic[]) {
  return comics.filter(c => c.digital && !c.completed && c.lastOpened > 0)
    .sort((a,b) => b.lastOpened-a.lastOpened || b.updatedAt-a.updatedAt || a.id.localeCompare(b.id))[0];
}
export function readingPosition(c: Comic) {
  const total = Math.max(0, Math.floor(c.pageCount));
  const page = total ? Math.min(total, Math.max(1, Math.floor(c.page)+1)) : 0;
  return {page,total,percent:total ? Math.round(page/total*100) : 0};
}
export function seriesSummaries(universes: Universe[], comics: Comic[]) {
  const groups = new Map<string,Comic[]>();
  for (const c of comics) { const id=comicUniverse(c); const group=groups.get(id)??[]; group.push(c); groups.set(id,group); }
  return universes.filter(u=>u.id!==STANDALONE_ID).map(universe=> {
    const entries=groups.get(universe.id)??[];
    const done=entries.filter(c=>c.completed).length;
    return {universe,comics:entries,total:entries.length,done,percent:entries.length?Math.round(done/entries.length*100):0};
  });
}
export function searchComics(comics:Comic[],query:string) {
  const q=query.trim().toLocaleLowerCase('ru');
  return comics.filter(c=>`${c.title} ${c.series} ${c.authors}`.toLocaleLowerCase('ru').includes(q));
}
