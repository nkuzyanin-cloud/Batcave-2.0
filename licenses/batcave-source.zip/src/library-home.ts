import { type Comic, paperReadPages } from './models';
import { comicUniverse, STANDALONE_ID, type Universe } from './universes';

// Explicit opt-out for new standalone records. Missing IDs retain legacy Batman ownership.
export { STANDALONE_ID } from './universes';
export function standaloneComics(comics: Comic[]) {
  return comics.filter(c => c.universeId === STANDALONE_ID);
}
export function continueReading(comics: Comic[]) {
  return comics.filter(c => c.digital && !c.completed && c.lastOpened > 0)
    .sort((a,b) => b.lastOpened-a.lastOpened || b.updatedAt-a.updatedAt || a.id.localeCompare(b.id))[0];
}
export function readingPosition(c: Comic) {
  const total = Math.max(0, Math.floor(c.pageCount));
  const page = total ? Math.min(total, Math.max(1, Math.floor(c.page)+1)) : 0;
  return {page,total,percent:total ? Math.round(page/total*100) : 0};
}
export function comicReadFraction(c:Comic) {
  if(c.completed)return 1;
  const digital=c.pageCount>0?new Set(c.visited.filter(p=>Number.isInteger(p)&&p>=0&&p<c.pageCount)).size/c.pageCount:0;
  const paper=c.physical==='yes'&&c.paperPageCount?paperReadPages(c)/c.paperPageCount:0;
  return Math.max(0,Math.min(1,Math.max(digital,paper)));
}
export function routeProgress(comics:Comic[]) {
  return comics.length ? Math.round(comics.reduce((sum,c)=>sum+comicReadFraction(c),0)/comics.length*1000)/10 : 0;
}
export function seriesSummaries(universes: Universe[], comics: Comic[]) {
  const groups = new Map<string,Comic[]>();
  for (const c of comics) { const id=comicUniverse(c); const group=groups.get(id)??[]; group.push(c); groups.set(id,group); }
  return universes.filter(u=>u.id!==STANDALONE_ID).map(universe=> {
    const entries=groups.get(universe.id)??[];
    const done=entries.filter(c=>c.completed).length;
    return {universe,comics:entries,total:entries.length,done,percent:routeProgress(entries)};
  });
}
export function searchComics(comics:Comic[],query:string) {
  const q=query.trim().toLocaleLowerCase('ru');
  return comics.filter(c=>`${c.title} ${c.series} ${c.authors}`.toLocaleLowerCase('ru').includes(q));
}

// Shorten shared series metadata only. Keep each story's distinguishing title,
// and use the full original title in accessible names, editing and search.
export function seriesIssueTitle(comic:Comic,seriesTitle:string) {
  const title=comic.title.trim();
  for(const prefix of [seriesTitle,comic.series].filter(Boolean).sort((a,b)=>b.length-a.length)) {
    const name=prefix.trim();
    if(title.toLocaleLowerCase('ru').startsWith(name.toLocaleLowerCase('ru'))) {
      const rest=title.slice(name.length);
      if(/^[\s.·:—–-]/.test(rest)) {
        const short=rest.replace(/^[\s.·:—–-]+/,'');
        if(short)return short;
      }
    }
  }
  return title;
}
