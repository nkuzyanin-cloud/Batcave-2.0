import type { Comic } from './models';
export const ERAS = [
  {id:'early',title:'Ранние годы'},
  {id:'family',title:'Становление Бэтсемьи'},
  {id:'knightfall',title:'Падение рыцаря'},
  {id:'no-mans-land',title:'Ничья земля'},
  {id:'new-gotham',title:'Новый Готэм'},
  {id:'legacy',title:'Наследие Бэтмена'},
  {id:'new-52',title:'New 52'},
  {id:'rebirth',title:'Rebirth'},
  {id:'infinite-frontier',title:'Infinite Frontier'},
  {id:'dawn-of-dc',title:'Dawn of DC'},
  {id:'modern',title:'Современный Бэтмен'},
  {id:'standalone',title:'Самостоятельные истории'},
  {id:'alternative',title:'Альтернативная вселенная'},
] as const;
export type EraId = typeof ERAS[number]['id'];
export const CHRONOLOGICAL_ERAS = ERAS.filter(e => e.id !== 'standalone' && e.id !== 'alternative');
export type ChronologicalEraId = typeof CHRONOLOGICAL_ERAS[number]['id'];
export const isChronologicalEra = (id: string): id is ChronologicalEraId => CHRONOLOGICAL_ERAS.some(e => e.id === id);
export const ERA_IDS = ERAS.map(e=>e.id) as [EraId,...EraId[]];
export const DEFAULT_ERA: EraId = 'early';
export function comicEra(c:Comic, all:Comic[] = []):EraId {
  const anchor=c.sideStoryAfter ? all.find(a=>a.id===c.sideStoryAfter) : undefined;
  return (anchor ?? c).era ?? DEFAULT_ERA;
}
