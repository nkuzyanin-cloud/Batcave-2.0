import type {LucideIcon} from 'lucide-react';

// One optical weight and a clean 24-unit viewBox for the application chrome.
// Artwork stays vector at every iPhone pixel density; hit areas belong to buttons.
export function AppIcon({icon:Icon,size=24}:{icon:LucideIcon;size?:number}) {
  return <Icon className="app-icon" size={size} strokeWidth={1.8} aria-hidden="true" focusable="false"/>;
}
