import { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, CheckCircle2, LockKeyhole } from 'lucide-react';
import { CHRONOLOGICAL_ERAS, type ChronologicalEraId } from '../eras';
import { eraProgress } from '../era-progress';
import type { Comic } from '../models';
import { errorMessage } from '../models';
import type { Achievement, AchievementState } from '../achievements';
import { saveEraPlan } from '../storage/db';
import { AchievementBadge } from './AchievementBadge';
import { Modal } from './ui';

export function EraPathDialog({comics,state,medals,initialEra,onClose,onContinue}:{comics:Comic[];state?:AchievementState;medals:Achievement[];initialEra?:ChronologicalEraId;onClose:()=>void;onContinue:(era:ChronologicalEraId)=>void}) {
  const [selected,setSelected] = useState(initialEra);
  const [busy,setBusy] = useState(false), [error,setError] = useState('');
  const era = CHRONOLOGICAL_ERAS.find(e => e.id === selected);
  const p = era ? eraProgress(comics,state?.eraPlans,era.id) : undefined;
  const medal = era ? medals.find(a => a.era === era.id)! : undefined;
  async function save() {
    if (!era || busy) return;
    setBusy(true);setError('');
    try {await saveEraPlan(era.id);} catch(e) {setError(errorMessage(e));} finally {setBusy(false);}
  }
  const earned = medals.filter(a => a.kind === 'eras' && a.earned).length;
  return <Modal title="Путь Бэтмена" className="gotham-sheet achievement-sheet era-path-sheet" onClose={onClose}>
    {era && p && medal ? <div className="era-plan-detail" data-era-detail={era.id}>
      <button className="award-back" onClick={()=>{setSelected(undefined);setError('');}}><ArrowLeft size={16}/>Все эры</button>
      <div className="era-plan-heading"><AchievementBadge medal={medal}/><div><small>ЭРА {String(CHRONOLOGICAL_ERAS.indexOf(era)+1).padStart(2,'0')}</small><h3>{era.title}</h3><p>{p.total ? `${p.done} из ${p.total} основных историй` : 'Маршрут пока пуст'}</p></div></div>
      <div className="era-plan-meter" role="progressbar" aria-label={`Маршрут: ${era.title}`} aria-valuenow={p.done} aria-valuemin={0} aria-valuemax={p.total || 1}><i style={{width:`${p.percent}%`}}/></div>
      {medal.earned ? <p className="era-plan-earned"><CheckCircle2 size={17}/>Награда за эру получена</p> : <p className="era-plan-hint">{p.planned ? 'Маршрут закреплён. Награда откроется, когда будут прочитаны все истории из этого списка.' : 'Добавьте все основные истории эры и закрепите состав. После их прочтения награда откроется автоматически.'}</p>}
      <button className="era-plan-continue" onClick={()=>onContinue(era.id)}>{p.total ? 'Открыть маршрут' : 'Добавить истории'}<ArrowRight size={16}/></button>
      {(!p.planned || p.changed) && <button className="era-plan-save" disabled={busy || (!comics.some(c=>!c.sideStoryAfter && c.era===era.id) && !p.total)} onClick={()=>void save()}>{busy ? 'Сохраняем…' : p.planned ? 'Обновить состав маршрута' : 'Закрепить маршрут эры'}</button>}
      {p.changed && <p className="era-plan-hint">В библиотеке изменился состав эры. Закреплённый список сохранён; обновите его, если хотите изменить условия награды.</p>}
      {error && <p role="alert" className="era-plan-error">{error}</p>}
      <h4>Основные истории</h4>
      {p.entries.length ? <ol className="era-plan-books">{p.entries.map((e,i)=><li key={e.id} className={e.done?'done':''}><span>{e.done ? <Check size={14}/> : String(i+1).padStart(2,'0')}</span><div>{e.title}{!comics.some(c=>c.id===e.id) && !e.done && <small>Карточка удалена · история ещё не завершена</small>}</div></li>)}</ol> : <p className="era-plan-hint">В этой эре ещё нет основных историй. Можно добавить бумажные и цифровые комиксы.</p>}
      <p className="era-plan-footnote">Дополнительные истории вне основного маршрута необязательны. Полученная награда сохраняется при изменении библиотеки.</p>
    </div> : <>
      <p className="award-collection-count">Пройдено эр: {earned} из {CHRONOLOGICAL_ERAS.length}</p>
      <div className="era-path-list">{CHRONOLOGICAL_ERAS.map((e,i)=>{
        const progress=eraProgress(comics,state?.eraPlans,e.id), a=medals.find(m=>m.era===e.id)!;
        return <button key={e.id} onClick={()=>setSelected(e.id)} data-era={e.id}>
          <span className="era-path-index">{String(i+1).padStart(2,'0')}</span><AchievementBadge medal={a}/><span className="era-path-label"><strong>{e.title}</strong><small>{a.earned ? 'Эра пройдена' : progress.total ? `${progress.done} / ${progress.total} историй${progress.planned ? '' : ' · состав не закреплён'}` : 'Маршрут ещё не собран'}</small></span>{a.earned ? <CheckCircle2 size={17}/> : <ArrowRight size={16}/>}
        </button>;
      })}</div>
      <p className="era-plan-footnote"><LockKeyhole size={13}/>Награда выдаётся за весь закреплённый маршрут. Самостоятельные истории и альтернативные вселенные остаются свободными подборками.</p>
    </>}
  </Modal>;
}
