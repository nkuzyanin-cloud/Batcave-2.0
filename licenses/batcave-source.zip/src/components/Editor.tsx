import { useEffect, useRef, useState } from 'react';
import { ImagePlus, Trash2, BookOpen, Upload, Star } from 'lucide-react';
import { type Comic, type Asset, percent, errorMessage, paperFinished, PAPER_PAGE_LIMIT } from '../models';
import { saveComic, deleteComic, deleteDigital, paperSession, completePaperSession } from '../storage/db';
import { ERAS, DEFAULT_ERA, type EraId } from '../eras';
import { imageToCanvas, detectFormat } from '../reader/source';
import { Modal, Cover, Progress } from './ui';
export function Editor({
  comic,
  onClose,
  onSaved,
  onRead,
  onAttach,
  draft = false,
}: {
  comic: Comic;
  onClose: () => void;
  onSaved: () => Promise<void>;
  onRead: (c: Comic) => void;
  onAttach: (c: Comic) => void;
  draft?: boolean;
}) {
  const [c, set] = useState({ ...comic });
  const [assets, setAssets] = useState<Asset[]>([]);
  const [busy, setBusy] = useState(false);
  const processing = useRef(false);
  const [error, setError] = useState('');
  const [confirm, setConfirm] = useState<'file' | 'record' | null>(null);
  const digitalDone = c.completed && (!!c.readDigitally || (c.pageCount > 0 && c.visited.length === c.pageCount) || (!paperFinished(c) && !!c.digital));
  async function timer(start: boolean) {
    if (busy || processing.current || draft) return;
    processing.current = true; setBusy(true); setError('');
    try {
      const saved = await paperSession(c.id, start);
      set(old => ({ ...old, paperTimer: saved.paperTimer, paperSeconds: saved.paperSeconds, paperStartedAt: saved.paperStartedAt }));
      await onSaved();
    } catch (e) { setError(errorMessage(e)); }
    finally { processing.current = false; setBusy(false); }
  }
  async function paperComplete(done: boolean) {
    if (busy || processing.current) return;
    if (draft) {
      set(old => ({ ...old, paperCompleted: done, paperPagesRead: done ? old.paperPageCount ?? 0 : 0, completed: done || digitalDone }));
      return;
    }
    processing.current = true; setBusy(true); setError('');
    set(old => ({ ...old, paperCompleted: done, paperPagesRead: done ? old.paperPageCount ?? 0 : 0, completed: done || digitalDone }));
    try {
      const saved = await completePaperSession(c.id, done, c.paperPageCount);
      set(old => ({ ...old, paperCompleted: saved.paperCompleted, paperPagesRead: saved.paperPagesRead, completed: saved.completed, readDigitally: saved.readDigitally, paperTimer: saved.paperTimer, paperSeconds: saved.paperSeconds, paperStartedAt: saved.paperStartedAt }));
      await onSaved();
    } catch (e) {
      set(old => ({ ...old, paperCompleted: c.paperCompleted, paperPagesRead: c.paperPagesRead, completed: c.completed }));
      setError(errorMessage(e));
    }
    finally { processing.current = false; setBusy(false); }
  }
  const change = <K extends keyof Comic>(key: K, value: Comic[K]) =>
    set((c) => ({ ...c, [key]: value }));
  async function image(file: File | undefined) {
    if (!file || processing.current) return;
    processing.current = true;
    setBusy(true);
    setError('');
    const canvas = document.createElement('canvas');
    try {
      if ((await detectFormat(file, file.name)) !== 'image')
        throw Error('Выберите изображение JPG, PNG или WebP.');
      await imageToCanvas(file, canvas, 1000);
      const blob = await new Promise<Blob>((r, j) =>
        canvas.toBlob(
          (b) => (b ? r(b) : j(Error('Не удалось обработать изображение.'))),
          'image/jpeg',
          0.88,
        ),
      );
      const asset = { id: crypto.randomUUID(), blob };
      const previous = c.coverId;
      setAssets((old) => [...old.filter(a => a.id !== previous), asset]);
      change('coverId', asset.id);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      canvas.width = canvas.height = 0;
      processing.current = false;
      setBusy(false);
    }
  }
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (processing.current || busy) return;
    if (!c.title.trim()) { setError('Укажите название комикса.'); return; }
    setBusy(true);
    setError('');
    try {
      await saveComic(
        { ...c, title: c.title.trim(), ...(c.physical === 'yes' ? { paperSeconds: c.paperSeconds ?? 0 } : {}) },
        assets.filter(a => a.id === c.coverId || a.id === c.photoId),
        [...new Set([comic.coverId, comic.photoId])].filter((id): id is string => !!id && id !== c.coverId && id !== c.photoId && id !== c.digital?.assetId),
        true,
      );
      await onSaved();
      onClose();
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  }
  async function remove() {
    setBusy(true);
    setError('');
    try {
      if (confirm === 'file') await deleteDigital(comic);
      else await deleteComic(comic);
      await onSaved();
      onClose();
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  }
  return (
    <Modal title="Карточка комикса" onClose={onClose}>
      {!draft && (
        <div className="detail-top">
          {assets.find(a => a.id === c.coverId) ? <div className="cover"><LocalPhoto blob={assets.find(a => a.id === c.coverId)!.blob} alt="Обложка книги" /></div> : <Cover comic={c} paper={c.physical === 'yes'} />}
          <div>
            <h2>{c.title}</h2>
            <p>
              {c.year}
              {c.yearEnd ? `–${c.yearEnd}` : ''} · {c.series}
            </p>
            {c.digital && <Progress value={percent(c)} />}
            <p>
              {c.digital
                ? `${c.page + 1} / ${c.pageCount} стр. · ${percent(c)}%`
                : 'Нет цифровой копии'}
            </p>
          </div>
        </div>
      )}
      {!draft && (
        <div className="detail-actions">
          {comic.digital ? (
            <button className="primary" onClick={() => onRead(comic)}>
              <BookOpen size={18} />
              Читать
            </button>
          ) : (
            <button className="primary" onClick={() => onAttach(comic)}>
              <Upload size={18} />
              Добавить файл
            </button>
          )}
        </div>
      )}
      <form onSubmit={submit} className="form editor-form">
        <div className="cover-upload">
          <label className={`secondary file-button ${busy ? 'disabled' : ''}`}>
            <ImagePlus size={17} />{c.coverId ? 'Заменить обложку' : 'Загрузить обложку'}
            <input aria-label="Обложка из изображения" type="file" disabled={busy} accept="image/jpeg,image/png,image/webp" onChange={e => { void image(e.target.files?.[0]); e.target.value = ''; }} />
          </label>
          {c.coverId && <button className="icon-button" type="button" disabled={busy} aria-label="Убрать обложку" onClick={() => change('coverId', undefined)}><Trash2 size={16} /></button>}
          {draft && c.coverId && <div className="cover-upload-preview">{assets.find(a => a.id === c.coverId) ? <LocalPhoto blob={assets.find(a => a.id === c.coverId)!.blob} alt="Обложка книги" /> : <Cover comic={c} />}</div>}
        </div>
        <label>
          Название
          <input
            required
            maxLength={300}
            value={c.title}
            onChange={(e) => change('title', e.target.value)}
          />
        </label>
        <label>
          Серия
          <input
            maxLength={300}
            value={c.series}
            onChange={(e) => change('series', e.target.value)}
          />
        </label>
        <label>
          Авторы
          <input
            maxLength={1000}
            value={c.authors}
            onChange={(e) => change('authors', e.target.value)}
          />
        </label>
        <div className="form-row">
          <label>
            Год произведения
            <input
              type="number"
              min="1800"
              max="2200"
              value={c.year ?? ''}
              onChange={(e) => change('year', e.target.value ? Number(e.target.value) : null)}
            />
          </label>
          <label>
            Бумажная книга
            <select
              value={c.physical}
              onChange={(e) => change('physical', e.target.value as Comic['physical'])}
            >
              <option value="unknown">Не проверено</option>
              <option value="yes">Есть в бумаге</option>
              <option value="no">Нет в бумаге</option>
            </select>
          </label>
        </div>
        {c.physical !== 'yes' && <label className="switch-label">
          <span>Прочитан</span>
          <input
            type="checkbox"
            checked={c.completed}
            onChange={(e) => {
              const done = e.target.checked;
              set(old => ({ ...old, completed: done, ...(!done ? { paperCompleted: false, paperPagesRead: 0 } : {}), ...(old.physical === 'yes' && !old.digital && !old.readDigitally && !old.lastOpened && !old.visited.length ? { paperCompleted: done, paperPagesRead: done ? old.paperPageCount ?? 0 : 0 } : {}) }));
            }}
          />
        </label>}
        {c.completed && c.physical === 'yes' && !c.digital && !c.visited.length && !c.lastOpened && (
          <label className="switch-label">
            <span>Также прочитан в цифре</span>
            <input type="checkbox" checked={!!c.readDigitally} onChange={e => change('readDigitally', e.target.checked)} />
          </label>
        )}
        {c.physical === 'yes' && <fieldset className="paper-progress-fields">
          <legend>Чтение бумажного издания</legend>
          <div className="form-row">
            <label>Количество страниц
              <input type="number" inputMode="numeric" min="1" max={PAPER_PAGE_LIMIT} step="1"
                placeholder="Не указано" value={c.paperPageCount ?? ''}
                onChange={e => {
                  const total = e.target.value ? Number(e.target.value) : 0;
                  set(old => ({ ...old, paperPageCount: total || undefined,
                    paperPagesRead: paperFinished(old) ? total : Math.min(old.paperPagesRead ?? 0, total) }));
                }} />
            </label>
            <div className="paper-timer-controls" role="group" aria-label="Чтение бумажной книги">
              <span>Чтение</span>
              <div className="paper-timer-buttons">
                <button type="button" className="paper-start" disabled={draft || busy || paperFinished(c) || c.paperStartedAt !== undefined} onClick={() => void timer(true)}>Старт</button>
                <button type="button" className="paper-stop" disabled={draft || busy || paperFinished(c) || c.paperStartedAt === undefined} onClick={() => void timer(false)}>Стоп</button>
              </div>
            </div>
          </div>
          <label className="switch-label">
            <span>Бумажное издание прочитано</span>
            <input type="checkbox" disabled={busy} checked={paperFinished(c)} onChange={e => void paperComplete(e.target.checked)} />
          </label>
          <small>{draft ? 'Сохраните книгу, чтобы начать чтение.' : 'Время учитывается по сеансам, страницы — после завершения книги.'}</small>
        </fieldset>}
        <label>
          Личная оценка
          <div className="rating" role="group" aria-label="Оценка">
            <button
              type="button"
              className={c.rating === 0 ? 'selected' : ''}
              onClick={() => change('rating', 0)}
            >
              Без
            </button>
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                type="button"
                key={n}
                aria-label={`Оценка ${n}`}
                aria-pressed={c.rating === n}
                className={c.rating >= n ? 'selected' : ''}
                onClick={() => change('rating', n)}
              >
                <Star size={20} />
              </button>
            ))}
          </div>
        </label>
        <details className="additional-fields">
          <summary>Дополнительно</summary>
          <div className="form">
            <label>Эра
              <select aria-label="Эра комикса" value={c.era ?? DEFAULT_ERA} disabled={!!c.sideStoryAfter} onChange={e=>change('era',e.target.value as EraId)}>
                {ERAS.map(era=><option key={era.id} value={era.id}>{era.title}</option>)}
              </select>
              {c.sideStoryAfter && <small>Эра совпадает с основным комиксом.</small>}
            </label>
            {c.physical === 'yes' && !c.digital && <label className="switch-label">
              <span>В маршруте чтения</span><input type="checkbox" checked={!!c.inRoadmap} onChange={e=>change('inRoadmap',e.target.checked)}/>
            </label>}
            <label>
              Издание
              <input
                maxLength={500}
                value={c.edition}
                onChange={(e) => change('edition', e.target.value)}
                placeholder="Например, объединённое издание"
              />
            </label>
            <label>
              Общий экземпляр
              <input
                maxLength={300}
                value={c.physicalGroup || ''}
                onChange={(e) => change('physicalGroup', e.target.value.trim() || undefined)}
                placeholder="Название объединённого издания"
              />
              <small>Одинаковое название объединяет тома в один бумажный экземпляр.</small>
            </label>
            <div className="form-row">
              <label>
                Издательство
                <input
                  maxLength={300}
                  value={c.publisher}
                  onChange={(e) => change('publisher', e.target.value)}
                />
              </label>
              <label>
                Год издания
                <input
                  type="number"
                  min="1800"
                  max="2200"
                  value={c.editionYear ?? ''}
                  onChange={(e) =>
                    change('editionYear', e.target.value ? Number(e.target.value) : null)
                  }
                />
              </label>
            </div>
            <label>
              Заметка
              <textarea
                maxLength={10000}
                value={c.note}
                onChange={(e) => change('note', e.target.value)}
                rows={3}
                placeholder="Что запомнилось, особенности издания…"
              />
            </label>
            {c.photoId && (
              <div className="photo-preview">
                {assets.find(a => a.id === c.photoId) ? <LocalPhoto blob={assets.find(a => a.id === c.photoId)!.blob} /> : <Cover comic={c} photo />}
                <button
                  type="button"
                  onClick={() => {
                    change('photoId', undefined);
                  }}
                >
                  Удалить фото
                </button>
              </div>
            )}
          </div>
        </details>
        {error && (
          <p className="error" role="alert">
            {error}
          </p>
        )}
        <button className="primary editor-save" type="submit" disabled={busy}>
          {busy ? 'Сохранение…' : 'Сохранить изменения'}
        </button>
        {!draft && (
          <div className="danger-actions">
            {comic.digital && (
              <button type="button" onClick={() => setConfirm('file')}>
                <Trash2 size={16} />
                Удалить цифровой файл
              </button>
            )}
            <button type="button" onClick={() => setConfirm('record')}>
              <Trash2 size={16} />
              Удалить запись из архива
            </button>
          </div>
        )}
        {confirm && (
          <div className="confirm-box">
            <p>
              {confirm === 'file'
                ? 'Удалить оригинальный файл? Карточка, обложка и прогресс останутся.'
                : 'Удалить комикс, файл, фотографию и прогресс? Это действие нельзя отменить.'}
            </p>
            <div>
              <button type="button" onClick={() => setConfirm(null)}>
                Отмена
              </button>
              <button
                type="button"
                className="danger"
                disabled={busy}
                onClick={() => void remove()}
              >
                Удалить
              </button>
            </div>
          </div>
        )}
      </form>
    </Modal>
  );
}
function LocalPhoto({ blob, alt = 'Фотография книги' }: { blob: Blob; alt?: string }) {
  const [url, set] = useState('');
  useEffect(() => {
    const u = URL.createObjectURL(blob);
    set(u);
    return () => URL.revokeObjectURL(u);
  }, [blob]);
  return <img src={url} alt={alt} />;
}
