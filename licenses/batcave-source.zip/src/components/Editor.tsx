import { useEffect, useRef, useState } from 'react';
import { ImagePlus, Trash2, BookOpen, Upload, Star, Ellipsis, Monitor, Check } from 'lucide-react';
import { type Comic, type Asset, percent, errorMessage, paperFinished, PAPER_PAGE_LIMIT } from '../models';
import { saveComic, deleteComic, deleteDigital, paperSession, completePaperSession } from '../storage/db';
import { ERAS, DEFAULT_ERA, comicEra, type EraId } from '../eras';
import { imageToCanvas, detectFormat } from '../reader/source';
import { Modal, Cover, Progress } from './ui';
import {STANDALONE_ID} from '../universes';
export function Editor({
  comic,
  onClose,
  onSaved,
  onRead,
  onAttach,
  draft = false,
  universes=[],
  relatedComics=[],
}: {
  comic: Comic;
  onClose: () => void;
  onSaved: () => Promise<void>;
  onRead: (c: Comic) => void;
  onAttach: (c: Comic) => void;
  draft?: boolean;
  universes?: import('../universes').Universe[];
  relatedComics?:Comic[];
}) {
  const [c, set] = useState({ ...comic,...(comic.sideStoryAfter?{era:comicEra(comic,relatedComics)}:{}) });
  const universe=universes.find(u=>u.id===(c.universeId||'batman'));
  const chapters=c.universeId===STANDALONE_ID?[{id:'main',title:'Без раздела'}]:universe?.chapters??ERAS;
  const [assets, setAssets] = useState<Asset[]>([]);
  const [busy, setBusy] = useState(false);
  const processing = useRef(false);
  const [error, setError] = useState('');
  const [menu, setMenu] = useState(false);
  const [confirm, setConfirm] = useState<'file' | 'record' | null>(null);
  const digitalDone = c.completed && (!!c.readDigitally || (c.pageCount > 0 && c.visited.length === c.pageCount) || (!paperFinished(c) && !!c.digital));
  async function timer(start: boolean) {
    if (busy || processing.current || draft) return;
    processing.current = true; setBusy(true); setError('');
    try {
      const saved = await paperSession(c.id, start);
      set(old => ({ ...old, paperTimer: saved.paperTimer, paperSeconds: saved.paperSeconds, paperStartedAt: saved.paperStartedAt }));
      await onSaved();
    } catch (e) { setError(errorMessage(e)); }
    finally { processing.current = false; setBusy(false); }
  }
  async function paperComplete(done: boolean) {
    if (busy || processing.current) return;
    if (draft) {
      set(old => ({ ...old, paperCompleted: done, paperPagesRead: done ? old.paperPageCount ?? 0 : 0, completed: done || digitalDone }));
      return;
    }
    processing.current = true; setBusy(true); setError('');
    set(old => ({ ...old, paperCompleted: done, paperPagesRead: done ? old.paperPageCount ?? 0 : 0, completed: done || digitalDone }));
    try {
      const saved = await completePaperSession(c.id, done, c.paperPageCount);
      set(old => ({ ...old, paperCompleted: saved.paperCompleted, paperPagesRead: saved.paperPagesRead, completed: saved.completed, readDigitally: saved.readDigitally, paperTimer: saved.paperTimer, paperSeconds: saved.paperSeconds, paperStartedAt: saved.paperStartedAt }));
      await onSaved();
    } catch (e) {
      set(old => ({ ...old, paperCompleted: c.paperCompleted, paperPagesRead: c.paperPagesRead, completed: c.completed }));
      setError(errorMessage(e));
    }
    finally { processing.current = false; setBusy(false); }
  }
  const change = <K extends keyof Comic>(key: K, value: Comic[K]) =>
    set((c) => ({ ...c, [key]: value }));
  async function image(file: File | undefined) {
    if (!file || processing.current) return;
    processing.current = true;
    setBusy(true);
    setError('');
    const canvas = document.createElement('canvas');
    try {
      if ((await detectFormat(file, file.name)) !== 'image')
        throw Error('Выберите изображение JPG, PNG или WebP.');
      await imageToCanvas(file, canvas, 1000);
      const blob = await new Promise<Blob>((r, j) =>
        canvas.toBlob(
          (b) => (b ? r(b) : j(Error('Не удалось обработать изображение.'))),
          'image/jpeg',
          0.88,
        ),
      );
      const asset = { id: crypto.randomUUID(), blob };
      const previous = c.coverId;
      setAssets((old) => [...old.filter(a => a.id !== previous), asset]);
      change('coverId', asset.id);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      canvas.width = canvas.height = 0;
      processing.current = false;
      setBusy(false);
    }
  }
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (processing.current || busy) return;
    if (!c.title.trim()) { setError('Укажите название комикса.'); return; }
    setBusy(true);
    setError('');
    try {
      await saveComic(
        { ...c, title: c.title.trim() },
        assets.filter(a => a.id === c.coverId || a.id === c.photoId),
        [...new Set([comic.coverId, comic.photoId])].filter((id): id is string => !!id && id !== c.coverId && id !== c.photoId && id !== c.digital?.assetId),
        true,
        draft ? undefined : comic,
      );
      await onSaved();
      onClose();
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  }
  async function remove() {
    setBusy(true);
    setError('');
    try {
      if (confirm === 'file') await deleteDigital(comic);
      else await deleteComic(comic);
      await onSaved();
      onClose();
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  }
  return (
    <Modal title={draft ? 'Добавить комикс' : 'Редактирование'} className="comic-editor" onClose={onClose} actions={
      <div className="editor-menu">
        <button className="icon-button" type="button" aria-label="Действия с комиксом" aria-expanded={menu} aria-haspopup="menu" onClick={() => setMenu(v => !v)}><Ellipsis size={21}/></button>
        {menu && <div className="editor-menu-items" role="menu">
          {!draft && <button role="menuitem" type="button" disabled={busy} onClick={() => { setMenu(false); onAttach(comic); }}><Upload size={16}/>{c.digital ? 'Заменить файл' : 'Добавить файл'}</button>}
          {c.coverId && <button role="menuitem" type="button" disabled={busy} onClick={() => { change('coverId', undefined); setMenu(false); }}><ImagePlus size={16}/>Убрать обложку</button>}
          {!draft && c.digital && <button role="menuitem" type="button" disabled={busy} onClick={() => {setMenu(false);setConfirm('file');}}><Trash2 size={16}/>Удалить цифровой файл</button>}
          {!draft && <button role="menuitem" type="button" disabled={busy} onClick={() => {setMenu(false);setConfirm('record');}}><Trash2 size={16}/>Удалить запись из архива</button>}
        </div>}
      </div>
    }>
        {confirm && (
          <div className="confirm-box">
            <p>
              {confirm === 'file'
                ? 'Удалить оригинальный файл? Карточка, обложка и прогресс останутся.'
                : 'Удалить комикс, файл, фотографию и прогресс? Это действие нельзя отменить.'}
            </p>
            <div>
              <button type="button" onClick={() => setConfirm(null)}>
                Отмена
              </button>
              <button
                type="button"
                className="danger"
                disabled={busy}
                onClick={() => void remove()}
              >
                Удалить
              </button>
            </div>
          </div>
        )}
      <div className="editor-overview">
        <div className="editor-cover">
          {assets.find(a => a.id === c.coverId) ? <div className="cover"><LocalPhoto blob={assets.find(a => a.id === c.coverId)!.blob} alt="Обложка книги" /></div> : <Cover comic={c} paper={c.physical === 'yes'} />}
          <label className={`editor-cover-change icon-button ${busy ? 'disabled' : ''}`} title="Заменить обложку">
            <ImagePlus size={18}/><input aria-label="Обложка из изображения" type="file" disabled={busy} accept="image/jpeg,image/png,image/webp" onChange={e => { void image(e.target.files?.[0]); e.target.value = ''; }}/>
          </label>
        </div>
        <div className="editor-overview-info">
          <h3>{c.title.trim() || 'Новый комикс'}</h3>
          {c.digital && <><Progress value={percent(c)}/><p>{c.page + 1} / {c.pageCount} страниц</p></>}
          {!draft && <button type="button" className="primary" disabled={busy} onClick={() => c.digital ? onRead(comic) : onAttach(comic)}>{c.digital ? <BookOpen size={17}/> : <Upload size={17}/>}{c.digital ? 'Читать' : 'Добавить файл'}</button>}
        </div>
      </div>
      <form onSubmit={submit} className="form editor-form">
        <label>
          Название
          <input
            required
            maxLength={300}
            value={c.title}
            onChange={(e) => change('title', e.target.value)}
          />
        </label>
        <label>
          Серия
          <input
            maxLength={300}
            value={c.series}
            onChange={(e) => change('series', e.target.value)}
          />
        </label>
        <label>
          Авторы
          <input
            maxLength={1000}
            value={c.authors}
            onChange={(e) => change('authors', e.target.value)}
          />
        </label>
        {universes.length>0 && <label>В библиотеке<select aria-label="Серия комикса" value={c.universeId||'batman'} disabled={!draft&&comic.universeId!==STANDALONE_ID} onChange={e=>{const u=universes.find(u=>u.id===e.target.value);set({...c,universeId:u?.id??STANDALONE_ID,era:u?.chapters[0].id??'main',inRoadmap:!!u,sideStoryAfter:undefined});}}><option value={STANDALONE_ID}>Без серии</option>{universes.filter(u=>u.id!==STANDALONE_ID).map(u=><option key={u.id} value={u.id}>{u.title}</option>)}</select></label>}
        <div className="form-row">
          <label>
            Год произведения
            <input
              type="number"
              min="1800"
              max="2200"
              value={c.year ?? ''}
              onChange={(e) => change('year', e.target.value ? Number(e.target.value) : null)}
            />
          </label>
          <label>Раздел
            <select aria-label="Эра комикса" value={c.era ?? DEFAULT_ERA} onChange={e=>set({...c,era:e.target.value as EraId,sideStoryAfter:undefined})}>
              {chapters.map(era=><option key={era.id} value={era.id}>{era.title}</option>)}
            </select>
          </label>
        </div>
        <fieldset className="editor-format"><legend>Формат</legend>
          <div className="form-row">
            <span className={`format-choice ${c.digital ? 'selected' : ''}`}><Monitor size={18}/>Цифровой{c.digital && <Check size={15}/>}</span>
            <button type="button" className={`format-choice ${c.physical === 'yes' ? 'selected' : ''}`} aria-label="Бумажная версия" aria-pressed={c.physical === 'yes'} onClick={() => change('physical',c.physical === 'yes' ? 'no' : 'yes')}><BookOpen size={18}/>Бумажный{c.physical === 'yes' && <Check size={15}/>}</button>
          </div>
        </fieldset>
        {c.physical === 'yes' && !c.digital && <label className="switch-label"><span>В маршруте чтения</span><input type="checkbox" checked={!!c.inRoadmap||!!c.sideStoryAfter} onChange={e=>set({...c,inRoadmap:e.target.checked,sideStoryAfter:undefined})}/></label>}
        {c.physical !== 'yes' && <label className="switch-label">
          <span>Прочитан</span>
          <input
            type="checkbox"
            checked={c.completed}
            onChange={(e) => {
              const done = e.target.checked;
              set(old => ({ ...old, completed: done, ...(!done ? { paperCompleted: false, paperPagesRead: 0 } : {}), ...(old.physical === 'yes' && !old.digital && !old.readDigitally && !old.lastOpened && !old.visited.length ? { paperCompleted: done, paperPagesRead: done ? old.paperPageCount ?? 0 : 0 } : {}) }));
            }}
          />
        </label>}
        {c.completed && c.physical === 'yes' && !c.digital && !c.visited.length && !c.lastOpened && (
          <label className="switch-label">
            <span>Также прочитан в цифре</span>
            <input type="checkbox" checked={!!c.readDigitally} onChange={e => change('readDigitally', e.target.checked)} />
          </label>
        )}
        {c.physical === 'yes' && <fieldset className="paper-progress-fields">
          <legend>Чтение бумажного издания</legend>
          <div className="form-row">
            <label>Количество страниц
              <input type="number" inputMode="numeric" min="1" max={PAPER_PAGE_LIMIT} step="1"
                placeholder="Не указано" value={c.paperPageCount ?? ''}
                onChange={e => {
                  const total = e.target.value ? Number(e.target.value) : 0;
                  set(old => ({ ...old, paperPageCount: total || undefined,
                    paperPagesRead: paperFinished(old) ? total : Math.min(old.paperPagesRead ?? 0, total) }));
                }} />
            </label>
            <div className="paper-timer-controls" role="group" aria-label="Чтение бумажной книги">
              <span>Чтение</span>
              <div className="paper-timer-buttons">
                <button type="button" className="paper-start" disabled={draft || busy || paperFinished(c) || c.paperStartedAt !== undefined} onClick={() => void timer(true)}>Старт</button>
                <button type="button" className="paper-stop" disabled={draft || busy || paperFinished(c) || c.paperStartedAt === undefined} onClick={() => void timer(false)}>Стоп</button>
              </div>
            </div>
          </div>
          <label className="switch-label">
            <span>Бумажное издание прочитано</span>
            <input type="checkbox" disabled={busy} checked={paperFinished(c)} onChange={e => void paperComplete(e.target.checked)} />
          </label>
          <small>{draft ? 'Сохраните книгу, чтобы начать чтение.' : 'Время учитывается по сеансам, страницы — после завершения книги.'}</small>
        </fieldset>}
        <label>
          Личная оценка
          <div className="rating" role="group" aria-label="Оценка">
            <button
              type="button"
              className={c.rating === 0 ? 'selected' : ''}
              onClick={() => change('rating', 0)}
            >
              Без
            </button>
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                type="button"
                key={n}
                aria-label={`Оценка ${n}`}
                aria-pressed={c.rating === n}
                className={c.rating >= n ? 'selected' : ''}
                onClick={() => change('rating', n)}
              >
                <Star size={20} />
              </button>
            ))}
          </div>
        </label>
        {error && <p className="error" role="alert">{error}</p>}
        <button className="primary editor-save" type="submit" disabled={busy}>{busy ? 'Сохранение…' : draft ? 'Добавить комикс' : 'Сохранить'}</button>

      </form>
    </Modal>
  );
}
function LocalPhoto({ blob, alt = 'Фотография книги' }: { blob: Blob; alt?: string }) {
  const [url, set] = useState('');
  useEffect(() => {
    const u = URL.createObjectURL(blob);
    set(u);
    return () => URL.revokeObjectURL(u);
  }, [blob]);
  return <img src={url} alt={alt} />;
}
