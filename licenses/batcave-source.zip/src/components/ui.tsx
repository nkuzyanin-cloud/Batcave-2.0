import { useEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { X, BookOpen, Check, Ellipsis, Library, Monitor } from 'lucide-react';
import { getAsset } from '../storage/db';
import { type Comic, percent, status } from '../models';
import { isDigitalStory } from '../collection';
import { isEditingField, lockModalDocument, revealFormField } from './modal-form';
export function Bat({ className = '' }: { className?: string }) {
  return (
    <svg className={`bat ${className}`} viewBox="0 0 200 74" fill="currentColor" aria-hidden="true">
      <path d="M2 3H67C69 15 73 17 84 18C89 19 92 19 93 17L94 6L96 13Q100 12 104 13L106 6L107 17C108 19 111 19 116 18C127 17 131 15 133 3H198C174 13 165 26 169 41C134 39 111 43 100 71C89 43 66 39 31 41C35 26 26 13 2 3Z" />
    </svg>
  );
}
export function CollectionIcon({size=20}:{size?:number}) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <rect x="3" y="5" width="4" height="15" rx=".7"/><rect x="10" y="7" width="4" height="13" rx=".7"/><rect x="17" y="3" width="4" height="17" rx=".7"/>
    <path d="M3 9h4M10 11h4M17 7h4"/>
  </svg>;
}
export function useBlobUrl(id?: string) {
  const [url, set] = useState<string>();
  useEffect(() => {
    let active = true;
    let objectUrl: string | undefined;
    set(undefined);
    if (id)
      void getAsset(id).then((a) => {
        if (a && active) {
          objectUrl = URL.createObjectURL(a.blob);
          set(objectUrl);
        }
      }).catch(() => {});
    return () => {
      active = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [id]);
  return url;
}
export function Cover({ comic, photo = false, paper = false }: { comic: Comic; photo?: boolean; paper?: boolean }) {
  const url = useBlobUrl(photo ? comic.photoId : paper ? comic.coverId || comic.photoId : comic.coverId);
  return (
    <div
      className="cover"
      style={
        {
          '--cover-color': comic.tone,
          '--cover-title-divisor': Math.max(
            5.5,
            Math.max(
              ...comic.title
                .replace(/^Бэтмен\. /, '')
                .split(/\s+/)
                .map((word) => word.length),
            ) * 0.85,
          ),
        } as React.CSSProperties
      }
    >
      {url ? (
        <img src={url} alt={`Обложка: ${comic.title}`} loading="lazy" />
      ) : (
        <div className="cover-art">
          <span className="cover-bat">
            <Bat />
          </span>
          <span className="cover-name">{comic.title.replace(/^Бэтмен\. /, '')}</span>
          {comic.year && <span className="cover-year">{comic.year}</span>}
          <div className="cover-lines" />
        </div>
      )}
    </div>
  );
}
export function Progress({ value }: { value: number }) {
  return (
    <div
      className="progress"
      role="progressbar"
      aria-label="Прогресс чтения"
      aria-valuenow={value}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <i style={{ width: `${value}%` }} />
    </div>
  );
}
export function Card({
  comic,
  onClick,
  onEdit,
  paper = false,
  collection = false,
  showFormats = true,
}: {
  comic: Comic;
  onClick: (rect: DOMRect) => void;
  onEdit: () => void;
  paper?: boolean;
  collection?: boolean;
  showFormats?: boolean;
}) {
  if(collection) {
    const state=status(comic),label=state==='done' ? 'Прочитано' : state==='reading' ? 'В процессе' : 'Не начато';
    const open=(el:HTMLElement)=>onClick(el.closest('article')!.querySelector('.cover')!.getBoundingClientRect());
    const year=comic.year ? `${comic.year}${comic.yearEnd && comic.yearEnd!==comic.year ? `–${comic.yearEnd}` : ''}` : '';
    return <article className="comic-card collection-card" data-status={state}>
      <button className="collection-cover" onClick={e=>open(e.currentTarget)} aria-label={`${comic.digital ? 'Читать' : 'Открыть'}: ${comic.title}`}><Cover comic={comic} paper={paper}/></button>
      <div className="collection-title"><button onClick={e=>open(e.currentTarget)}><h3>{comic.title}</h3></button><button className="icon-button" aria-label={`Сведения: ${comic.title}`} onClick={onEdit}><Ellipsis size={18}/></button></div>
      <span className={`collection-status status-${state}`}>{state==='done' && <Check size={12}/>}<span>{label}</span></span>
      <div className="collection-meta">
        {year && <span className="collection-year">{year}</span>}
        {comic.physical==='yes' && <span><CollectionIcon size={12}/>Бумажный</span>}
        {isDigitalStory(comic) && <span><Monitor size={12}/>Цифровой</span>}
      </div>
    </article>;
  }
  return (
    <article className={`comic-card ${paper ? 'paper-card' : ''}`}>
      <button className="card-open" onClick={(e) => onClick(e.currentTarget.querySelector('.cover')!.getBoundingClientRect())} aria-label={`${!collection && comic.digital ? 'Читать' : 'Открыть'}: ${comic.title}`}>
        <div className="card-image"><Cover comic={comic} paper={paper} /></div>
        <h3>{comic.title}</h3>
      </button>
      <button className="card-menu" aria-label={`Сведения: ${comic.title}`} onClick={onEdit}><Ellipsis size={19} /></button>
      {comic.completed ? (
        <span className="card-status"><Check size={12} />Прочитано</span>
      ) : comic.digital && !collection ? (
        <div className="card-progress">
          <Progress value={percent(comic)} />
          <span>{percent(comic)}%</span>
        </div>
      ) : !collection ? (
        <span className="no-copy">Нет цифровой копии</span>
      ) : null}
      {collection && showFormats && <div className="card-formats">
        {comic.physical === 'yes' && <span><Library size={11} />Бумага</span>}
        {isDigitalStory(comic) && <span title={comic.digital ? 'Есть цифровой файл' : 'Прочитан в цифре; файла нет'}><Monitor size={11} />Цифра</span>}
      </div>}
      {paper && (comic.publisher || comic.editionYear) && <span className="paper-caption">{[comic.publisher, comic.editionYear].filter(Boolean).join(' · ')}</span>}
    </article>
  );
}
export function Modal({
  title,
  children,
  onClose,
  wide = false,
  actions,
  className = '',
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
  actions?: ReactNode;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const backdrop = useRef<HTMLDivElement>(null);
  const close = useRef(onClose);
  close.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    const unlock = lockModalDocument(backdrop.current!);
    let revealFrame = 0;
    const restores = new Map<HTMLElement, () => void>();
    const reveal = () => {
      const field = document.activeElement;
      if (ref.current && field instanceof HTMLElement && isEditingField(field) && ref.current.contains(field)) revealFormField(ref.current, field);
    };
    const schedule = () => { cancelAnimationFrame(revealFrame); revealFrame = requestAnimationFrame(() => { revealFrame = requestAnimationFrame(reveal); }); };
    const focus = (event: FocusEvent) => {
      const field = event.target;
      if (!ref.current || !(field instanceof HTMLElement) || !ref.current.contains(field) || !isEditingField(field)) return;
      // Keep the iOS focus-pan guard from the working release, now shared by
      // every form. It runs only after the user focuses a field, never on open.
      const ios = /iP(?:hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
      if (ios && !restores.has(field)) {
        const value = field.style.getPropertyValue('opacity'), priority = field.style.getPropertyPriority('opacity');
        field.style.setProperty('opacity', '0');
        const restore = () => {
          if (value) field.style.setProperty('opacity', value, priority); else field.style.removeProperty('opacity');
          restores.delete(field);
        };
        restores.set(field, restore); requestAnimationFrame(restore);
      }
      schedule();
    };
    ref.current?.addEventListener('focusin', focus);
    window.visualViewport?.addEventListener('resize', schedule);
    window.visualViewport?.addEventListener('scroll', schedule);
    // A neutral close button never asks iOS to show the keyboard.
    ref.current?.querySelector<HTMLButtonElement>(':scope > header button[aria-label="Закрыть"]')?.focus({preventScroll:true});
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close.current();
      if (e.key === 'Tab') {
        const all = Array.from(
          ref.current?.querySelectorAll<HTMLElement>(
            'button,input,select,textarea,summary,[tabindex="0"]',
          ) || [],
        ).filter((x) => !x.hasAttribute('disabled') && x.tabIndex >= 0 && x.getClientRects().length > 0 && !x.closest('[inert]'));
        const first = all[0],
          last = all[all.length - 1];
        const active = document.activeElement;
        if (!first || active === ref.current || !ref.current?.contains(active)) {
          e.preventDefault(); (e.shiftKey ? last : first)?.focus({preventScroll:true});
        } else if (e.shiftKey && active === first) {
          e.preventDefault();
          last?.focus({preventScroll:true});
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus({preventScroll:true});
        }
      }
    };
    document.addEventListener('keydown', key);
    return () => {
      unlock();
      cancelAnimationFrame(revealFrame);
      for (const restore of restores.values()) restore();
      ref.current?.removeEventListener('focusin', focus);
      window.visualViewport?.removeEventListener('resize', schedule);
      window.visualViewport?.removeEventListener('scroll', schedule);
      document.removeEventListener('keydown', key);
      // Restoring a background search input would reopen the keyboard.
      if (previous?.isConnected && !isEditingField(previous) && !previous.closest('[inert]') && previous.matches('button,a[href],summary,[tabindex]'))
        previous.focus({preventScroll:true});
    };
  }, []);
  return createPortal(
    <div
      ref={backdrop}
      className="modal-backdrop"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={ref}
        tabIndex={-1}
        className={`modal ${wide ? 'wide' : ''} ${className}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <header>
          <h2>{title}</h2>
          {actions}
          <button type="button" className="icon-button" aria-label="Закрыть" onClick={onClose}>
            <X />
          </button>
        </header>
        {children}
      </div>
    </div>, document.body
  );
}
export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="empty">
      <BookOpen size={30} />
      <h3>{title}</h3>
      {children}
    </div>
  );
}
