import { useEffect, useRef, useState, type ReactNode } from 'react';
import { X, BookOpen, Check, Ellipsis, Library, Monitor } from 'lucide-react';
import { getAsset } from '../storage/db';
import { type Comic, percent } from '../models';
import { isDigitalStory } from '../collection';
export function Bat({ className = '' }: { className?: string }) {
  return (
    <svg className={`bat ${className}`} viewBox="0 0 200 74" fill="currentColor" aria-hidden="true">
      <path d="M2 3H67C69 15 73 17 84 18C89 19 92 19 93 17L94 6L96 13Q100 12 104 13L106 6L107 17C108 19 111 19 116 18C127 17 131 15 133 3H198C174 13 165 26 169 41C134 39 111 43 100 71C89 43 66 39 31 41C35 26 26 13 2 3Z" />
    </svg>
  );
}
export function useBlobUrl(id?: string) {
  const [url, set] = useState<string>();
  useEffect(() => {
    let active = true;
    let objectUrl: string | undefined;
    set(undefined);
    if (id)
      void getAsset(id).then((a) => {
        if (a && active) {
          objectUrl = URL.createObjectURL(a.blob);
          set(objectUrl);
        }
      }).catch(() => {});
    return () => {
      active = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [id]);
  return url;
}
export function Cover({ comic, photo = false, paper = false }: { comic: Comic; photo?: boolean; paper?: boolean }) {
  const url = useBlobUrl(photo ? comic.photoId : paper ? comic.coverId || comic.photoId : comic.coverId);
  return (
    <div
      className="cover"
      style={
        {
          '--cover-color': comic.tone,
          '--cover-title-divisor': Math.max(
            5.5,
            Math.max(
              ...comic.title
                .replace(/^Бэтмен\. /, '')
                .split(/\s+/)
                .map((word) => word.length),
            ) * 0.85,
          ),
        } as React.CSSProperties
      }
    >
      {url ? (
        <img src={url} alt={`Обложка: ${comic.title}`} loading="lazy" />
      ) : (
        <div className="cover-art">
          <span className="cover-bat">
            <Bat />
          </span>
          <span className="cover-name">{comic.title.replace(/^Бэтмен\. /, '')}</span>
          {comic.year && <span className="cover-year">{comic.year}</span>}
          <div className="cover-lines" />
        </div>
      )}
    </div>
  );
}
export function Progress({ value }: { value: number }) {
  return (
    <div
      className="progress"
      role="progressbar"
      aria-label="Прогресс чтения"
      aria-valuenow={value}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <i style={{ width: `${value}%` }} />
    </div>
  );
}
export function Card({
  comic,
  onClick,
  onEdit,
  paper = false,
  collection = false,
  showFormats = true,
}: {
  comic: Comic;
  onClick: (rect: DOMRect) => void;
  onEdit: () => void;
  paper?: boolean;
  collection?: boolean;
  showFormats?: boolean;
}) {
  return (
    <article className={`comic-card ${paper ? 'paper-card' : ''}`}>
      <button className="card-open" onClick={(e) => onClick(e.currentTarget.querySelector('.cover')!.getBoundingClientRect())} aria-label={`${!collection && comic.digital ? 'Читать' : 'Открыть'}: ${comic.title}`}>
        <div className="card-image"><Cover comic={comic} paper={paper} /></div>
        <h3>{comic.title}</h3>
      </button>
      <button className="card-menu" aria-label={`Сведения: ${comic.title}`} onClick={onEdit}><Ellipsis size={19} /></button>
      {comic.completed ? (
        <span className="card-status"><Check size={12} />Прочитано</span>
      ) : comic.digital && !collection ? (
        <div className="card-progress">
          <Progress value={percent(comic)} />
          <span>{percent(comic)}%</span>
        </div>
      ) : !collection ? (
        <span className="no-copy">Нет цифровой копии</span>
      ) : null}
      {collection && showFormats && <div className="card-formats">
        {comic.physical === 'yes' && <span><Library size={11} />Бумага</span>}
        {isDigitalStory(comic) && <span title={comic.digital ? 'Есть цифровой файл' : 'Прочитан в цифре; файла нет'}><Monitor size={11} />Цифра</span>}
      </div>}
      {paper && (comic.publisher || comic.editionYear) && <span className="paper-caption">{[comic.publisher, comic.editionYear].filter(Boolean).join(' · ')}</span>}
    </article>
  );
}
export function Modal({
  title,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    const old = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    ref.current?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab') {
        const all = Array.from(
          ref.current?.querySelectorAll<HTMLElement>(
            'button,input,select,textarea,summary,[tabindex="0"]',
          ) || [],
        ).filter((x) => !x.hasAttribute('disabled') && x.getClientRects().length > 0);
        const first = all[0],
          last = all[all.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    };
    document.addEventListener('keydown', key);
    return () => {
      document.body.style.overflow = old;
      document.removeEventListener('keydown', key);
      previous?.focus();
    };
  }, [onClose]);
  return (
    <div
      className="modal-backdrop"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={ref}
        tabIndex={-1}
        className={`modal ${wide ? 'wide' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <header>
          <h2>{title}</h2>
          <button className="icon-button" aria-label="Закрыть" onClick={onClose}>
            <X />
          </button>
        </header>
        {children}
      </div>
    </div>
  );
}
export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="empty">
      <BookOpen size={30} />
      <h3>{title}</h3>
      {children}
    </div>
  );
}
