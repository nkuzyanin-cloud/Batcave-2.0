import { useState } from 'react';
import { Check, ChevronDown, ChevronRight } from 'lucide-react';
import { ERAS, comicEra, type EraId } from '../eras';
import type { Comic } from '../models';
import { Modal } from './ui';
import {routeProgress} from '../library-home';
import {ReadingProgress} from './ReadingProgress';
export function EraPicker({value,onChange,comics=[],chapters=ERAS,title='Разделы маршрута',triggerLabel}:{value:EraId;onChange:(era:EraId)=>void;comics?:Comic[];chapters?:ReadonlyArray<{id:string;title:string}>;title?:string;triggerLabel?:string}) {
  const [open,setOpen]=useState(false);
  return <div className="era-picker">
    <button className="era-trigger" aria-label="Выбрать раздел" aria-haspopup="dialog" aria-expanded={open} onClick={()=>setOpen(true)}><span>{triggerLabel??chapters.find(e=>e.id===value)?.title}</span><ChevronDown size={18}/></button>
    {open&&<Modal title={title} className="gotham-sheet era-sheet" onClose={()=>setOpen(false)}>
      <div className="era-options" role="listbox" aria-label={title}>
        {chapters.map((e,i)=>{const books=comics.filter(c=>comicEra(c,comics)===e.id),done=books.filter(c=>c.completed).length;return <button key={e.id} role="option" aria-selected={e.id===value} onClick={()=>{setOpen(false);onChange(e.id);}}>
          <span className="era-number">{String(i+1).padStart(2,'0')}</span><span className="era-label"><strong>{e.title}</strong>{books.length>0&&<small>Комиксов: {books.length} · прочитано: {done}</small>}{books.length>0&&e.id===value&&<ReadingProgress className="era-progress" label={`Прогресс раздела ${e.title}`} value={routeProgress(books)} completed={done/books.length*100}/>}</span>{e.id===value?<Check size={19}/>:<ChevronRight size={17}/>}</button>;})}
      </div>
    </Modal>}
  </div>;
}
