import { useEffect, useRef } from 'react';
import { Check } from 'lucide-react';
import { type Comic, paperReadPages, status } from '../models';
import { readingPosition } from '../library-home';
import { Cover } from './ui';

export function Roadmap({comics, all, onRead, onEdit}: {
  comics: Comic[]; all: Comic[]; onRead: (comic:Comic,rect:DOMRect)=>void; onEdit:(comic:Comic)=>void;
}) {
  const current=all.filter(c=>!c.completed && (c.digital ? c.lastOpened>0 : status(c)==='reading'))
    .sort((a,b)=>b.lastOpened-a.lastOpened||b.updatedAt-a.updatedAt||a.id.localeCompare(b.id))[0]?.id;
  const positions=new Map(all.map((c,i)=>[c.id,i+1]));
  return <ol className="series-timeline" aria-label="Порядок чтения">
    {comics.map(c=><TimelineRow key={c.id} comic={c} number={positions.get(c.id)!} current={current===c.id} onRead={onRead} onEdit={onEdit}/>)}
  </ol>;
}

function TimelineRow({comic:c,number,current,onRead,onEdit}: {
  comic:Comic;number:number;current:boolean;onRead:(c:Comic,rect:DOMRect)=>void;onEdit:(c:Comic)=>void;
}) {
  const state=status(c),reading=!c.completed&&(current||state==='reading');
  const position=c.digital?readingPosition(c):{page:paperReadPages(c),total:c.paperPageCount??0,percent:c.paperPageCount?Math.min(100,Math.round(paperReadPages(c)/c.paperPageCount*100)):0};
  const label=c.completed?'Прочитано':reading?(position.total?`Страница ${position.page} из ${position.total}`:'Позиция чтения сохранена'):'Не начато';
  const press=useRef<{id:number;x:number;y:number;timer:ReturnType<typeof setTimeout>} | undefined>(undefined);
  const suppressClick=useRef(false);
  const edit=useRef(onEdit);edit.current=onEdit;
  const comic=useRef(c);comic.current=c;
  const dispose=useRef<()=>void>(()=>{});
  const cancel=() => {
    if(press.current){clearTimeout(press.current.timer);press.current=undefined;}
    dispose.current();dispose.current=()=>{};
  };
  useEffect(()=>()=>cancel(),[]);
  const observe=()=>{
    const move=(e:PointerEvent)=>{
      const p=press.current;
      if(p && e.pointerId===p.id && Math.hypot(e.clientX-p.x,e.clientY-p.y)>10){suppressClick.current=true;cancel();}
    };
    const end=(e:PointerEvent)=>{if(e.pointerId===press.current?.id)cancel();};
    const interrupted=()=>{if(press.current)suppressClick.current=true;cancel();};
    const multiTouch=(e:PointerEvent)=>{if(press.current && e.pointerId!==press.current.id)interrupted();};
    document.addEventListener('pointermove',move,{passive:true});
    document.addEventListener('pointerup',end,true);
    document.addEventListener('pointercancel',interrupted,true);
    document.addEventListener('pointerdown',multiTouch,true);
    document.addEventListener('scroll',interrupted,true);
    document.addEventListener('visibilitychange',interrupted);
    window.addEventListener('blur',interrupted);
    dispose.current=()=>{
      document.removeEventListener('pointermove',move);
      document.removeEventListener('pointerup',end,true);
      document.removeEventListener('pointercancel',interrupted,true);
      document.removeEventListener('pointerdown',multiTouch,true);
      document.removeEventListener('scroll',interrupted,true);
      document.removeEventListener('visibilitychange',interrupted);
      window.removeEventListener('blur',interrupted);
    };
  };
  return <li className={`series-timeline-entry ${current?'is-current':''}`} data-status={c.completed?'done':reading?'reading':'new'} data-comic-id={c.id}>
    <button className="series-comic-row" aria-label={`${c.digital?'Читать':'Открыть'}: ${c.title}. ${label}`}
      aria-description="Удерживайте карточку одну секунду для редактирования. С клавиатуры — F2."
      onPointerDown={e=>{
        if(!e.isPrimary || e.button!==0)return;
        cancel();suppressClick.current=false;
        press.current={id:e.pointerId,x:e.clientX,y:e.clientY,timer:setTimeout(()=>{
          suppressClick.current=true;cancel();edit.current(comic.current);
        },1000)};observe();
      }}
      onClick={e=>{
        cancel();if(suppressClick.current){e.preventDefault();return;}
        c.digital?onRead(c,e.currentTarget.querySelector('.cover')!.getBoundingClientRect()):onEdit(c);
      }}
      onKeyDown={e=>{if(e.key==='F2'||(e.shiftKey&&e.key==='F10')){e.preventDefault();cancel();edit.current(c);}else if(e.key==='Enter'||e.key===' '){suppressClick.current=false;}}}
      onContextMenu={e=>e.preventDefault()} onDragStart={e=>e.preventDefault()}>
      <span className="series-step" aria-hidden="true">{c.completed?<Check size={12}/>:String(number).padStart(2,'0')}</span>
      <Cover comic={c} paper={c.physical==='yes'}/>
      <span className="series-comic-copy">{current&&<span className="series-current-label">Читаю сейчас</span>}<strong>{c.title}</strong><span className="series-comic-status">{label}</span>
        {reading&&position.total>0&&<span className="series-comic-meter" role="progressbar" aria-label={`Прогресс: ${c.title}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={position.percent}><i style={{width:`${position.percent}%`}}/></span>}
      </span>
    </button>
  </li>;
}
