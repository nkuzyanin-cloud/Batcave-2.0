import { Ellipsis } from 'lucide-react';
import { type Comic } from '../models';
import { Cover } from './ui';
import { sideStories } from '../roadmap';
export function Roadmap({comics, all, archive, onRead, onEdit, onSideStories}: {
  comics: Comic[]; all: Comic[]; archive:Comic[]; onRead: (comic:Comic,rect:DOMRect)=>void; onEdit:(comic:Comic)=>void; onSideStories:(comic:Comic)=>void;
}) {
  const positions = new Map(all.map((c,i)=>[c.id,i+1]));
  const next = all.find(c => !c.completed);
  return <div className="reading-roadmap" aria-label="Маршрут чтения">
    {comics.map((c,i) => {
      const extra=sideStories(archive,c.id), done=extra.length>0 && extra.every(b=>b.completed);
      const mainIndex=all.findIndex(b=>b.id===c.id);
      const gap=i<comics.length-1;
      const circle=(gap && comics[i+1].id===all[mainIndex+1]?.id) || (!gap && extra.length>0);
      return <article className={`road-node comic-card ${i%2 ? 'road-right' : ''} ${c.completed ? 'road-complete' : ''} ${c.id===next?.id ? 'road-next' : ''} ${!gap && circle ? 'road-tail' : ''}`} key={c.id}>
      {(gap || circle) && <svg className="road-connector" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><path d="M0 0 C0 115 100 -15 100 100" /></svg>}
      {circle && <button className={`road-side-story ${done ? 'complete' : ''}`} aria-label={`Дополнительные комиксы после «${c.title}»: ${extra.length}${done ? ', все прочитаны' : ''}`} onClick={()=>onSideStories(c)}><span>{extra.length || ''}</span></button>}
      <button className="road-cover" aria-label={`${c.digital ? 'Читать' : 'Открыть'}: ${c.title}`} onClick={e => c.digital ? onRead(c,e.currentTarget.querySelector('.cover')!.getBoundingClientRect()) : onEdit(c)}>
        <Cover comic={c} paper={c.physical==='yes'} />
        <span className="road-number">{String(positions.get(c.id)).padStart(2,'0')}</span>
      </button>
      <div className="road-meta">
        <h3>{c.title}</h3>
        <button className="icon-button road-menu" aria-label={`Сведения: ${c.title}`} onClick={()=>onEdit(c)}><Ellipsis size={19}/></button>
      </div>
    </article>})}
  </div>;
}
