import {useRef,type PointerEvent,type TouchEvent} from 'react';
import {Check,Ellipsis,Star} from 'lucide-react';
import {type Comic,paperReadPages,status} from '../models';
import {readingPosition} from '../library-home';
import {Cover} from './ui';
import {ReadingProgress} from './ReadingProgress';

export interface RouteRowActions {
  sectionLabel?:{number:number;title:string};
  onMenu?:(comic:Comic)=>void;
  onHoldPointer?:(comic:Comic,event:PointerEvent)=>void;
  onHoldTouch?:(comic:Comic,event:TouchEvent)=>void;
  consumeClick?:(id:string)=>boolean;
  resetClick?:()=>void;
  draggingId?:string;
  beforeId?:string;
}
export function Roadmap({comics,all,onRead,onEdit,...actions}:{
  comics:Comic[];all:Comic[];onRead:(comic:Comic,rect:DOMRect)=>void;onEdit:(comic:Comic)=>void;
}&RouteRowActions) {
  const current=all.filter(c=>!c.completed&&(c.digital?c.lastOpened>0:status(c)==='reading'))
    .sort((a,b)=>b.lastOpened-a.lastOpened||b.updatedAt-a.updatedAt||a.id.localeCompare(b.id))[0]?.id;
  const positions=new Map(all.map((c,i)=>[c.id,i+1]));
  return <ol className="series-timeline" aria-label="Порядок чтения">
    {comics.map(c=><TimelineRow key={c.id} comic={c} number={positions.get(c.id)!} current={current===c.id} onRead={onRead} onEdit={onEdit} {...actions}/>)}
  </ol>;
}
function TimelineRow({comic:c,number,current,onRead,onEdit,...actions}:{
  comic:Comic;number:number;current:boolean;onRead:(c:Comic,rect:DOMRect)=>void;onEdit:(c:Comic)=>void;
}&RouteRowActions) {
  const state=status(c),reading=!c.completed&&(current||state==='reading');
  const position=c.digital?readingPosition(c):{page:paperReadPages(c),total:c.paperPageCount??0,percent:c.paperPageCount?Math.min(100,Math.round(paperReadPages(c)/c.paperPageCount*100)):0};
  const label=c.completed?'Прочитано':reading?(position.total?`Страница ${position.page} из ${position.total}`:'Позиция чтения сохранена'):'Не начато';
  const start=useRef<{x:number;y:number}|undefined>(undefined),swiped=useRef(false);
  return <li className={`series-timeline-entry ${current?'is-current':''} ${actions.draggingId===c.id?'is-dragging':''} ${actions.beforeId===c.id?'is-drop-before':''}`}
    data-status={c.completed?'done':reading?'reading':'new'} data-comic-id={c.id}>
    <button className="series-comic-row" aria-label={`${c.digital?'Читать':'Открыть'}: ${c.title}. ${label}`}
      aria-description="Меню выпуска — справа. Удерживайте обложку для переноса. С клавиатуры — F2 для редактирования."
      onPointerDown={e=>{start.current={x:e.clientX,y:e.clientY};swiped.current=false;}}
      onPointerMove={e=>{if(start.current&&Math.hypot(e.clientX-start.current.x,e.clientY-start.current.y)>10)swiped.current=true;}}
      onClick={e=>{
        if(actions.consumeClick?.(c.id)||swiped.current){e.preventDefault();return;}
        c.digital?onRead(c,e.currentTarget.querySelector('.cover')!.getBoundingClientRect()):onEdit(c);
      }}
      onKeyDown={e=>{
        if(e.key==='F2'){e.preventDefault();onEdit(c);}
        else if(e.shiftKey&&e.key==='F10'){e.preventDefault();(actions.onMenu??onEdit)(c);}
        else if(e.key==='Enter'||e.key===' '){swiped.current=false;actions.resetClick?.();}
      }} onContextMenu={e=>e.preventDefault()} onDragStart={e=>e.preventDefault()}>
      <span className="series-step" aria-hidden="true">{c.completed?<Check size={12}/>:String(number).padStart(2,'0')}</span>
      <span className="series-cover-handle" onPointerDown={e=>actions.onHoldPointer?.(c,e)} onTouchStart={e=>actions.onHoldTouch?.(c,e)}><Cover comic={c} paper={c.physical==='yes'}/></span>
      <span className="series-comic-copy">{current&&<span className="series-current-label">Читаю сейчас</span>}{actions.sectionLabel&&<span className="route-single-kicker">РАЗДЕЛ {String(actions.sectionLabel.number).padStart(2,'0')}</span>}<strong>{actions.sectionLabel?.title??c.title}</strong>{actions.sectionLabel&&actions.sectionLabel.title!==c.title&&<span className="route-single-title">{c.title}</span>}<span className="series-comic-status">{c.completed&&<Check size={13} aria-hidden="true"/>}{label}</span>
        {c.completed&&c.rating>0&&<span className="series-comic-rating" role="img" aria-label={`Оценка: ${c.rating} из 5`}>{[1,2,3,4,5].map(n=><Star key={n} size={12} className={n<=c.rating?'is-filled':''} aria-hidden="true"/>)}</span>}
        {reading&&position.total>0&&<ReadingProgress className="series-comic-meter" label={`Прогресс: ${c.title}`} value={position.percent}/>}
      </span>
    </button>
    <button className="series-comic-menu icon-button" aria-label={`Меню выпуска: ${c.title}`} onClick={()=>(actions.onMenu??onEdit)(c)}><Ellipsis size={19}/></button>
  </li>;
}
