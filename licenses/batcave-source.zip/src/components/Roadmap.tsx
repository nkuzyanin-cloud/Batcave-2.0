import { Ellipsis } from 'lucide-react';
import { type Comic } from '../models';
import { Cover } from './ui';
export function Roadmap({comics, all, onRead, onEdit}: {
  comics: Comic[]; all: Comic[]; onRead: (comic:Comic,rect:DOMRect)=>void; onEdit:(comic:Comic)=>void;
}) {
  const positions = new Map(all.map((c,i)=>[c.id,i+1]));
  const next = all.find(c => !c.completed);
  return <div className="reading-roadmap" aria-label="Маршрут чтения">
    {comics.map((c,i) => <article className={`road-node comic-card ${i%2 ? 'road-right' : ''} ${c.completed ? 'road-complete' : ''} ${c.id===next?.id ? 'road-next' : ''}`} key={c.id}>
      {i<comics.length-1 && <svg className="road-connector" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><path d="M0 0 C0 115 100 -15 100 100" /></svg>}
      <button className="road-cover" aria-label={`${c.digital ? 'Читать' : 'Открыть'}: ${c.title}`} onClick={e => c.digital ? onRead(c,e.currentTarget.querySelector('.cover')!.getBoundingClientRect()) : onEdit(c)}>
        <Cover comic={c} paper={c.physical==='yes'} />
        <span className="road-number">{String(positions.get(c.id)).padStart(2,'0')}</span>
      </button>
      <div className="road-meta">
        <h3>{c.title}</h3>
        <button className="icon-button road-menu" aria-label={`Сведения: ${c.title}`} onClick={()=>onEdit(c)}><Ellipsis size={19}/></button>
      </div>
    </article>)}
  </div>;
}
