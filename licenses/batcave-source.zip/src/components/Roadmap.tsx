import { useEffect, useRef } from 'react';
import { Check } from 'lucide-react';
import { type Comic, status } from '../models';
import { CollectionIcon, Cover } from './ui';
import { sideStories } from '../roadmap';
export function Roadmap({comics, all, archive, onRead, onEdit, onSideStories}: {
  comics: Comic[]; all: Comic[]; archive:Comic[]; onRead: (comic:Comic,rect:DOMRect)=>void; onEdit:(comic:Comic)=>void; onSideStories:(comic:Comic)=>void;
}) {
  return <div className="reading-roadmap" aria-label="Маршрут чтения">
    {comics.map((c,i) => {
      const state=status(c),label=state==='done' ? 'Прочитано' : state==='reading' ? 'В процессе' : 'Не начато';
      const extra=sideStories(archive,c.id), done=extra.length>0 && extra.every(b=>b.completed);
      const mainIndex=all.findIndex(b=>b.id===c.id);
      const gap=i<comics.length-1;
      const circle=(gap && comics[i+1].id===all[mainIndex+1]?.id) || (!gap && extra.length>0);
      return <article className={`road-node comic-card ${i%2 ? 'road-right' : ''} ${!gap && circle ? 'road-tail' : ''}`} data-status={state} key={c.id}>
      {(gap || circle) && <svg className="road-connector" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><path d="M0 0 C0 115 100 -15 100 100" /></svg>}
      {circle && <button className={`road-side-story ${extra.length ? 'populated' : ''} ${done ? 'complete' : ''}`} aria-label={`Дополнительные комиксы после «${c.title}»: ${extra.length}${done ? ', все прочитаны' : ''}`} onClick={()=>onSideStories(c)}><span className="road-side-story-symbol" aria-hidden="true">{extra.length>0 && <CollectionIcon size={17}/>}</span>{done && <Check className="road-side-story-check" size={11} aria-hidden="true"/>}</button>}
      <RoadCover comic={c} label={label} onRead={onRead} onEdit={onEdit}/>

    </article>})}
  </div>;
}

function RoadCover({comic:c,label,onRead,onEdit}: {
  comic:Comic;label:string;onRead:(c:Comic,rect:DOMRect)=>void;onEdit:(c:Comic)=>void;
}) {
  const press=useRef<{id:number;x:number;y:number;timer:ReturnType<typeof setTimeout>} | undefined>(undefined);
  const suppressClick=useRef(false);
  const edit=useRef(onEdit);edit.current=onEdit;
  const current=useRef(c);current.current=c;
  const dispose=useRef<()=>void>(()=>{});
  const cancel=() => {
    if(press.current){clearTimeout(press.current.timer);press.current=undefined;}
    dispose.current();dispose.current=()=>{};
  };
  useEffect(()=>()=>cancel(),[]);
  const observe=()=>{
    const move=(e:PointerEvent)=>{
      const p=press.current;
      if(p && e.pointerId===p.id && Math.hypot(e.clientX-p.x,e.clientY-p.y)>10){suppressClick.current=true;cancel();}
    };
    const end=(e:PointerEvent)=>{if(e.pointerId===press.current?.id)cancel();};
    const interrupted=()=>{if(press.current)suppressClick.current=true;cancel();};
    const multiTouch=(e:PointerEvent)=>{if(press.current && e.pointerId!==press.current.id)interrupted();};
    document.addEventListener('pointermove',move,{passive:true});
    document.addEventListener('pointerup',end,true);
    document.addEventListener('pointercancel',interrupted,true);
    document.addEventListener('pointerdown',multiTouch,true);
    document.addEventListener('scroll',interrupted,true);
    document.addEventListener('visibilitychange',interrupted);
    window.addEventListener('blur',interrupted);
    dispose.current=()=>{
      document.removeEventListener('pointermove',move);
      document.removeEventListener('pointerup',end,true);
      document.removeEventListener('pointercancel',interrupted,true);
      document.removeEventListener('pointerdown',multiTouch,true);
      document.removeEventListener('scroll',interrupted,true);
      document.removeEventListener('visibilitychange',interrupted);
      window.removeEventListener('blur',interrupted);
    };
  };
  return <button className="road-cover" aria-label={`${c.digital ? 'Читать' : 'Открыть'}: ${c.title}. ${label}`}
    aria-description="Удерживайте обложку одну секунду для редактирования. С клавиатуры — F2."
    onPointerDown={e=>{
      if(!e.isPrimary || e.button!==0)return;
      cancel();suppressClick.current=false;
      press.current={id:e.pointerId,x:e.clientX,y:e.clientY,timer:setTimeout(()=>{
        suppressClick.current=true;cancel();edit.current(current.current);
      },1000)};observe();
    }}
    onClick={e=>{
      cancel();if(suppressClick.current){e.preventDefault();return;}
      c.digital ? onRead(c,e.currentTarget.querySelector('.cover')!.getBoundingClientRect()) : onEdit(c);
    }}
    onKeyDown={e=>{if(e.key==='F2' || (e.shiftKey && e.key==='F10')){e.preventDefault();cancel();edit.current(c);}else if(e.key==='Enter'||e.key===' '){suppressClick.current=false;}}}
    onContextMenu={e=>e.preventDefault()} onDragStart={e=>e.preventDefault()}>
    <Cover comic={c} paper={c.physical==='yes'}/>
  </button>;
}
