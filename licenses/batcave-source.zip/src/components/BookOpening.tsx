import { useEffect, useRef } from 'react';
import type { Comic } from '../models';
import { Cover } from './ui';

// One compositor animation, without rerendering the book or the reader per frame.
export function BookOpening({ comic, rect, onDone }: { comic: Comic; rect: DOMRect; onDone: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (document.documentElement.dataset.motion === 'off') { onDone(); return; }
    const scale = Math.min(1.35, window.innerWidth * 0.62 / Math.max(1, rect.width));
    const x = (window.innerWidth - rect.width * scale) / 2;
    const y = (window.innerHeight - rect.height * scale) / 2;
    const animation = ref.current!.animate([
      { transform: `translate3d(${rect.x}px,${rect.y}px,0) scale(1)`, opacity: 1 },
      { transform: `translate3d(${x}px,${y}px,0) scale(${scale})`, opacity: 1, offset: 0.62 },
      { transform: `translate3d(${x}px,${y}px,0) scale(${scale * 1.04})`, opacity: 0 },
    ], { duration: document.documentElement.dataset.motion === 'fast' ? 150 : 260, easing: 'cubic-bezier(.2,.7,.3,1)', fill: 'both' });
    animation.onfinish = onDone;
    return () => { animation.onfinish = null; animation.cancel(); };
  }, [rect, onDone]);
  return <div ref={ref} className="book-opening" aria-hidden="true" style={{ width: rect.width, height: rect.height }}><Cover comic={comic} /></div>;
}
