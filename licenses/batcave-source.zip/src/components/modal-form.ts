import { focusedScrollDelta } from '../viewport';

// The archive scrolls in .screen, not in the document. Keep the document
// stationary while a form is open, including Safari's focus-scroll attempts.
let locks = 0;
let restoreBody: (() => void) | undefined;
const overlays: HTMLElement[] = [];
const inertBefore = new Map<HTMLElement, boolean>();
let observer: MutationObserver | undefined;
function updateInert() {
  const active = overlays.at(-1);
  for (const child of document.body.children) if (child instanceof HTMLElement) {
    if (!inertBefore.has(child)) inertBefore.set(child, child.inert);
    child.inert = child === active ? false : true;
  }
}
export function lockModalDocument(overlay: HTMLElement) {
  overlays.push(overlay);
  if (locks++ === 0) {
    const body = document.body;
    const keys = ['position', 'top', 'left', 'right', 'width', 'overflow'] as const;
    const old = keys.map(key => [key, body.style.getPropertyValue(key), body.style.getPropertyPriority(key)] as const);
    body.style.position = 'fixed';
    body.style.top = '0';
    body.style.left = '0';
    body.style.right = '0';
    body.style.width = '100%';
    body.style.overflow = 'hidden';
    restoreBody = () => {
      for (const [key, value, priority] of old) {
        if (value) body.style.setProperty(key, value, priority);
        else body.style.removeProperty(key);
      }
    };
    observer = new MutationObserver(updateInert);
    observer.observe(document.body, { childList: true });
  }
  updateInert();
  let released = false;
  return () => {
    if (released) return;
    released = true;
    const index = overlays.indexOf(overlay);
    if (index >= 0) overlays.splice(index, 1);
    if (--locks === 0) {
      observer?.disconnect(); observer = undefined;
      for (const [element, inert] of inertBefore) element.inert = inert;
      inertBefore.clear(); restoreBody?.(); restoreBody = undefined;
    } else updateInert();
  };
}

export function revealFormField(container: HTMLElement, field: HTMLElement) {
  const box = container.getBoundingClientRect(), rect = field.getBoundingClientRect();
  const label = field.closest('label')?.getBoundingClientRect();
  const header = container.querySelector(':scope > header')?.getBoundingClientRect();
  const visibleTop = Math.max(box.top + 12, header ? header.bottom + 12 : box.top + 12);
  const top = label && rect.bottom - label.top <= box.bottom - 16 - visibleTop ? Math.min(label.top, rect.top) : rect.top;
  const delta = focusedScrollDelta(top, rect.bottom, visibleTop, box.bottom - 16);
  // Never scrollIntoView(): it can scroll the document/visual viewport too.
  if (delta) container.scrollTop += delta;
}

export function isEditingField(element: Element | null): boolean {
  return element instanceof HTMLElement && element.matches('input:not([type="checkbox"]):not([type="radio"]):not([type="range"]):not([type="file"]):not([type="hidden"]):not([type="button"]):not([type="submit"]),textarea,select,[contenteditable="true"]');
}
