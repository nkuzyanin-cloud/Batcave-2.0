import {useRef,useState} from 'react';
import {BookOpen,ChevronRight,ImagePlus,Plus,Trash2} from 'lucide-react';
import {type Comic,errorMessage} from '../models';
import {type Universe,comicUniverse,BATMAN_ID,universeSchema} from '../universes';
import {saveUniverse,deleteUniverse} from '../storage/db';
import {Cover,Modal} from './ui';
import {imageToCanvas,detectFormat} from '../reader/source';

export function UniverseCover({universe,comics}:{universe:Universe;comics:Comic[]}){
  const c=comics.find(c=>comicUniverse(c)===universe.id&&c.coverId);
  return universe.cover?<div className="universe-cover"><img src={universe.cover} alt={`Обложка серии ${universe.title}`}/></div>:c?<Cover comic={c}/>:<div className="universe-cover universe-placeholder"><BookOpen/><strong>{universe.title}</strong></div>;
}
export function Universes({universes,comics,onOpen,onEdit}:{universes:Universe[];comics:Comic[];onOpen:(id:string)=>void;onEdit:(u:Universe)=>void}){
  return <div className="universe-grid">{universes.map(u=>{const list=comics.filter(c=>comicUniverse(c)===u.id),done=list.filter(c=>c.completed).length;return <article className="universe-card" key={u.id}>
    <button className="universe-open" onClick={()=>onOpen(u.id)} aria-label={`Открыть серию: ${u.title}`}><UniverseCover universe={u} comics={comics}/><span><strong>{u.title}</strong><ChevronRight size={15}/></span><small>{list.length?`${done} / ${list.length} прочитано`:'Создать дорожную карту'}</small><div className="universe-meter"><i style={{width:`${list.length?done/list.length*100:0}%`}}/></div></button>
    <button className="universe-edit" onClick={()=>onEdit(u)} aria-label={`Изменить серию: ${u.title}`}>Изменить</button>
  </article>})}</div>;
}
export function UniverseEditor({universe,onClose,onSaved}:{universe?:Universe;onClose:()=>void;onSaved:()=>Promise<void>}){
  const [u,set]=useState<Universe>(()=>universe?{...universe,chapters:universe.chapters.map(p=>({...p}))}:{id:crypto.randomUUID(),title:'',chapters:[{id:'main',title:'Основной маршрут'}],updatedAt:0});
  const [busy,setBusy]=useState(false),[error,setError]=useState('');const lock=useRef(false);
  async function image(file?:File){
    if(!file||lock.current)return;
    lock.current=true;setBusy(true);setError('');
    const canvas=document.createElement('canvas');
    try{
      if(await detectFormat(file,file.name)!=='image')throw Error('Выберите JPG, PNG или WebP.');
      await imageToCanvas(file,canvas,640);
      // State updaters can run after finally clears the canvas. Capture the
      // encoded bytes now; the queued update must only use immutable data.
      const cover=canvas.toDataURL('image/jpeg',.85);
      if(!universeSchema.shape.cover.safeParse(cover).success)
        throw Error('Не удалось подготовить обложку. Попробуйте выбрать другое изображение.');
      set(v=>({...v,cover}));
    }catch(e){setError(errorMessage(e));}
    finally{canvas.width=canvas.height=0;setBusy(false);lock.current=false;}
  }
  async function submit(e:React.FormEvent){e.preventDefault();if(lock.current)return;lock.current=true;setBusy(true);setError('');try{await saveUniverse(u,!!universe);await onSaved();onClose();}catch(e){setError(errorMessage(e));setBusy(false);lock.current=false;}}
  return <Modal title={universe?'Изменить серию':'Новая серия'} onClose={()=>{if(!busy)onClose();}}><form className="universe-form" onSubmit={submit}>
    {error&&<p className="error" role="alert">{error}</p>}
    <label>Название<input autoComplete="off" value={u.title} maxLength={100} required onChange={e=>set({...u,title:e.target.value})}/></label>
    <label className="universe-cover-upload">{u.cover?<img src={u.cover} alt="Выбранная обложка"/>:<ImagePlus size={25}/>}<span>{u.cover?'Заменить обложку':'Выбрать обложку'}</span><input type="file" accept="image/jpeg,image/png,image/webp" hidden disabled={busy} onChange={e=>{void image(e.target.files?.[0]);e.target.value='';}}/></label>
    {u.cover&&<button type="button" className="universe-remove-cover" disabled={busy} onClick={()=>set({...u,cover:undefined})}>Убрать обложку</button>}
    <h3>{u.id===BATMAN_ID?'Эры и подборки':'Разделы дорожной карты'}</h3>
    <div className="universe-chapters">{u.chapters.map((p,i)=><div key={p.id}><span>{i+1}</span><input aria-label={`Название раздела ${i+1}`} value={p.title} maxLength={100} required onChange={e=>set({...u,chapters:u.chapters.map(c=>c.id===p.id?{...c,title:e.target.value}:c)})}/>{u.chapters.length>1&&u.id!==BATMAN_ID&&<button type="button" className="icon-button" aria-label={`Удалить раздел ${p.title}`} onClick={()=>set({...u,chapters:u.chapters.filter(c=>c.id!==p.id)})}><Trash2 size={16}/></button>}</div>)}</div>
    <button type="button" className="universe-add-chapter" disabled={busy||u.chapters.length>=100} onClick={()=>set({...u,chapters:[...u.chapters,{id:'chapter-'+crypto.randomUUID(),title:''}]})}><Plus size={16}/>Добавить раздел</button>
    <button className="primary" type="submit" disabled={busy}>{busy?'Сохраняем…':'Сохранить'}</button>
  </form></Modal>;
}

export function DeleteSeriesDialog({universe,onClose,onDeleted}:{universe:Universe;onClose:()=>void;onDeleted:()=>Promise<void>}) {
  const [busy,setBusy]=useState(false),[error,setError]=useState('');const lock=useRef(false);
  async function remove(){
    if(lock.current)return;lock.current=true;setBusy(true);setError('');
    try{await deleteUniverse(universe.id,universe.updatedAt);await onDeleted();}
    catch(e){setError(errorMessage(e));setBusy(false);lock.current=false;}
  }
  return <Modal title="Удалить серию?" onClose={()=>{if(!busy)onClose();}}>
    <p className="series-delete-name">{universe.title}</p>
    <p>Серия и её разделы будут удалены. Все комиксы останутся в «Без серии»: файлы, оценки и прогресс чтения сохранятся.</p>
    {error&&<p className="error" role="alert">{error}</p>}
    <div className="series-delete-actions"><button disabled={busy} onClick={onClose}>Отмена</button><button className="danger" disabled={busy} onClick={()=>void remove()}>{busy?'Удаляем…':'Удалить серию'}</button></div>
  </Modal>;
}
