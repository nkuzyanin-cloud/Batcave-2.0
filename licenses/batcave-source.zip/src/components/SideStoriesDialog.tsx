import { useCallback, useRef, useState } from 'react';
import { ArrowLeft, Ellipsis, Plus, Search, X } from 'lucide-react';
import { type Comic, errorMessage } from '../models';
import { sideStories, sideStoryCandidates } from '../roadmap';
import { setSideStory } from '../storage/db';
import { Cover, Modal } from './ui';

export function SideStoriesDialog({afterId,nextId,comics,onClose,onSaved,onRead,onEdit,onAdd}:{
  afterId:string;nextId?:string;comics:Comic[];onClose:()=>void;onSaved:()=>Promise<void>;
  onRead:(comic:Comic,rect:DOMRect)=>void;onEdit:(comic:Comic)=>void;onAdd:()=>void;
}) {
  const [choosing,setChoosing]=useState(false),[query,setQuery]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
  const working=useRef(false),books=sideStories(comics,afterId);
  const close=useCallback(()=>{if(!working.current)onClose();},[onClose]);
  const candidates=sideStoryCandidates(comics,afterId,nextId).filter(c=>c.title.toLocaleLowerCase('ru').includes(query.toLocaleLowerCase('ru')));
  async function move(c:Comic,attach:boolean) {
    if(working.current)return;working.current=true;setBusy(true);setError('');
    try {await setSideStory(c.id,afterId,attach);await onSaved();setChoosing(false);setQuery('');}
    catch(e){setError(errorMessage(e));}finally{working.current=false;setBusy(false);}
  }
  return <Modal title={`Дополнительные комиксы${books.length ? ` · ${books.length}` : ''}`} onClose={close}>
    <div className="side-stories-dialog">
      {error && <p className="error" role="alert">{error}</p>}
      {choosing && <div className="side-stories-search">
        <button className="icon-button" disabled={busy} aria-label="Назад к дополнительным комиксам" onClick={()=>setChoosing(false)}><ArrowLeft size={18}/></button>
        <label className="search"><Search size={17}/><input aria-label="Найти комикс" placeholder="Название комикса" value={query} disabled={busy} onChange={e=>setQuery(e.target.value)}/></label>
      </div>}
      <div className="side-stories-list">
        {(choosing ? candidates : books).map(c=><div className={`side-story-row ${c.completed ? 'complete' : ''}`} key={c.id}>
          <button className="side-story-open" disabled={busy} aria-label={`${choosing ? 'Добавить' : c.digital ? 'Читать' : 'Открыть'}: ${c.title}`} onClick={e=>choosing ? void move(c,true) : c.digital ? onRead(c,e.currentTarget.querySelector('.cover')!.getBoundingClientRect()) : onEdit(c)}>
            <Cover comic={c} paper={c.physical==='yes'}/><span>{c.title}</span>
          </button>
          {!choosing && <>
            <button className="icon-button" disabled={busy} aria-label={`Сведения: ${c.title}`} onClick={()=>onEdit(c)}><Ellipsis size={18}/></button>
            <button className="icon-button" disabled={busy} aria-label={`Вернуть на основной путь: ${c.title}`} title="Вернуть на основной путь" onClick={()=>void move(c,false)}><X size={16}/></button>
          </>}
        </div>)}
        {choosing && !candidates.length && <p className="side-stories-empty">Комиксов для выбора нет</p>}
      </div>
      {!choosing && <button className="secondary" disabled={busy} onClick={()=>setChoosing(true)}>Выбрать существующий комикс</button>}
      <button className="primary" disabled={busy} onClick={onAdd}><Plus size={17}/>Добавить новый комикс</button>
    </div>
  </Modal>;
}
