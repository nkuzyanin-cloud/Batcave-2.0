import { useEffect, useRef, useState } from 'react';
import { type Comic, blankComic, errorMessage, bytes } from '../models';
import { inspectFile, fingerprint, type ImportPreview } from '../reader/source';
import { attachComicFile, allComics } from '../storage/db';
import { editionFingerprint } from '../storage/comic-data';
import { Modal } from './ui';
import { Upload, Check, FileText } from 'lucide-react';
import { DEFAULT_ERA, type EraId } from '../eras';
export function Importer({
  file,
  target,
  era=DEFAULT_ERA,
  onClose,
  onSaved,
}: {
  file: File;
  target?: Comic;
  era?: EraId;
  onClose: () => void;
  onSaved: () => Promise<void>;
}) {
  const [preview, setPreview] = useState<ImportPreview>();
  const [c, set] = useState(target ? { ...target } : {...blankComic(file.name.replace(/\.[^.]+$/, '')),era});
  const [url, setUrl] = useState('');
  const [hash, setHash] = useState('');
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('Проверка файла и первой страницы…');
  const active = useRef(true);
  const scan = useRef<AbortController | undefined>(undefined);
  const [auto, setAuto] = useState(true);
  const [preserveProgress, setPreserveProgress] = useState(true);
  useEffect(() => {
    active.current = true;
    const controller = new AbortController();
    let u = '';
    void (async () => {
      try {
        const p = await inspectFile(file, file.name, controller.signal);
        if (!active.current) return;
        setMessage('Проверка дубликатов…');
        const h = await fingerprint(file, controller.signal);
        const existing = (await allComics()).find(
          (b) => b.digital?.fingerprint === h && b.id !== target?.id,
        );
        if (existing) throw Error(`Этот файл уже в библиотеке: «${existing.title}».`);
        if (!active.current) return;
        u = URL.createObjectURL(p.cover);
        setUrl(u);
        setPreview(p);
        setHash(h);
        setBusy(false);
      } catch (e) {
        if (active.current) {
          setError(errorMessage(e));
          setBusy(false);
        }
      }
    })();
    return () => {
      active.current = false;
      controller.abort();
      scan.current?.abort();
      if (u) URL.revokeObjectURL(u);
    };
  }, [file, target]);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!preview || busy) return;
    if (!c.title.trim()) { setError('Укажите название комикса.'); return; }
    setBusy(true);
    setMessage('Сохранение на устройстве…');
    setError('');
    try {
      const estimate = await navigator.storage?.estimate?.();
      if (
        estimate?.quota &&
        estimate.usage !== undefined &&
        estimate.quota - estimate.usage < file.size * 1.15
      )
        throw Error('Недостаточно свободного места для файла.');
      const fileId = crypto.randomUUID(),
        coverId = crypto.randomUUID();
      const same = !!target && editionFingerprint(target) === hash;
      const keepCover = target?.coverId;
      let autoPanels = same ? target?.autoPanels : undefined;
      if (auto && !preview.prepared && !autoPanels && !(same && target?.panelEdits?.frames.length)) {
        const controller = new AbortController();scan.current = controller;
        try {
          const { recognizePanels } = await import('../reader/auto-panels');
          autoPanels = await recognizePanels(file,preview.format,hash,setMessage,controller.signal);
        } catch(e) {
          if(controller.signal.aborted || !active.current) return;
          setAuto(false);throw Error(`Не удалось распознать кадры: ${errorMessage(e)} Можно сохранить файл без кадров и повторить из настроек читалки.`);
        }
      }
      if(!active.current) return;
      setMessage('Сохранение на устройстве…');
      await attachComicFile(
        {
          ...c,
          title: c.title.trim(),
          pageCount: preview.count,
          digital: {
            assetId: fileId,
            name: file.name,
            size: file.size,
            format: preview.format,
            fingerprint: hash,
          },
          coverId: keepCover || coverId,
          autoPanels,
          autoPanelEdits: same ? target?.autoPanelEdits : undefined,
          panelEdits: same ? target?.panelEdits : undefined,
          ...(!same ? { page: 0, visited: [], seconds: 0, lastOpened: 0, readerView: undefined } : {}),
          completed: c.completed,
        },
        [
          { id: fileId, blob: file },
          ...(!keepCover ? [{ id: coverId, blob: preview.cover }] : []),
        ],
        target,
        !!target && preserveProgress,
      );
      await onSaved();
      onClose();
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  }
  return (
    <Modal title={target ? "Заменить файл комикса" : "Добавить комикс"} onClose={onClose}>
      <div className="import-summary">
        {url ? <img src={url} alt="Первая страница" /> : <FileText size={40} />}
        <div>
          <h3>{file.name}</h3>
          <p>
            {bytes(file.size)}
            {preview ? ` · ${preview.count} стр. · ${preview.format.toUpperCase()}` : ''}
          </p>
        </div>
      </div>
      {busy && (
        <p className="loading" role="status" aria-live="polite">
          <span className="spinner" />
          {message}
        </p>
      )}
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {preview && (
        <form className="form" onSubmit={submit}>
          <p className="success">
            <Check size={16} />
            Файл проверен
          </p>
          {!target && (
            <>
              <label>
                Название
                <input
                  required
                  maxLength={300}
                  value={c.title}
                  onChange={(e) => set({ ...c, title: e.target.value })}
                />
              </label>
              <label>
                Серия
                <input
                  maxLength={300}
                  value={c.series}
                  onChange={(e) => set({ ...c, series: e.target.value })}
                />
              </label>
              <label>
                Авторы
                <input
                  maxLength={1000}
                  value={c.authors}
                  onChange={(e) => set({ ...c, authors: e.target.value })}
                />
              </label>
              <label>
                Год
                <input
                  type="number"
                  min="1800"
                  max="2200"
                  value={c.year ?? ''}
                  onChange={(e) =>
                    set({ ...c, year: e.target.value ? Number(e.target.value) : null })
                  }
                />
              </label>
            </>
          )}
          {preview.prepared&&<p className="success">Разметка BATCAVE Studio найдена. Кадры и обрезка готовы.</p>}
          <p className="muted">Файл сохранится только на устройстве.</p>
          {target && <div>
            <label className="switch-label"><span>Сохранить прогресс и время чтения</span><input type="checkbox" checked={preserveProgress} disabled={busy} onChange={e => setPreserveProgress(e.target.checked)} /></label>
            <small>Сохраняет текущую страницу, просмотренные страницы и время чтения. Для другого издания можно отключить.</small>
            {preview.count !== target.pageCount && <p className="muted">Количество страниц изменилось: {target.pageCount} → {preview.count}. Прогресс переносится по номерам страниц. Если удаляли или переставляли страницы, после замены проверьте место продолжения чтения.</p>}
          </div>}
          <label className="switch-label"><span>Автоматически распознать кадры</span><input type="checkbox" checked={preview.prepared?false:auto} disabled={busy||preview.prepared} onChange={e=>setAuto(e.target.checked)} /></label>
          <button type="submit" className="primary" disabled={busy}>
            <Upload size={18} />
            {busy ? 'Сохранение…' : target ? 'Прикрепить к комиксу' : 'Сохранить в библиотеку'}
          </button>
        </form>
      )}
    </Modal>
  );
}
