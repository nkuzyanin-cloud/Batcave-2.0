import {useEffect,useState} from 'react';

export function ReadingProgress({value,label,className='',completed}: {value:number;label:string;className?:string;completed?:number}) {
  const percent=Math.max(0,Math.min(100,value));
  const [shown,setShown]=useState(0);
  useEffect(()=>{const frame=requestAnimationFrame(()=>setShown(percent));return()=>cancelAnimationFrame(frame);},[percent]);
  return <span className={`reading-progress ${className}`} role="progressbar" aria-label={label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent}>
    <i className="reading-progress-total" style={{transform:`scaleX(${shown/100})`}}/>
    {completed!==undefined&&<i className="reading-progress-complete" style={{transform:`scaleX(${Math.min(shown,Math.max(0,completed))/100})`}}/>}
  </span>;
}
