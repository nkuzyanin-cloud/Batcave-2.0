import {useEffect,useState} from 'react';
import {BookOpen,Check,Clock,Layers} from 'lucide-react';
import {stats,type Comic} from '../models';
import type {AchievementState} from '../achievements';
import {readerRanks,readerRankAwards,rankArt} from '../reader-ranks';
const num=(n:number)=>n.toLocaleString('ru-RU');
const time=(seconds:number)=>`${num(Math.floor(seconds/3600))} ч ${Math.floor(seconds/60)%60} м`;
export function AchievementsPage({comics,state}:{comics:Comic[];state?:AchievementState}) {
 const [now,setNow]=useState(Date.now());
 useEffect(()=>{if(!comics.some(c=>c.paperStartedAt!==undefined))return;const t=window.setInterval(()=>setNow(Date.now()),15000);return()=>clearInterval(t);},[comics]);
 const s=stats(comics,now),awards=readerRankAwards(comics,state),current=awards.filter(a=>a.earned).at(-1),next=readerRanks[awards.filter(a=>a.earned).length];
 const goals=next?[
  {id:'pages',label:'Прочитанные страницы',value:s.pages,goal:next.pages,icon:Layers,display:`${num(s.pages)} / ${num(next.pages)}`},
  {id:'stories',label:'Завершённые комиксы',value:s.done,goal:next.stories,icon:BookOpen,display:`${num(s.done)} / ${num(next.stories)}`},
  {id:'time',label:'Время за чтением',value:s.seconds,goal:next.hours*3600,icon:Clock,display:`${time(s.seconds)} / ${num(next.hours)} ч`},
 ]:[];
 return <section className={`reader-profile rank-${current?.tier??'none'}`} aria-label="Профиль читателя">
  <div className="rank-hero">{current?<img className="rank-book" src={rankArt(current.tier)} alt={`Награда: ${current.name}`} decoding="async"/>:<div className="rank-before"><BookOpen size={66} strokeWidth={1}/></div>}
   <span className="rank-eyebrow">{current?'Ваш ранг':'Начало истории'}</span><h2>{current?.name??'Всё впереди'}</h2>
  </div>
  <dl className="profile-reading-stats"><div><dd>{num(s.done)}</dd><dt>Прочитано</dt></div><div><dd>{num(s.pages)}</dd><dt>Страниц</dt></div><div><dd>{time(s.seconds)}</dd><dt>За чтением</dt></div></dl>
  {next?<section className="rank-next" aria-labelledby="rank-next-title"><h2 id="rank-next-title">Следующий ранг — {next.name.toLocaleLowerCase('ru')}</h2><div className="rank-goals">{goals.map(g=>{
   const done=g.value>=g.goal;return <div className={`rank-goal ${done?'is-done':''}`} key={g.id} data-rank-goal={g.id}><g.icon className="rank-goal-icon" size={24} strokeWidth={1.6}/><div className="rank-goal-copy"><div className="rank-goal-heading"><span>{g.label}</span><strong>{g.display}</strong></div><div className="rank-meter" role="progressbar" aria-label={g.label} aria-valuemin={0} aria-valuemax={g.goal} aria-valuenow={Math.min(g.goal,g.value)}><i style={{width:`${Math.min(100,g.value/g.goal*100)}%`}}/></div><small>{done?<><Check size={13}/>Готово</>:g.id==='time'?`Осталось ${time(Math.max(0,g.goal-g.value))}`:`Осталось ${num(g.goal-g.value)} ${g.id==='pages'?'стр.':'комикс.'}`}</small></div></div>;
  })}</div></section>:<div className="rank-finale"><Check size={20}/><h2>Платина заслужена</h2><p>Все условия высшего ранга выполнены.</p></div>}
 </section>;
}
