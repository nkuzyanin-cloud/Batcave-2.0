import type { ChronologicalEraId } from '../eras';
import { useState } from 'react';
import { ArrowLeft, Check, LockKeyhole } from 'lucide-react';
import { type Achievement, achievementKinds, nextAchievements } from '../achievements';
import { AchievementBadge, AchievementProgress } from './AchievementBadge';

function remainingText(a:Achievement) {
  const n=a.kind==='time'?Math.ceil((a.goal-a.value)/60):Math.max(0,a.goal-a.value);
  const words=a.kind==='pages'?['страница','страницы','страниц']:a.kind==='stories'?['история','истории','историй']:a.kind==='ratings'?['оценка','оценки','оценок']:a.kind==='time'?['минута','минуты','минут']:['издание','издания','изданий'];
  const index=n%10===1&&n%100!==11?0:n%10>=2&&n%10<=4&&(n%100<12||n%100>14)?1:2;
  return `До цели — ${n.toLocaleString('ru-RU')} ${words[index]}`;
}
const tierNames = {bronze:'Бронза',silver:'Серебро',gold:'Золото',platinum:'Платина'};
export function AchievementsPage({ medals, selected, onSelect, onEra }: { medals: Achievement[]; selected?: string; onSelect: (id?:string) => void; onEra:(era:ChronologicalEraId)=>void }) {
  const [filter,setFilter] = useState<'all'|'earned'|'progress'>('all');
  const detail = medals.find(a => a.id === selected);
  const earned = medals.filter(a => a.earned).length;
  const next=nextAchievements(medals,1)[0];
  const groups=[...achievementKinds].sort((a,b)=>['stories','pages','time','library','paper','ratings'].indexOf(a.id)-['stories','pages','time','library','paper','ratings'].indexOf(b.id));
  const visible = medals.filter(a => filter === 'all' || (filter === 'earned' ? a.earned : !a.earned));
  return <section className="achievements-page" aria-label="Коллекция достижений">
    {detail ? <div className="award-detail" data-achievement-detail={detail.id}>
      <button className="award-back" onClick={() => onSelect(undefined)}><ArrowLeft size={16}/>К коллекции</button>
      <AchievementBadge medal={detail}/>
      <span className={`award-tier tier-label-${detail.tier}`}>{tierNames[detail.tier]}</span>
      <h2>{detail.name}</h2><p>{detail.hint}</p>
      <AchievementProgress medal={detail} label/>
      {detail.era && <button className="era-plan-continue" onClick={()=>onEra(detail.era!)}>Открыть маршрут эры</button>}
      {detail.era && !detail.planned && !detail.earned && <p className="era-plan-hint">Состав маршрута ещё не закреплён.</p>}
      <div className={`award-detail-status ${detail.earned ? 'is-earned' : ''}`}>
        {detail.earned ? <Check size={16}/> : <LockKeyhole size={16}/>}
        <span>{detail.earned ? 'Достижение получено' : 'Ещё впереди'}</span>
      </div>
      {detail.earned && <small className="award-date">{detail.legacy ? 'Зачтено по вашей библиотеке' : detail.earnedAt ? new Date(detail.earnedAt).toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'}) : 'Условие выполнено'}</small>}
    </div> : <>
      <div className="award-overview"><div><span>Ваша коллекция</span><strong><b>{earned}</b> из {medals.length}</strong><div className="award-progress" role="progressbar" aria-label="Коллекция достижений" aria-valuemin={0} aria-valuemax={medals.length} aria-valuenow={earned}><i style={{width:`${earned/Math.max(1,medals.length)*100}%`}}/></div><small>{Math.round(earned/Math.max(1,medals.length)*100)}% завершено</small></div><img src={new URL('../assets/awards/award-46.webp',import.meta.url).href} alt=""/></div>
      <div className="award-filters" role="group" aria-label="Фильтр достижений">
        {([['all','Все'],['earned','Открыты'],['progress','В процессе']] as const).map(([id,label]) => <button key={id} aria-pressed={filter === id} onClick={() => setFilter(id)}>{label}</button>)}
      </div>
      {next&&filter!=='earned'&&<button className="award-nearest" onClick={()=>onSelect(next.id)} aria-label={`Ближайшая цель: ${next.name}`}><AchievementBadge medal={next}/><span><small>Ближайшая цель</small><strong>{next.name}</strong><AchievementProgress medal={next} label/><span className="award-remaining">{remainingText(next)}</span></span></button>}
      {groups.map(kind => {
        const group = visible.filter(a => a.kind === kind.id);
        if (!group.length) return null;
        return <section className="award-category" key={kind.id}>
          <h2>{kind.label}<small>{medals.filter(a => a.kind === kind.id && a.earned).length} / {medals.filter(a => a.kind === kind.id).length}</small></h2>
          <div className="award-grid">
            {group.map(a => <button type="button" key={a.id} className={`award-tile ${a.earned ? 'is-earned' : ''} ${a.id===group.find(g=>!g.earned)?.id?'is-next':''}`} data-achievement={a.id} onClick={() => onSelect(a.id)} aria-label={`${a.name}. ${a.earned ? 'Получено' : `${a.value} из ${a.goal}`}. ${a.hint}`}>
              <AchievementBadge medal={a}/><span className="award-name">{a.name}</span>
              {a.earned ? <small className="award-earned-label" aria-label="Получено"><Check size={12}/></small> : a.era && !a.planned ? <small className="award-plan-label">Маршрут не закреплён</small> : <AchievementProgress medal={a} label/>}
            </button>)}
          </div>
        </section>;
      })}
      {!visible.length && <p className="award-empty">{filter === 'earned' ? 'Первая награда ждёт своей истории.' : 'Вся коллекция собрана. Вот это масштаб!'}</p>}
    </>}
  </section>;
}
