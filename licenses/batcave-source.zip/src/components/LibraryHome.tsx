import {useMemo,useState} from 'react';
import {BookOpen,ChevronRight,Library} from 'lucide-react';
import {type Comic} from '../models';
import {type Universe} from '../universes';
import {continueReading,readingPosition,searchComics,seriesSummaries,standaloneComics} from '../library-home';
import {Card,Cover,Modal} from './ui';
import {UniverseCover} from './Universes';
import {ReadingProgress} from './ReadingProgress';
import {AppIcon} from './AppIcon';


export function SeriesRows({universes,comics,onOpen,shelf=false}:{universes:Universe[];comics:Comic[];onOpen:(id:string)=>void;shelf?:boolean}) {
  const rows=useMemo(()=>seriesSummaries(universes,comics),[universes,comics]);
  return <div className={`library-series-list${shelf?' series-shelf':''}`}>{rows.map(s=><button className="library-series" key={s.universe.id} onClick={()=>onOpen(s.universe.id)} aria-label={`Открыть серию: ${s.universe.title}`}>
    <UniverseCover universe={s.universe} comics={s.comics}/>
    <span className="library-series-copy"><strong>{s.universe.title}</strong><small>{s.total?`${s.done} из ${s.total} прочитано`:'Пока без комиксов'}</small><ReadingProgress className="library-meter" label={`Прогресс серии ${s.universe.title}`} value={s.percent} completed={s.total?s.done/s.total*100:0}/></span>
  </button>)}</div>;
}
export function AllSeriesDialog({universes,comics,onOpen,onClose,onAdd}:{universes:Universe[];comics:Comic[];onOpen:(id:string)=>void;onClose:()=>void;onAdd:()=>void}) {
  const [query,setQuery]=useState('');
  const filtered=universes.filter(u=>u.title.toLocaleLowerCase('ru').includes(query.trim().toLocaleLowerCase('ru')));
  return <Modal title="Все серии" onClose={onClose}><div className="library-all-series"><input type="search" aria-label="Найти серию" placeholder="Найти серию" value={query} onChange={e=>setQuery(e.target.value)}/><SeriesRows universes={filtered} comics={comics} onOpen={onOpen}/>{!filtered.length&&<p className="library-empty">{query?'Серии не найдены':'Добавьте первую серию'}</p>}<button className="library-text-action" onClick={onAdd}>Добавить серию</button></div></Modal>;
}
export function LibraryHome({comics,universes,query,onRead,onEdit,onSeries,onAllSeries,onArchive,onAddSeries}:{comics:Comic[];universes:Universe[];query:string;onRead:(c:Comic,rect?:DOMRect)=>void;onEdit:(c:Comic)=>void;onSeries:(id:string)=>void;onAllSeries:()=>void;onArchive:(standalone?:boolean)=>void;onAddSeries:()=>void}) {
  const [seriesLimit,setSeriesLimit]=useState(6);
  const reading=continueReading(comics),position=reading?readingPosition(reading):undefined;
  const standalone=standaloneComics(comics);
  const q=query.trim().toLocaleLowerCase('ru');
  const matching=useMemo(()=>searchComics(comics,query),[comics,query]);
  const shownSeries=q?universes.filter(u=>u.title.toLocaleLowerCase('ru').includes(q)):universes.slice(0,seriesLimit);
  return <div className="library-home">
    {!q&&<section className="library-section library-resume-section" aria-labelledby="resume-title">
      <h2 id="resume-title">Продолжить чтение</h2>
      {reading&&position?<article className="library-resume">
        <Cover comic={reading}/>
        <div className="library-resume-copy"><strong>{reading.title}</strong>
          <div className="resume-position">
            <span className="resume-ring" role="progressbar" aria-label="Прогресс текущего комикса" aria-valuemin={0} aria-valuemax={100} aria-valuenow={position.percent} aria-valuetext={position.total?`${position.percent}%. Страница ${position.page} из ${position.total}`:'Позиция чтения сохранена'}>
              <svg viewBox="0 0 48 48" aria-hidden="true"><circle className="resume-ring-track" cx="24" cy="24" r="20"/><circle className="resume-ring-fill" cx="24" cy="24" r="20" pathLength="100" strokeDasharray="100" strokeDashoffset={100-position.percent}/></svg>
              <span aria-hidden="true">{position.percent}%</span>
            </span>
            <span className="resume-page">{position.total?<><span>Страница</span><strong>{position.page} из {position.total}</strong></>:<span>Позиция чтения сохранена</span>}</span>
          </div>
          <button type="button" className="resume-read" aria-label={`Продолжить чтение: ${reading.title}`} onClick={e=>onRead(reading,e.currentTarget.closest('.library-resume')?.querySelector('.cover')?.getBoundingClientRect())}><AppIcon icon={BookOpen} size={20}/>Продолжить</button>
        </div>
      </article>:<p className="library-empty library-resume-empty">{comics.length?'Откройте комикс — продолжить можно будет здесь.':'Добавьте комикс, чтобы начать читать.'}</p>}
    </section>}
    <section className="library-section" aria-labelledby="series-title"><div className="library-section-heading"><h2 id="series-title">Серии</h2><button className="library-text-action" onClick={onAllSeries}>Все серии{universes.length>0&&<span>{universes.length}</span>}<AppIcon icon={ChevronRight} size={17}/></button></div>
      <SeriesRows shelf universes={shownSeries} comics={comics} onOpen={onSeries}/>
      {!q&&universes.length>shownSeries.length&&<button className="library-more-series" onClick={()=>setSeriesLimit(limit=>limit+6)} aria-label="Ещё серии — показать следующие 6">Ещё</button>}
      {!shownSeries.length&&<p className="library-empty">{q?'Подходящих серий нет.':<button className="library-text-action" onClick={onAddSeries}>Добавить первую серию</button>}</p>}
      {!q&&<div className="library-archive-links"><button onClick={()=>onArchive()}><AppIcon icon={Library} size={21}/><strong>Все комиксы</strong><span>{comics.length}</span><AppIcon icon={ChevronRight} size={17}/></button>{standalone.length>0&&<button onClick={()=>onArchive(true)}><strong>Без серии</strong><span>{standalone.length}</span><AppIcon icon={ChevronRight} size={17}/></button>}</div>}
    </section>
    {q?<section className="library-section"><div className="library-section-heading"><h2>Комиксы</h2><span className="library-count">{matching.length}</span></div>{matching.length?<div className="comic-grid collection-grid">{matching.map(c=><Card key={c.id} comic={c} collection paper={c.physical==='yes'} onClick={rect=>c.digital?onRead(c,rect):onEdit(c)} onEdit={()=>onEdit(c)}/>)}</div>:<p className="library-empty">Комиксы не найдены. Попробуйте другое название или автора.</p>}</section>:null}
  </div>;
}
