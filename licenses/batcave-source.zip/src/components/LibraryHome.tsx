import {useEffect,useMemo,useState} from 'react';
import {BookOpen,ChevronRight,Library} from 'lucide-react';
import {type Comic,stats} from '../models';
import {type Universe} from '../universes';
import {continueReading,readingPosition,searchComics,seriesSummaries,standaloneComics} from '../library-home';
import {Card,Cover,Modal} from './ui';
import {UniverseCover} from './Universes';
import {ReadingProgress} from './ReadingProgress';
import {AppIcon} from './AppIcon';
import {ReaderShelf} from './ReaderShelf';

export function SeriesRows({universes,comics,onOpen,shelf=false}:{universes:Universe[];comics:Comic[];onOpen:(id:string)=>void;shelf?:boolean}) {
  const rows=useMemo(()=>seriesSummaries(universes,comics),[universes,comics]);
  return <div className={`library-series-list${shelf?' series-shelf':''}`}>{rows.map(s=><button className="library-series" key={s.universe.id} onClick={()=>onOpen(s.universe.id)} aria-label={`Открыть серию: ${s.universe.title}`}>
    <UniverseCover universe={s.universe} comics={s.comics}/>
    <span className="library-series-copy"><strong>{s.universe.title}</strong><small>{s.total?`${s.done} из ${s.total} прочитано`:'Пока без комиксов'}</small><ReadingProgress className="library-meter" label={`Прогресс серии ${s.universe.title}`} value={s.percent} completed={s.total?s.done/s.total*100:0}/></span>
  </button>)}</div>;
}
export function AllSeriesDialog({universes,comics,onOpen,onClose,onAdd}:{universes:Universe[];comics:Comic[];onOpen:(id:string)=>void;onClose:()=>void;onAdd:()=>void}) {
  const [query,setQuery]=useState('');
  const filtered=universes.filter(u=>u.title.toLocaleLowerCase('ru').includes(query.trim().toLocaleLowerCase('ru')));
  return <Modal title="Все серии" onClose={onClose}><div className="library-all-series"><input type="search" aria-label="Найти серию" placeholder="Найти серию" value={query} onChange={e=>setQuery(e.target.value)}/><SeriesRows universes={filtered} comics={comics} onOpen={onOpen}/>{!filtered.length&&<p className="library-empty">{query?'Серии не найдены':'Добавьте первую серию'}</p>}<button className="library-text-action" onClick={onAdd}>Добавить серию</button></div></Modal>;
}
export function LibraryHome({comics,universes,query,onRead,onEdit,onSeries,onAllSeries,onArchive,onAddSeries}:{comics:Comic[];universes:Universe[];query:string;onRead:(c:Comic,rect?:DOMRect)=>void;onEdit:(c:Comic)=>void;onSeries:(id:string)=>void;onAllSeries:()=>void;onArchive:(standalone?:boolean)=>void;onAddSeries:()=>void}) {
  const [seriesLimit,setSeriesLimit]=useState(6);
  const [now,setNow]=useState(Date.now());
  useEffect(()=>{if(!comics.some(c=>c.paperStartedAt!==undefined))return;const timer=window.setInterval(()=>setNow(Date.now()),15000);return()=>clearInterval(timer);},[comics]);
  const reading=continueReading(comics),position=reading?readingPosition(reading):undefined,s=stats(comics,now);
  const standalone=standaloneComics(comics);
  const q=query.trim().toLocaleLowerCase('ru');
  const matching=useMemo(()=>searchComics(comics,query),[comics,query]);
  const shownSeries=q?universes.filter(u=>u.title.toLocaleLowerCase('ru').includes(q)):universes.slice(0,seriesLimit);
  return <div className="library-home">
    {!q&&<section className="library-section library-statistics" aria-labelledby="stats-title"><h2 id="stats-title" className="sr-only">Статистика чтения</h2><ReaderShelf pages={s.pages} hasComics={comics.length>0}/><dl className="library-stats"><div><dt>Прочитано</dt><dd>{s.done.toLocaleString('ru-RU')}</dd></div><div><dt>Страниц</dt><dd className={s.pages>=100000?'library-long-count':undefined}>{s.pages.toLocaleString('ru-RU')}</dd></div><div><dt>За чтением</dt><dd className="library-time">{Math.floor(s.seconds/3600).toLocaleString('ru-RU')}<small> ч </small>{Math.floor(s.seconds/60)%60}<small> м</small></dd></div></dl></section>}
    {!q&&<section className="library-section library-resume-section" aria-labelledby="resume-title">
      <h2 id="resume-title">Продолжить чтение</h2>
      {reading&&position?<button className="library-resume" onClick={e=>onRead(reading,e.currentTarget.querySelector('.cover')?.getBoundingClientRect())} aria-label={`Продолжить чтение: ${reading.title}`}>
        <Cover comic={reading}/>
        <span className="library-resume-copy"><strong>{reading.title}</strong><small>{position.total?`Страница ${position.page} из ${position.total}`:'Позиция чтения сохранена'}</small>
          <span className="resume-position"><ReadingProgress className="library-meter" label="Прогресс текущего комикса" value={position.percent}/><span>{position.percent}%</span></span>
          <span className="resume-read"><AppIcon icon={BookOpen} size={18}/>Читать</span>
        </span>
      </button>:<p className="library-empty library-resume-empty">{comics.length?'Откройте комикс — продолжить можно будет здесь.':'Добавьте комикс, чтобы начать читать.'}</p>}
    </section>}
    <section className="library-section" aria-labelledby="series-title"><div className="library-section-heading"><h2 id="series-title">Серии</h2><button className="library-text-action" onClick={onAllSeries}>Все серии{universes.length>0&&<span>{universes.length}</span>}<AppIcon icon={ChevronRight} size={17}/></button></div>
      <SeriesRows shelf universes={shownSeries} comics={comics} onOpen={onSeries}/>
      {!q&&universes.length>shownSeries.length&&<button className="library-more-series" onClick={()=>setSeriesLimit(limit=>limit+6)} aria-label="Ещё серии — показать следующие 6">Ещё</button>}
      {!shownSeries.length&&<p className="library-empty">{q?'Подходящих серий нет.':<button className="library-text-action" onClick={onAddSeries}>Добавить первую серию</button>}</p>}
      {!q&&<div className="library-archive-links"><button onClick={()=>onArchive()}><AppIcon icon={Library} size={21}/><strong>Все комиксы</strong><span>{comics.length}</span><AppIcon icon={ChevronRight} size={17}/></button>{standalone.length>0&&<button onClick={()=>onArchive(true)}><strong>Без серии</strong><span>{standalone.length}</span><AppIcon icon={ChevronRight} size={17}/></button>}</div>}
    </section>
    {q?<section className="library-section"><div className="library-section-heading"><h2>Комиксы</h2><span className="library-count">{matching.length}</span></div>{matching.length?<div className="comic-grid collection-grid">{matching.map(c=><Card key={c.id} comic={c} collection paper={c.physical==='yes'} onClick={rect=>c.digital?onRead(c,rect):onEdit(c)} onEdit={()=>onEdit(c)}/>)}</div>:<p className="library-empty">Комиксы не найдены. Попробуйте другое название или автора.</p>}</section>:null}
  </div>;
}
