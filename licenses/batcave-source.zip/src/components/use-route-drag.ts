import {useEffect,useRef,useState,type PointerEvent as ReactPointerEvent,type TouchEvent as ReactTouchEvent,type RefObject} from 'react';
import type {Comic} from '../models';

export interface RouteDrop {era:string;beforeId?:string}
interface Session {comic:Comic;x:number;y:number;startX:number;startY:number;active:boolean;pointer?:number;touch?:number;target?:RouteDrop}

export function useRouteDrag(root:RefObject<HTMLElement|null>,disabled:boolean,onDrop:(comic:Comic,target:RouteDrop)=>void) {
  const [dragging,setDragging]=useState<Comic>();
  const [target,setTarget]=useState<RouteDrop>();
  const session=useRef<Session|undefined>(undefined);
  const cleanup=useRef<()=>void>(()=>{}),frame=useRef(0),hold=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
  const suppressed=useRef<string|undefined>(undefined),releaseTimer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
  const latest=useRef(onDrop);latest.current=onDrop;
  function finish(commit=false) {
    const s=session.current;session.current=undefined;
    clearTimeout(hold.current);cancelAnimationFrame(frame.current);cleanup.current();cleanup.current=()=>{};
    setDragging(undefined);setTarget(undefined);
    if(s?.active){clearTimeout(releaseTimer.current);releaseTimer.current=setTimeout(()=>{suppressed.current=undefined;},700);}
    if(commit&&s?.active&&s.target)latest.current(s.comic,s.target);
  }
  const finishRef=useRef(finish);finishRef.current=finish;
  useEffect(()=>()=>{clearTimeout(hold.current);clearTimeout(releaseTimer.current);cancelAnimationFrame(frame.current);cleanup.current();},[]);
  useEffect(()=>{if(disabled&&session.current)finishRef.current();},[disabled]);
  function locate(s:Session) {
    const hit=document.elementFromPoint(s.x,s.y);
    const section=hit?.closest<HTMLElement>('[data-route-section]');
    let next:RouteDrop|undefined;
    if(section&&root.current?.contains(section)){
      const row=hit?.closest<HTMLElement>('[data-comic-id]');
      let beforeId:string|undefined;
      const rows=Array.from(section.querySelectorAll<HTMLElement>('[data-comic-id]')).filter(el=>el.dataset.comicId!==s.comic.id);
      if(row){
        const box=row.getBoundingClientRect();
        if(row.dataset.comicId===s.comic.id)beforeId=rows.find(el=>el.getBoundingClientRect().top>box.top)?.dataset.comicId;
        else if(s.y<box.top+box.height/2)beforeId=row.dataset.comicId;
        else beforeId=rows[rows.indexOf(row)+1]?.dataset.comicId;
      }else if(hit?.closest('.route-section-heading'))beforeId=rows[0]?.dataset.comicId;
      next={era:section.dataset.routeSection!,beforeId};
    }
    if(next?.era!==s.target?.era||next?.beforeId!==s.target?.beforeId){s.target=next;setTarget(next);}
  }
  function tick(){
    const s=session.current;if(!s?.active)return;
    const ghost=document.querySelector<HTMLElement>('[data-route-ghost]');
    if(ghost)ghost.style.transform=`translate3d(${Math.min(innerWidth-175,Math.max(8,s.x+12))}px,${Math.max(8,s.y-50)}px,0)`;
    const scroll=root.current?.closest<HTMLElement>('.screen');
    if(scroll){const b=scroll.getBoundingClientRect();const speed=s.y<b.top+65?-Math.min(16,(b.top+65-s.y)/4):s.y>b.bottom-65?Math.min(16,(s.y-b.bottom+65)/4):0;if(speed)scroll.scrollTop+=speed;}
    locate(s);frame.current=requestAnimationFrame(tick);
  }
  function begin(comic:Comic,x:number,y:number,ids:{pointer?:number;touch?:number}){
    if(disabled)return;
    finish();suppressed.current=undefined;
    session.current={comic,x,y,startX:x,startY:y,active:false,...ids};
    hold.current=setTimeout(()=>{
      const s=session.current;if(!s)return;s.active=true;suppressed.current=comic.id;
      setDragging(comic);navigator.vibrate?.(12);tick();
    },600);
    const move=(x:number,y:number,event:Event)=>{
      const s=session.current;if(!s)return;
      if(!s.active&&Math.hypot(x-s.startX,y-s.startY)>9){finish();return;}
      s.x=x;s.y=y;if(s.active&&event.cancelable)event.preventDefault();
    };
    const pointerMove=(e:PointerEvent)=>{if(e.pointerId===session.current?.pointer)move(e.clientX,e.clientY,e);};
    const pointerEnd=(e:PointerEvent)=>{if(e.pointerId===session.current?.pointer)finish(true);};
    const touchMove=(e:TouchEvent)=>{
      if(e.touches.length!==1){finish();return;}
      const t=Array.from(e.touches).find(t=>t.identifier===session.current?.touch);if(t)move(t.clientX,t.clientY,e);
    };
    const touchEnd=(e:TouchEvent)=>{if(Array.from(e.changedTouches).some(t=>t.identifier===session.current?.touch))finish(true);};
    const cancel=()=>finish();
    const escape=(e:KeyboardEvent)=>{if(e.key==='Escape'){e.preventDefault();finish();}};
    const scroll=()=>{if(session.current&&!session.current.active)finish();};
    const extraTouch=(e:TouchEvent)=>{if(e.touches.length>1)finish();};
    if(ids.touch!==undefined){document.addEventListener('touchmove',touchMove,{passive:false});document.addEventListener('touchend',touchEnd);document.addEventListener('touchcancel',cancel);document.addEventListener('touchstart',extraTouch);}
    else {document.addEventListener('pointermove',pointerMove,{passive:false});document.addEventListener('pointerup',pointerEnd);document.addEventListener('pointercancel',cancel);}
    document.addEventListener('keydown',escape);document.addEventListener('scroll',scroll,true);document.addEventListener('visibilitychange',cancel);window.addEventListener('blur',cancel);
    cleanup.current=()=>{
      document.removeEventListener('pointermove',pointerMove);document.removeEventListener('pointerup',pointerEnd);document.removeEventListener('pointercancel',cancel);
      document.removeEventListener('touchmove',touchMove);document.removeEventListener('touchend',touchEnd);document.removeEventListener('touchcancel',cancel);document.removeEventListener('touchstart',extraTouch);
      document.removeEventListener('keydown',escape);document.removeEventListener('scroll',scroll,true);document.removeEventListener('visibilitychange',cancel);window.removeEventListener('blur',cancel);
    };
  }
  return {dragging,target,
    startPointer:(c:Comic,e:ReactPointerEvent)=>{if(e.pointerType!=='touch'&&e.isPrimary&&e.button===0)begin(c,e.clientX,e.clientY,{pointer:e.pointerId});},
    startTouch:(c:Comic,e:ReactTouchEvent)=>{if(e.touches.length===1){const t=e.touches[0];begin(c,t.clientX,t.clientY,{touch:t.identifier});}},
    consumeClick:(id:string)=>{if(suppressed.current===id){suppressed.current=undefined;return true;}return false;},
    resetClick:()=>{suppressed.current=undefined;}
  };
}
