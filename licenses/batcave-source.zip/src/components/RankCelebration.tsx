import type {CSSProperties} from 'react';
import {BookOpen,Clock,Layers} from 'lucide-react';
import {readerRanks,rankArt} from '../reader-ranks';
import {Modal} from './ui';
import '../rank-celebration.css';

type ReaderRank = typeof readerRanks[number];
const particles = Array.from({length:14},(_,i)=>({
 '--particle-x':`${12+(i*31)%78}%`,
 '--particle-y':`${18+(i*19)%61}%`,
 '--particle-delay':`${180+(i*137)%1100}ms`,
 '--particle-drift':`${(i%2?1:-1)*(8+i%5*4)}px`,
}) as CSSProperties);

export function RankCelebration({rank,onClose}:{rank:ReaderRank;onClose:()=>void}) {
 const art=rankArt(rank.tier);
 return <Modal title="Новый ранг" focusDialog onClose={onClose} className={`rank-celebration rank-celebration-${rank.tier}`}>
  <div className="rank-celebration-content">
   <div className="rank-celebration-stage" aria-hidden="true">
    <div className="rank-celebration-halo"/>
    <div className="rank-celebration-orbit"/>
    <div className="rank-celebration-particles">{particles.map((style,i)=><i key={i} style={style}/>)}</div>
    <div className="rank-celebration-reveal"><div className="rank-celebration-float">
     <img src={art} alt="" decoding="async" draggable={false}/>
     <span className="rank-celebration-glint" style={{maskImage:`url("${art}")`,WebkitMaskImage:`url("${art}")`}}/>
    </div></div>
   </div>
   <h2 className="rank-celebration-name">{rank.name}</h2>
   <dl className="rank-celebration-stats">
    <div><Layers size={20} strokeWidth={1.5} aria-hidden="true"/><dd>{rank.pages.toLocaleString('ru-RU')}</dd><dt>страниц</dt></div>
    <div><BookOpen size={20} strokeWidth={1.5} aria-hidden="true"/><dd>{rank.stories}</dd><dt>комиксов</dt></div>
    <div><Clock size={20} strokeWidth={1.5} aria-hidden="true"/><dd>{rank.hours} ч</dd><dt>за чтением</dt></div>
   </dl>
   <button type="button" className="rank-celebration-continue" onClick={onClose}>Продолжить</button>
  </div>
 </Modal>;
}
