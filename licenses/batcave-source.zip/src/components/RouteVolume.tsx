import {useRef} from 'react';
import {BookOpen,Check,ChevronDown,Ellipsis,Plus,Star} from 'lucide-react';
import {type Comic,status} from '../models';
import {routeProgress} from '../library-home';
import {Cover} from './ui';
import {ReadingProgress} from './ReadingProgress';
import type {RouteRowActions} from './Roadmap';

export function RouteVolume({title,number,entries,expanded,bodyId,busy,onOpen,onMenu,onAdd,onEdit,actions}:{
  title:string;number:number;entries:Comic[];expanded:boolean;bodyId:string;busy:boolean;
  onOpen:(rect:DOMRect)=>void;onMenu:()=>void;onAdd:()=>void;onEdit:(comic:Comic)=>void;actions:RouteRowActions;
}) {
  const comic=entries[0],single=entries.length===1,done=entries.filter(c=>c.completed).length;
  const finished=!!entries.length&&done===entries.length,reading=entries.some(c=>status(c)==='reading');
  const count=entries.length,ending=count%10===1&&count%100!==11?'выпуск':count%10>=2&&count%10<=4&&(count%100<12||count%100>14)?'выпуска':'выпусков';
  const start=useRef<{x:number;y:number}|undefined>(undefined),swiped=useRef(false);
  return <>
    <div className="route-volume-heading"><span className="route-single-kicker">РАЗДЕЛ {String(number).padStart(2,'0')}</span>
      {!!count&&<button className="icon-button route-volume-menu" aria-label={single?`Меню выпуска: ${comic.title}`:`Меню раздела: ${title}`} disabled={busy} onClick={onMenu}><Ellipsis size={19}/></button>}
    </div>
    {comic?<>
      <button className="route-volume-open" disabled={busy} aria-label={single?`${comic.digital?'Читать':'Открыть'}: ${comic.title}`:`${expanded?'Свернуть':'Раскрыть'} раздел «${title}»`}
        aria-expanded={single?undefined:expanded} aria-controls={single?undefined:bodyId} title={title}
        onPointerDown={e=>{start.current={x:e.clientX,y:e.clientY};swiped.current=false;}}
        onPointerMove={e=>{if(start.current&&Math.hypot(e.clientX-start.current.x,e.clientY-start.current.y)>10)swiped.current=true;}}
        onClick={e=>{if(swiped.current||(single&&actions.consumeClick?.(comic.id))){e.preventDefault();return;}onOpen(e.currentTarget.querySelector('.cover')!.getBoundingClientRect());}}
        onContextMenu={e=>e.preventDefault()} onDragStart={e=>e.preventDefault()}
        onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){swiped.current=false;actions.resetClick?.();}else if(e.key==='F2'&&single){e.preventDefault();onEdit(comic);}else if(e.shiftKey&&e.key==='F10'){e.preventDefault();onMenu();}}}>
        <span className={`route-volume-cover ${single?'series-cover-handle':''}`} onPointerDown={e=>{if(single)actions.onHoldPointer?.(comic,e);}} onTouchStart={e=>{if(single)actions.onHoldTouch?.(comic,e);}}>
          <Cover comic={comic} paper={comic.physical==='yes'}/>
          {finished&&<span className="route-volume-done" aria-hidden="true"><Check size={15}/></span>}
        </span>
        <span className="route-volume-title"><strong className="route-section-name">{title}</strong>{!single&&<ChevronDown className="route-volume-chevron" size={19}/>}</span>
      </button>
      <span className="route-volume-meta">{single?'1 комикс':`${count} ${ending}`}</span>
      <div className="route-volume-status"><span>{finished?'Прочитано':done?`${done} из ${count} прочитано`:reading?'Читаю сейчас':'Не начато'}</span>
        {single&&finished&&comic.rating>0&&<span className="series-comic-rating" role="img" aria-label={`Оценка: ${comic.rating} из 5`}>{[1,2,3,4,5].map(n=><Star key={n} size={11} className={n<=comic.rating?'is-filled':''} aria-hidden="true"/>)}</span>}
      </div>
      {!finished&&(done>0||reading)&&<ReadingProgress className="route-volume-progress" label={`Прогресс раздела ${title}`} value={routeProgress(entries)}/>}
    </>:<button className="route-volume-empty" disabled={busy} aria-label={`Добавить комикс в раздел «${title}»`} onClick={onAdd}>
      <span><BookOpen size={24}/><Plus size={15}/></span><strong className="route-section-name">{title}</strong><small>Добавить комикс</small>
    </button>}
  </>;
}
