import { useId } from 'react';
import { achievementCatalog, type Achievement } from '../achievements';

// Small native illustrations stay crisp offline and never contain generated anatomy.
const BAT = 'M2 3H67C69 15 73 17 84 18C89 19 92 19 93 17L94 6L96 13Q100 12 104 13L106 6L107 17C108 19 111 19 116 18C127 17 131 15 133 3H198C174 13 165 26 169 41C134 39 111 43 100 71C89 43 66 39 31 41C35 26 26 13 2 3Z';
export function BatGlyph({x=25,y=44,w=70,h=30,className=''}:{x?:number;y?:number;w?:number;h?:number;className?:string}) {
  return <svg x={x} y={y} width={w} height={h} viewBox="0 0 200 74" className={className}><path d={BAT}/></svg>;
}
export function Cowl({x=28,y=21,w=64,h=78,fractured=false}:{x?:number;y?:number;w?:number;h?:number;fractured?:boolean}) {
  return <svg x={x} y={y} width={w} height={h} viewBox="0 0 100 110">
    <path d="M16 105L9 51L13 3L35 28Q50 21 65 28L87 3L91 51L84 105L66 97L50 109L34 97Z" fill="var(--badge-ink)" stroke="var(--badge-high)" strokeWidth="2"/>
    <path d="M15 54L38 63L30 70L17 64ZM85 54L62 63L70 70L83 64Z" fill="var(--badge-light)"/>
    <path d="M50 50L43 82H56L50 50M34 97L38 84H62L66 97M38 91H62" fill="none" stroke="var(--badge-mid)" strokeWidth="2"/>
    {fractured && <path d="M56 24L45 48L59 66L44 85L54 109" stroke="var(--badge-accent)" strokeWidth="3" fill="none"/>}
  </svg>;
}
function Skyline({y=92,variant=0}:{y?:number;variant?:number}) {
  return <g fill="var(--badge-mid)" stroke="var(--badge-high)" strokeWidth=".7">
    {Array.from({length:7},(_,i) => {const h=15+(i*13+variant*9)%34;return <g key={i}><path d={`M${16+i*12} ${y}v-${h}h8v${h}Z`}/><path d={`M${20+i*12} ${y-h}v-5`} fill="none"/>{[0,1].map(n=><path key={n} d={`M${19+i*12} ${y-h+6+n*6}h2`} stroke="var(--badge-light)"/>)}</g>;})}
  </g>;
}
function Signal({x=22,y=22,size=76}:{x?:number;y?:number;size?:number}) {
  return <svg x={x} y={y} width={size} height={size} viewBox="0 0 80 80"><path d="M25 66H55L59 74H21ZM33 53V67H47V53" fill="var(--badge-mid)" stroke="var(--badge-high)" strokeWidth="2"/><circle cx="40" cy="31" r="28" fill="var(--badge-mid)" stroke="var(--badge-high)" strokeWidth="3"/><circle cx="40" cy="31" r="23" fill="var(--badge-light)"/><BatGlyph x={15} y={20} w={50} h={23} className="badge-dark-bat"/></svg>;
}
function Computer({variant=0}:{variant?:number}) {
  const screens=variant===0 ? 1 : variant<3 ? 3 : 5;
  return <g stroke="var(--badge-high)" strokeWidth="1.7" strokeLinejoin="round">
    <path d="M16 83H104L111 97H9Z" fill="var(--badge-mid)"/><path d="M28 89H89M35 94H83M27 97V104M93 97V104"/>
    {Array.from({length:screens},(_,i) => {
      const w=screens===1?66:screens===3?29:22, x=screens===1?27:screens===3?14+i*31:5+i*22;
      const y=screens===1?29:screens===3?31+Math.abs(i-1)*5:37+Math.abs(i-2)*4;
      return <g key={i}><rect x={x} y={y} width={w} height={39} rx={2} fill="var(--badge-ink)"/>{i===Math.floor(screens/2) ? <BatGlyph x={x+3} y={y+11} w={w-6} h={18} className="badge-screen-bat"/> : <path d={`M${x+4} ${y+10}h${w-8}m-${w-8} 6h${w-12}m-${w-12} 6h${w-8}`} stroke="var(--badge-screen)" strokeWidth="1"/>}</g>;
    })}
    {variant>1 && <path d="M17 25H31V18M103 25H89V18M20 76H11M100 76H109" stroke="var(--badge-accent)"/>}
  </g>;
}
function Star({cx=60,cy=59,r=31}:{cx?:number;cy?:number;r?:number}) {
  const points=Array.from({length:10},(_,i)=>{const radius=i%2?r*.45:r,angle=-Math.PI/2+i*Math.PI/5;return `${cx+Math.cos(angle)*radius},${cy+Math.sin(angle)*radius}`;}).join(' ');
  return <polygon points={points} fill="var(--badge-mid)" stroke="var(--badge-high)" strokeWidth="1.5"/>;
}
function PagePanels({variant}:{variant:number}) {
  const n=variant%3+1;
  return <g stroke="var(--badge-high)" strokeWidth="1.5" strokeLinejoin="round">
    {Array.from({length:n},(_,i)=><path key={i} d={`M${24+i*4} ${25-i*4}H${85+i*4}V${96-i*4}H${24+i*4}Z`} fill="var(--badge-ink)"/>)}
    <path d="M31 31H81V63H31ZM31 69H53V88H31ZM59 69H81V88H59Z" fill="var(--badge-mid)"/>
    <BatGlyph x={35} y={39} w={42} h={18} className="badge-panel-bat"/>
    {variant>4 && <path d="M35 84V79H39V75H43V81H47V85M63 84L69 74L76 84" stroke="var(--badge-light)" fill="none"/>}
    {variant>7 && <path d="M20 36L14 42V87L21 94M94 28L101 36V80L95 86" stroke="var(--badge-accent)" fill="none"/>}
  </g>;
}
function Shelf({variant}:{variant:number}) {
  return <g stroke="var(--badge-high)" strokeWidth="1.5" strokeLinejoin="round">
    <path d="M15 94H105V102H15ZM21 30H99V94H21Z" fill="var(--badge-ink)"/>
    {Array.from({length:variant%3+4},(_,i)=>{const h=38+(i*7+variant*3)%19;return <g key={i}><path d={`M${28+i*10} 90v-${h}h7v${h}Z`} fill="var(--badge-mid)"/><path d={`M${29+i*10} ${96-h}h5M${29+i*10} 83h5`} stroke="var(--badge-light)" strokeWidth="1"/></g>;})}
    <BatGlyph x={39} y={17} w={42} h={18}/>
    {variant>2 && <path d="M16 32L60 12L104 32M13 39V101M107 39V101" fill="none" stroke="var(--badge-accent)"/>}
  </g>;
}
function EraSymbol({id}:{id:string}) {
  switch(id) {
    case 'early':return <><Skyline variant={1}/><Cowl x={32} y={18} w={56} h={75}/></>;
    case 'family':return <><BatGlyph x={25} y={26} w={70} h={29}/><path d="M52 55H72Q87 56 85 67Q84 75 72 76L88 96H70L55 76H48L43 96H29L39 55ZM53 64L51 70H66Q71 70 71 66Q71 64 66 64Z" fill="var(--badge-red)" stroke="var(--badge-high)" strokeWidth="1"/></>;
    case 'knightfall':return <Cowl x={24} y={14} w={72} h={88} fractured/>;
    case 'no-mans-land':return <><Skyline variant={5}/><path d="M62 22L51 45L69 56L48 79L62 104" stroke="var(--badge-accent)" strokeWidth="4" fill="none"/><BatGlyph x={19} y={22} w={36} h={16}/><path d="M20 98L42 89M79 87L101 98" stroke="var(--badge-high)" strokeWidth="2"/></>;
    case 'new-gotham':return <><path d="M18 101V44L34 25V100M86 100V25L102 44V101M42 101V38L60 15L78 38V101" fill="var(--badge-mid)" stroke="var(--badge-high)" strokeWidth="2"/><path d="M48 45H72M48 53H72M48 61H72" stroke="var(--badge-light)"/><BatGlyph x={17} y={61} w={86} h={34}/></>;
    case 'legacy':return <><Cowl x={17} y={45} w={34} h={47}/><Cowl x={69} y={45} w={34} h={47}/><Cowl x={36} y={15} w={48} h={69}/><BatGlyph x={25} y={89} w={70} h={22}/></>;
    case 'new-52':return <><path d="M75 16L44 58H61L44 100L83 52H66L87 16Z" fill="var(--badge-red)" stroke="var(--badge-high)"/><BatGlyph x={18} y={37} w={84} h={35}/><path d="M24 89L36 95M85 95L96 89" stroke="var(--badge-high)" strokeWidth="2"/></>;
    case 'rebirth':return <><circle cx="60" cy="58" r="32" stroke="var(--badge-accent)" strokeWidth="4" fill="none"/><path d="M35 31L44 18M76 18L85 31M20 61H9M100 61H111" stroke="var(--badge-high)" strokeWidth="2"/><BatGlyph x={13} y={43} w={94} h={40}/></>;
    case 'infinite-frontier':return <><ellipse cx="60" cy="59" rx="45" ry="20" transform="rotate(-30 60 59)" fill="none" stroke="var(--badge-high)" strokeWidth="2"/><ellipse cx="60" cy="59" rx="45" ry="20" transform="rotate(30 60 59)" fill="none" stroke="var(--badge-accent)" strokeWidth="2"/><BatGlyph x={22} y={44} w={76} h={30}/><path d="M60 14V26M54 20H66M24 86L17 93M93 86L100 93" stroke="var(--badge-light)" strokeWidth="2"/></>;
    case 'dawn-of-dc':return <><path d="M25 69A35 35 0 0 1 95 69" fill="var(--badge-accent)" opacity=".65"/><path d="M60 14V25M25 27L33 36M95 27L87 36M13 56H25M95 56H107" stroke="var(--badge-high)" strokeWidth="2"/><Skyline variant={3}/><BatGlyph x={23} y={44} w={74} h={29}/></>;
    default:return <><path d="M21 34H31V19H43M99 34H89V19H77M16 68H28M104 68H92M29 97H41M91 97H79" fill="none" stroke="var(--badge-screen)" strokeWidth="2"/><Cowl x={30} y={13} w={60} h={89}/><path d="M49 98L60 108L71 98" fill="none" stroke="var(--badge-accent)" strokeWidth="2"/></>;
  }
}
function StorySymbol({variant}:{variant:number}) {
  switch(variant) {
    case 0:return <><BatGlyph x={9} y={39} w={102} h={43}/><path d="M29 32L36 22M91 32L84 22" stroke="var(--badge-high)" strokeWidth="2"/></>;
    case 1:return <><Skyline variant={1}/><BatGlyph x={17} y={23} w={86} h={35}/><path d="M22 103L60 88L98 103" fill="none" stroke="var(--badge-high)" strokeWidth="2"/></>;
    case 2:return <><path d="M60 17V30M46 38Q46 25 60 25Q74 25 74 38L65 49V77Q65 89 51 96" fill="none" stroke="var(--badge-high)" strokeWidth="4"/><BatGlyph x={18} y={49} w={84} h={34}/></>;
    case 3:return <><Cowl x={31} y={17} w={58} h={83}/><path d="M21 49L14 75L25 91M99 49L106 75L95 91" stroke="var(--badge-high)" strokeWidth="2" fill="none"/></>;
    case 4:return <Signal/>;
    case 5:return <><path d="M15 79L23 63L39 59L48 46H77L88 60L103 66L109 81L101 90H18Z" fill="var(--badge-ink)" stroke="var(--badge-high)" strokeWidth="2"/><path d="M43 59L52 49H73L81 59Z" fill="var(--badge-screen)"/><circle cx="32" cy="85" r="10" fill="var(--badge-mid)" stroke="var(--badge-high)" strokeWidth="2"/><circle cx="89" cy="85" r="10" fill="var(--badge-mid)" stroke="var(--badge-high)" strokeWidth="2"/><BatGlyph x={31} y={22} w={58} h={25}/></>;
    case 6:return <Computer variant={3}/>;
    case 7:return <><Skyline variant={4}/><circle cx="79" cy="31" r="18" fill="var(--badge-light)" opacity=".4"/><BatGlyph x={17} y={32} w={90} h={39}/><path d="M28 107L60 94L92 107" stroke="var(--badge-high)" strokeWidth="2" fill="none"/></>;
    case 8:return <><path d="M10 37L32 46L29 78L60 105L91 78L88 46L110 37L100 87L60 115L20 87Z" fill="var(--badge-mid)" stroke="var(--badge-high)"/><Cowl x={33} y={13} w={54} h={79}/></>;
    default:return <><path d="M9 39L37 52L60 17L83 52L111 39L92 84L60 108L28 84Z" fill="var(--badge-mid)" stroke="var(--badge-high)" strokeWidth="2"/><BatGlyph x={13} y={46} w={94} h={40}/><path d="M43 19L47 31M77 19L73 31" stroke="var(--badge-light)" strokeWidth="2"/></>;
  }
}
export function BadgeArt({medal}:{medal:Achievement}) {
  const uid = useId().replace(/:/g,'');
  const variant = achievementCatalog.filter(a => a.kind === medal.kind).findIndex(a => a.id === medal.id);
  const frames = ['M60 7L105 27L99 78L60 114L21 78L15 27Z','M32 8H88L111 32V87L60 114L9 87V32Z','M60 6L111 34L103 87L60 115L17 87L9 34Z','M60 5L112 59L60 115L8 59Z','M16 111V45Q16 8 60 8Q104 8 104 45V111Z'];
  const frame = frames[(medal.art + (medal.era ? 2 : 0)) % frames.length];
  const isBare = medal.id === 'first';
  return <svg className="award-vector" viewBox="0 0 120 124" aria-hidden="true">
    <defs>
      <linearGradient id={`edge-${uid}`} x1="0" y1="0" x2=".8" y2="1"><stop stopColor="var(--badge-high)"/><stop offset=".38" stopColor="var(--badge-mid)"/><stop offset=".62" stopColor="var(--badge-high)"/><stop offset="1" stopColor="var(--badge-low)"/></linearGradient>
      <radialGradient id={`face-${uid}`}><stop stopColor="var(--badge-face)"/><stop offset="1" stopColor="var(--badge-ink)"/></radialGradient>
    </defs>
    {!isBare && <><path d={frame} fill={`url(#edge-${uid})`} stroke="var(--badge-low)" strokeWidth="1"/><path d={frame} transform="translate(5 5) scale(.9167)" fill={`url(#face-${uid})`} stroke="var(--badge-high)" strokeWidth=".8"/><path d={frame} transform="translate(9 9) scale(.85)" fill="none" stroke="var(--badge-mid)" strokeWidth=".5"/></>}
    <g fill="var(--badge-high)">
      {medal.era ? <EraSymbol id={medal.era}/> : medal.kind === 'stories' ? <StorySymbol variant={variant}/> : medal.kind === 'pages' ? <PagePanels variant={variant}/> : medal.kind === 'library' ? <Computer variant={variant}/> : medal.kind === 'paper' ? <Shelf variant={variant}/> : medal.kind === 'ratings' ? <><Star r={32+variant*3}/><BatGlyph x={31} y={48} w={58} h={24} className="badge-dark-bat"/>{Array.from({length:variant},(_,i)=><circle key={i} cx={43+i*17} cy={99} r="2" fill="var(--badge-light)"/>)}</> : variant === 0 ? <><circle cx="78" cy="33" r="18" fill="var(--badge-light)" opacity=".6"/><Skyline variant={3}/><BatGlyph x={16} y={35} w={88} h={36}/></> : variant === 1 ? <><Computer variant={0}/><path d="M20 95V54H43V96ZM26 61H37M26 69H37M26 77H37" fill="var(--badge-mid)" stroke="var(--badge-high)" strokeWidth="1.5"/></> : variant === 2 ? <><Skyline variant={0}/><path d="M60 17V99" stroke="var(--badge-accent)" strokeWidth="1.5"/><BatGlyph x={18} y={25} w={84} h={35}/><path d="M25 102H95" stroke="var(--badge-high)" strokeWidth="3"/></> : <><path d="M30 30H90V99H30Z" fill="var(--badge-mid)" stroke="var(--badge-high)" strokeWidth="2"/><path d="M37 37H83V92H37Z" fill="var(--badge-ink)" stroke="var(--badge-high)"/><BatGlyph x={39} y={50} w={42} h={25}/><path d="M44 84H76" stroke="var(--badge-accent)" strokeWidth="2"/></>}
    </g>
  </svg>;
}
