import { useId, type ReactNode, type CSSProperties } from 'react';
import { achievementCatalog, type Achievement } from '../achievements';
import cowl from '../assets/batcave-cowl.svg';

const BAT = 'M2 3H67C69 15 73 17 84 18C89 19 92 19 93 17L94 6L96 13Q100 12 104 13L106 6L107 17C108 19 111 19 116 18C127 17 131 15 133 3H198C174 13 165 26 169 41C134 39 111 43 100 71C89 43 66 39 31 41C35 26 26 13 2 3Z';
function Bat({x=25,y=44,w=70,h=30,dark=false}:{x?:number;y?:number;w?:number;h?:number;dark?:boolean}) {
  return <svg x={x} y={y} width={w} height={h} viewBox="0 0 200 74" fill={dark?'var(--badge-ink)':'var(--art-metal)'}><path d={BAT}/></svg>;
}
// The approved emoji is kept intact as a separate, shared SVG asset. Its own
// gradients remain graphite regardless of an award's metal or locked state.
function Cowl({x=23,y=13,size=74}:{x?:number;y?:number;size?:number}) {
  return <image data-badge-cowl="approved" href={cowl} x={x} y={y} width={size} height={size}/>;
}
function Metal({children}:{children:ReactNode}) {
  return <g fill="var(--art-metal)" stroke="var(--badge-high)" strokeWidth=".9" strokeLinejoin="round" strokeLinecap="round">{children}</g>;
}
function Signal({x=27,y=23,size=66}:{x?:number;y?:number;size?:number}) {
  return <svg x={x} y={y} width={size} height={size} viewBox="0 0 80 80"><Metal><path d="M30 58H50L54 72H26ZM25 72H55V77H25Z"/><circle cx="40" cy="31" r="29"/></Metal><circle cx="40" cy="31" r="23" fill="var(--badge-light)"/><circle cx="40" cy="31" r="20" fill="var(--badge-light)" stroke="var(--badge-mid)" strokeWidth=".6"/><Bat x={14} y={22} w={52} h={22} dark/></svg>;
}
function Batarang({x=13,y=36,w=94,h=43}:{x?:number;y?:number;w?:number;h?:number}) {
  return <svg x={x} y={y} width={w} height={h} viewBox="0 0 100 48"><Metal><path d="M2 4C11 9 22 10 34 8L38 19L44 19L47 13L50 17L53 13L56 19L62 19L66 8C78 10 89 9 98 4L82 29C70 24 61 30 50 45C39 30 30 24 18 29Z"/></Metal><path d="M6 7L21 24C34 22 41 28 50 40C59 28 66 22 79 24L94 7" fill="none" stroke="var(--badge-light)" strokeOpacity=".35" strokeWidth=".8"/></svg>;
}
// Each comic has a visible illustrated front cover and a thin paper edge;
// the shelf stages count actual volumes, rather than repeating book spines.
function Comic({x,y,w,h,cover=0}:{x:number;y:number;w:number;h:number;cover?:number}) {
  return <svg x={x} y={y} width={w} height={h} viewBox="0 0 32 49" preserveAspectRatio="none" data-comic-volume="true">
    <path d="M3 3L31 1V46L3 49Z" fill="var(--badge-light)" stroke="var(--badge-mid)" strokeWidth=".7"/>
    <path d="M1 1H28V47H1Z" fill="var(--art-enamel)" stroke="var(--badge-high)" strokeWidth="1.1"/>
    <path d="M3 3H26V9H3Z" fill="var(--art-metal)"/>
    <path d="M5 5H23M5 7H17" stroke="var(--badge-ink)" strokeWidth=".8"/>
    {cover%3===0 ? <><path d="M3 12H26V33H3Z" fill="var(--badge-mid)" opacity=".5"/><Bat x={4} y={17} w={21} h={12} dark/><path d="M3 36H13V44H3ZM16 36H26V44H16Z" fill="var(--badge-mid)" opacity=".65"/></> : cover%3===1 ? <><path d="M4 12L25 13L9 43H4Z" fill="var(--badge-mid)"/><path d="M24 14C16 17 17 25 10 31L23 39L25 33V15Z" fill="var(--badge-ink)"/><Bat x={7} y={16} w={18} h={9}/><path d="M18 39H25V44H18Z" fill="var(--badge-mid)"/></> : <><circle cx="16" cy="22" r="10" fill="var(--badge-light)" opacity=".72"/><Bat x={5} y={18} w={22} h={10} dark/><path d="M3 35H25V44H3Z" fill="var(--badge-mid)" opacity=".6"/><path d="M5 38H17M5 41H22" stroke="var(--badge-ink)" strokeWidth=".8"/></>}
    <path d="M2 2V46" stroke="var(--badge-light)" strokeOpacity=".4" strokeWidth=".6"/>
  </svg>;
}
function Shelf({stage}:{stage:number}) {
  const count=Math.min(6,Math.max(1,stage+1));
  const width=count===1?38:count===2?34:count===3?32:count===4?30:count===5?29:28;
  const step=count<=2?width+3:count===3?27:count===4?20:count===5?15:12;
  const total=width+(count-1)*step;
  return <g data-comic-shelf={count}>
    <path d="M16 94H104L99 100H21Z" fill="var(--art-metal)" stroke="var(--badge-high)" strokeWidth="1"/>
    <path d="M21 100H99V104H21Z" fill="var(--badge-low)"/>
    {Array.from({length:count},(_,i)=><Comic key={i} x={(120-total)/2+i*step} y={36} w={width} h={58} cover={i}/>)}
    <Bat x={45} y={18} w={30} h={13}/>
  </g>;
}
function PageArt({stage}:{stage:number}) {
  if(stage===0)return <Comic x={36} y={23} w={48} h={73}/>;
  if(stage<5)return <g>{Array.from({length:Math.min(4,stage+1)},(_,i)=><g key={i} transform={`translate(${(i-(stage/2))*7} ${Math.abs(i-stage/2)*2}) rotate(${(i-stage/2)*6} 60 62)`}><Comic x={36} y={25} w={46} h={70} cover={i}/></g>)}</g>;
  if(stage<8)return <g><Comic x={22} y={32} w={36} h={57}/><Comic x={61} y={32} w={36} h={57} cover={2}/><path d="M58 34V92M19 91Q40 87 58 94Q80 87 101 91" stroke="var(--badge-high)" strokeWidth="1.5" fill="none"/>{stage>5&&<Bat x={40} y={16} w={40} h={17}/>}</g>;
  return <g><path d="M24 31C39 20 81 20 96 31V88C81 99 39 99 24 88Z" fill="none" stroke="var(--badge-mid)" strokeWidth="2"/><Comic x={34} y={30} w={52} h={72} cover={2}/>{stage===9&&<Batarang x={32} y={85} w={56} h={25}/>}</g>;
}
function Computer() {
  return <g><Metal><path d="M21 28Q21 24 25 24H95Q99 24 99 28V76Q99 80 95 80H25Q21 80 21 76Z"/><path d="M53 80H67L70 89H50ZM16 90H104L111 98H9Z"/></Metal><path d="M26 29H94V74H26Z" fill="var(--art-enamel)"/><Bat x={34} y={40} w={52} h={23}/><path d="M28 70H92M28 93H92" stroke="var(--badge-light)" strokeOpacity=".3" strokeWidth="1"/></g>;
}
function Archive({stage}:{stage:number}) {
  if(stage===0)return <Computer/>;
  if(stage===1)return <g><Metal><path d="M19 37V29Q19 25 23 25H46L54 33H97Q101 33 101 37V90H19Z"/><path d="M15 45Q15 41 20 41H101Q106 41 105 47L98 94H22Z"/></Metal><path d="M23 48H97L92 86H28Z" fill="var(--art-enamel)"/><Bat x={34} y={59} w={52} h={23}/></g>;
  if(stage===2)return <g><Metal><path d="M26 35C26 22 94 22 94 35V86C94 100 26 100 26 86Z"/><ellipse cx="60" cy="35" rx="34" ry="11"/></Metal><path d="M27 52C35 64 85 64 93 52M27 70C35 82 85 82 93 70" fill="none" stroke="var(--badge-low)" strokeWidth="2"/><Bat x={39} y={29} w={42} h={16} dark/></g>;
  if(stage===3)return <g><Metal><path d="M21 27H99V97H21Z"/></Metal><path d="M28 34H92V90H28Z" fill="var(--art-enamel)" stroke="var(--badge-mid)"/><circle cx="60" cy="61" r="22" fill="var(--art-metal)" stroke="var(--badge-high)"/><circle cx="60" cy="61" r="15" fill="var(--badge-ink)"/><Bat x={41} y={53} w={38} h={17}/><path d="M25 37V48M25 77V88" stroke="var(--badge-light)" strokeWidth="2"/></g>;
  if(stage===4)return <g><Metal><path d="M29 32H91L99 93H21Z"/><path d="M24 70H96V83H24ZM26 51H94V64H26Z"/></Metal><path d="M32 36H88V46H32Z" fill="var(--badge-ink)"/><Bat x={40} y={33} w={40} h={17} dark/><circle cx="87" cy="57" r="2" fill="var(--badge-light)"/><circle cx="87" cy="76" r="2" fill="var(--badge-light)"/></g>;
  return <g><circle cx="60" cy="59" r="38" fill="var(--art-enamel)" stroke="var(--badge-high)" strokeWidth="2"/><ellipse cx="60" cy="59" rx="20" ry="38" fill="none" stroke="var(--badge-mid)"/><path d="M24 46H96M22 66H98M30 84H90" stroke="var(--badge-mid)"/><Batarang x={19} y={42} w={82} h={37}/></g>;
}
function City() {
  return <g><path d="M21 91V58L30 50V41L39 31L48 41V69H54V29L60 19L66 29V69H72V46L81 35L90 46V58L99 65V91Z" fill="var(--art-enamel)" stroke="var(--badge-high)" strokeWidth="1.3"/><path d="M34 47V81M60 34V80M81 49V81" stroke="var(--badge-light)" strokeOpacity=".25"/><path d="M17 92H103" stroke="var(--badge-high)" strokeWidth="2"/></g>;
}
function Era({id}:{id:string}) {
  switch(id) {
    case 'early':return <Cowl x={13} y={8} size={94}/>;
    case 'family':return <g><Batarang x={25} y={24} w={70} h={31}/><Metal><path d="M44 51H70Q86 51 84 64Q83 73 71 76L83 94H67L55 77H49L45 94H32L41 51ZM53 61L51 68H65Q71 68 71 64Q71 61 66 61Z"/></Metal></g>;
    case 'knightfall':return <g><Cowl x={13} y={8} size={94}/><path d="M67 42L58 56L65 65L57 78L63 88" stroke="#0a1016" strokeWidth="3"/><path d="M65 42L56 56L63 65L55 78L61 88" stroke="var(--badge-high)" strokeOpacity=".6" strokeWidth=".8"/></g>;
    case 'no-mans-land':return <g><City/><path d="M65 24L56 47L66 57L54 74L63 94" fill="none" stroke="var(--badge-ink)" strokeWidth="5"/><Batarang x={28} y={44} w={64} h={29}/></g>;
    case 'new-gotham':return <g><City/><Bat x={28} y={50} w={64} h={28}/></g>;
    case 'legacy':return <g><path d="M18 47Q20 90 60 104Q100 90 102 47L82 54L60 35L38 54Z" fill="var(--art-metal)" stroke="var(--badge-high)"/><Cowl x={19} y={8} size={82}/></g>;
    case 'new-52':return <g><Metal><path d="M65 18L39 59H56L48 99L84 49H66L77 18Z"/></Metal><Batarang x={18} y={40} w={84} h={38}/></g>;
    case 'rebirth':return <g><path d="M86 34A34 34 0 1 0 93 76" stroke="var(--art-metal)" strokeWidth="5" fill="none"/><path d="M76 34H88V22" stroke="var(--badge-high)" strokeWidth="3" fill="none"/><Batarang x={24} y={43} w={72} h={33}/></g>;
    case 'infinite-frontier':return <g><path d="M60 59C28 19 12 45 22 65C34 89 55 67 60 59C92 19 108 45 98 65C86 89 65 67 60 59Z" fill="none" stroke="var(--art-metal)" strokeWidth="6"/><Bat x={38} y={49} w={44} h={20}/></g>;
    case 'dawn-of-dc':return <g><circle cx="60" cy="48" r="27" fill="var(--art-metal)"/><path d="M60 14V21M31 22L36 28M89 22L84 28" stroke="var(--badge-high)" strokeWidth="1.5"/><City/><Bat x={34} y={43} w={52} h={23} dark/></g>;
    default:return <g><circle cx="60" cy="61" r="40" fill="var(--art-enamel)" stroke="var(--badge-high)" strokeWidth="1.5"/><Cowl x={13} y={9} size={94}/></g>;
  }
}
function Story({stage}:{stage:number}) {
  switch(stage) {
    case 0:return <Batarang x={7} y={34} w={106} h={48}/>;
    case 1:return <g><City/><Bat x={23} y={30} w={74} h={32}/></g>;
    case 2:return <Batarang x={15} y={37} w={90} h={41}/>;
    case 3:return <Cowl x={13} y={9} size={94}/>;
    case 4:return <Signal/>;
    case 5:return <g><Metal><path d="M17 73L26 63L42 58L49 45H73L84 58L97 63L105 78L99 87H21Z"/></Metal><path d="M46 58L53 49H69L77 58Z" fill="var(--badge-ink)"/><path d="M17 73L8 59L14 84L22 88M103 73L112 59L106 84L98 88" fill="var(--badge-mid)"/><circle cx="32" cy="83" r="10" fill="var(--badge-ink)" stroke="var(--badge-high)" strokeWidth="2"/><circle cx="88" cy="83" r="10" fill="var(--badge-ink)" stroke="var(--badge-high)" strokeWidth="2"/><Bat x={39} y={65} w={42} h={17} dark/></g>;
    case 6:return <Computer/>;
    case 7:return <g><circle cx="78" cy="36" r="20" fill="var(--badge-light)" opacity=".3"/><City/><Batarang x={17} y={39} w={86} h={39}/></g>;
    case 8:return <g><path d="M19 45Q22 82 60 104Q98 82 101 45L80 56L60 33L40 56Z" fill="var(--art-metal)"/><Cowl x={16} y={7} size={88}/></g>;
    default:return <g><path d="M18 42L33 53L46 34L60 50L74 34L87 53L102 42L91 90Q60 103 29 90Z" fill="var(--art-metal)" stroke="var(--badge-high)"/><Batarang x={25} y={59} w={70} h={32}/></g>;
  }
}
function Quill({stage}:{stage:number}) {
  return <g><Metal><path d="M35 84C32 62 46 27 87 22C86 50 69 75 45 79L29 98L25 96L39 78Z"/></Metal><path d="M38 82L77 33M47 69L46 51M57 58L58 40M57 58L74 57" stroke="var(--badge-low)" strokeWidth="1.4" fill="none"/>{stage>0&&<g><circle cx="79" cy="85" r={14+stage} fill="var(--art-metal)" stroke="var(--badge-high)"/><Bat x={67} y={79} w={24} h={11} dark/></g>}</g>;
}
function Special({stage}:{stage:number}) {
  if(stage===0)return <g><Comic x={32} y={24} w={56} h={78}/><path d="M29 29V98H83" fill="none" stroke="var(--badge-high)" strokeWidth="1.5"/></g>;
  if(stage===1)return <g><path d="M65 29H99V89H65Z" fill="var(--art-metal)" stroke="var(--badge-high)"/><path d="M69 34H95V80H69Z" fill="var(--badge-ink)"/><Bat x={71} y={47} w={22} h={13}/><Comic x={20} y={28} w={42} h={65} cover={2}/></g>;
  if(stage===2)return <g><circle cx="60" cy="60" r="36" stroke="var(--art-metal)" strokeWidth="4" fill="var(--art-enamel)"/><path d="M60 30V35M60 85V90M30 60H35M85 60H90M60 39V59L77 69" stroke="var(--badge-high)" strokeWidth="2" strokeLinecap="round"/><Bat x={30} y={48} w={60} h={25}/></g>;
  return <g><path d="M30 33H90V96H30Z" fill="var(--art-metal)" stroke="var(--badge-high)"/><Comic x={37} y={28} w={46} h={70}/><Batarang x={27} y={82} w={66} h={29}/></g>;
}
export function BadgeArt({medal}:{medal:Achievement}) {
  const uid=useId().replace(/[^a-zA-Z0-9_-]/g,'');
  const stage=achievementCatalog.filter(a=>a.kind===medal.kind).findIndex(a=>a.id===medal.id);
  const metal=`metal-${uid}`,enamel=`enamel-${uid}`;
  // Frames have no floating ornaments: every visible element belongs to the
  // border or to the subject. Tiers change the frame, never the cowl artwork.
  const frame=medal.kind==='paper'?'M29 9H91L109 29V89L60 115L11 89V29Z':medal.era?'M60 6L109 34V88L60 116L11 88V34Z':'M60 6L108 27L103 83Q88 104 60 116Q32 104 17 83L12 27Z';
  return <svg className="award-vector" viewBox="0 0 120 124" aria-hidden="true" style={{'--art-metal':`url(#${metal})`,'--art-enamel':`url(#${enamel})`} as CSSProperties}>
    <defs><linearGradient id={metal} x1="0" y1="0" x2=".85" y2="1"><stop stopColor="var(--badge-light)"/><stop offset=".26" stopColor="var(--badge-high)"/><stop offset=".55" stopColor="var(--badge-mid)"/><stop offset=".78" stopColor="var(--badge-high)"/><stop offset="1" stopColor="var(--badge-low)"/></linearGradient><radialGradient id={enamel} cx=".35" cy=".23" r=".9"><stop stopColor="var(--badge-face)"/><stop offset="1" stopColor="var(--badge-ink)"/></radialGradient></defs>
    {medal.id!=='first'&&<g><path d={frame} fill={`url(#${metal})`} stroke="var(--badge-low)" strokeWidth=".7"/><path d={frame} transform="translate(3.6 3.6) scale(.94)" fill={`url(#${enamel})`} stroke="var(--badge-low)" strokeWidth="1.2"/><path d={frame} transform="translate(6.6 6.6) scale(.89)" fill="none" stroke="var(--badge-high)" strokeOpacity=".3" strokeWidth=".6"/></g>}
    {medal.era?<Era id={medal.era}/>:medal.kind==='stories'?<Story stage={stage}/>:medal.kind==='pages'?<PageArt stage={stage}/>:medal.kind==='library'?<Archive stage={stage}/>:medal.kind==='paper'?<Shelf stage={stage}/>:medal.kind==='ratings'?<Quill stage={stage}/>:<Special stage={stage}/>}
  </svg>;
}
