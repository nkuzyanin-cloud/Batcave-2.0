import {BookOpen} from 'lucide-react';
import type { Achievement } from '../achievements';

// Legacy era screens retain a lightweight symbol, never the retired art catalog.
export function AchievementBadge({ medal, className = '' }: { medal: Achievement; className?: string }) {
  return <span className={`award-badge tier-${medal.tier} ${className}`} aria-hidden="true"><BookOpen size={36} strokeWidth={1.5}/></span>;
}
const duration=(s:number)=>{const h=Math.floor(s/3600),m=Math.floor(s/60)%60;return h?`${h} ч${m?` ${m} м`:''}`:`${m} м`;};
export function AchievementProgress({ medal, label = false }: { medal: Achievement; label?: boolean }) {
  return <div className="award-progress-wrap">
    {label && <small>{medal.kind==='time'?duration(medal.value):medal.value.toLocaleString('ru-RU')} / {medal.kind==='time'?duration(medal.goal):medal.goal.toLocaleString('ru-RU')}</small>}
    <div className="award-progress" role="progressbar" aria-label={medal.hint} aria-valuemin={0} aria-valuemax={medal.goal} aria-valuenow={medal.value}>
      <i style={{width:`${Math.min(100,medal.value / medal.goal * 100)}%`}} />
    </div>
  </div>;
}
