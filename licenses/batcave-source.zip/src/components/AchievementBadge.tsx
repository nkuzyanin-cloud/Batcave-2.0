import type { CSSProperties } from 'react';
import type { Achievement } from '../achievements';

export function AchievementBadge({ medal, className = '' }: { medal: Achievement; className?: string }) {
  return <span className={`award-badge tier-${medal.tier} ${medal.earned ? 'is-earned' : 'is-locked'} ${className}`} aria-hidden="true">
    <span className="award-art" style={{ '--art-x':`${(medal.art % 4) * 100 / 3}%`, '--art-y':`${Math.floor(medal.art / 4) * 50}%` } as CSSProperties} />
    <span className="award-rank">{Array.from({length:({bronze:1,silver:2,gold:3,platinum:4})[medal.tier]},(_,i) => <i key={i}/>)}</span>
  </span>;
}
export function AchievementProgress({ medal, label = false }: { medal: Achievement; label?: boolean }) {
  return <div className="award-progress-wrap">
    {label && <small>{medal.value.toLocaleString('ru-RU')} / {medal.goal.toLocaleString('ru-RU')}</small>}
    <div className="award-progress" role="progressbar" aria-label={medal.hint} aria-valuemin={0} aria-valuemax={medal.goal} aria-valuenow={medal.value}>
      <i style={{width:`${Math.min(100,medal.value / medal.goal * 100)}%`}} />
    </div>
  </div>;
}
