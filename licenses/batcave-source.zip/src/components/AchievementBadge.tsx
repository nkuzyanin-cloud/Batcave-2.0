import type { Achievement } from '../achievements';
import { BookOpen, Layers, Clock3, Library, Monitor, Star } from 'lucide-react';

export function AchievementBadge({ medal, className = '' }: { medal: Achievement; className?: string }) {
  const Icon=medal.kind==='time'?Clock3:medal.kind==='pages'?BookOpen:medal.kind==='stories'?Layers:medal.kind==='paper'?Library:medal.kind==='ratings'?Star:Monitor;
  return <span className={`award-badge universal-badge tier-${medal.tier} ${medal.earned ? 'is-earned' : 'is-locked'} ${className}`} aria-hidden="true"><Icon strokeWidth={1.35}/></span>;
}
const duration=(s:number)=>{const h=Math.floor(s/3600),m=Math.floor(s/60)%60;return h?`${h} ч${m?` ${m} м`:''}`:`${m} м`;};
export function AchievementProgress({ medal, label = false }: { medal: Achievement; label?: boolean }) {
  return <div className="award-progress-wrap">
    {label && <small>{medal.kind==='time'?duration(medal.value):medal.value.toLocaleString('ru-RU')} / {medal.kind==='time'?duration(medal.goal):medal.goal.toLocaleString('ru-RU')}</small>}
    <div className="award-progress" role="progressbar" aria-label={medal.hint} aria-valuemin={0} aria-valuemax={medal.goal} aria-valuenow={medal.value}>
      <i style={{width:`${Math.min(100,medal.value / medal.goal * 100)}%`}} />
    </div>
  </div>;
}
