import { useState } from 'react';
import { APP_VERSION } from '../updates';

type Row = [string, string];
const rounded = (n: number) => Math.round(n * 100) / 100;

export function screenMeasurements(): Row[] {
  const root = document.documentElement;
  const vv = window.visualViewport;
  const rows: Row[] = [
    ['Версия', APP_VERSION],
    ['Браузер', navigator.userAgent],
    ['Экран', `${screen.width} × ${screen.height}; DPR ${devicePixelRatio}`],
    ['Окно', `${innerWidth} × ${innerHeight}`],
    ['Режим', `${matchMedia('(display-mode: standalone)').matches ? 'standalone' : 'browser'} / iOS standalone: ${String((navigator as Navigator & { standalone?: boolean }).standalone)}`],
    ['Visual viewport', vv ? `${rounded(vv.width)} × ${rounded(vv.height)}; top ${rounded(vv.offsetTop)}; scale ${vv.scale}` : 'нет'],
    ['CSS высота', getComputedStyle(root).getPropertyValue('--app-height').trim()],
    ['Клавиатура', `${root.style.getPropertyValue('--keyboard-height') || 'нет'}; top ${root.style.getPropertyValue('--keyboard-top') || '0'}`],
  ];
  for (const [name, selector] of [['HTML', 'html'], ['Body', 'body'], ['Приложение', '.app'], ['Прокрутка', '.app main']] as const) {
    const el = document.querySelector<HTMLElement>(selector);
    if (!el) continue;
    const rect = el.getBoundingClientRect();
    const css = getComputedStyle(el);
    rows.push([name, `top ${rounded(rect.top)}; h ${rounded(rect.height)}; bottom ${rounded(rect.bottom)}; client ${el.clientHeight}; scroll ${el.scrollHeight}; overflow ${css.overflowY}`]);
  }
  // Temporary probes are invisible, do not enter layout, and are removed even
  // if a measurement throws. No library data or settings are accessed.
  const probe = document.createElement('div');
  probe.style.cssText = 'position:fixed;left:0;top:0;width:0;visibility:hidden;pointer-events:none;contain:strict;box-sizing:content-box;';
  document.body.append(probe);
  try {
    for (const unit of ['vh', 'dvh', 'svh', 'lvh']) {
      if (!CSS.supports('height', `100${unit}`)) continue;
      probe.style.height = `100${unit}`;
      rows.push([`100${unit}`, `${rounded(probe.getBoundingClientRect().height)}`]);
    }
    probe.style.cssText += 'height:auto;bottom:0;';
    rows.push(['Fixed inset 0', `${rounded(probe.getBoundingClientRect().height)}`]);
    probe.style.paddingTop = 'env(safe-area-inset-top, 0px)';
    probe.style.paddingBottom = 'env(safe-area-inset-bottom, 0px)';
    const css = getComputedStyle(probe);
    rows.push(['Safe area', `top ${css.paddingTop}; bottom ${css.paddingBottom}`]);
  } finally { probe.remove(); }
  return rows;
}

export function ScreenDiagnostics() {
  const [rows, setRows] = useState<Row[]>();
  const [copied, setCopied] = useState(false);
  return <div className="screen-diagnostics">
    <button className="secondary" onClick={() => { setRows(screenMeasurements()); setCopied(false); }}>Диагностика экрана</button>
    {rows && <>
      <p className="muted">Размеры страницы на этом устройстве. Пришлите этот текст или скриншоты таблицы.</p>
      <table><tbody>{rows.map(([label, value]) => <tr key={label}><th scope="row">{label}</th><td>{value}</td></tr>)}</tbody></table>
      <button className="secondary" onClick={async () => {
        try { await navigator.clipboard.writeText(rows.map(([label, value]) => `${label}: ${value}`).join('\n')); setCopied(true); }
        catch { setCopied(false); }
      }}>{copied ? 'Скопировано' : 'Скопировать размеры'}</button>
    </>}
  </div>;
}
