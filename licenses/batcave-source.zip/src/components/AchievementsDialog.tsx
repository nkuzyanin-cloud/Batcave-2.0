import type { ChronologicalEraId } from '../eras';
import { useState } from 'react';
import { ArrowLeft, Check, LockKeyhole } from 'lucide-react';
import { type Achievement, achievementKinds } from '../achievements';
import { Modal } from './ui';
import { AchievementBadge, AchievementProgress } from './AchievementBadge';

const tierNames = {bronze:'Бронза',silver:'Серебро',gold:'Золото',platinum:'Платина'};
export function AchievementsDialog({ medals, initialId, onClose, onEra }: { medals: Achievement[]; initialId?: string; onClose: () => void; onEra:(era:ChronologicalEraId)=>void }) {
  const [filter,setFilter] = useState<'all'|'earned'|'progress'>('all');
  const [selected,setSelected] = useState(initialId);
  const detail = medals.find(a => a.id === selected);
  const earned = medals.filter(a => a.earned).length;
  const visible = medals.filter(a => filter === 'all' || (filter === 'earned' ? a.earned : !a.earned));
  return <Modal title="Достижения" onClose={onClose} className="gotham-sheet achievement-sheet">
    {detail ? <div className="award-detail" data-achievement-detail={detail.id}>
      <button className="award-back" onClick={() => setSelected(undefined)}><ArrowLeft size={16}/>К коллекции</button>
      <AchievementBadge medal={detail}/>
      <span className={`award-tier tier-label-${detail.tier}`}>{tierNames[detail.tier]}</span>
      <h3>{detail.name}</h3><p>{detail.hint}</p>
      <AchievementProgress medal={detail} label/>
      {detail.era && <button className="era-plan-continue" onClick={()=>onEra(detail.era!)}>Открыть маршрут эры</button>}
      {detail.era && !detail.planned && !detail.earned && <p className="era-plan-hint">Состав маршрута ещё не закреплён.</p>}
      <div className={`award-detail-status ${detail.earned ? 'is-earned' : ''}`}>
        {detail.earned ? <Check size={16}/> : <LockKeyhole size={16}/>}
        <span>{detail.earned ? 'Достижение получено' : 'Ещё впереди'}</span>
      </div>
      {detail.earned && <small className="award-date">{detail.legacy ? 'Зачтено по вашей библиотеке' : detail.earnedAt ? new Date(detail.earnedAt).toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'}) : 'Условие выполнено'}</small>}
    </div> : <>
      <p className="award-collection-count">Получено {earned} из {medals.length}</p>
      <div className="award-filters" role="group" aria-label="Фильтр достижений">
        {([['all','Все'],['earned','Получены'],['progress','В процессе']] as const).map(([id,label]) => <button key={id} aria-pressed={filter === id} onClick={() => setFilter(id)}>{label}</button>)}
      </div>
      {achievementKinds.map(kind => {
        const group = visible.filter(a => a.kind === kind.id);
        if (!group.length) return null;
        return <section className="award-category" key={kind.id}>
          <h3>{kind.label}<small>{medals.filter(a => a.kind === kind.id && a.earned).length} / {medals.filter(a => a.kind === kind.id).length}</small></h3>
          <div className="award-grid">
            {group.map(a => <button type="button" key={a.id} className={`award-tile ${a.earned ? 'is-earned' : ''}`} data-achievement={a.id} onClick={() => setSelected(a.id)} aria-label={`${a.name}. ${a.earned ? 'Получено' : `${a.value} из ${a.goal}`}. ${a.hint}`}>
              <AchievementBadge medal={a}/><span className="award-name">{a.name}</span>
              {a.earned ? <small className="award-earned-label"><Check size={10}/>Получено</small> : a.era && !a.planned ? <small className="award-plan-label">Маршрут не закреплён</small> : <AchievementProgress medal={a} label/>}
            </button>)}
          </div>
        </section>;
      })}
      {!visible.length && <p className="award-empty">{filter === 'earned' ? 'Первая награда ждёт своей истории.' : 'Вся коллекция собрана. Вот это масштаб!'}</p>}
    </>}
  </Modal>;
}
