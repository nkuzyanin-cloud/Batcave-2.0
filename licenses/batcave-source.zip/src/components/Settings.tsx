import { useEffect, useState, useRef } from 'react';
import { APP_VERSION } from '../updates';
import { Download, Upload, HardDrive, ShieldCheck, Trash2, RotateCcw, Info, BookOpen, ChevronRight, ArrowLeft } from 'lucide-react';
import { type Comic, type Settings, bytes, errorMessage } from '../models';
import { usage, deleteDigital, resetProgress } from '../storage/db';
import {
  exportMetadata,
  restore,
  download,
  type PreparedBackup,
} from '../storage/backup';
import { exportParts, prepareRestoreParts, discardPrepared, type BackupParts } from '../storage/backup-parts';
import { ReaderPreferences } from '../reader/ReaderPreferences';
import { Toast } from './ui';
import { ScreenDiagnostics } from './ScreenDiagnostics';
export function SettingsPanel({
  settings,
  onChange,
  comics,
  onRefresh,
  offline,
  updates,
}: {
  settings: Settings;
  onChange: (s: Settings) => void;
  comics: Comic[];
  onRefresh: () => Promise<void>;
  offline: string;
  updates: ReturnType<typeof import('../updates').useAppUpdates>;
}) {
  const [section, setSection] = useState<'reading' | 'backup' | 'storage' | 'about'>();
  const [parts, setParts] = useState<BackupParts>();
  const [sent, setSent] = useState<number[]>([]);
  const preparedRef = useRef<PreparedBackup | undefined>(undefined);
  const alive = useRef(true);
  const operation = useRef(new AbortController());
  useEffect(() => { alive.current = true; operation.current = new AbortController(); return () => { alive.current = false; operation.current.abort(); void discardPrepared(preparedRef.current); }; }, []);
  const [storage, setStorage] = useState<Awaited<ReturnType<typeof usage>>>();
  const [busy, setBusy] = useState('');
  const [generated, setGenerated] = useState<{ blob: Blob; name: string }>();
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [prepared, setPrepared] = useState<PreparedBackup>();
  const [policy, setPolicy] = useState<'keep' | 'replace'>('keep');
  const [replaceSettings, setReplaceSettings] = useState(false);
  const [confirm, setConfirm] = useState<'reset' | Comic | null>(null);
  const refresh = async () => {
    await onRefresh();
    setStorage(await usage());
  };
  useEffect(() => {
    void usage()
      .then(setStorage)
      .catch((e) => setError(errorMessage(e)));
  }, [comics]);
  async function backup(full: boolean) {
    setGenerated(undefined);
    setParts(undefined); setSent([]);
    setBusy('Подготовка копии…');
    setError('');
    setNotice('');
    try {
      if (full) {
        const result = await exportParts(setBusy, { signal: operation.current.signal });
        if (!alive.current) return;
        setParts(result);
        setNotice(`Копия готова: ${result.count} ${result.count === 1 ? 'часть' : 'частей'}. Сохраните все части комплекта.`);
        return;
      }
      const blob = await exportMetadata();
      const name = `BATCAVE-${new Date().toISOString().slice(0, 10)}.${full ? 'zip' : 'json'}`;
      setGenerated({ blob, name });
      download(blob, name);
      setNotice(
        full
          ? 'Полная копия подготовлена. Сохраните скачанный архив в «Файлы».'
          : 'JSON подготовлен. Он содержит коллекцию, настройки и прогресс, без оригиналов и фотографий.',
      );
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy('');
    }
  }
  async function partDownload(index: number) {
    if (!parts || busy) return;
    setGenerated(undefined); setBusy(`Подготовка части ${index + 1}…`); setError('');
    try {
      const blob = await parts.makePart(index, setBusy);
      if (!alive.current) return;
      const name = parts.names[index]; setGenerated({blob,name}); download(blob,name);
      setSent(old => [...new Set([...old,index])]);
      setNotice(`Часть ${index + 1} из ${parts.count} подготовлена. Сохраните её в «Файлы».`);
    } catch(e) {if(alive.current)setError(errorMessage(e));}
    finally {if(alive.current)setBusy('');}
  }
  async function load(files: File[]) {
    if (!files.length) return;
    await discardPrepared(preparedRef.current); preparedRef.current = undefined;
    setBusy('Проверка резервной копии…');
    setError('');
    setNotice('');
    setPrepared(undefined);
    try {
      const result = await prepareRestoreParts(files, setBusy, operation.current.signal);
      if (!alive.current) {await discardPrepared(result);return;}
      preparedRef.current = result; setPrepared(result);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy('');
    }
  }
  async function apply() {
    if (!prepared) return;
    setBusy('Восстановление библиотеки…');
    setError('');
    try {
      const result = await restore(prepared, policy, replaceSettings);
      preparedRef.current = undefined; setPrepared(undefined);
      await refresh();
      setNotice(
        `Восстановлено: ${result.imported}. Сохранено существующих записей: ${result.skipped}. Возвращено файлов: ${result.hydrated}.`,
      );
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy('');
    }
  }
  async function remove() {
    if (!confirm) return;
    setBusy('Сохранение…');
    setError('');
    try {
      if (confirm === 'reset') await resetProgress();
      else await deleteDigital(confirm);
      setConfirm(null);
      await refresh();
      setNotice('Готово.');
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy('');
    }
  }
  return (
    <div className="settings-grid">
      {!section && <div className="settings-home">
        {([
          ['reading',BookOpen,'Чтение','Режим, масштаб и оформление'],
          ['backup',Download,'Резервные копии','Сохранить и восстановить библиотеку'],
          ['storage',HardDrive,'Хранилище',`На устройстве · ${storage ? bytes(storage.local) : '…'}`],
          ['about',Info,'О приложении',`Версия ${APP_VERSION}`],
        ] as const).map(([id,Icon,title,subtitle]) => <button key={id} onClick={() => {setError('');setNotice('');setSection(id);}}><Icon/><span><strong>{title}</strong><small>{subtitle}</small></span><ChevronRight/></button>)}
      </div>}
      {section && <div className="settings-detail-heading"><button className="icon-button" aria-label="Назад к настройкам" disabled={!!busy} onClick={() => setSection(undefined)}><ArrowLeft size={20}/></button><h2>{{reading:'Чтение',backup:'Резервные копии',storage:'Хранилище',about:'О приложении'}[section]}</h2></div>}
      {section === 'reading' && (
      <section className="panel">
        <div className="section-label">
          <ShieldCheck size={19} />
          <h2>Чтение</h2>
        </div>
        <ReaderPreferences settings={settings} onChange={onChange} />
      </section>
      )}
      {section === 'backup' && (
      <section className="panel">
        <div className="section-label">
          <Download size={19} />
          <h2>Резервные копии</h2>
        </div>
        <p className="muted">
          Сохраняйте резервные копии в «Файлах» или на компьютере. Очистка Safari может удалить библиотеку с устройства.
        </p>
        <div className="stack">
          <button className="secondary" disabled={!!busy} onClick={() => void backup(false)}>
            <Download size={18} />
            Экспорт JSON
          </button>
          <button className="primary" disabled={!!busy} onClick={() => void backup(true)}>
            <Download size={18} />
            Экспорт всей библиотеки
          </button>
          <small>
            Вся библиотека сохраняется частями до 250 МБ. Размер библиотеки не ограничен 300 МБ. Сохраните весь комплект.
          </small>
          <label className={`secondary file-button ${busy ? 'disabled' : ''}`}>
            <Upload size={18} />
            Восстановить из JSON / ZIP
            <input
              type="file"
              multiple
              accept=".json,.zip,application/json,application/zip"
              disabled={!!busy}
              onChange={(e) => {
                void load(Array.from(e.target.files || []));
                e.target.value = '';
              }}
            />
          </label>
        </div>
        {parts && <div className="restore-box backup-parts">
          <h3>Части резервной копии · {parts.count}</h3>
          <small>Выберите все части при восстановлении или упакуйте их вместе в один ZIP.</small>
          {parts.names.map((name,i)=><button className="secondary" key={name} disabled={!!busy} onClick={() => void partDownload(i)}><span>Скачать часть {i+1} из {parts.count}</span><span>{sent.includes(i) ? '↻' : '↓'}</span></button>)}
        </div>}
        {generated && (
          <div className="restore-box">
            <p>Копия готова: {generated.name}</p>
            <button className="secondary" onClick={() => download(generated.blob, generated.name)}>
              <Download size={18} />
              Сохранить копию
            </button>
            <small>
              Если Safari не начал скачивание автоматически, нажмите эту кнопку и сохраните файл в
              «Файлы».
            </small>
          </div>
        )}
        {prepared && (
          <div className="restore-box">
            <h3>Копия проверена</h3>
            <p>
              {prepared.data.comics.length} записей · {prepared.data.assets.length} файлов ·
              совпадений: {prepared.conflicts}
            </p>
            <label>
              При совпадении
              <select value={policy} onChange={(e) => setPolicy(e.target.value as typeof policy)}>
                <option value="keep">Сохранить мои текущие данные</option>
                <option value="replace">Заменить данными из копии</option>
              </select>
            </label>
            <label className="switch-label">
              <span>Восстановить настройки</span>
              <input
                type="checkbox"
                checked={replaceSettings}
                onChange={(e) => setReplaceSettings(e.target.checked)}
              />
            </label>
            <p className="muted">
              JSON не возвращает оригиналы. В полной копии каждый файл проверяется по SHA-256.
              Замена затрагивает совпадающие записи, остальные остаются.
            </p>
            <div className="form-row">
              <button disabled={!!busy} onClick={() => {void discardPrepared(prepared);preparedRef.current=undefined;setPrepared(undefined);}}>Отмена</button>
              <button className="primary" disabled={!!busy} onClick={() => void apply()}>
                Восстановить
              </button>
            </div>
          </div>
        )}
      </section>
      )}
      {section === 'storage' && (
      <section className="panel">
        <div className="section-label">
          <HardDrive size={19} />
          <h2>На устройстве</h2>
        </div>
        <div className="storage-number">
          {storage ? bytes(storage.local) : '…'}
          <small>Оригиналы, обложки и фотографии</small>
        </div>
        {storage?.estimate?.quota && (
          <p className="muted">
            Свободно в хранилище браузера: примерно{' '}
            {bytes(Math.max(0, storage.estimate.quota - (storage.estimate.usage || 0)))}. Это не
            свободное место на всём iPhone.
          </p>
        )}
        <button
          className="secondary"
          disabled={!!busy}
          onClick={() => {
            void (async () => {
              try {
                const persisted = await navigator.storage?.persist?.();
                setNotice(
                  persisted
                    ? 'Браузер разрешил устойчивое хранение. Резервные копии всё равно необходимы.'
                    : 'Браузер не предоставил устойчивое хранение. Используйте резервные копии.',
                );
              } catch (e) {
                setError(errorMessage(e));
              }
            })();
          }}
        >
          <ShieldCheck size={18} />
          Запросить сохранение данных
        </button>
        <div className="file-list">
          {comics
            .filter((c) => c.digital)
            .map((c) => (
              <div key={c.id}>
                <span>
                  {c.title}
                  <small>{bytes(c.digital!.size)}</small>
                </span>
                <button
                  className="icon-button"
                  aria-label={`Удалить файл ${c.title}`}
                  disabled={!!busy}
                  onClick={() => setConfirm(c)}
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ))}
        </div>
        <button className="danger secondary" disabled={!!busy} onClick={() => setConfirm('reset')}>
          <RotateCcw size={18} />
          Сбросить прогресс чтения
        </button>
        {confirm && (
          <div className="confirm-box">
            <p>
              {confirm === 'reset'
                ? 'Сбросить страницы, статусы «Прочитан» и время чтения всех комиксов? Файлы и коллекция останутся.'
                : `Удалить оригинальный файл «${confirm.title}»? Карточка и прогресс останутся.`}
            </p>
            <div>
              <button onClick={() => setConfirm(null)}>Отмена</button>
              <button className="danger" disabled={!!busy} onClick={() => void remove()}>
                Подтвердить
              </button>
            </div>
          </div>
        )}
      </section>
      )}
      {section === 'about' && (
      <section className="panel">
        <div className="section-label">
          <Info size={19} />
          <h2>BATCAVE / {APP_VERSION}</h2>
        </div>
        <div className="app-update-settings">
          <p role="status">{{ idle: 'Проверка обновлений при открытии приложения.', checking: 'Проверяем обновления…', downloading: 'Загружаем новую версию…', current: 'Установлена актуальная версия.', ready: 'Новая версия готова к установке.', offline: updates.detail || 'Сервер обновлений недоступен.', error: updates.detail || 'Не удалось установить обновление. Повторите проверку.' }[updates.state]}</p>
          <button className={updates.state === 'ready' ? 'primary' : 'secondary'} onClick={updates.state === 'ready' ? updates.apply : updates.check} disabled={updates.state === 'checking' || updates.state === 'downloading'}>
            <RotateCcw size={17} />{updates.state === 'ready' ? 'Обновить приложение' : 'Проверить обновление'}
          </button>
        </div>
        <p>Личный архив комиксов DC</p>
        <ScreenDiagnostics />
        <p className="muted"><a href={`${import.meta.env.BASE_URL}licenses/batcave-source.zip`} download>Исходный код и лицензии</a></p>
        <p className="muted">
          PDF · CBZ · JPG · PNG · WebP
          <br />
          CBR / RAR не поддерживается. Лимит импорта — 600 МБ; страницы архива — до 32 МБ.
        </p>
        <p className="connection-state">{offline}</p>
        <p className="muted">
          На iPhone: откройте сайт в Safari → «Поделиться» → «На экран Домой». Дождитесь надписи
          «Офлайн готов» перед отключением сети.
        </p>
        <p className="muted">
          Файлы и коллекция хранятся только на устройстве. Приложение не связано с DC и не содержит
          коммерческих комиксов.
        </p>
      </section>
      )}
      {busy && (
        <div className="task-toast" role="status">
          <span className="spinner" />
          {busy}
        </div>
      )}
      {error && <Toast error message={error} onClose={()=>setError('')}/>}
      {notice && <Toast message={notice} onClose={()=>setNotice('')}/>}

    </div>
  );
}
