import { useState, useEffect } from 'react';
import { BookOpen, Layers, Clock3, Star, ChevronRight, ArrowRight } from 'lucide-react';
import { type Comic, stats } from '../models';
import { Cover } from './ui';
import { AchievementBadge } from './AchievementBadge';
import { type Achievement, type AchievementState } from '../achievements';
import { completedHistory } from '../completion';
import { CHRONOLOGICAL_ERAS, isChronologicalEra, type ChronologicalEraId, type EraId } from '../eras';
import { eraProgress } from '../era-progress';

export function Profile({ comics, onEdit, medals, state, selectedEra, onAchievements, onEra, onContinue }: {
  comics:Comic[];onEdit:(comic:Comic)=>void;medals:Achievement[];state?:AchievementState;selectedEra:EraId;
  onAchievements:(id?:string)=>void;onEra:(era?:ChronologicalEraId)=>void;onContinue:(era:ChronologicalEraId)=>void;
}) {
  const [now,setNow]=useState(Date.now()),[historyExpanded,setHistoryExpanded]=useState(false);
  useEffect(()=>{
    if(!comics.some(c=>c.paperStartedAt!==undefined))return;
    const update=()=>setNow(Date.now());update();const id=window.setInterval(update,1000);
    document.addEventListener('visibilitychange',update);return()=>{clearInterval(id);document.removeEventListener('visibilitychange',update);};
  },[comics]);
  const s=stats(comics,now),history=completedHistory(comics);
  const fallback=CHRONOLOGICAL_ERAS.find(e=>eraProgress(comics,state?.eraPlans,e.id).total>0)?.id ?? 'early';
  const eraId=isChronologicalEra(selectedEra)?selectedEra:fallback;
  const era=CHRONOLOGICAL_ERAS.find(e=>e.id===eraId)!;
  const progress=eraProgress(comics,state?.eraPlans,eraId),eraMedal=medals.find(a=>a.era===eraId)!;
  const eraIndex=CHRONOLOGICAL_ERAS.findIndex(e=>e.id===eraId),start=Math.min(eraIndex,8);
  const eraPreview=CHRONOLOGICAL_ERAS.slice(start,start+3);
  const eraDone=medals.filter(a=>a.kind==='eras' && a.earned).length;
  const earned=medals.filter(a=>a.earned);
  const recent=[...earned].sort((a,b)=>(b.earnedAt??0)-(a.earnedAt??0) || medals.indexOf(a)-medals.indexOf(b)).slice(0,2);
  const ratingOnly=comics.filter(c=>c.rating>0&&!c.completed).sort((a,b)=>b.rating-a.rating);
  return <div className="profile-content path-profile">
    <section className="profile-era-hero" aria-label={`Текущая эра: ${era.title}`}>
      <div className="profile-hero-scene" aria-hidden="true"/>
      <div className="profile-hero-content"><span className="profile-eyebrow">ТЕКУЩАЯ ЭРА</span><h2>{era.title}</h2>
        <p>{progress.total ? `${progress.done} из ${progress.total} историй` : 'Ваш следующий маршрут'}</p>
        {progress.total>0 && <div className="profile-era-meter" role="progressbar" aria-label="Прогресс текущей эры" aria-valuenow={progress.done} aria-valuemin={0} aria-valuemax={progress.total}><i style={{width:`${progress.percent}%`}}/></div>}
        <button onClick={()=>onContinue(eraId)}>{progress.total ? 'Продолжить путь' : 'Собрать маршрут'}<ArrowRight size={17}/></button>
        <button className="profile-plan-link" onClick={()=>onEra(eraId)}>{eraMedal.earned ? 'Эра пройдена · посмотреть награду' : progress.planned ? `До награды: ${progress.total-progress.done} историй` : 'Закрепить состав эры'}<ChevronRight size={12}/></button>
      </div>
    </section>
    <div className="profile-inline-stats" aria-label="Общая статистика чтения">
      <span><BookOpen size={16}/><strong>{s.done}</strong>прочитано</span><span><Layers size={16}/><strong>{s.pages.toLocaleString('ru-RU')}</strong>страниц</span><span><Clock3 size={16}/><strong>{Math.floor(s.seconds/3600)} ч {Math.floor(s.seconds/60)%60} м</strong></span>
    </div>
    <section className="profile-path-section"><div className="profile-section-heading"><h2>Путь Бэтмена</h2><span>{eraDone} / 11 эр</span><button onClick={()=>onEra()}>Все эры<ArrowRight size={13}/></button></div>
      <div className="profile-era-rail">{eraPreview.map(e=>{
        const p=eraProgress(comics,state?.eraPlans,e.id),a=medals.find(m=>m.era===e.id)!;
        return <button key={e.id} className={`profile-era-stop ${e.id===eraId?'is-current':''} ${a.earned?'is-complete':''}`} onClick={()=>onEra(e.id)} aria-label={`Эра: ${e.title}`}><AchievementBadge medal={a}/><strong>{e.title}</strong><small>{a.earned?'Пройдена':p.total?`${p.done} / ${p.total} историй`:'Не начата'}</small></button>;
      })}</div>
    </section>
    <section className="profile-path-section profile-recent-awards"><div className="profile-section-heading"><h2>Последние награды</h2><button onClick={()=>onAchievements()}>Все {earned.length} / {medals.length}<ArrowRight size={13}/></button></div>
      {recent.length ? <div className="profile-award-rows">{recent.map(a=><button key={a.id} onClick={()=>onAchievements(a.id)}><AchievementBadge medal={a}/><span><strong>{a.name}</strong><small>{a.kind==='eras'?'Закреплённый маршрут эры пройден':a.hint.split('.')[0]}</small></span><ChevronRight size={17}/></button>)}</div> : <div className="profile-awards-empty"><AchievementBadge medal={medals.find(a=>a.id==='first')!}/><p>Первый патруль ещё впереди<small>Прочитайте свою первую историю.</small></p></div>}
    </section>
    <section className="profile-path-section profile-history-section"><div className="profile-section-heading"><h2>Недавно прочитано</h2>{history.length>3 && <button onClick={()=>setHistoryExpanded(v=>!v)}>{historyExpanded?'Свернуть':'Вся история'}<ArrowRight size={13}/></button>}</div>
      {history.length ? <div className={`profile-history-shelf ${historyExpanded?'is-expanded':''}`}>{(historyExpanded?history:history.slice(0,3)).map(c=><button key={c.id} onClick={()=>onEdit(c)} aria-label={`Сведения: ${c.title}`}><Cover comic={c} paper={c.physical==='yes'}/><strong>{c.title.replace(/^Бэтмен[.·:]?\s*/i,'')}</strong>{c.rating>0 && <span className="profile-shelf-stars" aria-label={`Оценка ${c.rating} из 5`}>{[1,2,3,4,5].map(n=><Star key={n} size={9} className={n<=c.rating?'rated':''}/>)}</span>}</button>)}</div> : <p className="profile-history-empty">Здесь появятся завершённые истории.</p>}
    </section>
    <p className="profile-archive-note">В архиве: {s.total} · Бумажных изданий: {s.paper}</p>
    {ratingOnly.length>0 && <section className="profile-path-section"><div className="profile-section-heading"><h2>Личные оценки</h2></div><div className="profile-personal-ratings">{ratingOnly.map(c=><button key={c.id} onClick={()=>onEdit(c)}><span>{c.title}</span><strong>{'★'.repeat(c.rating)}</strong><ChevronRight size={14}/></button>)}</div></section>}
  </div>;
}
