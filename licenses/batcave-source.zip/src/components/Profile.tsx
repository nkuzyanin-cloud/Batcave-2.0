import { useState, useEffect } from 'react';
import { BookOpen, Layers, Clock3, Star, ChevronRight, ChevronDown } from 'lucide-react';
import { type Comic, stats } from '../models';
import { Cover } from './ui';
import { AchievementBadge, AchievementProgress } from './AchievementBadge';
import { type Achievement, nextAchievements } from '../achievements';
import { completedHistory } from '../completion';
export function Profile({ comics, onEdit, medals, onAchievements }: { comics: Comic[]; onEdit: (comic: Comic) => void; medals: Achievement[]; onAchievements:(id?:string) => void }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!comics.some(c => c.paperStartedAt !== undefined)) return;
    const update = () => setNow(Date.now());
    update(); const id = window.setInterval(update, 1000);
    document.addEventListener('visibilitychange', update);
    return () => { clearInterval(id); document.removeEventListener('visibilitychange', update); };
  }, [comics]);
  const s = stats(comics, now);
  const ratings = comics.filter((c) => c.rating > 0 && !c.completed).sort((a, b) => b.rating - a.rating);
  const history = completedHistory(comics);
  const [historyLimit,setHistoryLimit]=useState(3);
  const earned = medals.filter(a => a.earned);
  const latest = [...earned].sort((a,b) => (b.earnedAt ?? 0) - (a.earnedAt ?? 0) || medals.indexOf(b) - medals.indexOf(a))[0];
  const next = nextAchievements(medals);
  return (
    <div className="profile-content">
      <div className="profile-summary award-summary">
        <div><BookOpen size={19}/><strong>{s.done}</strong><span>Прочитано</span></div>
        <div><Layers size={19}/><strong>{s.pages.toLocaleString('ru-RU')}</strong><span>Страниц</span></div>
        <div><Clock3 size={19}/><strong className="award-time">{Math.floor(s.seconds / 3600)} ч {Math.floor(s.seconds / 60) % 60} м</strong><span>Время чтения</span></div>
        <small className="archive-total">В архиве: {s.total} · На бумаге: {s.paper}</small>
      </div>
      <section className="profile-section award-preview">
        <h2>Достижения<button className="award-count-button" onClick={() => onAchievements()} aria-label="Открыть все достижения">{earned.length} / {medals.length}<ChevronRight size={15}/></button></h2>
        {latest ? <button className="award-latest" onClick={() => onAchievements(latest.id)}>
          <AchievementBadge medal={latest}/><span><small>ПОСЛЕДНЯЯ НАГРАДА</small><strong>{latest.name}</strong><span>{latest.hint.split('.')[0]}</span></span><ChevronRight size={17}/>
        </button> : <div className="award-intro"><AchievementBadge medal={medals[0]}/><p>Каждая история оставляет след.<small>Здесь появится ваша первая награда.</small></p></div>}
        {next.length > 0 && <><h3 className="award-next-heading">Следующие цели</h3><div className="award-next-grid">
          {next.map(a => <button className="award-next-card" key={a.id} onClick={() => onAchievements(a.id)}>
            <AchievementBadge medal={a}/><strong>{a.name}</strong><AchievementProgress medal={a} label/>
          </button>)}
        </div></>}
        <button className="award-all-button" onClick={() => onAchievements()}>Все достижения<ChevronRight size={16}/></button>
      </section>
      {history.length > 0 && <section className="profile-section">
        <h2>Прочитанные истории</h2>
        <div className="reading-history" id="reading-history">
          {history.slice(0,historyLimit).map(c => <button key={c.id} onClick={() => onEdit(c)}>
            <Cover comic={c} paper={c.physical === 'yes'} />
            <div><h3>{c.title}</h3>{c.authors && <small className="history-authors">{c.authors}</small>}
              {c.rating > 0 && <span className="history-stars" aria-label={`Оценка ${c.rating} из 5`}>{[1, 2, 3, 4, 5].map(n => <Star key={n} size={14} className={n <= c.rating ? 'rated' : ''} />)}</span>}
            </div><ChevronRight size={18} />
          </button>)}
        </div>
        {historyLimit<history.length && <button className="history-more secondary" aria-controls="reading-history" onClick={()=>setHistoryLimit(n=>n+3)}>Ещё<ChevronDown size={16}/></button>}
      </section>}
      {ratings.length > 0 && (
        <section className="profile-section">
          <h2>
            <Star size={15} />
            Личные оценки
          </h2>
          <div className="ratings-list">
            {ratings.map((c) => (
              <button key={c.id} onClick={() => onEdit(c)}>
                <span>{c.title}</span>
                <strong>{'★'.repeat(c.rating)}</strong>
              </button>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
