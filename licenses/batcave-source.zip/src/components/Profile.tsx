import {useEffect,useState} from 'react';
import {BookOpen,Layers,Clock3,Star,ChevronRight,ArrowRight} from 'lucide-react';
import {type Comic,stats} from '../models';
import {Cover} from './ui';
import {AchievementBadge,AchievementProgress} from './AchievementBadge';
import {type Achievement} from '../achievements';
import {completedHistory} from '../completion';
import {comicUniverse,type Universe} from '../universes';
import {UniverseCover} from './Universes';
export function Profile({comics,universes,onEdit,medals,onAchievements,onRead,onUniverse}:{comics:Comic[];universes:Universe[];onEdit:(c:Comic)=>void;medals:Achievement[];onAchievements:(id?:string)=>void;onRead:(c:Comic)=>void;onUniverse:(id:string)=>void}){
 const[now,setNow]=useState(Date.now()),[historyExpanded,setHistoryExpanded]=useState(false);
 useEffect(()=>{if(!comics.some(c=>c.paperStartedAt!==undefined))return;const id=window.setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(id);},[comics]);
 const s=stats(comics,now),history=completedHistory(comics),earned=medals.filter(a=>a.earned);
 const reading=[...comics].filter(c=>c.digital&&!c.completed&&c.lastOpened).sort((a,b)=>b.lastOpened-a.lastOpened)[0];
 const preview=['stories','pages','time'].map(kind=>{const list=medals.filter(a=>a.kind===kind);return list.find(a=>!a.earned)??list.at(-1)!;});
 const ratingOnly=comics.filter(c=>c.rating>0&&!c.completed).sort((a,b)=>b.rating-a.rating);
 return <div className="profile-content neutral-profile">
  {reading&&<section className="profile-path-section"><div className="profile-section-heading"><h2>Продолжить чтение</h2></div><button className="profile-continue" onClick={()=>onRead(reading)}><Cover comic={reading}/><span><strong>{reading.title}</strong><small>Страница {reading.page+1} из {reading.pageCount}</small><i className="universe-meter"><i style={{width:`${Math.min(100,(reading.page+1)/Math.max(1,reading.pageCount)*100)}%`}}/></i></span><ChevronRight size={17}/></button></section>}
  <section className="profile-path-section"><div className="profile-section-heading"><h2>Статистика</h2></div><div className="neutral-stats" aria-label="Общая статистика чтения"><div><Layers/><strong>{s.done}</strong><small>Комиксов</small></div><div><BookOpen/><strong>{s.pages.toLocaleString('ru-RU')}</strong><small>Страниц</small></div><div><Clock3/><strong>{Math.floor(s.seconds/3600)} ч {Math.floor(s.seconds/60)%60} м</strong><small>За чтением</small></div></div></section>
  <section className="profile-path-section"><div className="profile-section-heading"><h2>Достижения</h2><button onClick={()=>onAchievements()}>Все {earned.length} / {medals.length}<ArrowRight size={13}/></button></div><div className="neutral-achievements">{preview.map(a=><button key={a.id} onClick={()=>onAchievements(a.id)}><AchievementBadge medal={a}/><strong>{a.name}</strong><AchievementProgress medal={a} label/></button>)}</div></section>
  <section className="profile-path-section"><div className="profile-section-heading"><h2>Мои серии</h2></div><div className="profile-series-list">{universes.map(u=>{const list=comics.filter(c=>comicUniverse(c)===u.id),done=list.filter(c=>c.completed).length;return <button key={u.id} onClick={()=>onUniverse(u.id)}><UniverseCover universe={u} comics={comics}/><span><strong>{u.title}</strong><small>{list.length?`${done} / ${list.length} прочитано`:'Не начато'}</small><i className="universe-meter"><i style={{width:`${list.length?done/list.length*100:0}%`}}/></i></span><ChevronRight size={17}/></button>})}</div></section>
  <section className="profile-path-section profile-history-section"><div className="profile-section-heading"><h2>Недавно прочитано</h2>{history.length>3&&<button onClick={()=>setHistoryExpanded(v=>!v)}>{historyExpanded?'Свернуть':'Вся история'}<ArrowRight size={13}/></button>}</div>{history.length?<div className={`profile-history-shelf ${historyExpanded?'is-expanded':''}`}>{(historyExpanded?history:history.slice(0,3)).map(c=><button key={c.id} onClick={()=>onEdit(c)} aria-label={`Сведения: ${c.title}`}><Cover comic={c} paper={c.physical==='yes'}/><strong>{c.title}</strong>{c.rating>0&&<span className="profile-shelf-stars" aria-label={`Оценка ${c.rating} из 5`}>{[1,2,3,4,5].map(n=><Star key={n} size={9} className={n<=c.rating?'rated':''}/>)}</span>}</button>)}</div>:<p className="profile-history-empty">Здесь появятся завершённые истории.</p>}</section>
  <p className="profile-archive-note">В архиве: {s.total} · Бумажных изданий: {s.paper}</p>
  {ratingOnly.length>0&&<section className="profile-path-section"><div className="profile-section-heading"><h2>Личные оценки</h2></div><div className="profile-personal-ratings">{ratingOnly.map(c=><button key={c.id} onClick={()=>onEdit(c)}><span>{c.title}</span><strong>{'★'.repeat(c.rating)}</strong><ChevronRight size={14}/></button>)}</div></section>}
 </div>;
}
