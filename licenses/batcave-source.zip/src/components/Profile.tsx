import { useState, useEffect } from 'react';
import { BookOpen, Library, Monitor, Check, Star, ChevronRight, ChevronDown } from 'lucide-react';
import { type Comic, stats } from '../models';
import { Bat, Cover } from './ui';
import { achievements } from '../achievements';
export function Profile({ comics, onEdit }: { comics: Comic[]; onEdit: (comic: Comic) => void }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!comics.some(c => c.paperStartedAt !== undefined)) return;
    const update = () => setNow(Date.now());
    update(); const id = window.setInterval(update, 1000);
    document.addEventListener('visibilitychange', update);
    return () => { clearInterval(id); document.removeEventListener('visibilitychange', update); };
  }, [comics]);
  const s = stats(comics, now);
  const ratings = comics.filter((c) => c.rating > 0 && !c.completed).sort((a, b) => b.rating - a.rating);
  const history = comics.filter(c => c.completed).sort((a, b) => b.lastOpened - a.lastOpened || b.updatedAt - a.updatedAt);
  const [expanded, setExpanded] = useState(false);
  const medals = achievements(comics);
  const earned = medals.filter(a => a.earned);
  const preview = [...earned, ...medals.filter(a => !a.earned)].slice(0, 3);
  return (
    <div className="profile-content">
      <h2 className="gallery-heading">Моё чтение</h2>
      <div className="stats-grid">
        {[
          [s.total, 'Комиксов'],
          [s.done, 'Прочитано'],
          [s.pages, 'Страниц'],
          [
            `${Math.floor(s.seconds / 3600)} ч ${Math.floor(s.seconds / 60) % 60} м`,
            'Время чтения',
          ],
        ].map(([value, label]) => (
          <div className="stat" key={label}>
            <strong>{value}</strong>
            <span>{label}</span>
          </div>
        ))}
      </div>
      <section className="profile-section">
        <h2>Достижения<small className="achievement-count" aria-label={`Достигнуто ${earned.length} из ${medals.length}`}>{earned.length} / {medals.length}</small></h2>
        <div className="achievements" id="achievements-list">
          {(expanded ? medals : preview).map(a => (
            <div key={a.id} className={a.earned ? 'earned' : ''} title={a.hint} data-achievement={a.id}>
              <div className={`achievement-medal medal-${a.kind}`} aria-hidden="true">
                {a.kind === 'stories' ? <Bat /> : a.kind === 'pages' ? <BookOpen size={25} strokeWidth={1.5} /> : a.kind === 'paper' ? <Library size={25} strokeWidth={1.5} /> : <Monitor size={25} strokeWidth={1.5} />}
                {a.goal > 1 && <b className="medal-level">{a.goal}</b>}
              </div>
              <span>{a.name}</span>
              {a.earned ? <span className="sr-only">Достигнуто: {a.hint}</span> : <small aria-label={a.hint}>{a.value} / {a.goal}</small>}
            </div>
          ))}
        </div>
        <button className="achievement-toggle" aria-expanded={expanded} aria-controls="achievements-list" onClick={() => setExpanded(v => !v)}>{expanded ? 'Свернуть' : 'Все достижения'}<ChevronDown size={15} /></button>
      </section>
      {history.length > 0 && <section className="profile-section">
        <h2>Прочитанные истории</h2>
        <div className="reading-history">
          {history.map(c => <button key={c.id} onClick={() => onEdit(c)}>
            <Cover comic={c} paper={c.physical === 'yes'} />
            <div><h3>{c.title}</h3><span className="card-status"><Check size={12} />Прочитано</span>
              {c.rating > 0 && <span className="history-stars" aria-label={`Оценка ${c.rating} из 5`}>{[1, 2, 3, 4, 5].map(n => <Star key={n} size={14} className={n <= c.rating ? 'rated' : ''} />)}</span>}
            </div><ChevronRight size={18} />
          </button>)}
        </div>
      </section>}
      {ratings.length > 0 && (
        <section className="profile-section">
          <h2>
            <Star size={15} />
            Личные оценки
          </h2>
          <div className="ratings-list">
            {ratings.map((c) => (
              <button key={c.id} onClick={() => onEdit(c)}>
                <span>{c.title}</span>
                <strong>{'★'.repeat(c.rating)}</strong>
              </button>
            ))}
          </div>
        </section>
      )}
      <details className="stat-notes">
        <summary>Как считается статистика</summary>
        <p>
          Страницы — разные открытые цифровые страницы и полный объём завершённых бумажных изданий (старый частичный прогресс сохранён). Для одного комикса в двух форматах учитывается больший прогресс, а не сумма. Бумажное время учитывается от «Старт» до «Стоп», даже при закрытом приложении. Завершение книги останавливает сеанс. Цифровое время — приблизительная активность в читалке, с
          паузой при сворачивании и после двух минут без действий. Бумажные книги можно отметить
          прочитанными вручную.
        </p>
      </details>
    </div>
  );
}
