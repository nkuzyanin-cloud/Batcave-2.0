import {Fragment,useEffect,useLayoutEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
import {Plus,Pencil,ArrowUpDown,Trash2,ChevronDown} from 'lucide-react';
import {type Comic,errorMessage} from '../models';
import {type Universe} from '../universes';
import {orderedSeriesTimeline} from '../roadmap';
import {searchComics} from '../library-home';
import {RouteVolume} from './RouteVolume';
import '../route-gallery.css';
import {Roadmap} from './Roadmap';
import {getCollapsedSections,saveSectionDisclosure,getExpandedIssueLists,saveExpandedIssueList} from '../storage/route-disclosures';
import {Cover,Modal} from './ui';
import {useRouteDrag,type RouteDrop} from './use-route-drag';

export function SeriesRoute({universe,comics,query,onReady,onRead,onEdit,onAdd,onMove,onDelete}:{
  universe:Universe;comics:Comic[];query:string;onReady:()=>void;
  onRead:(c:Comic,rect:DOMRect)=>void;onEdit:(c:Comic)=>void;onAdd:(era:string)=>void;
  onMove:(id:string,era:string,beforeId?:string)=>Promise<void>;onDelete:(comic:Comic)=>Promise<void>;
}) {
  const root=useRef<HTMLDivElement>(null);
  const [menu,setMenu]=useState<Comic>(),[moving,setMoving]=useState<Comic>(),[deleting,setDeleting]=useState<Comic>();
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const [collapsed,setCollapsed]=useState<Set<string>>();
  const [fullLists,setFullLists]=useState<Set<string>>(new Set());
  const [sectionMenu,setSectionMenu]=useState<string>();
  useEffect(()=>{
    let active=true;
    void Promise.all([getCollapsedSections(universe.id),getExpandedIssueLists(universe.id)]).then(([ids,lists])=>{if(active){setCollapsed(ids);setFullLists(lists);}}).catch(e=>{
      if(active){setCollapsed(new Set());setError(`Не удалось восстановить вид разделов: ${errorMessage(e)}`);}
    });
    return()=>{active=false;};
  },[universe.id]);
  useLayoutEffect(()=>{if(collapsed)onReady();},[onReady,!!collapsed]);
  // Search opens matching sections without discarding the ordinary disclosure state.
  const [searchCollapsed,setSearchCollapsed]=useState({query:'',ids:new Set<string>()});
  const searching=query.trim();
  const closed=searching?(searchCollapsed.query===searching?searchCollapsed.ids:new Set<string>()):collapsed??new Set<string>();
  function toggle(era:string){
    const next=new Set(closed);next.has(era)?next.delete(era):next.add(era);
    if(searching)setSearchCollapsed({query:searching,ids:next});else {
      setCollapsed(next);
      void saveSectionDisclosure(universe.id,era,next.has(era)).catch(e=>setError(`Вид разделов не сохранён: ${errorMessage(e)}`));
    }
  }
  function showAll(era:string){
    const expanded=!fullLists.has(era);
    setFullLists(prev=>{const next=new Set(prev);expanded?next.add(era):next.delete(era);return next;});
    void saveExpandedIssueList(universe.id,era,expanded).catch(e=>setError(`Вид выпусков не сохранён: ${errorMessage(e)}`));
  }
  const all=universe.chapters.flatMap(ch=>orderedSeriesTimeline(comics,ch.id));
  async function move(c:Comic,target:RouteDrop){
    setBusy(true);setError('');
    try {await onMove(c.id,target.era,target.beforeId);setCollapsed(prev=>{const next=new Set(prev);next.delete(target.era);return next;});setMoving(undefined);setNotice(`«${c.title}» перемещён: ${universe.chapters.find(ch=>ch.id===target.era)?.title??''}`);}
    catch(e){setError(errorMessage(e));}
    finally{setBusy(false);}
  }
  const drag=useRouteDrag(root,busy||!!query.trim()||!!menu||!!sectionMenu||!!moving||!!deleting,(c,target)=>{void move(c,target);});
  const visibleChapters=universe.chapters.map((ch,index)=>({ch,index,entries:orderedSeriesTimeline(comics,ch.id)})).filter(({entries})=>!searching||searchComics(entries,query).length);
  if(!collapsed)return <p className="library-empty" role="status">Загрузка разделов…</p>;
  return <div ref={root} className={`series-route ${drag.dragging?'route-drag-active':''}`} aria-busy={busy}>
    <div className="sr-only" role="status">{drag.dragging?`Перенос: ${drag.dragging.title}. ${drag.target?universe.chapters.find(ch=>ch.id===drag.target?.era)?.title:'Выберите место вставки'}`:busy?'Сохранение порядка…':notice}</div>
    {error&&!moving&&!deleting&&<p className="error" role="alert">{error}</p>}
    {query.trim()&&!searchComics(all,query).length&&<p className="library-empty">Ничего не найдено. Измените поисковый запрос.</p>}
    <div className="route-gallery">
    {Array.from({length:Math.ceil(visibleChapters.length/2)},(_,pair)=>{
      const chapters=visibleChapters.slice(pair*2,pair*2+2);
      return <Fragment key={chapters[0].ch.id}>
        {chapters.map(({ch,index,entries},column)=>{
          const done=entries.filter(c=>c.completed).length,single=entries.length===1;
          const dropEnd=drag.dragging&&drag.target?.era===ch.id&&!drag.target.beforeId;
          const expanded=!closed.has(ch.id);
          return <section key={ch.id} id={`route-section-${ch.id}`} data-route-section={ch.id} data-comic-id={single?entries[0].id:undefined}
            className={`route-section route-volume ${single?'route-single':''} ${!entries.length?'route-section-vacant':''} ${entries.length&&done===entries.length?'is-complete':''} ${expanded&&entries.length>1?'is-expanded':''} ${dropEnd?'is-drop-end':''} ${single&&drag.target?.beforeId===entries[0]?.id?'is-drop-before':''} ${drag.dragging?.id===entries[0]?.id&&single?'is-dragging':''}`} aria-label={ch.title} style={{gridColumn:column+1}}>
            <RouteVolume title={ch.title} number={index+1} entries={entries} expanded={expanded} bodyId={`route-issues-${ch.id}`} busy={busy}
              onOpen={rect=>single?(entries[0].digital?onRead(entries[0],rect):onEdit(entries[0])):toggle(ch.id)}
              onMenu={()=>{setError('');single?setMenu(entries[0]):setSectionMenu(ch.id);}} onAdd={()=>onAdd(ch.id)} onEdit={onEdit}
              actions={{onHoldPointer:drag.startPointer,onHoldTouch:drag.startTouch,consumeClick:drag.consumeClick,resetClick:drag.resetClick}}/>
          </section>;
        })}
        {chapters.filter(({entries})=>entries.length>1).map(({ch,entries})=>{
          const shown=searchComics(entries,query),done=entries.filter(c=>c.completed).length;
          const full=!!searching||fullLists.has(ch.id),visible=full?shown:shown.slice(0,3);
          return <section key={`issues-${ch.id}`} id={`route-issues-${ch.id}`} data-route-issue-section={ch.id} aria-label={`Выпуски раздела «${ch.title}»`}
            className={`route-section-body route-gallery-issues ${drag.dragging&&drag.target?.era===ch.id&&!drag.target.beforeId?'is-drop-end':''}`} hidden={closed.has(ch.id)}>
            <header className="route-gallery-issues-heading"><div><h3>{ch.title}</h3><span>{searching?`Найдено: ${shown.length}`:`${done} из ${entries.length} прочитано`}</span></div>
              <button className="icon-button route-add" aria-label={`Добавить комикс в раздел «${ch.title}»`} disabled={busy} onClick={()=>onAdd(ch.id)}><Plus size={21}/></button>
            </header>
            <Roadmap comics={visible} all={all} onRead={onRead} onEdit={onEdit} onMenu={c=>{setError('');setMenu(c);}}
              onHoldPointer={drag.startPointer} onHoldTouch={drag.startTouch} consumeClick={drag.consumeClick} resetClick={drag.resetClick}
              draggingId={drag.dragging?.id} beforeId={drag.target?.era===ch.id?drag.target.beforeId:undefined}/>
            {!searching&&shown.length>3&&<button className="route-gallery-all" aria-expanded={full} onClick={()=>showAll(ch.id)}>{full?'Свернуть список':`Все выпуски (${shown.length})`}<ChevronDown size={17}/></button>}
          </section>;
        })}
      </Fragment>;
    })}
    </div>
    {sectionMenu&&<Modal title={universe.chapters.find(ch=>ch.id===sectionMenu)?.title??'Раздел'} className="route-actions-sheet" onClose={()=>setSectionMenu(undefined)}>
      <div className="route-menu-actions">
        <button onClick={()=>{onAdd(sectionMenu);setSectionMenu(undefined);}}><Plus size={18}/>Добавить комикс</button>
        <button onClick={()=>{toggle(sectionMenu);setSectionMenu(undefined);}}><ChevronDown size={18}/>{closed.has(sectionMenu)?'Раскрыть выпуски':'Свернуть выпуски'}</button>
      </div>
    </Modal>}
    {drag.dragging&&createPortal(<div className="route-drag-ghost" data-route-ghost aria-hidden="true"><Cover comic={drag.dragging}/><span>{drag.dragging.title}</span></div>,document.body)}
    {menu&&<Modal title={menu.title} className="route-actions-sheet" onClose={()=>setMenu(undefined)}>
      <div className="route-menu-actions">
        <button onClick={()=>{const era=universe.chapters.find(ch=>orderedSeriesTimeline(comics,ch.id).some(c=>c.id===menu.id))?.id;if(era){setMenu(undefined);onAdd(era);}}}><Plus size={18}/>Добавить комикс в раздел</button>
        <button onClick={()=>{setMenu(undefined);onEdit(menu);}}><Pencil size={18}/>Редактировать</button>
        <button onClick={()=>{setMenu(undefined);setMoving(menu);}}><ArrowUpDown size={18}/>Переместить</button>
        <button className="danger" onClick={()=>{setMenu(undefined);setDeleting(menu);}}><Trash2 size={18}/>Удалить комикс</button>
      </div>
    </Modal>}
    {moving&&<MoveDialog comic={moving} universe={universe} comics={comics} busy={busy} error={error} onClose={()=>{if(!busy){setMoving(undefined);setError('');}}} onMove={target=>void move(moving,target)}/>}
    {deleting&&<Modal title="Удалить комикс?" onClose={()=>{if(!busy){setDeleting(undefined);setError('');}}}>
      <p>«{deleting.title}» и его локальный файл будут удалены из библиотеки.</p>
      {error&&<p className="error" role="alert">{error}</p>}
      <div className="route-dialog-actions"><button className="secondary" disabled={busy} onClick={()=>setDeleting(undefined)}>Отмена</button><button className="danger" disabled={busy} onClick={()=>void(async()=>{
        setBusy(true);setError('');try{await onDelete(deleting);setDeleting(undefined);setNotice('Комикс удалён.');}catch(e){setError(errorMessage(e));}finally{setBusy(false);}
      })()}>{busy?'Удаление…':'Удалить'}</button></div>
    </Modal>}
  </div>;
}

function MoveDialog({comic,universe,comics,busy,error,onMove,onClose}:{comic:Comic;universe:Universe;comics:Comic[];busy:boolean;error:string;onMove:(target:RouteDrop)=>void;onClose:()=>void}) {
  const [era,setEra]=useState(universe.chapters.find(ch=>orderedSeriesTimeline(comics,ch.id).some(c=>c.id===comic.id))?.id??universe.chapters[0].id);
  const [before,setBefore]=useState('');
  const candidates=orderedSeriesTimeline(comics,era).filter(c=>c.id!==comic.id);
  return <Modal title="Переместить комикс" onClose={onClose}>
    <form className="route-move-form" onSubmit={e=>{e.preventDefault();if(!busy)onMove({era,beforeId:before||undefined});}}>
      <p>{comic.title}</p>
      <label>Раздел<select aria-label="Раздел назначения" disabled={busy} value={era} onChange={e=>{setEra(e.target.value);setBefore('');}}>{universe.chapters.map(ch=><option key={ch.id} value={ch.id}>{ch.title}</option>)}</select></label>
      <label>Положение<select aria-label="Место в разделе" disabled={busy} value={before} onChange={e=>setBefore(e.target.value)}><option value="">В конец раздела</option>{candidates.map(c=><option key={c.id} value={c.id}>Перед: {c.title}</option>)}</select></label>
      {error&&<p className="error" role="alert">{error}</p>}
      <button type="submit" className="primary" disabled={busy}>{busy?'Сохранение…':'Переместить'}</button>
    </form>
  </Modal>;
}
