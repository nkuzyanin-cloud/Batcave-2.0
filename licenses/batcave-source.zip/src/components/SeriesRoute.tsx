import {useEffect,useLayoutEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
import {Plus,Pencil,ArrowUpDown,Trash2,ChevronDown} from 'lucide-react';
import {type Comic,errorMessage} from '../models';
import {type Universe} from '../universes';
import {orderedSeriesTimeline} from '../roadmap';
import {routeProgress,searchComics} from '../library-home';
import {Roadmap} from './Roadmap';
import {getCollapsedSections,saveSectionDisclosure} from '../storage/route-disclosures';
import {Cover,Modal} from './ui';
import {AppIcon} from './AppIcon';
import {ReadingProgress} from './ReadingProgress';
import {useRouteDrag,type RouteDrop} from './use-route-drag';

export function SeriesRoute({universe,comics,query,onReady,onRead,onEdit,onAdd,onMove,onDelete}:{
  universe:Universe;comics:Comic[];query:string;onReady:()=>void;
  onRead:(c:Comic,rect:DOMRect)=>void;onEdit:(c:Comic)=>void;onAdd:(era:string)=>void;
  onMove:(id:string,era:string,beforeId?:string)=>Promise<void>;onDelete:(comic:Comic)=>Promise<void>;
}) {
  const root=useRef<HTMLDivElement>(null);
  const [menu,setMenu]=useState<Comic>(),[moving,setMoving]=useState<Comic>(),[deleting,setDeleting]=useState<Comic>();
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const [collapsed,setCollapsed]=useState<Set<string>>();
  useEffect(()=>{
    let active=true;
    void getCollapsedSections(universe.id).then(ids=>{if(active)setCollapsed(ids);}).catch(e=>{
      if(active){setCollapsed(new Set());setError(`Не удалось восстановить вид разделов: ${errorMessage(e)}`);}
    });
    return()=>{active=false;};
  },[universe.id]);
  useLayoutEffect(()=>{if(collapsed)onReady();},[onReady,!!collapsed]);
  // Search opens matching sections without discarding the ordinary disclosure state.
  const [searchCollapsed,setSearchCollapsed]=useState({query:'',ids:new Set<string>()});
  const searching=query.trim();
  const closed=searching?(searchCollapsed.query===searching?searchCollapsed.ids:new Set<string>()):collapsed??new Set<string>();
  function toggle(era:string){
    const next=new Set(closed);next.has(era)?next.delete(era):next.add(era);
    if(searching)setSearchCollapsed({query:searching,ids:next});else {
      setCollapsed(next);
      void saveSectionDisclosure(universe.id,era,next.has(era)).catch(e=>setError(`Вид разделов не сохранён: ${errorMessage(e)}`));
    }
  }
  const all=universe.chapters.flatMap(ch=>orderedSeriesTimeline(comics,ch.id));
  async function move(c:Comic,target:RouteDrop){
    setBusy(true);setError('');
    try {await onMove(c.id,target.era,target.beforeId);setCollapsed(prev=>{const next=new Set(prev);next.delete(target.era);return next;});setMoving(undefined);setNotice(`«${c.title}» перемещён: ${universe.chapters.find(ch=>ch.id===target.era)?.title??''}`);}
    catch(e){setError(errorMessage(e));}
    finally{setBusy(false);}
  }
  const drag=useRouteDrag(root,busy||!!query.trim()||!!menu||!!moving||!!deleting,(c,target)=>{void move(c,target);});
  if(!collapsed)return <p className="library-empty" role="status">Загрузка разделов…</p>;
  return <div ref={root} className={`series-route ${drag.dragging?'route-drag-active':''}`} aria-busy={busy}>
    <div className="sr-only" role="status">{drag.dragging?`Перенос: ${drag.dragging.title}. ${drag.target?universe.chapters.find(ch=>ch.id===drag.target?.era)?.title:'Выберите место вставки'}`:busy?'Сохранение порядка…':notice}</div>
    {error&&!moving&&!deleting&&<p className="error" role="alert">{error}</p>}
    {query.trim()&&!searchComics(all,query).length&&<p className="library-empty">Ничего не найдено. Измените поисковый запрос.</p>}
    {universe.chapters.map((ch,index)=>{
      const entries=orderedSeriesTimeline(comics,ch.id),shown=searchComics(entries,query),done=entries.filter(c=>c.completed).length;
      if(query.trim()&&!shown.length)return null;
      const dropEnd=drag.dragging&&drag.target?.era===ch.id&&!drag.target.beforeId;
      const expanded=!closed.has(ch.id),bodyId=`route-issues-${ch.id}`;
      const count=entries.length,ending=count%10===1&&count%100!==11?'выпуск':count%10>=2&&count%10<=4&&(count%100<12||count%100>14)?'выпуска':'выпусков';
      return <section key={ch.id} id={`route-section-${ch.id}`} data-route-section={ch.id} className={`route-section ${entries.length?'':'route-section-vacant'} ${dropEnd?'is-drop-end':''}`}  aria-label={ch.title}>
        <h2 className="route-section-heading"><button className="route-section-toggle" aria-expanded={expanded} aria-controls={bodyId} aria-label={`${expanded?'Свернуть':'Раскрыть'} раздел «${ch.title}»`} disabled={busy||!!drag.dragging} onClick={()=>toggle(ch.id)}>
          <span className="route-section-copy"><span className="route-section-kicker">РАЗДЕЛ {String(index+1).padStart(2,'0')}</span><span className="route-section-name">{ch.title}</span><span className="route-section-meta">{count?`${count} ${ending} · ${done===count?'Все прочитаны':done?`${done} прочитано`:'Ещё не начато'}`:'Пока нет выпусков'}</span></span>
          <AppIcon icon={ChevronDown} size={22}/>
        </button></h2>
        <div className="route-section-body" id={bodyId} hidden={!expanded}>
        <div className="route-section-tools"><span>Выпуски</span><button className="icon-button route-add" aria-label={`Добавить комикс в раздел «${ch.title}»`} disabled={busy} onClick={()=>onAdd(ch.id)}><AppIcon icon={Plus} size={19}/><span>Добавить</span></button></div>
        {entries.length>0&&<div className="route-section-progress"><span>{done} из {entries.length} прочитано</span><ReadingProgress label={`Прогресс раздела ${ch.title}`} value={routeProgress(entries)} completed={done/entries.length*100}/></div>}
        {shown.length?<Roadmap comics={shown} all={all} onRead={onRead} onEdit={onEdit} onMenu={c=>{setError('');setMenu(c);}}
          onHoldPointer={drag.startPointer} onHoldTouch={drag.startTouch} consumeClick={drag.consumeClick} resetClick={drag.resetClick}
          draggingId={drag.dragging?.id} beforeId={drag.target?.era===ch.id?drag.target.beforeId:undefined}/>
          :null}
        </div>
      </section>;
    })}
    {drag.dragging&&createPortal(<div className="route-drag-ghost" data-route-ghost aria-hidden="true"><Cover comic={drag.dragging}/><span>{drag.dragging.title}</span></div>,document.body)}
    {menu&&<Modal title={menu.title} className="route-actions-sheet" onClose={()=>setMenu(undefined)}>
      <div className="route-menu-actions">
        <button onClick={()=>{setMenu(undefined);onEdit(menu);}}><Pencil size={18}/>Редактировать</button>
        <button onClick={()=>{setMenu(undefined);setMoving(menu);}}><ArrowUpDown size={18}/>Переместить</button>
        <button className="danger" onClick={()=>{setMenu(undefined);setDeleting(menu);}}><Trash2 size={18}/>Удалить комикс</button>
      </div>
    </Modal>}
    {moving&&<MoveDialog comic={moving} universe={universe} comics={comics} busy={busy} error={error} onClose={()=>{if(!busy){setMoving(undefined);setError('');}}} onMove={target=>void move(moving,target)}/>}
    {deleting&&<Modal title="Удалить комикс?" onClose={()=>{if(!busy){setDeleting(undefined);setError('');}}}>
      <p>«{deleting.title}» и его локальный файл будут удалены из библиотеки.</p>
      {error&&<p className="error" role="alert">{error}</p>}
      <div className="route-dialog-actions"><button className="secondary" disabled={busy} onClick={()=>setDeleting(undefined)}>Отмена</button><button className="danger" disabled={busy} onClick={()=>void(async()=>{
        setBusy(true);setError('');try{await onDelete(deleting);setDeleting(undefined);setNotice('Комикс удалён.');}catch(e){setError(errorMessage(e));}finally{setBusy(false);}
      })()}>{busy?'Удаление…':'Удалить'}</button></div>
    </Modal>}
  </div>;
}

function MoveDialog({comic,universe,comics,busy,error,onMove,onClose}:{comic:Comic;universe:Universe;comics:Comic[];busy:boolean;error:string;onMove:(target:RouteDrop)=>void;onClose:()=>void}) {
  const [era,setEra]=useState(universe.chapters.find(ch=>orderedSeriesTimeline(comics,ch.id).some(c=>c.id===comic.id))?.id??universe.chapters[0].id);
  const [before,setBefore]=useState('');
  const candidates=orderedSeriesTimeline(comics,era).filter(c=>c.id!==comic.id);
  return <Modal title="Переместить комикс" onClose={onClose}>
    <form className="route-move-form" onSubmit={e=>{e.preventDefault();if(!busy)onMove({era,beforeId:before||undefined});}}>
      <p>{comic.title}</p>
      <label>Раздел<select aria-label="Раздел назначения" disabled={busy} value={era} onChange={e=>{setEra(e.target.value);setBefore('');}}>{universe.chapters.map(ch=><option key={ch.id} value={ch.id}>{ch.title}</option>)}</select></label>
      <label>Положение<select aria-label="Место в разделе" disabled={busy} value={before} onChange={e=>setBefore(e.target.value)}><option value="">В конец раздела</option>{candidates.map(c=><option key={c.id} value={c.id}>Перед: {c.title}</option>)}</select></label>
      {error&&<p className="error" role="alert">{error}</p>}
      <button type="submit" className="primary" disabled={busy}>{busy?'Сохранение…':'Переместить'}</button>
    </form>
  </Modal>;
}
