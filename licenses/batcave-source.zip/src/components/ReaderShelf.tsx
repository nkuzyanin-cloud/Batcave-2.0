import {useEffect,useState,type CSSProperties} from 'react';
import {readerLevel,pagesLabel,SHELF_SIZE} from '../reader-level';
import artwork from '../assets/reader-shelf-city.webp';

const SEEN_KEY='comics-shelf-seen-v1';
function seenLevel(fallback:number) {
  try {
    const value=sessionStorage.getItem(SEEN_KEY);
    if(value===null)return fallback;
    const level=Number(value);
    return Number.isInteger(level)&&level>=0&&level<=SHELF_SIZE?level:fallback;
  }catch{return fallback;}
}

export function ReaderShelf({pages,hasComics}:{pages:number;hasComics:boolean}) {
  const progress=readerLevel(pages,hasComics);
  const [seen,setSeen]=useState(()=>seenLevel(progress.level));
  useEffect(()=>{
    try{sessionStorage.setItem(SEEN_KEY,String(progress.level));}catch{/* Progress itself is derived from the library. */}
    const timer=window.setTimeout(()=>setSeen(progress.level),800);
    return()=>window.clearTimeout(timer);
  },[progress.level]);
  const remaining=progress.next===undefined?0:progress.next-progress.pages;
  return <div className="reader-shelf" data-reader-level={progress.level}>
    <span className="reader-shelf-caption">Ваш прогресс</span>
    <div className="reader-shelf-scene" role="img" aria-label={`Полка читателя: ${progress.level} из ${SHELF_SIZE} корешков`}>
      <div className="reader-shelf-books" aria-hidden="true">
        {Array.from({length:progress.level},(_,index)=><span key={index} className="reader-shelf-spine" data-spine={index+1} data-new={index>=seen||undefined}
          style={{backgroundImage:`url(${artwork})`,backgroundPosition:`${index/(SHELF_SIZE-1)*100}% bottom`,height:`${100-[0,1.1,.4,1.7,.8,.2,1.3][index%7]}%`,
            '--spine-delay':`${Math.min(5,Math.max(0,index-seen))*55}ms`} as CSSProperties}/>) }
      </div>
      <div className="reader-shelf-ledge" aria-hidden="true"/>
    </div>
    <p className="reader-shelf-level">Уровень {progress.level}</p>
    <p className="reader-shelf-next">{progress.level===0?'Добавьте первый комикс':progress.next===undefined?'Полка собрана':`До уровня ${progress.level+1} — ${remaining.toLocaleString('ru-RU')} ${pagesLabel(remaining)}`}</p>
  </div>;
}
