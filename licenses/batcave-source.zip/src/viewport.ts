import { useLayoutEffect } from 'react';

export function keyboardViewport(visible: number, layout: number, typing: boolean, scale: number) {
  // A shortened standalone viewport is not evidence of a keyboard. Only
  // resize while editing, with a keyboard-sized reduction and no pinch zoom.
  return typing && Math.abs(scale - 1) < .01 && visible > 0 && layout - visible > 150
    ? visible : undefined;
}

export function overlayTop(visualTop: number, canvasTop: number) {
  return Math.max(0, visualTop - canvasTop);
}

export function focusedScrollDelta(top: number, bottom: number, visibleTop: number, visibleBottom: number) {
  if (top < visibleTop) return top - visibleTop;
  if (bottom > visibleBottom) return bottom - visibleBottom;
  return 0;
}

// CSS owns the full-page geometry. visualViewport is only a keyboard signal:
// installed iOS apps may report a shorter height even without browser chrome.
export function useAppViewport() {
  useLayoutEffect(() => {
    let frame = 0;
    let keyboardActive = false;
    let modalKeyboard = false;
    const viewport = window.visualViewport;
    const root = document.documentElement;
    const measure = () => {
      const standalone = window.matchMedia('(display-mode: standalone)').matches || (navigator as Navigator & { standalone?: boolean }).standalone === true;
      root.toggleAttribute('data-standalone', standalone);
      const active = document.activeElement;
      const typing = active instanceof HTMLElement && (active.matches('input, textarea, select') || active.isContentEditable);
      // Keep the keyboard geometry during blur/field switches until it closes.
      const height = keyboardViewport(viewport?.height || window.innerHeight, root.clientHeight, typing || keyboardActive, viewport?.scale || 1);
      if (height !== undefined) {
        keyboardActive = true;
        modalKeyboard = modalKeyboard || !!active?.closest('.modal');
        const top = overlayTop(viewport?.offsetTop || 0, document.body.getBoundingClientRect().top);
        root.style.setProperty('--overlay-height', `${height}px`);
        root.style.setProperty('--overlay-top', `${top}px`);
        root.toggleAttribute('data-keyboard-open', true);
        if (modalKeyboard) {
          // Opening a form must not resize or move the underlying archive/reader.
          root.style.removeProperty('--keyboard-height');
          root.style.removeProperty('--keyboard-top');
        } else {
          root.style.setProperty('--keyboard-height', `${height}px`);
          root.style.setProperty('--keyboard-top', `${top}px`);
        }
        const modal = active instanceof HTMLElement ? active.closest<HTMLElement>('.modal') : null;
        if (modal) {
          const field = active!.getBoundingClientRect(), box = modal.getBoundingClientRect();
          const header = modal.querySelector<HTMLElement>(':scope > header');
          const delta = focusedScrollDelta(field.top, field.bottom, Math.max(box.top, header?.getBoundingClientRect().bottom ?? box.top) + 8, box.bottom - 12);
          if (delta) modal.scrollTop += delta;
        }
      } else {
        keyboardActive = false;
        modalKeyboard = false;
        root.style.removeProperty('--keyboard-height');
        root.style.removeProperty('--keyboard-top');
        root.style.removeProperty('--overlay-height');
        root.style.removeProperty('--overlay-top');
        root.removeAttribute('data-keyboard-open');
      }
    };
    const schedule = () => { cancelAnimationFrame(frame); frame = requestAnimationFrame(measure); };
    measure();
    window.addEventListener('resize', schedule);
    window.addEventListener('scroll', schedule, {passive:true});
    window.addEventListener('pageshow', schedule);
    document.addEventListener('visibilitychange', schedule);
    document.addEventListener('focusin', schedule);
    document.addEventListener('focusout', schedule);
    viewport?.addEventListener('resize', schedule);
    viewport?.addEventListener('scroll', schedule);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('resize', schedule);
      window.removeEventListener('scroll', schedule);
      window.removeEventListener('pageshow', schedule);
      document.removeEventListener('visibilitychange', schedule);
      document.removeEventListener('focusin', schedule);
      document.removeEventListener('focusout', schedule);
      viewport?.removeEventListener('resize', schedule);
      viewport?.removeEventListener('scroll', schedule);
      root.removeAttribute('data-standalone');
      root.style.removeProperty('--keyboard-height');
      root.style.removeProperty('--keyboard-top');
      root.style.removeProperty('--overlay-height');
      root.style.removeProperty('--overlay-top');
      root.removeAttribute('data-keyboard-open');
    };
  }, []);
}
