import { useLayoutEffect } from 'react';

// The installed iOS web app and Safari can disagree about vh/lvh. Use the
// visible viewport for the whole shell; its footer is a non-scrolling row.
export function useAppViewport() {
  useLayoutEffect(() => {
    let frame = 0;
    const viewport = window.visualViewport;
    const measure = () => {
      if (viewport && Math.abs(viewport.scale - 1) > .01) return;
      const height = viewport?.height || window.innerHeight;
      document.documentElement.style.setProperty('--app-height', `${height}px`);
    };
    const schedule = () => { cancelAnimationFrame(frame); frame = requestAnimationFrame(measure); };
    measure();
    window.addEventListener('resize', schedule);
    window.addEventListener('pageshow', schedule);
    viewport?.addEventListener('resize', schedule);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('resize', schedule);
      window.removeEventListener('pageshow', schedule);
      viewport?.removeEventListener('resize', schedule);
    };
  }, []);
}
