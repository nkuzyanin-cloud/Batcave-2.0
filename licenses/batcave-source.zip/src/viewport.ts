import { useLayoutEffect } from 'react';

export function shellHeight(visible: number, full: number, _phoneStandalone: boolean, _typing: boolean) {
  return visible > 0 ? visible : full;
}

// Fit the usable viewport, including keyboard changes. There is no footer;
// physical screen dimensions must not place the end of the content off-screen.
export function useAppViewport() {
  useLayoutEffect(() => {
    let frame = 0;
    const viewport = window.visualViewport;
    const measure = () => {
      if (viewport && Math.abs(viewport.scale - 1) > .01) return;
      const standalone = window.matchMedia('(display-mode: standalone)').matches || (navigator as Navigator & { standalone?: boolean }).standalone === true;
      const phone = /iPhone|iPod/.test(navigator.userAgent);
      const landscape = window.matchMedia('(orientation: landscape)').matches;
      const full = landscape ? Math.min(screen.width, screen.height) : Math.max(screen.width, screen.height);
      const active = document.activeElement;
      const typing = active instanceof HTMLElement && (active.matches('input, textarea, select') || active.isContentEditable);
      const height = shellHeight(viewport?.height || window.innerHeight, full, standalone && phone, typing);
      document.documentElement.style.setProperty('--app-height', `${height}px`);
    };
    const schedule = () => { cancelAnimationFrame(frame); frame = requestAnimationFrame(measure); };
    measure();
    window.addEventListener('resize', schedule);
    window.addEventListener('pageshow', schedule);
    document.addEventListener('visibilitychange', schedule);
    viewport?.addEventListener('resize', schedule);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('resize', schedule);
      window.removeEventListener('pageshow', schedule);
      document.removeEventListener('visibilitychange', schedule);
      viewport?.removeEventListener('resize', schedule);
    };
  }, []);
}
