import { useLayoutEffect } from 'react';

export function keyboardViewport(visible: number, layout: number, typing: boolean, scale: number) {
  // A shortened standalone viewport is not evidence of a keyboard. Only
  // resize while editing, with a keyboard-sized reduction and no pinch zoom.
  return typing && Math.abs(scale - 1) < .01 && visible > 0 && layout - visible > 150
    ? visible : undefined;
}

// CSS owns the full-page geometry. visualViewport is only a keyboard signal:
// installed iOS apps may report a shorter height even without browser chrome.
export function useAppViewport() {
  useLayoutEffect(() => {
    let frame = 0;
    const viewport = window.visualViewport;
    const root = document.documentElement;
    const measure = () => {
      const standalone = window.matchMedia('(display-mode: standalone)').matches || (navigator as Navigator & { standalone?: boolean }).standalone === true;
      root.toggleAttribute('data-standalone', standalone);
      const active = document.activeElement;
      const typing = active instanceof HTMLElement && (active.matches('input, textarea, select') || active.isContentEditable);
      const height = keyboardViewport(viewport?.height || window.innerHeight, root.clientHeight, typing, viewport?.scale || 1);
      if (height !== undefined) {
        root.style.setProperty('--keyboard-height', `${height}px`);
        root.style.setProperty('--keyboard-top', `${viewport?.offsetTop || 0}px`);
      } else {
        root.style.removeProperty('--keyboard-height');
        root.style.removeProperty('--keyboard-top');
      }
    };
    const schedule = () => { cancelAnimationFrame(frame); frame = requestAnimationFrame(measure); };
    measure();
    window.addEventListener('resize', schedule);
    window.addEventListener('pageshow', schedule);
    document.addEventListener('visibilitychange', schedule);
    document.addEventListener('focusin', schedule);
    document.addEventListener('focusout', schedule);
    viewport?.addEventListener('resize', schedule);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('resize', schedule);
      window.removeEventListener('pageshow', schedule);
      document.removeEventListener('visibilitychange', schedule);
      document.removeEventListener('focusin', schedule);
      document.removeEventListener('focusout', schedule);
      viewport?.removeEventListener('resize', schedule);
      root.removeAttribute('data-standalone');
      root.style.removeProperty('--keyboard-height');
      root.style.removeProperty('--keyboard-top');
    };
  }, []);
}
