import { useCallback, useEffect, useRef, useState } from 'react';
export const APP_VERSION = '1.9.3';

export type UpdateState = 'idle' | 'checking' | 'downloading' | 'current' | 'ready' | 'offline' | 'error';
export function useAppUpdates() {
  const [state, setState] = useState<UpdateState>('idle');
  const [detail, setDetail] = useState('');
  const [offline, setOffline] = useState('Подготовка офлайн-режима…');
  const [noticeDismissed, dismissNotice] = useState(false);
  const checkRef = useRef<(manual?: boolean) => Promise<void>>(async () => {});
  const registration = useRef<ServiceWorkerRegistration | undefined>(undefined);
  const ready = useRef(false);
  useEffect(() => {
    if (!('serviceWorker' in navigator) || import.meta.env.DEV) {
      setOffline(import.meta.env.DEV ? 'Режим разработки' : 'Офлайн недоступен в этом браузере');
      return;
    }
    let alive = true, checking = false, lastCheck = 0, installError = '';
    let initialController = navigator.serviceWorker.controller;
    const cleanups: (() => void)[] = [];
    const watched = new WeakSet<ServiceWorker>();
    const registrations = new WeakSet<ServiceWorkerRegistration>();
    const available = () => {
      if (!alive) return;
      ready.current = true;
      setState('ready'); setDetail(''); dismissNotice(false);
    };
    const announce = (worker: ServiceWorker | null | undefined) => {
      worker?.postMessage({ type: 'CLIENT_VERSION', version: APP_VERSION });
      worker?.postMessage({ type: 'OFFLINE_STATUS' });
    };
    const watch = (worker: ServiceWorker | null) => {
      if (!worker || watched.has(worker)) return;
      watched.add(worker);
      const changed = () => {
        if (!alive) return;
        if (worker.state === 'installing') { installError = ''; setState('downloading'); }
        if (worker.state === 'installed') {
          if (initialController) available();
          else { setOffline('Офлайн готов. Подготовка автораспознавания…'); setState('current'); }
        }
        if (worker.state === 'redundant' && !ready.current) {
          setState('error');
          setDetail(installError || 'Не удалось установить файлы приложения. Повторите проверку обновления.');
          if (!registration.current?.active) setOffline('Офлайн пока не готов: установка файлов приложения не завершена.');
        }
      };
      worker.addEventListener('statechange', changed);
      cleanups.push(() => worker.removeEventListener('statechange', changed));
      changed();
    };
    const attach = (r: ServiceWorkerRegistration) => {
      registration.current = r;
      if (r.active) { setOffline('Офлайн готов'); announce(r.active); }
      if (r.waiting) available();
      watch(r.installing);
      if (!registrations.has(r)) {
        registrations.add(r);
        const found = () => watch(r.installing);
        r.addEventListener('updatefound', found);
        cleanups.push(() => r.removeEventListener('updatefound', found));
      }
    };
    const check = async (manual = false) => {
      if (checking || !alive || (!manual && Date.now() - lastCheck < 60000)) return;
      lastCheck = Date.now(); checking = true;
      if (!ready.current) { setState('checking'); setDetail(''); }
      let phase = 'server';
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(), 30000);
      try {
        // A real request is authoritative. navigator.onLine can be stale in an installed web app.
        const response = await fetch(new URL('./release.json', document.baseURI), { cache: 'no-store', signal: ac.signal });
        if (!response.ok) throw Error(`На сервере не найден файл версии release.json (HTTP ${response.status}).`);
        const release: { version?: string; build?: string } = await response.json();
        if (!release.version || !release.build) throw Error('Сервер вернул некорректный файл версии release.json.');
        clearTimeout(timer); phase = 'worker';
        let r = await navigator.serviceWorker.getRegistration(new URL('./', document.baseURI).href);
        // Never retain a rejected registration promise or retry update() on a failed empty registration.
        if (!r || (!r.active && !r.installing && !r.waiting)) {
          r = await navigator.serviceWorker.register(new URL('./sw.js', document.baseURI), { scope: './', updateViaCache: 'none' });
          if (!alive) return;
          attach(r);
        } else {
          attach(r);
          if (!r.installing && !r.waiting) await r.update();
        }
        if (!alive) return;
        r.active?.postMessage({ type: 'PREPARE_EXTRAS' });
        if (r.waiting) available();
        else if (r.installing) { watch(r.installing); setState('downloading'); }
        else if (!ready.current) setState('current');
      } catch (error) {
        if (alive && !ready.current) {
          const message = error instanceof Error ? error.message : '';
          setState('error');
          setDetail(phase === 'worker'
            ? installError || `Сервер доступен, но установка обновления не удалась. ${message}`
            : error instanceof TypeError || ac.signal.aborted
              ? 'Сервер обновлений не ответил. Интернет может работать; повторите проверку позже.'
              : message || 'Сервер вернул ошибку при проверке версии.');
        }
      } finally { clearTimeout(timer); checking = false; }
    };
    checkRef.current = check;
    const resume = () => { if (!document.hidden) void check(); };
    const controlled = () => {
      if (!alive) return;
      setOffline('Офлайн готов. Подготовка автораспознавания…');
      if (initialController && navigator.serviceWorker.controller !== initialController) available();
      initialController = navigator.serviceWorker.controller;
      announce(initialController);
    };
    const message = (e: MessageEvent) => {
      if (!alive) return;
      if (e.data?.type === 'VERSION_REQUEST') announce(navigator.serviceWorker.controller);
      if (e.data?.type === 'OFFLINE_STATUS') {
        setOffline(e.data.aiReady ? 'Офлайн готов' : 'Офлайн готов. Автораспознавание пока требует сети.');
        if (e.data.version !== APP_VERSION) available();
      }
      if (e.data?.type === 'INSTALL_ERROR') {
        const d = e.data.detail || {};
        const reason = d.status ? `HTTP ${d.status}` : d.reason === 'storage' ? 'недостаточно места' : d.reason === 'timeout' ? 'сервер не ответил вовремя' : d.reason === 'html' ? 'сервер вернул страницу вместо файла' : 'ошибка загрузки';
        installError = `Не удалось загрузить ${d.file || 'файл приложения'}: ${reason}. Повторите проверку обновления.`;
        setDetail(installError); setState('error');
      }
    };
    navigator.serviceWorker.addEventListener('controllerchange', controlled);
    navigator.serviceWorker.addEventListener('message', message);
    document.addEventListener('visibilitychange', resume);
    window.addEventListener('pageshow', resume);
    window.addEventListener('online', resume);
    // Existing offline files remain usable even if the server cannot be reached.
    void navigator.serviceWorker.getRegistration(new URL('./', document.baseURI).href).then(r => {
      if (alive && r) attach(r);
    }).catch(() => {});
    void check();
    return () => {
      alive = false; cleanups.forEach(fn => fn());
      navigator.serviceWorker.removeEventListener('controllerchange', controlled);
      navigator.serviceWorker.removeEventListener('message', message);
      document.removeEventListener('visibilitychange', resume);
      window.removeEventListener('pageshow', resume);
      window.removeEventListener('online', resume);
    };
  }, []);
  const check = useCallback(() => { void checkRef.current(true); }, []);
  const apply = useCallback(() => {
    const worker = registration.current?.waiting;
    if (worker) {
      navigator.serviceWorker.addEventListener('controllerchange', () => location.reload(), { once: true });
      worker.postMessage('ACTIVATE');
    } else if (ready.current) location.reload();
  }, []);
  return { state, detail, offline, check, apply, noticeDismissed, dismiss: () => dismissNotice(true) };
}
