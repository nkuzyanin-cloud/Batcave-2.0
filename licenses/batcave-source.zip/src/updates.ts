import { useCallback, useEffect, useRef, useState } from 'react';
export const APP_VERSION = '1.7.1';

export type UpdateState = 'idle' | 'checking' | 'downloading' | 'current' | 'ready' | 'offline' | 'error';
export function useAppUpdates() {
  const [state, setState] = useState<UpdateState>('idle');
  const [offline, setOffline] = useState('Подготовка офлайн-режима…');
  const [noticeDismissed, dismissNotice] = useState(false);
  const checkRef = useRef<(manual?: boolean) => Promise<void>>(async () => {});
  const registration = useRef<ServiceWorkerRegistration | undefined>(undefined);
  const ready = useRef(false);
  useEffect(() => {
    if (!('serviceWorker' in navigator) || import.meta.env.DEV) {
      setOffline(import.meta.env.DEV ? 'Режим разработки' : 'Офлайн недоступен в этом браузере');
      return;
    }
    let alive = true, checking = false, lastCheck = 0;
    let initialController = navigator.serviceWorker.controller;
    const cleanups: (() => void)[] = [];
    const watched = new WeakSet<ServiceWorker>();
    const available = () => {
      if (!alive) return;
      ready.current = true;
      setState('ready');
      dismissNotice(false);
    };
    const watch = (worker: ServiceWorker | null) => {
      if (!worker || watched.has(worker)) return;
      watched.add(worker);
      const changed = () => {
        if (!alive) return;
        if (worker.state === 'installing') setState('downloading');
        if (worker.state === 'installed') {
          if (initialController) available();
          else { setOffline('Офлайн готов'); setState('current'); }
        }
        if (worker.state === 'redundant') {
          setState('error');
          if (!registration.current?.active) setOffline('Не удалось подготовить офлайн. Повторите проверку при подключении к сети.');
        }
      };
      worker.addEventListener('statechange', changed);
      cleanups.push(() => worker.removeEventListener('statechange', changed));
      changed();
    };
    const registered = navigator.serviceWorker.register(new URL('./sw.js', document.baseURI), {
      scope: './', updateViaCache: 'none',
    }).then(r => {
      if (!alive) return r;
      registration.current = r;
      r.active?.postMessage({ type: 'CLIENT_VERSION', version: APP_VERSION });
      if (r.active) setOffline('Офлайн готов');
      if (r.waiting) available();
      watch(r.installing);
      const found = () => watch(r.installing);
      r.addEventListener('updatefound', found);
      cleanups.push(() => r.removeEventListener('updatefound', found));
      return r;
    });
    void registered.catch(() => { if (alive && !ready.current) setState(navigator.onLine ? 'error' : 'offline'); });
    const check = async (manual = false) => {
      if (checking || !alive || (!manual && Date.now() - lastCheck < 60000)) return;
      if (!navigator.onLine) { if (!ready.current) setState('offline'); return; }
      lastCheck = Date.now(); checking = true;
      if (!ready.current) setState('checking');
      let timer: ReturnType<typeof setTimeout> | undefined;
      try {
        await Promise.race([
          registered.then(async r => { await r.update(); return r; }),
          new Promise<never>((_, reject) => { timer = setTimeout(() => reject(Error('timeout')), 30000); }),
        ]);
        if (!alive) return;
        const r = registration.current;
        if (r?.waiting) available();
        else if (r?.installing) { watch(r.installing); setState('downloading'); }
        else if (!ready.current) setState('current');
      } catch {
        if (alive && !ready.current) setState(navigator.onLine ? 'error' : 'offline');
      } finally { clearTimeout(timer); checking = false; }
    };
    checkRef.current = check;
    const resume = () => { if (!document.hidden) void check(); };
    const controlled = () => {
      if (!alive) return;
      setOffline('Офлайн готов');
      if (initialController && navigator.serviceWorker.controller !== initialController) available();
      initialController = navigator.serviceWorker.controller;
      navigator.serviceWorker.controller?.postMessage({ type: 'CLIENT_VERSION', version: APP_VERSION });
    };
    const message = (e: MessageEvent) => {
      if (e.data?.type === 'VERSION_REQUEST') navigator.serviceWorker.controller?.postMessage({ type: 'CLIENT_VERSION', version: APP_VERSION });
    };
    navigator.serviceWorker.addEventListener('controllerchange', controlled);
    navigator.serviceWorker.addEventListener('message', message);
    document.addEventListener('visibilitychange', resume);
    window.addEventListener('pageshow', resume);
    window.addEventListener('online', resume);
    void check();
    return () => {
      alive = false;
      cleanups.forEach(fn => fn());
      navigator.serviceWorker.removeEventListener('controllerchange', controlled);
      navigator.serviceWorker.removeEventListener('message', message);
      document.removeEventListener('visibilitychange', resume);
      window.removeEventListener('pageshow', resume);
      window.removeEventListener('online', resume);
    };
  }, []);
  const check = useCallback(() => { void checkRef.current(true); }, []);
  const apply = useCallback(() => {
    const worker = registration.current?.waiting;
    if (worker) {
      navigator.serviceWorker.addEventListener('controllerchange', () => location.reload(), { once: true });
      worker.postMessage('ACTIVATE');
    } else if (ready.current) location.reload();
  }, []);
  return { state, offline, check, apply, noticeDismissed, dismiss: () => dismissNotice(true) };
}
