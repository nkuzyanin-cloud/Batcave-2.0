import { useEffect, useRef, useState } from 'react';
import { cropCanvas } from './page-quality';
import { errorMessage } from '../models';
import type { PageSource } from './source';
export function RenderedPage({
  source,
  index,
  onLoaded,
  onError,
  onRatio,
  sharp = false,
  cropMargins = false,
}: {
  source: PageSource;
  index: number;
  onLoaded: (p: number) => void;
  onError: (s: string) => void;
  onRatio?: (p: number, r: number) => void;
  sharp?: boolean;
  cropMargins?: boolean;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [busy, setBusy] = useState(true);
  useEffect(() => {
    const canvas = ref.current!;
    const abort = new AbortController();
    let alive = true;
    setBusy(true);
    void source
      .render(
        index,
        canvas,
        Math.min(2200, window.innerWidth * (window.devicePixelRatio || 1) * (sharp ? 2 : 1)),
        abort.signal,
      )
      .then(() => {
        if (alive) {
          if (cropMargins) cropCanvas(canvas);
          setBusy(false);
          onRatio?.(index, canvas.height / canvas.width);
          onLoaded(index);
        }
      })
      .catch((e) => {
        if (alive && !abort.signal.aborted) onError(errorMessage(e));
      });
    return () => {
      alive = false;
      abort.abort();
      canvas.width = canvas.height = 0;
    };
  }, [source, index, onLoaded, onError, onRatio, sharp, cropMargins]);
  return (
    <>
      <canvas
        ref={ref}
        className="reader-canvas"
        aria-label={`Страница ${index + 1}`}
        data-page={index}
        style={{ opacity: busy ? 0 : 1 }}
      />
      {busy && <span className="page-spinner spinner" />}
    </>
  );
}
