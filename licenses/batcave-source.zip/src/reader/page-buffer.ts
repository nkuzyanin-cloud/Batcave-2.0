import type { PageSource } from './source';

interface Entry {
  canvas: HTMLCanvasElement;
  abort: AbortController;
  state: 'queued' | 'rendering' | 'ready' | 'failed';
  error?: unknown;
}

// Keep only a small reading window. Rendering is serial: in particular two
// PDF tasks never fight over the same PDFPageProxy or its cleanup(). Detached
// canvases are reused directly, without copies, data URLs or decoded images.
export class PageBuffer {
  private entries = new Map<number, Entry>();
  private order: number[] = [];
  private rendering = false;
  private closed = false;
  private listeners = new Set<() => void>();

  constructor(
    private source: PageSource,
    private width: number,
    private createCanvas = () => document.createElement('canvas'),
  ) {}

  subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => { this.listeners.delete(listener); };
  }

  keep(pages: number[]) {
    if (this.closed) return;
    this.order = [...new Set(pages)].filter(p => p >= 0 && p < this.source.count).slice(0, 3);
    for (const [page, entry] of this.entries) {
      if (!this.order.includes(page)) {
        entry.abort.abort();
        // A cancelled PDF task may still be unwinding. Clear it again in finally.
        entry.canvas.width = entry.canvas.height = 0;
        this.entries.delete(page);
      }
    }
    for (const page of this.order) {
      if (this.entries.has(page)) continue;
      const canvas = this.createCanvas();
      canvas.width = canvas.height = 0;
      canvas.className = 'reader-canvas';
      canvas.dataset.page = String(page);
      canvas.setAttribute('aria-label', `Страница ${page + 1}`);
      this.entries.set(page, { canvas, abort: new AbortController(), state: 'queued' });
    }
    void this.pump();
  }

  get(page: number) {
    const entry = this.entries.get(page);
    return entry?.state === 'ready' ? entry.canvas : undefined;
  }

  error(page: number) { return this.entries.get(page)?.error; }

  dispose() {
    this.closed = true;
    for (const entry of this.entries.values()) {
      entry.abort.abort();
      entry.canvas.width = entry.canvas.height = 0;
    }
    this.entries.clear();
    this.listeners.clear();
  }

  private async pump() {
    if (this.rendering || this.closed) return;
    const page = this.order.find(p => this.entries.get(p)?.state === 'queued');
    if (page === undefined) return;
    const entry = this.entries.get(page)!;
    this.rendering = true;
    entry.state = 'rendering';
    try {
      await this.source.render(page, entry.canvas, this.width, entry.abort.signal);
      if (!entry.abort.signal.aborted && !this.closed) entry.state = 'ready';
    } catch (error) {
      if (!entry.abort.signal.aborted && !this.closed) {
        entry.error = error;
        entry.state = 'failed';
        entry.canvas.width = entry.canvas.height = 0;
      }
    } finally {
      if (entry.abort.signal.aborted || this.closed) entry.canvas.width = entry.canvas.height = 0;
      this.rendering = false;
      if (!this.closed) {
        for (const listener of this.listeners) listener();
        void this.pump();
      }
    }
  }
}
