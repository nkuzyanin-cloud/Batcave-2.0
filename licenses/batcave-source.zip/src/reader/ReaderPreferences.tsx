import { useState } from 'react';
import type { Settings } from '../models';
export function ReaderPreferences({settings:s,onChange,panelsAvailable,onOverview}:{settings:Settings;onChange:(s:Settings)=>void;panelsAvailable?:boolean;onOverview?:()=>void}) {
  const [tab,setTab]=useState<'frames'|'gestures'|'look'>('frames');
  const tabs=[['frames','Кадры'],['gestures','Управление'],['look','Вид']] as const;
  return <div className="reading-preferences">
    <div className="reading-tabs" role="tablist" aria-label="Раздел настроек чтения">{tabs.map(([id,label])=><button key={id} id={`reading-tab-${id}`} role="tab" aria-selected={tab===id} aria-controls={`reading-panel-${id}`} tabIndex={tab===id?0:-1} onClick={()=>setTab(id)} onKeyDown={e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();const next=tabs[(tabs.findIndex(t=>t[0]===tab)+(e.key==='ArrowRight'?1:2))%3][0];setTab(next);requestAnimationFrame(()=>document.getElementById(`reading-tab-${next}`)?.focus());}}}>{label}</button>)}</div>
    <section className="reading-tab-panel" role="tabpanel" id={`reading-panel-${tab}`} aria-labelledby={`reading-tab-${tab}`}>
      {tab==='frames'&&<>
        <label className="reading-choice"><span>Режим чтения</span><select aria-label="Режим чтения" value={s.mode} onChange={e=>onChange({...s,mode:e.target.value as Settings['mode']})}><option value="single">Страница</option><option value="panels" disabled={panelsAvailable===false}>По кадрам</option><option value="guided">Фрагменты</option><option value="vertical">Прокрутка</option></select></label>
        {s.mode==='panels'?<>
          <div className="reading-dimming"><label htmlFor="reading-opacity">Затемнение <output>{Math.round(s.panelOpacity*100)}%</output></label><input id="reading-opacity" aria-label="Затемнение вне кадра" type="range" min="0" max="100" step="5" value={Math.round(s.panelOpacity*100)} onChange={e=>onChange({...s,panelOpacity:Number(e.target.value)/100})}/><div className="reading-presets">{([[0,'Без'],[.75,'Мягкое'],[1,'Полное']] as const).map(([v,label])=><button key={label} aria-pressed={s.panelOpacity===v} onClick={()=>onChange({...s,panelOpacity:v})}>{label}</button>)}</div></div>
          <label className="switch-label"><span>Вся страница перед кадрами</span><input type="checkbox" checked={s.panelPageFirst} onChange={e=>onChange({...s,panelPageFirst:e.target.checked})}/></label>
          <label className="switch-label"><span>Вся страница после кадров</span><input type="checkbox" checked={s.panelPageLast} onChange={e=>onChange({...s,panelPageLast:e.target.checked})}/></label>
        </>:<p className="reading-hint">Затемнение и порядок показа страницы доступны в режиме «По кадрам».</p>}
        {onOverview&&<button className="reading-overview" onClick={onOverview}>Показать всю страницу</button>}
      </>}
      {tab==='gestures'&&<>
        <label className="reading-choice"><span>Направление свайпов</span><select aria-label="Направление свайпов" value={s.direction} onChange={e=>onChange({...s,direction:e.target.value as Settings['direction']})}><option value="ltr">Слева направо</option><option value="rtl">Справа налево</option></select></label>
        <label className="switch-label"><span>Масштаб двойным касанием</span><input type="checkbox" checked={s.doubleTap} onChange={e=>onChange({...s,doubleTap:e.target.checked})}/></label>
        <p className="reading-hint">Коснитесь комикса, чтобы скрыть или показать управление.</p>
      </>}
      {tab==='look'&&<>
        <label className="switch-label"><span>Тёплый экран</span><input type="checkbox" checked={!!s.warmScreen} onChange={e=>onChange({...s,warmScreen:e.target.checked})}/></label>
        <label className="reading-choice"><span>Фон страницы</span><select aria-label="Фон страницы" value={s.readerTheme} onChange={e=>onChange({...s,readerTheme:e.target.value as Settings['readerTheme']})}><option value="black">Чёрный</option><option value="gray">Графит</option><option value="light">Светлый</option></select></label>
        <label className="reading-choice"><span>Анимации</span><select aria-label="Анимации" value={s.motion} onChange={e=>onChange({...s,motion:e.target.value as Settings['motion']})}><option value="system">Как в системе</option><option value="full">Плавные</option><option value="fast">Быстрые</option><option value="off">Выключены</option></select></label>
        <label className="switch-label"><span>Номер страницы</span><input type="checkbox" checked={s.showPage} onChange={e=>onChange({...s,showPage:e.target.checked})}/></label>
        <label className="switch-label"><span>Обрезать поля</span><input type="checkbox" checked={s.cropMargins} onChange={e=>onChange({...s,cropMargins:e.target.checked})}/></label>
      </>}
    </section>
  </div>;
}
