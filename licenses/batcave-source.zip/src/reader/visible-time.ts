// A visible reader session, independent of gestures, pages and interval cadence.
// Monotonic milliseconds prevent wall-clock corrections from changing duration.
export class VisibleReadingTime {
  private since:number | undefined;
  private pending=0;
  constructor(private now:()=>number=()=>performance.now()) {}
  setVisible(visible:boolean) {
    const now=this.now();
    if(this.since!==undefined)this.pending+=Math.max(0,now-this.since);
    this.since=visible ? now : undefined;
  }
  drainSeconds() {
    if(this.since!==undefined){const now=this.now();this.pending+=Math.max(0,now-this.since);this.since=now;}
    const seconds=this.pending/1000;this.pending=0;return seconds;
  }
}
