import type {PanelMap,Rect} from './panels';
export const PREPARED_FILE='batcave-prepared.json';
export interface PreparedPage {name:string;sha256:string;width:number;height:number;crop:Rect;frames:Rect[];kind:'story'|'cover'|'text'}
export interface PreparedComic {app:'BATCAVE Studio';version:1;pages:PreparedPage[]}
const validRect=(r:unknown):r is Rect=>Array.isArray(r)&&r.length===4&&r.every(n=>typeof n==='number'&&Number.isFinite(n))&&r[0]>=0&&r[1]>=0&&r[2]>.0001&&r[3]>.0001&&r[0]+r[2]<=1.000001&&r[1]+r[3]<=1.000001;
export function parsePrepared(raw:unknown,names:string[]):PreparedComic {
  const m=raw as PreparedComic;
  if(!m||m.app!=='BATCAVE Studio'||m.version!==1||!Array.isArray(m.pages)||m.pages.length!==names.length||!names.length||names.length>5000)throw Error('Разметка редактора не соответствует страницам CBZ.');
  for(const [i,p] of m.pages.entries()){
    if(!p||p.name!==names[i]||! /^[a-f0-9]{64}$/.test(p.sha256)||!Number.isInteger(p.width)||!Number.isInteger(p.height)||p.width<1||p.height<1||p.width*p.height>100_000_000||!validRect(p.crop)||!Array.isArray(p.frames)||p.frames.length>100||!p.frames.every(validRect)||!['story','cover','text'].includes(p.kind))throw Error('Повреждена разметка редактора.');
    for(const r of p.frames)if(r[0]<p.crop[0]-.000001||r[1]<p.crop[1]-.000001||r[0]+r[2]>p.crop[0]+p.crop[2]+.000001||r[1]+r[3]>p.crop[1]+p.crop[3]+.000001)throw Error('Кадр выходит за обрезку страницы.');
  }
  return m;
}
export function preparedPanelMap(m:PreparedComic,hash:string):PanelMap {
  return {version:1,sha256:hash,pageCount:m.pages.length,pages:m.pages.map(p=>({width:p.width*p.crop[2],height:p.height*p.crop[3],kind:p.kind,frames:(p.frames.length?p.frames:[p.crop]).map(r=>[(r[0]-p.crop[0])/p.crop[2],(r[1]-p.crop[1])/p.crop[3],r[2]/p.crop[2],r[3]/p.crop[3]] as Rect)}))};
}
