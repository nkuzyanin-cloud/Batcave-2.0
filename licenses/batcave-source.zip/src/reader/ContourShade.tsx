import {useId,useLayoutEffect,useRef} from 'react';
import {shapePath,type FrameShape} from './frame-shapes';
import type {Rect} from './panels';

// The four compositor quads shade outside the bounding box. This small SVG
// shades only its interior outside the authored contour, never the picture.
export function ContourShade({shape,bounds,opacity,duration}:{shape?:FrameShape;bounds:Rect;opacity:number;duration:number}) {
  const id=useId(),latest=useRef<SVGPathElement>(null),previous=useRef<SVGPathElement>(null),oldClip=useRef<SVGRectElement>(null);
  const remembered=useRef<{d:string;bounds:Rect;opacity:number}|undefined>(undefined),animations=useRef<Animation[]>([]);
  const d=shapePath(undefined,bounds)+' '+shapePath(shape,bounds);
  const stop=()=>{animations.current.forEach(a=>a.cancel());animations.current=[];};
  useLayoutEffect(()=>()=>stop(),[]);
  useLayoutEffect(()=>{
    const old=remembered.current;stop();remembered.current={d,bounds:[...bounds],opacity};
    if(!old||duration===0||old.d===d||!latest.current||!previous.current||!oldClip.current)return;
    previous.current.setAttribute('d',old.d);
    for(const [key,value] of Object.entries({x:old.bounds[0],y:old.bounds[1],width:old.bounds[2],height:old.bounds[3]}))oldClip.current.setAttribute(key,String(value));
    const options={duration,easing:'cubic-bezier(.4,0,.2,1)'};
    const next=[previous.current.animate([{opacity:old.opacity},{opacity:0}],options),latest.current.animate([{opacity:0},{opacity}],options)];
    animations.current=next;next[0].onfinish=()=>{if(animations.current===next)stop();};
  },[d,opacity,duration]);
  return <svg className="panel-contour" viewBox="0 0 1 1" preserveAspectRatio="none" aria-hidden="true" data-testid="panel-contour">
    <defs><clipPath id={id+'-old'}><rect ref={oldClip}/></clipPath><clipPath id={id+'-new'}><rect x={bounds[0]} y={bounds[1]} width={bounds[2]} height={bounds[3]}/></clipPath></defs>
    <path ref={previous} fill="#000" fillRule="evenodd" clipPath={`url(#${id}-old)`} style={{opacity:0}}/>
    <path ref={latest} d={d} fill="#000" fillRule="evenodd" clipPath={`url(#${id}-new)`} style={{opacity}} data-shape={shape?.type??'rect'}/>
  </svg>;
}
