import type { ReaderView } from '../models';

export type Rect = [number, number, number, number];
export interface PanelPage { width: number; height: number; kind: 'story' | 'cover' | 'text'; frames: Rect[] }
export interface PanelMap { version: 1; sha256: string; pageCount: number; pages: PanelPage[]; detector?: 'inkwell-v1' }
export interface PanelStep { page: number; panel: number; part: number; parts: number; bounds: Rect; focus: Rect; overview?: 'before' | 'after' }
export const YEAR_ONE_HASH = '08e14cafe1d4e5063beae4d0a46b47ffb17201db6f5560bc6089a3d12432b1b5';

export function parsePanelMap(value: unknown, hash: string, count: number): PanelMap {
  const m = value as Partial<PanelMap> | null;
  if (!m || m.version !== 1 || m.sha256 !== hash || m.pageCount !== count || !Array.isArray(m.pages) || m.pages.length !== count)
    throw Error('Разметка кадров не соответствует этому PDF.');
  for (const p of m.pages) {
    if (!p || !Number.isFinite(p.width) || !Number.isFinite(p.height) || p.width <= 0 || p.height <= 0 || !['story', 'cover', 'text'].includes(p.kind) || !Array.isArray(p.frames) || !p.frames.length || p.frames.length > 100)
      throw Error('Повреждена разметка кадров.');
    for (const r of p.frames)
      if (!Array.isArray(r) || r.length !== 4 || r.some(n => !Number.isFinite(n)) || r[0] < 0 || r[1] < 0 || r[2] <= 0 || r[3] <= 0 || r[0] + r[2] > 1.00002 || r[1] + r[3] > 1.00002)
        throw Error('Некорректные границы кадра.');
  }
  return m as PanelMap;
}

export async function loadPanelMap(hash: string, count: number, signal?: AbortSignal): Promise<PanelMap | undefined> {
  // Match content, never a filename or a title. A different edition cannot
  // silently receive this edition's coordinates. No PDF leaves the device.
  if (hash !== YEAR_ONE_HASH || count !== 99) return undefined;
  const response = await fetch(`${import.meta.env.BASE_URL}panels/year-one.json`, { signal });
  if (!response.ok) throw Error('Не удалось загрузить разметку кадров. Откройте приложение с интернетом один раз.');
  return parsePanelMap(await response.json(), hash, count);
}

export function panelSteps(map: PanelMap, rtl = false, first = false, last = false): PanelStep[] {
  const steps: PanelStep[] = [];
  map.pages.forEach((page, p) => {
    const full: Rect = [0, 0, 1, 1];
    if (first && page.kind !== 'cover') steps.push({ page: p, panel: 0, part: 0, parts: 1, bounds: full, focus: full, overview: 'before' });
    page.frames.forEach((bounds, panel) => {
      const [x,y,w,h] = bounds;
      // Wide panels keep their REAL boundary illuminated. Two overlapping
      // camera positions make their lettering readable without hiding a caption.
      const parts = !map.detector && page.kind === 'story' && w > 0.72 ? 2 : 1;
      for (let part = 0; part < parts; part++) {
        const side = rtl ? parts-1-part : part;
        const fw = parts === 2 ? w * 0.62 : w;
        steps.push({ page: p, panel, part, parts, bounds, focus: [x + side * (w-fw), y, fw, h] });
      }
    });
    if (last && page.kind !== 'cover') steps.push({ page: p, panel: page.frames.length-1, part: 0, parts: 1, bounds: full, focus: full, overview: 'after' });
  });
  return steps;
}

export function findPanelStep(steps: PanelStep[], page: number, saved?: ReaderView): number {
  const valid = saved?.mode === 'panels' && saved.page === page;
  if (valid) {
    const exact = steps.findIndex(s => s.page === page && s.panel === (saved.panel ?? 0) && s.part === (saved.part ?? 0) && s.overview === saved.overview);
    if (exact !== -1) return exact;
  }
  return Math.max(0, steps.findIndex(s => s.page === page));
}

export function panelCamera(focus: Rect, ratio: number, width: number, height: number, zoom = 1, pan = { x: 0, y: 0 }) {
  const baseWidth = 1000, baseHeight = baseWidth * ratio;
  const [x,y,w,h] = focus;
  const scale = Math.min(Math.max(1,width-24) / (w*baseWidth), Math.max(1,height-24) / (h*baseHeight)) * zoom;
  return { scale, x: (width-w*baseWidth*scale)/2 - x*baseWidth*scale + pan.x, y: (height-h*baseHeight*scale)/2 - y*baseHeight*scale + pan.y, width: baseWidth, height: baseHeight };
}
