import {validShapes,type FrameShape} from './frame-shapes';
import type { ReaderView, PanelEdits } from '../models';

import { sameRegion, type PageQuality } from './page-quality';
export type Rect = [number, number, number, number];
export interface PanelPage { width: number; height: number; kind: 'story' | 'cover' | 'text'; frames: Rect[]; shapes?: FrameShape[] }
export interface PanelMap { version: 1; sha256: string; pageCount: number; pages: PanelPage[]; detector?: 'inkwell-v1' }
export interface PanelStep { page: number; panel: number; part: number; parts: number; bounds: Rect; focus: Rect; overview?: 'before' | 'after'; viewPart?: number }
export const YEAR_ONE_HASH = '08e14cafe1d4e5063beae4d0a46b47ffb17201db6f5560bc6089a3d12432b1b5';

export function parsePanelMap(value: unknown, hash: string, count: number): PanelMap {
  const m = value as Partial<PanelMap> | null;
  if (!m || m.version !== 1 || m.sha256 !== hash || m.pageCount !== count || !Array.isArray(m.pages) || m.pages.length !== count)
    throw Error('Разметка кадров не соответствует этому PDF.');
  for (const p of m.pages) {
    if (!p || !Number.isFinite(p.width) || !Number.isFinite(p.height) || p.width <= 0 || p.height <= 0 || !['story', 'cover', 'text'].includes(p.kind) || !Array.isArray(p.frames) || !p.frames.length || p.frames.length > 100 || !validShapes(p.shapes,p.frames.length))
      throw Error('Повреждена разметка кадров.');
    for (const r of p.frames)
      if (!Array.isArray(r) || r.length !== 4 || r.some(n => !Number.isFinite(n)) || r[0] < 0 || r[1] < 0 || r[2] <= 0 || r[3] <= 0 || r[0] + r[2] > 1.00002 || r[1] + r[3] > 1.00002)
        throw Error('Некорректные границы кадра.');
  }
  return m as PanelMap;
}

export async function loadPanelMap(hash: string, count: number, signal?: AbortSignal): Promise<PanelMap | undefined> {
  // Match content, never a filename or a title. A different edition cannot
  // silently receive this edition's coordinates. No PDF leaves the device.
  if (hash !== YEAR_ONE_HASH || count !== 99) return undefined;
  const response = await fetch(`${import.meta.env.BASE_URL}panels/year-one.json`, { signal });
  if (!response.ok) throw Error('Не удалось загрузить разметку кадров. Откройте приложение с интернетом один раз.');
  return parsePanelMap(await response.json(), hash, count);
}

// One navigation stop per real frame. Dimensions and direction stay in the
// signature for existing callers; neither can create synthetic close views.
export function panelSteps(map: PanelMap, _rtl = false, first = false, last = false, _width = 375, _height = 812, options: { edits?: PanelEdits; quality?: Map<number, PageQuality>; crop?: boolean } = {}): PanelStep[] {
  const steps: PanelStep[] = [];
  map.pages.forEach((page, p) => {
    const quality = options.quality?.get(p);
    const full: Rect = options.crop && quality ? quality.crop : [0, 0, 1, 1];
    const edits = options.edits?.fingerprint === map.sha256 ? options.edits.frames.filter(e => e.page === p) : [];
    const kept = page.frames.flatMap((bounds, panel) => {
      const edit = edits.find(e => e.panel === panel);
      if (edit?.hidden || (!edit && (quality?.blank.includes(panel) || quality?.duplicate.includes(panel)))) return [];
      return [{ bounds, panel, edit }];
    });
    if (!kept.length) { steps.push({page:p,panel:0,part:0,parts:1,bounds:full,focus:full,overview:'before'}); return; }
    const onlyFull = kept.length === 1 && sameRegion(kept[0].edit?.bounds ?? kept[0].bounds, quality?.crop ?? full);
    if (first && !onlyFull && page.kind !== 'cover') steps.push({ page: p, panel: 0, part: 0, parts: 1, bounds: full, focus: full, overview: 'before' });
    kept.forEach(({ bounds, panel }) => {
      steps.push({ page: p, panel, part: 0, parts: 1, bounds, focus: bounds, viewPart: 0 });
    });
    if (last && !onlyFull && page.kind !== 'cover') steps.push({ page: p, panel: page.frames.length - 1, part: 0, parts: 1, bounds: full, focus: full, overview: 'after' });
  });
  return steps;
}

export function findPanelStep(steps: PanelStep[], page: number, saved?: ReaderView): number {
  const valid = saved?.mode === 'panels' && saved.page === page;
  if (valid) {
    const exact = steps.findIndex(s => s.page === page && s.panel === (saved.panel ?? 0) && (saved.viewPart === undefined ? s.part === (saved.part ?? 0) : s.viewPart === saved.viewPart) && s.overview === saved.overview);
    if (exact !== -1) return exact;
    const samePanel = steps.map((s, i) => ({ s, i })).filter(({ s }) => s.page === page && s.panel === (saved.panel ?? 0) && !s.overview);
    if (samePanel.length) return samePanel[Math.min(saved.part ?? 0, samePanel.length - 1)].i;
  }
  if (valid && !saved.overview) {
    const next = steps.findIndex(s => s.page === page && !s.overview && s.panel >= (saved.panel ?? 0));
    if (next !== -1) return next;
    const previous = steps.map((s,i) => s.page === page && !s.overview ? i : -1).filter(i => i >= 0).at(-1) ?? -1;
    if (previous !== -1) return previous;
  }
  return Math.max(0, steps.findIndex(s => s.page === page));
}

export function panelCamera(focus: Rect, ratio: number, width: number, height: number, zoom = 1, pan = { x: 0, y: 0 }) {
  const baseWidth = 1000, baseHeight = baseWidth * ratio;
  const [x,y,w,h] = focus;
  const scale = Math.min(Math.max(1,width-24) / (w*baseWidth), Math.max(1,height-24) / (h*baseHeight)) * zoom;
  // A wide strip can fit at almost full-page scale. Centring that strip must
  // not push the rest of an otherwise fitting page beyond the viewport.
  // Explicit zoom/pan (including saved manual views) keeps its authored pose.
  const contain = (position: number, span: number, viewport: number) =>
    zoom === 1 && pan.x === 0 && pan.y === 0 && span <= viewport - 24
      ? Math.max(12, Math.min(viewport - 12 - span, position)) : position;
  return { scale,
    x: contain((width-w*baseWidth*scale)/2 - x*baseWidth*scale + pan.x, baseWidth*scale, width),
    y: contain((height-h*baseHeight*scale)/2 - y*baseHeight*scale + pan.y, baseHeight*scale, height),
    width: baseWidth, height: baseHeight, viewportWidth: width, viewportHeight: height };
}

// Inspection can exceed the viewport on either axis. Bound dragging by the
// actual frame, and keep both ranges compatible with saved ReaderView values.
export function panelInspection(bounds: Rect, base: ReturnType<typeof panelCamera>, zoom: number, requestedPan = { x: 0, y: 0 }) {
  const { width, height, viewportWidth: vw, viewportHeight: vh } = base;
  const [x, y, w, h] = bounds;
  const availableWidth = Math.max(1, vw - 24), availableHeight = Math.max(1, vh - 24);
  const scale = Math.min(base.scale * Math.max(1, zoom),
    (availableWidth + vw * 1.8) / (w * width),
    (availableHeight + vh * 1.8) / (h * height));
  const limits = {
    x: Math.min(vw * .9, Math.max(0, (w * width * scale - availableWidth) / 2)),
    y: Math.min(vh * .9, Math.max(0, (h * height * scale - availableHeight) / 2)),
  };
  const pan = { x: Math.max(-limits.x, Math.min(limits.x, requestedPan.x)),
    y: Math.max(-limits.y, Math.min(limits.y, requestedPan.y)) };
  const camera = { ...base, scale,
    x: (vw - w * width * scale) / 2 - x * width * scale + pan.x,
    y: (vh - h * height * scale) / 2 - y * height * scale + pan.y };
  return { camera, pan, limits };
}

// Preserve the paper point under the finger while changing scale. In
// particular, entering zoom must not recenter a fitting strip sideways.
export function anchoredPanelInspection(bounds: Rect, base: ReturnType<typeof panelCamera>, from: ReturnType<typeof panelCamera>, zoom: number,
  point = { x: base.viewportWidth / 2, y: base.viewportHeight / 2 }) {
  const centered = panelInspection(bounds, base, zoom);
  const ratio = centered.camera.scale / from.scale;
  return panelInspection(bounds, base, zoom, {
    x: point.x - (point.x - from.x) * ratio - centered.camera.x,
    y: point.y - (point.y - from.y) * ratio - centered.camera.y,
  });
}
