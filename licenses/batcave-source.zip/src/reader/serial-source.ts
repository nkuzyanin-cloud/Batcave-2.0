import type {PageSource} from './source';

/** Share one render queue between the camera, prefetch and page previews.
 * PDFPageProxy.cleanup must never race another render of the same page. */
export function serialSource(source: PageSource): PageSource {
  let tail = Promise.resolve(), closed = false;
  let closing: Promise<void> | undefined;
  return {
    count: source.count, ratio: source.ratio, prepared: source.prepared,
    render(index, canvas, width, signal) {
      const task = tail.then(() => {
        if (closed || signal?.aborted) throw new DOMException('Отменено', 'AbortError');
        return source.render(index, canvas, width, signal);
      });
      tail = task.catch(() => {});
      return task;
    },
    close() {
      closed = true;
      return closing ??= tail.then(() => source.close());
    },
  };
}
