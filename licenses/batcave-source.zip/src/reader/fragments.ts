export interface Position { x: number; y: number }
export function fragmentLayout(width: number, height: number, ratio: number, zoom: number, rtl = false) {
  const maxX = Math.max(0, (width * zoom - width) / 2);
  const maxY = Math.max(0, (width * ratio * zoom - height) / 2);
  const columns = Math.max(1, Math.ceil(2 * maxX / (width * 0.9)) + 1);
  const rows = Math.max(1, Math.ceil(2 * maxY / (height * 0.9)) + 1);
  const stops: Position[] = [];
  for (let row = 0; row < rows; row++)
    for (let col = 0; col < columns; col++)
      stops.push({
        x: columns === 1 ? 0 : maxX * (1 - 2 * col / (columns - 1)) * (rtl ? -1 : 1),
        y: rows === 1 ? 0 : maxY * (1 - 2 * row / (rows - 1)),
      });
  return { stops, maxX, maxY };
}
export function nearestFragment(stops: Position[], pan: Position) {
  let nearest = 0;
  for (let i = 1; i < stops.length; i++)
    if (Math.hypot(stops[i].x - pan.x, stops[i].y - pan.y) < Math.hypot(stops[nearest].x - pan.x, stops[nearest].y - pan.y)) nearest = i;
  return nearest;
}
