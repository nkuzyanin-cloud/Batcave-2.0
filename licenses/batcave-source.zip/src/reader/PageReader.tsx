import {forwardRef,useCallback,useImperativeHandle,useLayoutEffect,useRef} from 'react';
import type {ReaderView,Settings} from '../models';
import type {PageSource} from './source';
import {RenderedPage} from './RenderedPage';
import {PageCamera} from './page-camera';
export interface PageReaderHandle {zoom:(delta:number)=>void;reset:()=>void}
interface Props {source:PageSource;page:number;settings:Settings;enabled:boolean;initial?:ReaderView;onLoaded:(page:number)=>void;onError:(message:string)=>void;onView:(view:ReaderView)=>void;onToggle:()=>void;onTurn:(delta:number)=>void}
export const PageReader=forwardRef<PageReaderHandle,Props>(function PageReader(props,ref){
 const stage=useRef<HTMLDivElement>(null),layer=useRef<HTMLDivElement>(null),camera=useRef<PageCamera|undefined>(undefined),latest=useRef(props),view=useRef(props.initial);
 latest.current=props;
 useImperativeHandle(ref,()=>({zoom:delta=>camera.current?.zoom(delta),reset:()=>camera.current?.reset()}),[]);
 useLayoutEffect(()=>{
  const c=new PageCamera(stage.current!,layer.current!,{page:props.page,initial:view.current,enabled:()=>latest.current.enabled,settings:()=>latest.current.settings,onView:v=>{view.current=v;latest.current.onView(v);},onToggle:()=>latest.current.onToggle(),onTurn:delta=>latest.current.onTurn(delta)});camera.current=c;
  return()=>{c.destroy();camera.current=undefined;};
 },[props.source,props.page,props.settings.cropMargins]);
 useLayoutEffect(()=>{if(!props.enabled)camera.current?.pause();},[props.enabled]);
 const loaded=useCallback((p:number)=>{camera.current?.ready();latest.current.onLoaded(p);},[props.source,props.page,props.settings.cropMargins]);
 return <div ref={stage} className="reader-stage free-page-stage" data-testid="reader-stage" aria-label="Страница со свободным масштабом"><div ref={layer} className="page-transform free-page-transform" data-testid="page-transform"><RenderedPage source={props.source} index={props.page} cropMargins={props.settings.cropMargins} sharp onLoaded={loaded} onError={props.onError}/></div></div>;
});
