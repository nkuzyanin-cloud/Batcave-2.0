import {preparedPanelMap} from './prepared';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Settings2,
  Minus,
  Plus,
  Maximize,
  ZoomOut,
  ZoomIn,
} from 'lucide-react';
import { type Comic, type Settings, type ReaderView, errorMessage } from '../models';
import { getAsset, getComic, updateProgress, saveReaderView, savePanelEdit, saveAutomaticPanels } from '../storage/db';
import { ReadingSummary } from './ReadingSummary';
import { openSource, type PageSource } from './source';
import { Modal } from '../components/ui';
import { GuidedReader, type GuideHandle, type GuideState } from './GuidedReader';
import { RenderedPage } from './RenderedPage';
import { PanelReader } from './PanelReader';
import { loadPanelMap, type PanelMap } from './panels';
import { VisibleReadingTime } from './visible-time';
export function Reader({
  comic,
  settings,
  onSettings,
  onClose,
  onFinishClose,
}: {
  comic: Comic;
  settings: Settings;
  onSettings: (s: Settings) => void;
  onClose: () => void;
  onFinishClose?:()=>void;
}) {
  const [source, setSource] = useState<PageSource>();
  const [panelMap, setPanelMap] = useState<PanelMap | undefined>(comic.autoPanels);
  const [panelInitial,setPanelInitial] = useState(comic.readerView);
  const [recognizing, setRecognizing] = useState('');
  const scan = useRef<AbortController | undefined>(undefined);
  useEffect(()=>()=>scan.current?.abort(),[]);
  const [panelNotice, setPanelNotice] = useState('');
  const mode = settings.mode === 'panels' && !panelMap ? 'guided' : settings.mode;
  const focusedMode = mode === 'guided' || mode === 'panels';
  const [error, setError] = useState('');
  const [page, setPage] = useState(comic.page);
  const pageRef = useRef(page);
  pageRef.current = page;
  const [visible, setVisible] = useState(true);
  const [preferences, setPreferences] = useState(false);
  const [ending,setEnding]=useState(false),[result,setResult]=useState<Comic>(),[endingError,setEndingError]=useState('');
  const endingRef=useRef(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [panelEditing, setPanelEditing] = useState(false);
  const [panelEdits, setPanelEdits] = useState(comic.autoPanels ? comic.autoPanelEdits : comic.panelEdits);
  const initialView = comic.readerView?.mode === 'single' && comic.readerView.page === comic.page ? comic.readerView : undefined;
  const [zoom, setZoom] = useState(initialView?.zoom || 1);
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const restorePan = useRef<{ x: number; y: number } | undefined>(initialView);
  const guide = useRef<GuideHandle>(null);
  const [guideState, setGuideState] = useState<GuideState>({ step: 0, total: 1, zoom: 1.85 });
  const toggleUI = useCallback(() => { setToolsOpen(false); setVisible((v) => !v); }, []);
  const viewRef = useRef<ReaderView | undefined>(undefined);
  const viewTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const area = useRef<HTMLDivElement>(null);
  const ready = useRef(false);
  const saved = useRef<Promise<void>>(Promise.resolve());
  const flushTime = useRef<()=>Promise<void>>(()=>Promise.resolve());
  const persist = useCallback(
    (p: number, loaded: boolean, seconds = 0) => {
      saved.current = saved.current
        .then(() => updateProgress(comic.id, p, loaded, seconds))
        .catch((e) => setError(`Не удалось сохранить прогресс: ${errorMessage(e)}`));
      return saved.current;
    },
    [comic.id],
  );
  const persistView = useCallback(() => {
    clearTimeout(viewTimer.current);
    const view = viewRef.current;
    if (view) saved.current = saved.current.then(() => saveReaderView(comic.id, view)).catch((e) => setError(`Не удалось сохранить место чтения: ${errorMessage(e)}`));
    return saved.current;
  }, [comic.id]);
  const leave=useCallback(async()=>{
    await flushTime.current();
    await persistView();
    onClose();
  },[persistView,onClose]);
  const finish=useCallback(async()=>{
    if(endingRef.current || !ready.current)return;
    endingRef.current=true;setEnding(true);setResult(undefined);setEndingError('');
    setPreferences(false);setToolsOpen(false);
    clearTimeout(tapTimer.current);
    try {
      await flushTime.current();await persistView();
      const latest=await getComic(comic.id);
      if(!latest)throw Error('Комикс не найден.');
      setResult(latest);
    } catch(e){setEndingError(errorMessage(e));}
  },[comic.id,persistView]);
  const backToLast=()=>{endingRef.current=false;setEnding(false);setVisible(true);setPanelInitial(viewRef.current);};
  const rememberView = useCallback((view: ReaderView) => {
    viewRef.current = view;
    clearTimeout(viewTimer.current);
    viewTimer.current = setTimeout(() => void persistView(), 220);
  }, [persistView]);
  useEffect(() => {
    const flush = () => void persistView();
    document.addEventListener('visibilitychange', flush);
    window.addEventListener('pagehide', flush);
    return () => {
      flush();
      document.removeEventListener('visibilitychange', flush);
      window.removeEventListener('pagehide', flush);
    };
  }, [persistView]);
  useEffect(() => {
    let cancelled = false;
    let opened: PageSource | undefined;
    void (async () => {
      try {
        const asset = comic.digital ? await getAsset(comic.digital.assetId) : undefined;
        if (!asset) throw Error('Цифровой файл отсутствует. Добавьте его заново из библиотеки.');
        opened = await openSource(asset.blob, comic.digital!.format);
        if(opened.prepared&&!cancelled)setPanelMap(preparedPanelMap(opened.prepared,comic.digital!.fingerprint));
        if (!opened.prepared && !comic.autoPanels && comic.digital!.format === 'pdf') {
          try {
            const map = await loadPanelMap(comic.digital!.fingerprint, opened.count);
            if (!cancelled) setPanelMap(map);
          } catch (e) {
            if (!cancelled) setPanelNotice(errorMessage(e));
          }
        }
        if (cancelled) {
          await opened.close();
          return;
        }
        setSource(opened);
        setPage(Math.min(comic.page, opened.count - 1));
      } catch (e) {
        if (!cancelled) setError(errorMessage(e));
      }
    })();
    return () => {
      cancelled = true;
      ready.current = false;
      void opened?.close().catch(() => {});
    };
  }, [comic.id, comic.digital?.assetId]);
  async function recognize() {
    if(!comic.digital || recognizing) return;
    const controller=new AbortController();scan.current=controller;
    setRecognizing('Подготовка…');setPanelNotice('');
    try {
      const asset=await getAsset(comic.digital.assetId);
      if(!asset) throw Error('Цифровой файл отсутствует.');
      const {recognizePanels}=await import('./auto-panels');
      const map=await recognizePanels(asset.blob,comic.digital.format,comic.digital.fingerprint,setRecognizing,controller.signal);
      if(controller.signal.aborted) return;
      await persistView();
      const updated=await saveAutomaticPanels(comic.id,map);
      if(controller.signal.aborted) return;
      clearTimeout(viewTimer.current);viewRef.current=undefined;
      setPanelEdits(updated.autoPanelEdits);setPanelMap(updated.autoPanels);
      setPanelInitial(undefined);
      setPanelNotice('Кадры готовы. Правки доступны по удержанию кадра.');
    } catch(e) {if(!controller.signal.aborted) setPanelNotice(errorMessage(e));}
    finally {if(!controller.signal.aborted) setRecognizing('');}
  }
  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const clock=new VisibleReadingTime();
    clock.setVisible(!!source && !ending && !document.hidden);
    function flush() {
      const seconds=clock.drainSeconds();
      return seconds>0 ? persist(pageRef.current,false,seconds) : saved.current;
    }
    const stop=()=>{clock.setVisible(false);return flush();};
    flushTime.current=stop;
    const interval = setInterval(flush, 5000);
    const visibility = () => {
      clock.setVisible(!!source && !endingRef.current && !document.hidden);
      void flush();
    };
    document.addEventListener('visibilitychange', visibility);
    window.addEventListener('pagehide', stop);
    window.addEventListener('pageshow', visibility);
    return () => {
      void stop();
      clearInterval(interval);
      document.removeEventListener('visibilitychange', visibility);
      window.removeEventListener('pagehide', stop);
      window.removeEventListener('pageshow', visibility);
      document.body.style.overflow = previous;
    };
  }, [persist, source, ending]);
  const go = useCallback(
    (p: number) => {
      if (!source) return;
      if(p>=source.count){void finish();return;}
      const next = Math.min(source.count - 1, Math.max(0, p));
      setPage(next);
      pageRef.current = next;
      clearTimeout(tapTimer.current);
      clearTimeout(viewTimer.current);
      viewRef.current = undefined;
      restorePan.current = { x: settings.direction === 'rtl' ? -1 : 1, y: 1 };
      setPan({ x: 0, y: 0 });
      ready.current = false;
      void persist(next, false);
    },
    [source, persist, settings.direction,finish],
  );
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (e.defaultPrevented || preferences || panelEditing) return;
      if(ending){if(e.key==='Escape')void leave();return;}
      if (e.key === 'ArrowRight') focusedMode ? (settings.direction === 'ltr' ? guide.current?.next() : guide.current?.previous()) : go(pageRef.current + (settings.direction === 'ltr' ? 1 : -1));
      if (e.key === 'ArrowLeft') focusedMode ? (settings.direction === 'ltr' ? guide.current?.previous() : guide.current?.next()) : go(pageRef.current + (settings.direction === 'ltr' ? -1 : 1));
      if (e.key === 'Escape') void leave();
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [go, settings.direction, focusedMode, leave, preferences, panelEditing,ending]);
  const loaded = useCallback(
    (p: number) => {
      if (p === pageRef.current) {
        ready.current = true;
        void persist(p, true);
        if (restorePan.current && area.current) {
          const limits = bound(Infinity, Infinity, zoomRef.current);
          setPan({ x: restorePan.current.x * limits.x, y: restorePan.current.y * limits.y });
          restorePan.current = undefined;
        }
      }
    },
    [persist],
  );
  const points = useRef(new Map<number, { x: number; y: number }>());
  const gesture = useRef({
    x: 0,
    y: 0,
    px: 0,
    py: 0,
    scale: 1,
    distance: 0,
    moved: false,
    pinch: false,
    time: 0,
  });
  const tap = useRef(0);
  const tapTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => () => clearTimeout(tapTimer.current), []);
  function bound(x: number, y: number, scale: number) {
    const w = area.current?.clientWidth || 400,
      h = area.current?.clientHeight || 600;
    const canvas = area.current?.querySelector('canvas');
    const maxX = Math.max(0, ((canvas?.offsetWidth || w) * scale - w) / 2);
    const maxY = Math.max(0, ((canvas?.offsetHeight || h) * scale - h) / 2);
    return { x: Math.max(-maxX, Math.min(maxX, x)), y: Math.max(-maxY, Math.min(maxY, y)) };
  }
  useEffect(() => {
    if (mode !== 'single' || !source || !ready.current) return;
    const limits = bound(Infinity, Infinity, zoom);
    const bounded = bound(pan.x, pan.y, zoom);
    if (bounded.x !== pan.x || bounded.y !== pan.y) { setPan(bounded); return; }
    rememberView({ page, mode: 'single', zoom, x: limits.x ? Math.max(-1, Math.min(1, pan.x / limits.x)) : 0, y: limits.y ? Math.max(-1, Math.min(1, pan.y / limits.y)) : 0 });
  }, [mode, source, page, zoom, pan, rememberView]);
  const distance = () => {
    const p = Array.from(points.current.values());
    return p.length >= 2 ? Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y) : 0;
  };
  function down(e: React.PointerEvent) {
    e.currentTarget.setPointerCapture(e.pointerId);
    points.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (points.current.size === 1)
      gesture.current = {
        x: e.clientX,
        y: e.clientY,
        px: pan.x,
        py: pan.y,
        scale: zoom,
        distance: 0,
        moved: false,
        pinch: false,
        time: Date.now(),
      };
    if (points.current.size === 2) {
      gesture.current.distance = distance();
      gesture.current.scale = zoom;
      gesture.current.pinch = true;
      clearTimeout(tapTimer.current);
    }
  }
  function move(e: React.PointerEvent) {
    if (!points.current.has(e.pointerId)) return;
    points.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const g = gesture.current;
    if (points.current.size === 2) {
      const z = Math.max(1, Math.min(4, (g.scale * distance()) / Math.max(1, g.distance)));
      setZoom(z);
      setPan(bound(pan.x, pan.y, z));
      g.moved = true;
    } else if (!g.pinch) {
      const dx = e.clientX - g.x,
        dy = e.clientY - g.y;
      if (Math.hypot(dx, dy) > 8) g.moved = true;
      if (zoom > 1) setPan(bound(g.px + dx, g.py + dy, zoom));
    }
  }
  function up(e: React.PointerEvent) {
    points.current.delete(e.pointerId);
    if (points.current.size) return;
    const g = gesture.current;
    if (g.pinch) return;
    const dx = e.clientX - g.x,
      dy = e.clientY - g.y;
    if (zoom === 1 && Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.3) {
      go(page + (dx < 0 ? 1 : -1) * (settings.direction === 'ltr' ? 1 : -1));
      return;
    }
    if (g.moved || Date.now() - g.time > 500) return;
    const now = Date.now();
    if (now - tap.current < 280 && settings.doubleTap) {
      clearTimeout(tapTimer.current);
      setZoom(zoom > 1 ? 1 : 2.5);
      setPan({ x: 0, y: 0 });
      tap.current = 0;
    } else {
      tap.current = now;
      tapTimer.current = setTimeout(toggleUI, settings.doubleTap ? 280 : 0);
    }
  }
  if(ending)return <ReadingSummary comic={result} error={endingError || error} onBack={backToLast} onClose={()=>void(async()=>{await flushTime.current();await persistView();(onFinishClose ?? onClose)();})()} onChanged={setResult}/>;
  return (
    <div className={`reader theme-${settings.readerTheme} ${visible ? '' : 'ui-hidden'}`} aria-label="Читалка">
      <header className={`reader-header ${visible ? '' : 'hidden-ui'}`} inert={panelEditing || !visible} aria-hidden={!visible || panelEditing}>
        <button
          className="icon-button"
          aria-label="Вернуться к комиксам"
          onClick={() => void leave()}
        >
          <ArrowLeft />
        </button>
        <div><span title={comic.title}>{comic.title}</span></div>
        <button
          className="icon-button"
          aria-label="Настройки чтения"
          onClick={() => { setToolsOpen(false); setPreferences(true); }}
        >
          <Settings2 />
        </button>
      </header>
      {error ? (
        <div className="reader-error">
          <p role="alert">{error}</p>
          <button className="primary" onClick={() => void leave()}>
            В библиотеку
          </button>
        </div>
      ) : !source ? (
        <div className="reader-loading">
          <span className="spinner" />
          <p>Открытие комикса…</p>
        </div>
      ) : mode === 'panels' && panelMap ? <PanelReader
        ref={guide}
        source={source}
        map={panelMap}
        page={page}
        settings={settings}
        enabled={!preferences}
        initial={panelInitial}
        fingerprint={comic.digital!.fingerprint}
        edits={panelEdits}
        onEditing={(editing) => { setToolsOpen(false); setPanelEditing(editing); }}
        onSaveEdit={async (page, panel, edit) => {
          const updated = await savePanelEdit(comic.id, comic.digital!.fingerprint, page, panel, edit);
          setPanelEdits(updated);
        }}
        onPage={go}
        onLoaded={loaded}
        onError={setError}
        onToggle={toggleUI}
        onView={rememberView}
        onState={setGuideState}
        onEnd={()=>void finish()}
      /> : mode === 'guided' ? <GuidedReader
        ref={guide}
        source={source}
        cropMargins={settings.cropMargins}
        page={page}
        direction={settings.direction}
        doubleTap={settings.doubleTap}
        enabled={!preferences}
        initial={panelInitial}
        onPage={go}
        onLoaded={loaded}
        onError={setError}
        onToggle={toggleUI}
        onView={rememberView}
        onState={setGuideState}
        onEnd={()=>void finish()}
      /> : mode === 'single' ? (
        <div
          ref={area}
          className="reader-stage"
          data-testid="reader-stage"
          onPointerDown={down}
          onPointerMove={move}
          onPointerUp={up}
          onPointerCancel={() => points.current.clear()}
          onWheel={(e) => {
            if (e.ctrlKey) {
              setZoom((z) => Math.max(1, Math.min(4, z - e.deltaY * 0.005)));
            } else if (zoom > 1) setPan(bound(pan.x - e.deltaX, pan.y - e.deltaY, zoom));
          }}
        >
          <div
            className="page-transform"
            data-testid="page-transform"
            style={{ transform: `translate(${pan.x}px,${pan.y}px) scale(${zoom})` }}
          >
            <RenderedPage cropMargins={settings.cropMargins}
              key={page}
              source={source}
              index={page}
              onLoaded={loaded}
              onError={setError}
            />
          </div>
        </div>
      ) : (
        <VerticalReader
          onEnd={()=>void finish()}
          cropMargins={settings.cropMargins}
          source={source}
          page={page}
          onPage={(p) => {
            pageRef.current = p;
            setPage(p);
            void persist(p, false);
          }}
          onLoaded={loaded}
          onError={setError}
          onTap={toggleUI}
          doubleTap={settings.doubleTap}
        />
      )}
      {source && (
        <footer className={`reader-controls ${visible ? '' : 'hidden-ui'}`} inert={panelEditing || !visible} aria-hidden={!visible || panelEditing}>
          <input
            aria-label="Перейти к странице"
            type="range"
            min="0"
            max={source.count - 1}
            value={page}
            style={{ '--seek-progress': `${source.count > 1 ? page / (source.count - 1) * 100 : 100}%` } as React.CSSProperties}
            onChange={(e) => go(Number(e.target.value))}
          />
          <div className="reader-toolbar">
            <button
              className="icon-button"
              aria-label={mode === 'panels' ? 'Предыдущий кадр' : mode === 'guided' ? 'Предыдущий фрагмент' : 'Предыдущая страница'}
              disabled={page === 0 && (!focusedMode || guideState.step === 0)}
              onClick={() => focusedMode ? guide.current?.previous() : go(page - 1)}
            >
              <ChevronLeft />
            </button>
            <span aria-live="polite">
              {settings.showPage
                ? `${page + 1} / ${source.count}`
                : `${Math.round(((page + 1) / source.count) * 100)}%`}
              {(mode==='single' || (mode==='panels' && guideState.label==='Вся страница')) && <small>Вся страница</small>}
            </span>
            <button
              className="icon-button"
              aria-label={mode === 'panels' ? 'Следующий кадр' : mode === 'guided' ? 'Следующий фрагмент' : 'Следующая страница'}
              onClick={() => focusedMode ? guide.current?.next() : go(page + 1)}
            >
              <ChevronRight />
            </button>
            <button className={`icon-button reader-tools-toggle ${toolsOpen ? 'active' : ''}`} aria-label="Инструменты чтения" aria-expanded={toolsOpen} onClick={() => setToolsOpen(v => !v)}><ZoomIn size={20} /></button>
          </div>
          {toolsOpen && <div className="reader-tools" role="group" aria-label="Масштаб и экран">
            {mode !== 'vertical' && (
              <>
                <button
                  className="icon-button"
                  aria-label="Уменьшить масштаб"
                  onClick={() => {
                    if (focusedMode) { guide.current?.zoom(-0.25); return; }
                    setZoom((z) => Math.max(1, z - 0.5));
                    setPan({ x: 0, y: 0 });
                  }}
                >
                  <Minus size={19} />
                </button>
                <button
                  className="icon-button"
                  aria-label="Увеличить масштаб"
                  onClick={() => focusedMode ? guide.current?.zoom(0.25) : setZoom((z) => Math.min(4, z + 0.5))}
                >
                  <Plus size={19} />
                </button>
                <button
                  className="icon-button"
                  aria-label={focusedMode ? 'Показать всю страницу' : 'Сбросить масштаб'}
                  onClick={() => {
                    if (focusedMode) {
                      clearTimeout(viewTimer.current);
                      viewRef.current = undefined;
                      onSettings({ ...settings, mode: 'single' });
                    }
                    setToolsOpen(false);
                    setZoom(1);
                    setPan({ x: 0, y: 0 });
                  }}
                >
                  <ZoomOut size={19} />
                </button>
              </>
            )}
            <button
              className="icon-button"
              aria-label="Полный экран"
              onClick={() => {
                setToolsOpen(false);
                const el = document.documentElement;
                if (document.fullscreenElement) void document.exitFullscreen?.();
                else if (el.requestFullscreen)
                  void el.requestFullscreen().catch(() => setVisible(false));
                else setVisible(false);
              }}
            >
              <Maximize size={18} />
            </button>
          </div>}
        </footer>
      )}
      {preferences && (
        <Modal title="Настройки чтения" onClose={() => setPreferences(false)}>
          <ReaderPreferences
            settings={settings}
            panelsAvailable={!!panelMap}
            onChange={(s) => {
              onSettings(s);
              if (s.mode !== settings.mode) { clearTimeout(viewTimer.current); viewRef.current = undefined; setZoom(1); setPan({ x: 0, y: 0 }); }
            }}
          />
          <p className="muted">
            {mode === 'panels' ? 'Каждый кадр показывается целиком один раз. Прокрутка вверх — следующий кадр. Вниз — предыдущий. Свайп в сторону также переключает кадр. Одно касание — меню, два — масштаб. При увеличении кадр целиком виден по высоте и двигается только влево-вправо. Удержание кадра — правка границ и масштаба.' : mode === 'guided' ? 'Фрагменты: касание края или короткий свайп — следующий участок. Центр — меню. Двигайте страницу пальцем; щипок и два касания меняют масштаб.' : 'Свайп — перелистнуть. Два касания — масштаб. Два пальца — увеличение. Касание — скрыть интерфейс.'}
          </p>
          {panelEdits?.frames.some(e => e.hidden) && <button className="secondary" disabled={!!recognizing} onClick={() => void (async () => {
            try {
              let updated: typeof comic.autoPanelEdits = panelEdits;
              for (const edit of panelEdits.frames.filter(e => e.hidden)) {
                const { hidden: _, ...restored } = edit;
                updated = await savePanelEdit(comic.id, comic.digital!.fingerprint, edit.page, edit.panel, restored);
              }
              setPanelEdits(updated); setPanelNotice('Удалённые кадры восстановлены.');
            } catch(e) { setPanelNotice(`Не удалось восстановить: ${errorMessage(e)}`); }
          })()}>Восстановить удалённые кадры</button>}
          {panelNotice && <p className="muted">{panelNotice}</p>}
          {!source?.prepared && !panelMap?.detector && <button className="secondary" disabled={!!recognizing} onClick={()=>void recognize()}>Распознать кадры автоматически</button>}
          {recognizing && <><p role="status" className="loading"><span className="spinner" />{recognizing}</p><button className="secondary" onClick={()=>{scan.current?.abort();setRecognizing('');}}>Отменить распознавание</button></>}
          {!panelMap && <p className="muted">Можно распознать кадры на устройстве или читать крупными фрагментами.</p>}
        </Modal>
      )}
    </div>
  );
}
export function ReaderPreferences({
  settings: s,
  onChange,
  panelsAvailable,
}: {
  settings: Settings;
  onChange: (s: Settings) => void;
  panelsAvailable?: boolean;
}) {
  return (
    <div className="form">
      <label className="switch-label"><span>Обрезать поля</span><input type="checkbox" checked={s.cropMargins} onChange={e => onChange({ ...s, cropMargins: e.target.checked })} /></label>
      <small className="muted">Внешние поля и распознанная подпись скана.</small>
      <label>
        Режим чтения
        <select
          value={s.mode}
          onChange={(e) => onChange({ ...s, mode: e.target.value as Settings['mode'] })}
        >
          <option value="single">Одиночные страницы</option>
          <option value="panels" disabled={panelsAvailable === false}>По кадрам · с разметкой</option>
          <option value="guided">Крупные фрагменты · для телефона</option>
          <option value="vertical">Вертикальная прокрутка</option>
        </select>
      </label>
      {s.mode === 'panels' && <fieldset className="panel-preferences">
        <legend>Чтение по кадрам</legend>
        <label className="panel-opacity-label">Затемнение вне кадра <output>{Math.round(s.panelOpacity*100)}%</output>
          <input type="range" aria-label="Затемнение вне кадра" min="0" max="90" step="5" value={Math.round(s.panelOpacity*100)} onChange={e => onChange({ ...s, panelOpacity: Number(e.target.value)/100 })} />
        </label>
        <label className="switch-label"><span>Вся страница перед кадрами</span><input type="checkbox" checked={s.panelPageFirst} onChange={e => onChange({ ...s, panelPageFirst: e.target.checked })} /></label>
        <label className="switch-label"><span>Вся страница после кадров</span><input type="checkbox" checked={s.panelPageLast} onChange={e => onChange({ ...s, panelPageLast: e.target.checked })} /></label>
      </fieldset>}
      <label>
        Направление свайпов
        <select
          value={s.direction}
          onChange={(e) => onChange({ ...s, direction: e.target.value as Settings['direction'] })}
        >
          <option value="ltr">Слева направо</option>
          <option value="rtl">Справа налево</option>
        </select>
      </label>
      <label>
        Фон страницы
        <select
          value={s.readerTheme}
          onChange={(e) =>
            onChange({ ...s, readerTheme: e.target.value as Settings['readerTheme'] })
          }
        >
          <option value="black">Чёрный</option>
          <option value="gray">Графит</option>
          <option value="light">Светлый</option>
        </select>
      </label>
      <label>
        Анимации
        <select
          value={s.motion}
          onChange={(e) => onChange({ ...s, motion: e.target.value as Settings['motion'] })}
        >
          <option value="system">Как в системе</option>
          <option value="full">Плавные</option>
          <option value="fast">Быстрые</option>
          <option value="off">Выключены</option>
        </select>
      </label>
      <label className="switch-label">
        <span>Масштаб двойным касанием</span>
        <input
          type="checkbox"
          checked={s.doubleTap}
          onChange={(e) => onChange({ ...s, doubleTap: e.target.checked })}
        />
      </label>
      <label className="switch-label">
        <span>Номер страницы</span>
        <input
          type="checkbox"
          checked={s.showPage}
          onChange={(e) => onChange({ ...s, showPage: e.target.checked })}
        />
      </label>
    </div>
  );
}
function VerticalReader({
  source,
  cropMargins,
  page,
  onPage,
  onLoaded,
  onError,
  onTap,
  doubleTap,
  onEnd,
}: {
  source: PageSource;
  page: number;
  onPage: (p: number) => void;
  onEnd:()=>void;
  onLoaded: (p: number) => void;
  onError: (s: string) => void;
  onTap: () => void;
  doubleTap: boolean;
  cropMargins?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [scroll, setScroll] = useState(0);
  const [width, setWidth] = useState(window.innerWidth);
  const [ratios, setRatios] = useState<Record<number, number>>({});
  const [zoom, setZoom] = useState(1);
  const scrollPage = useRef(page);
  const heights = Array.from(
    { length: source.count },
    (_, i) => Math.max(200, width * (ratios[i] || source.ratio)) + 14,
  );
  const offsets = [0];
  for (const h of heights) offsets.push(offsets[offsets.length - 1] + h);
  const offsetsRef = useRef(offsets);
  offsetsRef.current = offsets;
  const updateRatio = useCallback(
    (p: number, r: number) => setRatios((old) => (old[p] === r ? old : { ...old, [p]: r })),
    [],
  );
  const loadedPages = useRef(new Set<number>());
  const loaded = useCallback(
    (p: number) => {
      loadedPages.current.add(p);
      onLoaded(p);
    },
    [onLoaded],
  );
  useEffect(() => {
    const node = ref.current!;
    const observer = new ResizeObserver(() => setWidth(node.clientWidth));
    observer.observe(node);
    node.scrollTop = offsetsRef.current[page];
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (page !== scrollPage.current) {
      ref.current?.scrollTo({ top: offsetsRef.current[page] });
      setZoom(1);
      scrollPage.current = page;
    }
    if (loadedPages.current.has(page)) onLoaded(page);
  }, [page, onLoaded]);
  function onScroll() {
    const node = ref.current!;
    const top = node.scrollTop;
    if(top>=offsetsRef.current[source.count]-1 && scrollPage.current===source.count-1 && loadedPages.current.has(source.count-1)){onEnd();return;}
    setScroll(top);
    const center = top + Math.min(node.clientHeight * 0.35, 150);
    let p = 0;
    while (p < source.count - 1 && offsetsRef.current[p + 1] <= center) p++;
    if (p !== scrollPage.current) {
      scrollPage.current = p;
      onPage(p);
      if (loadedPages.current.has(p)) onLoaded(p);
      setZoom(1);
    }
  }
  const height = ref.current?.clientHeight || window.innerHeight;
  let first = 0;
  while (first < source.count - 1 && offsets[first + 1] < scroll) first++;
  let last = first;
  while (last < source.count - 1 && offsets[last] < scroll + height) last++;
  const from = Math.max(0, first - 1),
    to = Math.min(source.count - 1, last + 1, from + 4);
  const tap = useRef(0);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => () => clearTimeout(timer.current), []);
  const touch = useRef<{ distance: number; scale: number }>({ distance: 0, scale: 1 });
  return (
    <div ref={ref} className="vertical-reader" onScroll={onScroll}>
      <div style={{ height: offsets[source.count]+height, position: 'relative' }}>
        {Array.from({ length: to - from + 1 }, (_, i) => from + i).map((p) => (
          <div
            key={p}
            className="vertical-page"
            style={{ top: offsets[p], height: heights[p] - 14 }}
          >
            <div
              className="vertical-zoom"
              onTouchStart={(e) => {
                if (e.touches.length === 2) {
                  touch.current = {
                    distance: Math.hypot(
                      e.touches[0].clientX - e.touches[1].clientX,
                      e.touches[0].clientY - e.touches[1].clientY,
                    ),
                    scale: zoom,
                  };
                }
              }}
              onTouchMove={(e) => {
                if (e.touches.length === 2 && p === page) {
                  const d = Math.hypot(
                    e.touches[0].clientX - e.touches[1].clientX,
                    e.touches[0].clientY - e.touches[1].clientY,
                  );
                  setZoom(
                    Math.max(
                      1,
                      Math.min(4, (touch.current.scale * d) / Math.max(1, touch.current.distance)),
                    ),
                  );
                }
              }}
              onClick={() => {
                const now = Date.now();
                if (doubleTap && now - tap.current < 280) {
                  clearTimeout(timer.current);
                  setZoom((z) => (z === 1 ? 2.5 : 1));
                  tap.current = 0;
                } else {
                  tap.current = now;
                  timer.current = setTimeout(onTap, doubleTap ? 280 : 0);
                }
              }}
              style={{ touchAction: p === page && zoom > 1 ? 'pan-x pan-y' : 'pan-y' }}
            >
              <div style={{ width: p === page ? `${zoom * 100}%` : '100%', minHeight: '100%' }}>
                <RenderedPage cropMargins={cropMargins}
                  source={source}
                  index={p}
                  onLoaded={loaded}
                  onError={onError}
                  onRatio={updateRatio}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
