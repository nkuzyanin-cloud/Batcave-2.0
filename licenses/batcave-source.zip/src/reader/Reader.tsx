import {preparedPanelMap} from './prepared';
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Settings as SettingsIcon,
  Ellipsis,
  ChevronDown,
  Minus,
  Plus,
  Maximize,
  ZoomOut,
} from 'lucide-react';
import { type Comic, type Settings, type ReaderView, errorMessage } from '../models';
import { getAsset, getComic, updateProgress, saveReaderView, savePanelEdit, saveAutomaticPanels } from '../storage/db';
import { ReadingSummary } from './ReadingSummary';
import { openSource, type PageSource } from './source';
import { Modal } from '../components/ui';
import { GuidedReader, type GuideHandle } from './GuidedReader';
import { RenderedPage } from './RenderedPage';
import { PanelReader } from './PanelReader';
import { loadPanelMap, type PanelMap } from './panels';
import { VisibleReadingTime } from './visible-time';
import { ReaderPreferences } from './ReaderPreferences';
import { PageGrid } from './PageGrid';
import { PageStrip } from './PageStrip';
import { serialSource } from './serial-source';
import './reader-chrome.css';
import { PageReader,type PageReaderHandle } from './PageReader';
export { ReaderPreferences } from './ReaderPreferences';
export function Reader({
  comic,
  settings,
  onSettings,
  onClose,
  onFinishClose,
}: {
  comic: Comic;
  settings: Settings;
  onSettings: (s: Settings) => void;
  onClose: () => void;
  onFinishClose?:()=>void;
}) {
  const [source, setSource] = useState<PageSource>();
  const [panelMap, setPanelMap] = useState<PanelMap | undefined>(comic.autoPanels);
  const [panelInitial,setPanelInitial] = useState(comic.readerView);
  const [recognizing, setRecognizing] = useState('');
  const scan = useRef<AbortController | undefined>(undefined);
  useEffect(()=>()=>scan.current?.abort(),[]);
  const [panelNotice, setPanelNotice] = useState('');
  const mode = settings.mode === 'panels' && !panelMap ? 'guided' : settings.mode;
  const focusedMode = mode === 'guided' || mode === 'panels';
  const [error, setError] = useState('');
  const [page, setPage] = useState(comic.page);
  const pageRef = useRef(page);
  pageRef.current = page;
  const [visible, setVisible] = useState(false);
  const [pageReady, setPageReady] = useState(false);
  const [preferences, setPreferences] = useState(false);
  const [pageGrid,setPageGrid]=useState(false);
  const [ending,setEnding]=useState(comic.completed),[result,setResult]=useState<Comic|undefined>(comic.completed?comic:undefined),[endingError,setEndingError]=useState('');
  const endingRef=useRef(comic.completed);
  const [started,setStarted]=useState(!comic.completed);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [panelEditing, setPanelEditing] = useState(false);
  const [panelEdits, setPanelEdits] = useState(comic.autoPanels ? comic.autoPanelEdits : comic.panelEdits);
  const initialView = comic.readerView?.mode === 'single' && comic.readerView.page === comic.page ? comic.readerView : undefined;
  const singleInitial=useRef(initialView);
  const pageReader=useRef<PageReaderHandle>(null);
  const guide = useRef<GuideHandle>(null);
  const onGuideState = useCallback(() => {}, []);
  const toggleUI = useCallback(() => { setToolsOpen(false); setVisible((v) => !v); }, []);
  const viewRef = useRef<ReaderView | undefined>(undefined);
  const viewTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const ready = useRef(false);
  const saved = useRef<Promise<void>>(Promise.resolve());
  const flushTime = useRef<()=>Promise<void>>(()=>Promise.resolve());
  const persist = useCallback(
    (p: number, loaded: boolean, seconds = 0) => {
      saved.current = saved.current
        .then(() => updateProgress(comic.id, p, loaded, seconds))
        .catch((e) => setError(`Не удалось сохранить прогресс: ${errorMessage(e)}`));
      return saved.current;
    },
    [comic.id],
  );
  const persistView = useCallback(() => {
    clearTimeout(viewTimer.current);
    const view = viewRef.current;
    if (view) saved.current = saved.current.then(() => saveReaderView(comic.id, view)).catch((e) => setError(`Не удалось сохранить место чтения: ${errorMessage(e)}`));
    return saved.current;
  }, [comic.id]);
  const leave=useCallback(async()=>{
    await flushTime.current();
    await persistView();
    onClose();
  },[persistView,onClose]);
  const finish=useCallback(async()=>{
    if(endingRef.current || !ready.current)return;
    endingRef.current=true;setEnding(true);setResult(undefined);setEndingError('');
    setPreferences(false);setToolsOpen(false);
    try {
      await flushTime.current();await persistView();
      const latest=await getComic(comic.id);
      if(!latest)throw Error('Комикс не найден.');
      setResult(latest);
    } catch(e){setEndingError(errorMessage(e));}
  },[comic.id,persistView]);
  const backToLast=()=>{setStarted(true);endingRef.current=false;setEnding(false);setVisible(true);setPanelInitial(viewRef.current ?? comic.readerView);};
  const rememberView = useCallback((view: ReaderView) => {
    if(view.page!==pageRef.current)return;
    if(view.mode==='single')singleInitial.current=view;
    viewRef.current = view;
    clearTimeout(viewTimer.current);
    viewTimer.current = setTimeout(() => void persistView(), 220);
  }, [persistView]);
  useEffect(() => {
    const flush = () => void persistView();
    document.addEventListener('visibilitychange', flush);
    window.addEventListener('pagehide', flush);
    return () => {
      flush();
      document.removeEventListener('visibilitychange', flush);
      window.removeEventListener('pagehide', flush);
    };
  }, [persistView]);
  useEffect(() => {
    if(!started)return;
    let cancelled = false;
    let opened: PageSource | undefined;
    void (async () => {
      try {
        const asset = comic.digital ? await getAsset(comic.digital.assetId) : undefined;
        if (!asset) throw Error('Цифровой файл отсутствует. Добавьте его заново из библиотеки.');
        opened = serialSource(await openSource(asset.blob, comic.digital!.format));
        if(opened.prepared&&!cancelled)setPanelMap(preparedPanelMap(opened.prepared,comic.digital!.fingerprint));
        if (!opened.prepared && !comic.autoPanels && comic.digital!.format === 'pdf') {
          try {
            const map = await loadPanelMap(comic.digital!.fingerprint, opened.count);
            if (!cancelled) setPanelMap(map);
          } catch (e) {
            if (!cancelled) setPanelNotice(errorMessage(e));
          }
        }
        if (cancelled) {
          await opened.close();
          return;
        }
        setSource(opened);
        setPage(Math.min(comic.page, opened.count - 1));
      } catch (e) {
        if (!cancelled) setError(errorMessage(e));
      }
    })();
    return () => {
      cancelled = true;
      ready.current = false;
      void opened?.close().catch(() => {});
    };
  }, [comic.id, comic.digital?.assetId, started]);
  async function recognize() {
    if(!comic.digital || recognizing) return;
    const controller=new AbortController();scan.current=controller;
    setRecognizing('Подготовка…');setPanelNotice('');
    try {
      const asset=await getAsset(comic.digital.assetId);
      if(!asset) throw Error('Цифровой файл отсутствует.');
      const {recognizePanels}=await import('./auto-panels');
      const map=await recognizePanels(asset.blob,comic.digital.format,comic.digital.fingerprint,setRecognizing,controller.signal);
      if(controller.signal.aborted) return;
      await persistView();
      const updated=await saveAutomaticPanels(comic.id,map);
      if(controller.signal.aborted) return;
      clearTimeout(viewTimer.current);viewRef.current=undefined;
      setPanelEdits(updated.autoPanelEdits);setPanelMap(updated.autoPanels);
      setPanelInitial(undefined);
      setPanelNotice('Кадры готовы. Правки доступны по удержанию кадра.');
    } catch(e) {if(!controller.signal.aborted) setPanelNotice(errorMessage(e));}
    finally {if(!controller.signal.aborted) setRecognizing('');}
  }
  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const clock=new VisibleReadingTime();
    clock.setVisible(!!source && !ending && !preferences && !pageGrid && !document.hidden);
    function flush() {
      const seconds=clock.drainSeconds();
      return seconds>0 ? persist(pageRef.current,false,seconds) : saved.current;
    }
    const stop=()=>{clock.setVisible(false);return flush();};
    flushTime.current=stop;
    const interval = setInterval(flush, 5000);
    const visibility = () => {
      clock.setVisible(!!source && !endingRef.current && !preferences && !pageGrid && !document.hidden);
      void flush();
    };
    document.addEventListener('visibilitychange', visibility);
    window.addEventListener('pagehide', stop);
    window.addEventListener('pageshow', visibility);
    return () => {
      void stop();
      clearInterval(interval);
      document.removeEventListener('visibilitychange', visibility);
      window.removeEventListener('pagehide', stop);
      window.removeEventListener('pageshow', visibility);
      document.body.style.overflow = previous;
    };
  }, [persist, source, ending, preferences, pageGrid]);
  const go = useCallback(
    (p: number) => {
      if (!source) return;
      if(p>=source.count){void finish();return;}
      const next = Math.min(source.count - 1, Math.max(0, p));
      if(next===pageRef.current)return;
      setPage(next);
      pageRef.current = next;
      clearTimeout(viewTimer.current);
      viewRef.current = undefined;
      singleInitial.current=undefined;
      ready.current = false;
      setPageReady(false);
      void persist(next, false);
    },
    [source, persist, settings.direction,finish],
  );
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (e.defaultPrevented || preferences || pageGrid || panelEditing) return;
      if (e.target instanceof Element && e.target.closest('input, select, textarea, button, [contenteditable="true"]')) return;
      if(ending){if(e.key==='Escape')void leave();return;}
      if (e.key === 'ArrowRight') focusedMode ? (settings.direction === 'ltr' ? guide.current?.next() : guide.current?.previous()) : go(pageRef.current + (settings.direction === 'ltr' ? 1 : -1));
      if (e.key === 'ArrowLeft') focusedMode ? (settings.direction === 'ltr' ? guide.current?.previous() : guide.current?.next()) : go(pageRef.current + (settings.direction === 'ltr' ? -1 : 1));
      if (e.key === 'Escape') void leave();
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [go, settings.direction, focusedMode, leave, preferences, pageGrid, panelEditing,ending]);
  const loaded = useCallback(
    (p: number) => {
      if (p === pageRef.current) {
        ready.current = true;
        setPageReady(true);
        void persist(p, true);
      }
    },
    [persist],
  );
  useLayoutEffect(() => {
    // Safari chrome must follow the reading canvas rather than retaining the
    // library's graphite colour. Restore it when leaving the reader.
    const meta = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    const reader = document.querySelector('.reader');
    if (!meta || !reader) return;
    const previous = meta.content;
    meta.content = getComputedStyle(reader).getPropertyValue('--reader-bg').trim();
    return () => { meta.content = previous; };
  }, [settings.readerTheme, ending]);
  if(ending)return <ReadingSummary comic={result} error={endingError || error} onBack={backToLast} onClose={()=>void(async()=>{await flushTime.current();await persistView();(onFinishClose ?? onClose)();})()} onChanged={setResult}/>;
  return (
    <div className={`reader theme-${settings.readerTheme} ${visible ? '' : 'ui-hidden'}`} aria-label="Читалка">
      <header className={`reader-header ${visible && !panelEditing ? '' : 'hidden-ui'}`} inert={panelEditing || !visible} aria-hidden={!visible || panelEditing}>
        <button
          className="icon-button"
          aria-label="Вернуться к комиксам"
          onClick={() => void leave()}
        >
          <ArrowLeft />
        </button>
        <div><span title={comic.title}>{comic.title}</span></div>
        <button
          className="icon-button"
          aria-label="Настройки чтения"
          onClick={() => { setToolsOpen(false); setPreferences(true); }}
        >
          <SettingsIcon />
        </button>
      </header>
      {error ? (
        <div className="reader-error">
          <p role="alert">{error}</p>
          <button className="primary" onClick={() => void leave()}>
            В библиотеку
          </button>
        </div>
      ) : !source ? (
        <div className="reader-loading">
          <span className="spinner" />
          <p>Открытие комикса…</p>
        </div>
      ) : mode === 'panels' && panelMap ? <PanelReader
        ref={guide}
        source={source}
        map={panelMap}
        page={page}
        settings={settings}
        enabled={!preferences&&!pageGrid}
        initial={panelInitial}
        fingerprint={comic.digital!.fingerprint}
        edits={panelEdits}
        onEditing={(editing) => { setToolsOpen(false); setPanelEditing(editing); }}
        onSaveEdit={async (page, panel, edit) => {
          const updated = await savePanelEdit(comic.id, comic.digital!.fingerprint, page, panel, edit);
          setPanelEdits(updated);
        }}
        onPage={go}
        onLoaded={loaded}
        onError={setError}
        onToggle={toggleUI}
        onView={rememberView}
        onState={onGuideState}
        onEnd={()=>void finish()}
      /> : mode === 'guided' ? <GuidedReader
        ref={guide}
        source={source}
        cropMargins={settings.cropMargins}
        page={page}
        direction={settings.direction}
        doubleTap={settings.doubleTap}
        enabled={!preferences&&!pageGrid}
        initial={panelInitial}
        onPage={go}
        onLoaded={loaded}
        onError={setError}
        onToggle={toggleUI}
        onView={rememberView}
        onState={onGuideState}
        onEnd={()=>void finish()}
      /> : mode === 'single' ? (
        <PageReader ref={pageReader} key={`${comic.id}:${page}`} source={source} page={page} settings={settings} enabled={!preferences&&!pageGrid} initial={singleInitial.current} onLoaded={loaded} onError={setError} onView={rememberView} onToggle={toggleUI} onTurn={delta=>go(pageRef.current+delta)}/>
      ) : (
        <VerticalReader
          onEnd={()=>void finish()}
          cropMargins={settings.cropMargins}
          source={source}
          page={page}
          onPage={(p) => {
            pageRef.current = p;
            setPage(p);
            void persist(p, false);
          }}
          onLoaded={loaded}
          onError={setError}
          onTap={toggleUI}
          doubleTap={settings.doubleTap}
        />
      )}
      {source && (
        <footer className={`reader-controls ${visible && !panelEditing ? '' : 'hidden-ui'}`} inert={panelEditing || !visible} aria-hidden={!visible || panelEditing}>
          <PageStrip source={source} current={page} active={visible && pageReady && !panelEditing && !preferences && !pageGrid} onSelect={go}/>
          <input
            aria-label="Перейти к странице"
            aria-valuetext={`Страница ${page + 1} из ${source.count}`}
            type="range"
            min="0"
            max={Math.max(0, source.count - 1)}
            disabled={source.count < 2}
            value={page}
            style={{ '--seek-progress': `${source.count > 1 ? page / (source.count - 1) * 100 : 100}%` } as React.CSSProperties}
            onChange={(e) => go(Number(e.target.value))}
          />
          <div className="reader-toolbar">
            <button className="reader-page-count" aria-label={`Все страницы: ${page + 1} из ${source.count}`} onClick={()=>{setToolsOpen(false);setPageGrid(true);}}>
              <span aria-live="polite">{settings.showPage ? <>{page + 1} <span>из {source.count}</span></> : 'Страницы'}</span><ChevronDown size={14}/>
            </button>
            <div className="reader-page-actions">
              <button className="icon-button" aria-label="Предыдущая страница" disabled={page === 0} onClick={() => go(page - 1)}><ChevronLeft/></button>
              <button className="icon-button" aria-label={page === source.count - 1 ? 'Завершить чтение' : 'Следующая страница'} onClick={() => go(page + 1)}><ChevronRight/></button>
              <button className={`icon-button reader-tools-toggle ${toolsOpen ? 'active' : ''}`} aria-label="Инструменты чтения" aria-expanded={toolsOpen} onClick={() => setToolsOpen(v => !v)}><Ellipsis/></button>
            </div>
          </div>
          {toolsOpen && <div className="reader-tools" role="group" aria-label="Масштаб и экран">
            {mode !== 'vertical' && (
              <>
                <button
                  className="icon-button"
                  aria-label="Уменьшить масштаб"
                  onClick={() => {
                    if (focusedMode) { guide.current?.zoom(-0.25); return; }
                    pageReader.current?.zoom(-0.5);
                  }}
                >
                  <Minus size={19} />
                </button>
                <button
                  className="icon-button"
                  aria-label="Увеличить масштаб"
                  onClick={() => focusedMode ? guide.current?.zoom(0.25) : pageReader.current?.zoom(0.5)}
                >
                  <Plus size={19} />
                </button>
                <button
                  className="icon-button"
                  aria-label={focusedMode ? 'Показать всю страницу' : 'Сбросить масштаб'}
                  onClick={() => {
                    if (focusedMode) {
                      clearTimeout(viewTimer.current);
                      viewRef.current = undefined;
                      onSettings({ ...settings, mode: 'single' });
                    }
                    setToolsOpen(false);
                    singleInitial.current=undefined;
                    pageReader.current?.reset();
                  }}
                >
                  <ZoomOut size={19} />
                </button>
              </>
            )}
            <button
              className="icon-button"
              aria-label="Полный экран"
              onClick={() => {
                setToolsOpen(false);
                const el = document.documentElement;
                if (document.fullscreenElement) void document.exitFullscreen?.();
                else if (el.requestFullscreen)
                  void el.requestFullscreen().catch(() => setVisible(false));
                else setVisible(false);
              }}
            >
              <Maximize size={18} />
            </button>
          </div>}
        </footer>
      )}
      {pageGrid&&source&&<PageGrid source={source} current={page} onClose={()=>setPageGrid(false)} onSelect={p=>{go(p);setPageGrid(false);setVisible(true);}}/>}
      {preferences && (
        <Modal title="Настройки чтения" className="gotham-sheet reading-sheet" onClose={() => setPreferences(false)}>
          <ReaderPreferences
            settings={settings}
            panelsAvailable={!!panelMap}
            onOverview={()=>{clearTimeout(viewTimer.current);viewRef.current=undefined;singleInitial.current=undefined;onSettings({...settings,mode:'single'});pageReader.current?.reset();setPreferences(false);}}
            onChange={(s) => {
              onSettings(s);
              if (s.mode !== settings.mode) { clearTimeout(viewTimer.current); viewRef.current = undefined; singleInitial.current=undefined; }
            }}
          />
          <details className="reading-extra"><summary>Подсказки и разметка</summary><p className="muted">
            {mode === 'panels' ? 'Каждый кадр показывается целиком один раз. Прокрутка вверх — следующий кадр. Вниз — предыдущий. Свайп в сторону также переключает кадр. Одно касание — меню, два — масштаб. При увеличении кадр целиком виден по высоте и двигается только влево-вправо. Удержание кадра — правка границ и масштаба.' : mode === 'guided' ? 'Фрагменты: касание края или короткий свайп — следующий участок. Центр — меню. Двигайте страницу пальцем; щипок и два касания меняют масштаб.' : mode==='single' ? 'Щипок — плавный масштаб выбранного места. Двигайте увеличенную страницу одним пальцем. Два касания — приблизить или вернуть целиком. Свайп перелистывает только при масштабе всей страницы.' : 'Прокрутка — переход между страницами. Два касания — масштаб. Касание — скрыть интерфейс.'}
          </p>
          {panelEdits?.frames.some(e => e.hidden) && <button className="secondary" disabled={!!recognizing} onClick={() => void (async () => {
            try {
              let updated: typeof comic.autoPanelEdits = panelEdits;
              for (const edit of panelEdits.frames.filter(e => e.hidden)) {
                const { hidden: _, ...restored } = edit;
                updated = await savePanelEdit(comic.id, comic.digital!.fingerprint, edit.page, edit.panel, restored);
              }
              setPanelEdits(updated); setPanelNotice('Удалённые кадры восстановлены.');
            } catch(e) { setPanelNotice(`Не удалось восстановить: ${errorMessage(e)}`); }
          })()}>Восстановить удалённые кадры</button>}
          {panelNotice && <p className="muted">{panelNotice}</p>}
          {!source?.prepared && !panelMap?.detector && <button className="secondary" disabled={!!recognizing} onClick={()=>void recognize()}>Распознать кадры автоматически</button>}
          {recognizing && <><p role="status" className="loading"><span className="spinner" />{recognizing}</p><button className="secondary" onClick={()=>{scan.current?.abort();setRecognizing('');}}>Отменить распознавание</button></>}
          {!panelMap && <p className="muted">Можно распознать кадры на устройстве или читать крупными фрагментами.</p>}</details>
        </Modal>
      )}
    </div>
  );
}
function VerticalReader({
  source,
  cropMargins,
  page,
  onPage,
  onLoaded,
  onError,
  onTap,
  doubleTap,
  onEnd,
}: {
  source: PageSource;
  page: number;
  onPage: (p: number) => void;
  onEnd:()=>void;
  onLoaded: (p: number) => void;
  onError: (s: string) => void;
  onTap: () => void;
  doubleTap: boolean;
  cropMargins?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [scroll, setScroll] = useState(0);
  const [width, setWidth] = useState(window.innerWidth);
  const [ratios, setRatios] = useState<Record<number, number>>({});
  const [zoom, setZoom] = useState(1);
  const scrollPage = useRef(page);
  const heights = Array.from(
    { length: source.count },
    (_, i) => Math.max(200, width * (ratios[i] || source.ratio)) + 14,
  );
  const offsets = [0];
  for (const h of heights) offsets.push(offsets[offsets.length - 1] + h);
  const offsetsRef = useRef(offsets);
  offsetsRef.current = offsets;
  const updateRatio = useCallback(
    (p: number, r: number) => setRatios((old) => (old[p] === r ? old : { ...old, [p]: r })),
    [],
  );
  const loadedPages = useRef(new Set<number>());
  const loaded = useCallback(
    (p: number) => {
      loadedPages.current.add(p);
      onLoaded(p);
    },
    [onLoaded],
  );
  useEffect(() => {
    const node = ref.current!;
    const observer = new ResizeObserver(() => setWidth(node.clientWidth));
    observer.observe(node);
    node.scrollTop = offsetsRef.current[page];
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (page !== scrollPage.current) {
      ref.current?.scrollTo({ top: offsetsRef.current[page] });
      setZoom(1);
      scrollPage.current = page;
    }
    if (loadedPages.current.has(page)) onLoaded(page);
  }, [page, onLoaded]);
  function onScroll() {
    const node = ref.current!;
    const top = node.scrollTop;
    if(top>=offsetsRef.current[source.count]-1 && scrollPage.current===source.count-1 && loadedPages.current.has(source.count-1)){onEnd();return;}
    setScroll(top);
    const center = top + Math.min(node.clientHeight * 0.35, 150);
    let p = 0;
    while (p < source.count - 1 && offsetsRef.current[p + 1] <= center) p++;
    if (p !== scrollPage.current) {
      scrollPage.current = p;
      onPage(p);
      if (loadedPages.current.has(p)) onLoaded(p);
      setZoom(1);
    }
  }
  const height = ref.current?.clientHeight || window.innerHeight;
  let first = 0;
  while (first < source.count - 1 && offsets[first + 1] < scroll) first++;
  let last = first;
  while (last < source.count - 1 && offsets[last] < scroll + height) last++;
  const from = Math.max(0, first - 1),
    to = Math.min(source.count - 1, last + 1, from + 4);
  const tap = useRef(0);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => () => clearTimeout(timer.current), []);
  const touch = useRef<{ distance: number; scale: number }>({ distance: 0, scale: 1 });
  return (
    <div ref={ref} className="vertical-reader" onScroll={onScroll}>
      <div style={{ height: offsets[source.count]+height, position: 'relative' }}>
        {Array.from({ length: to - from + 1 }, (_, i) => from + i).map((p) => (
          <div
            key={p}
            className="vertical-page"
            style={{ top: offsets[p], height: heights[p] - 14 }}
          >
            <div
              className="vertical-zoom"
              onTouchStart={(e) => {
                if (e.touches.length === 2) {
                  touch.current = {
                    distance: Math.hypot(
                      e.touches[0].clientX - e.touches[1].clientX,
                      e.touches[0].clientY - e.touches[1].clientY,
                    ),
                    scale: zoom,
                  };
                }
              }}
              onTouchMove={(e) => {
                if (e.touches.length === 2 && p === page) {
                  const d = Math.hypot(
                    e.touches[0].clientX - e.touches[1].clientX,
                    e.touches[0].clientY - e.touches[1].clientY,
                  );
                  setZoom(
                    Math.max(
                      1,
                      Math.min(4, (touch.current.scale * d) / Math.max(1, touch.current.distance)),
                    ),
                  );
                }
              }}
              onClick={() => {
                const now = Date.now();
                if (doubleTap && now - tap.current < 280) {
                  clearTimeout(timer.current);
                  setZoom((z) => (z === 1 ? 2.5 : 1));
                  tap.current = 0;
                } else {
                  tap.current = now;
                  timer.current = setTimeout(onTap, doubleTap ? 280 : 0);
                }
              }}
              style={{ touchAction: p === page && zoom > 1 ? 'pan-x pan-y' : 'pan-y' }}
            >
              <div style={{ width: p === page ? `${zoom * 100}%` : '100%', minHeight: '100%' }}>
                <RenderedPage cropMargins={cropMargins}
                  source={source}
                  index={p}
                  onLoaded={loaded}
                  onError={onError}
                  onRatio={updateRatio}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
