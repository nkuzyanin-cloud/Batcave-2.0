import { useEffect, useRef, useState } from 'react';
import { Modal } from '../components/ui';
import type { PageSource } from './source';
export function PageGrid({source,current,onSelect,onClose}:{source:PageSource;current:number;onSelect:(page:number)=>void;onClose:()=>void}) {
  const root=useRef<HTMLDivElement>(null);
  const [thumbs,setThumbs]=useState<Record<number,string>>({}),[errors,setErrors]=useState<Set<number>>(new Set());
  useEffect(()=>{
    const element=root.current!;const controller=new AbortController(),urls:string[]=[];
    const waiting=new Set<number>(),finished=new Set<number>();let running=false;
    const pump=async()=>{if(running)return;running=true;try{while(waiting.size&&!controller.signal.aborted){const i=waiting.values().next().value!;waiting.delete(i);finished.add(i);const canvas=document.createElement('canvas');try{await source.render(i,canvas,160,controller.signal);if(controller.signal.aborted)break;const blob=await new Promise<Blob|null>(resolve=>canvas.toBlob(resolve,'image/jpeg',.7));if(blob&&!controller.signal.aborted){const url=URL.createObjectURL(blob);urls.push(url);setThumbs(old=>({...old,[i]:url}));}}catch{if(!controller.signal.aborted)setErrors(old=>new Set([...old,i]));}finally{canvas.width=canvas.height=0;}}}finally{running=false;}};
    const observer=new IntersectionObserver(entries=>{for(const entry of entries){const i=Number((entry.target as HTMLElement).dataset.page);if(entry.isIntersecting&&!finished.has(i))waiting.add(i);else if(!entry.isIntersecting)waiting.delete(i);}void pump();},{root:element.closest('.modal'),rootMargin:'160px'});
    element.querySelectorAll('[data-page]').forEach(el=>observer.observe(el));
    element.querySelector<HTMLElement>(`[data-page="${current}"]`)?.scrollIntoView({block:'center'});
    return()=>{controller.abort();observer.disconnect();waiting.clear();urls.forEach(url=>URL.revokeObjectURL(url));};
  },[source,current]);
  return <Modal title="Страницы комикса" className="gotham-sheet page-grid-sheet" onClose={onClose}>
    <div className="page-grid" ref={root}>{Array.from({length:source.count},(_,i)=><button key={i} data-page={i} aria-label={`Страница ${i+1}`} aria-current={i===current?'page':undefined} onClick={()=>onSelect(i)}><span className="page-thumb">{thumbs[i]?<img src={thumbs[i]} alt=""/>:<span>{errors.has(i)?'Нет превью':'…'}</span>}</span><span>{i+1}</span></button>)}</div>
  </Modal>;
}
