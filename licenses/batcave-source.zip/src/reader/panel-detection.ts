import type { Rect } from './panels';

export interface Detection { bounds: Rect; score: number }
const area = (r: Rect) => r[2] * r[3];
function intersection(a: Rect, b: Rect) {
  return Math.max(0, Math.min(a[0]+a[2], b[0]+b[2])-Math.max(a[0],b[0])) *
    Math.max(0, Math.min(a[1]+a[3], b[1]+b[3])-Math.max(a[1],b[1]));
}
export function decodeDetections(data: Float32Array, count: number, width: number, height: number): Detection[] {
  const scale = Math.min(640/width,640/height);
  const padX = Math.floor((640-Math.round(width*scale))/2);
  const padY = Math.floor((640-Math.round(height*scale))/2);
  const candidates: Detection[] = [];
  for (let i=0;i<count;i++) {
    const score=data[4*count+i], cx=data[i], cy=data[count+i], w=data[2*count+i], h=data[3*count+i];
    if (![score,cx,cy,w,h].every(Number.isFinite) || score<.25 || w<=0 || h<=0) continue;
    const x=Math.max(0,Math.min(1,((cx-w/2)-padX)/scale/width));
    const y=Math.max(0,Math.min(1,((cy-h/2)-padY)/scale/height));
    const right=Math.max(0,Math.min(1,((cx+w/2)-padX)/scale/width));
    const bottom=Math.max(0,Math.min(1,((cy+h/2)-padY)/scale/height));
    if (right-x < .015 || bottom-y < .015) continue;
    candidates.push({bounds:[x,y,right-x,bottom-y],score});
  }
  candidates.sort((a,b)=>b.score-a.score);
  const kept: Detection[]=[];
  for(const c of candidates) {
    if(!kept.some(k=>{const n=intersection(k.bounds,c.bounds);return n/(area(k.bounds)+area(c.bounds)-n)>.45;})) kept.push(c);
    if(kept.length===100) break;
  }
  return kept;
}

export function cleanDetections(input: Detection[]): Rect[] {
  const boxes=input.filter(p=>!(p.score<.5 && p.bounds[1]>.94 && p.bounds[3]<.06 && p.bounds[2]>.75));
  const removed=new Set<Detection>();
  // A weak giant rectangle enclosing a grid is a duplicate parent detection.
  for(const parent of boxes) {
    const children=boxes.filter(p=>p!==parent && area(p.bounds)<area(parent.bounds)*.75 && intersection(parent.bounds,p.bounds)/area(p.bounds)>.96);
    if(children.length>=3 && parent.score+.15<Math.max(...children.map(c=>c.score)) &&
       children.reduce((s,c)=>s+area(c.bounds),0)>area(parent.bounds)*.65) removed.add(parent);
  }
  // Keep the complete scene and captions rather than repeat a portrait inset.
  for(const child of boxes) if(!removed.has(child) && boxes.some(parent=>parent!==child && !removed.has(parent) &&
    area(parent.bounds)>area(child.bounds)*1.8 && intersection(parent.bounds,child.bounds)/area(child.bounds)>.96)) removed.add(child);
  const result=boxes.filter(p=>!removed.has(p)).map(p=>p.bounds);
  if(result.length===1 && area(result[0])<.12) return [];
  return readingOrder(result);
}

// Recursive whitespace cuts preserve rows/columns and cannot rank the bottom
// row ahead of the top one. Irregular overlapping pages use a stable fallback.
export function readingOrder(boxes: Rect[]): Rect[] {
  if(boxes.length<2) return [...boxes];
  for(const axis of [1,0] as const) {
    const sorted=[...boxes].sort((a,b)=>a[axis]-b[axis]);
    let edge=sorted[0][axis]+sorted[0][axis+2];
    for(let i=1;i<sorted.length;i++) {
      if(sorted[i][axis]-edge>.004) return [...readingOrder(sorted.slice(0,i)),...readingOrder(sorted.slice(i))];
      edge=Math.max(edge,sorted[i][axis]+sorted[i][axis+2]);
    }
  }
  return [...boxes].sort((a,b)=>{
    const overlap=Math.max(0,Math.min(a[1]+a[3],b[1]+b[3])-Math.max(a[1],b[1]));
    return overlap/Math.min(a[3],b[3])>.5 ? a[0]-b[0] || a[1]-b[1] : a[1]-b[1] || a[0]-b[0];
  });
}
