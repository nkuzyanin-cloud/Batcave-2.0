import { useEffect, useRef, type PointerEvent, type KeyboardEvent, type CSSProperties } from 'react';
import { Crop, ZoomIn, Minus, Plus, RotateCcw, Check } from 'lucide-react';
import type { PanelRect, PanelViewEdit } from '../models';
import { MIN_FRAME_ZOOM, MAX_FRAME_ZOOM, moveBounds, resizeBounds, normalizeView } from './panel-edits';
import type { panelCamera } from './panels';

export type PanelEditMode = 'scale' | 'bounds';
interface Props {
  page: number; panel: number; bounds: PanelRect; view: PanelViewEdit; mode: PanelEditMode;
  size: { width: number; height: number }; camera: ReturnType<typeof panelCamera>;
  busy: boolean; error: string;
  onChange: (bounds: PanelRect, view: PanelViewEdit) => void;
  onMode: (mode: PanelEditMode) => void;
  onCancel: () => void; onReset: () => void; onSave: () => void;
  onMetrics: (top: number, bottom: number) => void;
}
interface Point { x: number; y: number }
interface Drag {
  action: string; start: Point; bounds: PanelRect; view: PanelViewEdit;
  distance: number; middle: Point; origin: Point;
}
const middle = (a: Point, b: Point) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y);

export function PanelEditor(props: Props) {
  const footer = useRef<HTMLDivElement>(null), header = useRef<HTMLElement>(null), latest = useRef(props);
  latest.current = props;
  const pointers = useRef(new Map<number, Point>()), drag = useRef<Drag | undefined>(undefined);
  useEffect(() => {
    const node = footer.current!;
    const measure = () => latest.current.onMetrics(Math.ceil(header.current!.getBoundingClientRect().height), Math.ceil(node.getBoundingClientRect().height));
    measure();const observer = new ResizeObserver(measure);observer.observe(node);observer.observe(header.current!);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    const old = document.activeElement as HTMLElement | null;
    const stage = header.current!.closest('.panel-stage')!;
    header.current!.querySelector('button')!.focus({ preventScroll: true });
    const key = (e: globalThis.KeyboardEvent) => {
      if (e.key === 'Escape' && !latest.current.busy) { e.preventDefault();latest.current.onCancel(); }
      if (e.key === 'Tab') {
        const nodes = [...stage.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),[tabindex="0"]')]
          .filter(el => el.getClientRects().length > 0);
        const index = nodes.indexOf(document.activeElement as HTMLElement);
        if (nodes.length && ((e.shiftKey && index <= 0) || (!e.shiftKey && (index < 0 || index === nodes.length - 1)))) {
          e.preventDefault();nodes[e.shiftKey ? nodes.length - 1 : 0].focus({ preventScroll: true });
        }
      }
    };
    document.addEventListener('keydown', key);
    return () => { document.removeEventListener('keydown', key);if (old?.isConnected) old.focus({ preventScroll: true }); };
  }, []);
  const { bounds, view, mode, camera, busy, error } = props;
  const begin = (e: PointerEvent<HTMLDivElement>) => {
    if (latest.current.busy) return;
    e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);
    const point = { x: e.clientX, y: e.clientY };
    pointers.current.set(e.pointerId, point);
    const p = latest.current, rect = e.currentTarget.getBoundingClientRect();
    const values = [...pointers.current.values()];
    const target = (e.target as HTMLElement).closest<HTMLElement>('[data-edge]');
    const action = p.mode === 'scale' ? 'pan' : target?.dataset.edge || '';
    drag.current = { action, start: point, bounds: p.bounds, view: p.view,
      distance: values.length === 2 ? distance(values[0], values[1]) : 0,
      middle: values.length === 2 ? middle(values[0], values[1]) : point,
      origin: { x: rect.left, y: rect.top } };
  };
  const move = (e: PointerEvent<HTMLDivElement>) => {
    const d = drag.current, p = latest.current;
    if (!d || !pointers.current.has(e.pointerId) || p.busy) return;
    e.preventDefault();pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const points = [...pointers.current.values()];
    if (p.mode === 'scale') {
      if (points.length === 2 && d.distance > 0) {
        const mid = middle(points[0], points[1]);
        const zoom = normalizeView({ ...d.view, zoom: d.view.zoom * distance(points[0], points[1]) / d.distance }).zoom;
        const ratio = zoom / d.view.zoom;
        const cx = d.origin.x + p.size.width / 2, cy = d.origin.y + p.size.height / 2;
        p.onChange(p.bounds, normalizeView({ ...d.view, zoom,
          x: (mid.x - cx - (d.middle.x - cx - d.view.x * p.size.width) * ratio) / p.size.width,
          y: (mid.y - cy - (d.middle.y - cy - d.view.y * p.size.height) * ratio) / p.size.height }));
      } else if (points.length === 1) {
        p.onChange(p.bounds, normalizeView({ ...d.view,
          x: d.view.x + (e.clientX - d.start.x) / p.size.width,
          y: d.view.y + (e.clientY - d.start.y) / p.size.height }));
      }
    } else if (points.length === 1 && d.action) {
      const dx = (e.clientX - d.start.x) / (p.camera.width * p.camera.scale);
      const dy = (e.clientY - d.start.y) / (p.camera.height * p.camera.scale);
      const bounds = d.action === 'move' ? moveBounds(d.bounds, dx, dy) : resizeBounds(d.bounds, d.action, dx, dy);
      p.onChange(bounds, p.view);
    }
  };
  const end = (e: PointerEvent<HTMLDivElement>) => {
    pointers.current.delete(e.pointerId);
    const p = latest.current, remaining = [...pointers.current.values()][0];
    if (remaining && drag.current) {
      drag.current = { ...drag.current, start: remaining, distance: 0, bounds: p.bounds, view: p.view };
    } else drag.current = undefined;
  };
  const keys = (e: KeyboardEvent<HTMLElement>, edge: string) => {
    if (busy || !['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) return;
    e.preventDefault();e.stopPropagation();
    const pixels = e.shiftKey ? 10 : 2;
    const dx = (e.key === 'ArrowLeft' ? -pixels : e.key === 'ArrowRight' ? pixels : 0) / (camera.width * camera.scale);
    const dy = (e.key === 'ArrowUp' ? -pixels : e.key === 'ArrowDown' ? pixels : 0) / (camera.height * camera.scale);
    props.onChange(edge === 'move' ? moveBounds(bounds, dx, dy) : resizeBounds(bounds, edge, dx, dy), view);
  };
  const changeZoom = (zoom: number) => props.onChange(bounds, normalizeView({ ...view, zoom }));
  const positions: [string, string, number, number][] = [
    ['nw', 'Верхний левый угол кадра', 0, 0], ['n', 'Верхняя граница кадра', .5, 0], ['ne', 'Верхний правый угол кадра', 1, 0],
    ['w', 'Левая граница кадра', 0, .5], ['e', 'Правая граница кадра', 1, .5],
    ['sw', 'Нижний левый угол кадра', 0, 1], ['s', 'Нижняя граница кадра', .5, 1], ['se', 'Нижний правый угол кадра', 1, 1],
  ];
  return <>
    <div className="panel-edit-gesture" data-testid="panel-edit-gesture" onPointerDown={begin} onPointerMove={move}
      onPointerUp={end} onPointerCancel={end} onLostPointerCapture={end} onContextMenu={e => e.preventDefault()}>
      {mode === 'bounds' && <div className="panel-edit-bounds" data-edge="move" role="button" tabIndex={0}
        aria-label="Сдвинуть границы кадра" onKeyDown={e => keys(e, 'move')}
        style={{ left: camera.x + bounds[0] * camera.width * camera.scale, top: camera.y + bounds[1] * camera.height * camera.scale,
          width: bounds[2] * camera.width * camera.scale, height: bounds[3] * camera.height * camera.scale }}>
        {positions.map(([edge, label, x, y]) => <button key={edge} type="button" className={`panel-edit-handle edge-${edge}`}
          aria-label={label} data-edge={edge} disabled={busy} onKeyDown={e => keys(e, edge)}
          style={{ '--handle-x': `${x * 100}%`, '--handle-y': `${y * 100}%` } as CSSProperties} />)}
      </div>}
    </div>
    <header ref={header} className="panel-edit-header">
      <button type="button" className="panel-edit-cancel" onClick={props.onCancel} disabled={busy}>Отмена</button>
      <h2>Кадр {props.panel + 1}<span> · стр. {props.page + 1}</span></h2>
      <span className="panel-edit-percent">{mode === 'scale' ? `${Math.round(view.zoom * 100)}%` : ''}</span>
    </header>
    <div ref={footer} className="panel-edit-footer">
      <div className="panel-edit-modes" role="group" aria-label="Правка кадра">
        <button type="button" aria-pressed={mode === 'bounds'} disabled={busy} onClick={() => props.onMode('bounds')}><Crop size={16} />Границы</button>
        <button type="button" aria-pressed={mode === 'scale'} disabled={busy} onClick={() => props.onMode('scale')}><ZoomIn size={16} />Масштаб</button>
      </div>
      {mode === 'scale' ? <div className="panel-edit-zoom">
        <button type="button" aria-label="Уменьшить масштаб кадра" disabled={busy || view.zoom <= MIN_FRAME_ZOOM} onClick={() => changeZoom(view.zoom - .1)}><Minus size={18} /></button>
        <input type="range" aria-label="Масштаб этого кадра" min={MIN_FRAME_ZOOM} max={MAX_FRAME_ZOOM} step="0.05" value={view.zoom}
          disabled={busy} onChange={e => changeZoom(Number(e.target.value))} />
        <button type="button" aria-label="Увеличить масштаб кадра" disabled={busy || view.zoom >= MAX_FRAME_ZOOM} onClick={() => changeZoom(view.zoom + .1)}><Plus size={18} /></button>
      </div> : null}
      <p className="panel-edit-hint">{mode === 'bounds' ? 'Потяни границы, чтобы включить весь текст.' : 'Щипок — масштаб · один палец — положение.'}</p>
      {error && <p className="panel-edit-error" role="alert">{error}</p>}
      <div className="panel-edit-actions">
        <button type="button" className="panel-edit-reset" disabled={busy} onClick={props.onReset}><RotateCcw size={15} />Сбросить</button>
        <button type="button" className="panel-edit-save" disabled={busy} onClick={props.onSave}><Check size={17} />{busy ? 'Сохранение…' : 'Сохранить'}</button>
      </div>
    </div>
  </>;
}
