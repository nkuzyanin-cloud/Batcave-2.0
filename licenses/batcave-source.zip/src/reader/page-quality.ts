import type { Rect } from './panels';

export interface Pixels { width: number; height: number; data: Uint8ClampedArray }
export interface PageQuality { crop: Rect; blank: number[]; duplicate: number[]; emptyViews: Record<number, number[]> }
const full = (): Rect => [0, 0, 1, 1];

// Sample a bounded thumbnail once, never during an animation. The original
// canvas and source bytes stay intact; all coordinates remain page-relative.
export function samplePage(canvas: HTMLCanvasElement): Pixels {
  const small = document.createElement('canvas');
  const scale = Math.min(1, 900 / Math.max(canvas.width, canvas.height));
  small.width = Math.max(1, Math.round(canvas.width * scale));
  small.height = Math.max(1, Math.round(canvas.height * scale));
  const ctx = small.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(canvas, 0, 0, small.width, small.height);
  const pixels = ctx.getImageData(0, 0, small.width, small.height);
  small.width = small.height = 0;
  return pixels;
}

export function outerMargins(p: Pixels): Rect {
  const { width: w, height: h, data } = p;
  const white = (x: number, y: number) => {
    const i = (y * w + x) * 4;
    return data[i] >= 238 && data[i + 1] >= 238 && data[i + 2] >= 238;
  };
  const row = (y: number) => { for (let x = 0; x < w; x++) if (!white(x, y)) return false; return true; };
  const col = (x: number) => { for (let y = 0; y < h; y++) if (!white(x, y)) return false; return true; };
  let top = 0, bottom = h - 1, left = 0, right = w - 1;
  while (top < h && row(top)) top++;
  if (top === h) return full(); // A blank page must not become zero-sized.
  while (bottom > top && row(bottom)) bottom--;
  while (left < right && col(left)) left++;
  while (right > left && col(right)) right--;
  // Leave a small safety border, retain any ink/caption outside frame borders.
  top = Math.max(0, top - 2); bottom = Math.min(h - 1, bottom + 2);
  left = Math.max(0, left - 2); right = Math.min(w - 1, right + 2);
  if (right - left < w * .35 || bottom - top < h * .35) return full();
  return [left / w, top / h, (right - left + 1) / w, (bottom - top + 1) / h];
}

// Ignore only a thin boundary: a blank rectangle may have its own printed
// border. Even a small patch of text or art inside keeps the frame.
export function emptyRegion(p: Pixels, r: Rect, dark = false, inset = .08): boolean {
  const x0 = Math.max(0, Math.ceil((r[0] + r[2] * inset) * p.width));
  const y0 = Math.max(0, Math.ceil((r[1] + r[3] * inset) * p.height));
  const x1 = Math.min(p.width, Math.floor((r[0] + r[2] * (1 - inset)) * p.width));
  const y1 = Math.min(p.height, Math.floor((r[1] + r[3] * (1 - inset)) * p.height));
  if ((x1 - x0) * (y1 - y0) < 80) return false;
  let white = 0, black = 0, count = 0;
  const marks: number[] = [];
  for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
    const i = (y * p.width + x) * 4, lo = Math.min(p.data[i], p.data[i + 1], p.data[i + 2]), hi = Math.max(p.data[i], p.data[i + 1], p.data[i + 2]);
    white += lo >= 232 ? 1 : 0; black += hi <= 27 ? 1 : 0; count++;
    if (lo < 232 && marks.length < 13) marks.push(y*p.width+x);
  }
  if (count - white <= 2 || (dark && count - black <= 2)) return true;
  // Isolated scanner dust is not a panel. A connected 4-pixel stroke or more
  // than 12 marked pixels keeps even tiny lettering and white drawings.
  if (count - white > 12) return false;
  const todo = new Set(marks);
  while (todo.size) {
    const seed = todo.values().next().value!; todo.delete(seed);
    const group = [seed];
    for (let i=0; i<group.length; i++) {
      const n=group[i], x=n%p.width;
      for (const next of [n-p.width,n+p.width,...(x>0?[n-1]:[]),...(x<p.width-1?[n+1]:[])])
        if (todo.delete(next)) group.push(next);
      if (group.length >= 4) return false;
    }
  }
  return true;
}

export function sameRegion(a: Rect, b: Rect): boolean {
  const overlap = Math.max(0, Math.min(a[0] + a[2], b[0] + b[2]) - Math.max(a[0], b[0])) * Math.max(0, Math.min(a[1] + a[3], b[1] + b[3]) - Math.max(a[1], b[1]));
  return overlap / Math.max(a[2] * a[3], b[2] * b[3]) > .96;
}

export function emptyCloseView(p: Pixels, r: Rect): boolean {
  if (emptyRegion(p, r, true, .12)) return true;
  // A close view of a solid black cloak can contain thin blue strips at its
  // sides, so it is not literally monochrome. Preserve any white lettering
  // and any appreciable central detail; never drop the full-frame view.
  const counts = (inset: number) => {
    let black = 0, white = 0, n = 0;
    for (let y = Math.ceil((r[1]+r[3]*inset)*p.height); y < Math.min(p.height,(r[1]+r[3]*(1-inset))*p.height); y++)
      for (let x = Math.ceil((r[0]+r[2]*inset)*p.width); x < Math.min(p.width,(r[0]+r[2]*(1-inset))*p.width); x++) {
        const i=(y*p.width+x)*4, lo=Math.min(p.data[i],p.data[i+1],p.data[i+2]), hi=Math.max(p.data[i],p.data[i+1],p.data[i+2]);
        black += hi < 35 ? 1 : 0; white += lo > 205 ? 1 : 0; n++;
      }
    return {black:black/Math.max(1,n),white:white/Math.max(1,n),n};
  };
  const whole=counts(.04), middle=counts(.22);
  return whole.n > 150 && whole.black > .8 && middle.black > .97 && whole.white < .0005;
}

export function inspectPage(p: Pixels, frames: Rect[]): PageQuality {
  const blank = frames.flatMap((r, i) => emptyRegion(p, r) || emptyMarginStripe(p, r) ? [i] : []);
  const duplicate = frames.flatMap((r, i) => frames.slice(0, i).some((q, j) => !blank.includes(j) && sameRegion(r, q)) ? [i] : []);
  return { crop: outerMargins(p), blank, duplicate, emptyViews: {} };
}

export function emptyMarginStripe(p: Pixels, r: Rect): boolean {
  // A very thin detector box at the page edge may cover both white paper and
  // a straight black gutter. Restrict this rule to edge strips, never scenes.
  if (!((r[2] < .08 && (r[0] < .025 || r[0]+r[2] > .975)) ||
    (r[3] < .08 && (r[1] < .025 || r[1]+r[3] > .975)))) return false;
  const x0=Math.ceil((r[0]+r[2]*.12)*p.width), x1=Math.floor((r[0]+r[2]*.88)*p.width);
  const y0=Math.ceil((r[1]+r[3]*.12)*p.height), y1=Math.floor((r[1]+r[3]*.88)*p.height);
  if (x1-x0 < 8 || y1-y0 < 8) return false;
  const axis = (vertical: boolean) => {
    let complex=0, transitions=0, previous=-1;
    const rows=vertical?x1-x0:y1-y0, columns=vertical?y1-y0:x1-x0;
    for(let a=0;a<rows;a++) {
      let white=0,black=0;
      for(let b=0;b<columns;b++) {
        const x=vertical?x0+a:x0+b, y=vertical?y0+b:y0+a, i=(y*p.width+x)*4;
        const lo=Math.min(p.data[i],p.data[i+1],p.data[i+2]),hi=Math.max(p.data[i],p.data[i+1],p.data[i+2]);
        white+=lo>=232?1:0;black+=hi<=65?1:0;
      }
      if(Math.max(white,black)/columns < .98) { complex++;continue; }
      const color=white>black?1:0;
      if(previous!==-1 && previous!==color) transitions++;
      previous=color;
    }
    return complex<=Math.max(1,Math.floor(rows*.02)) && transitions<=3;
  };
  return axis(false) || axis(true);
}

export function cropCanvas(canvas: HTMLCanvasElement) {
  const r = outerMargins(samplePage(canvas));
  if (r.every((v, i) => Math.abs(v - full()[i]) < .001)) return;
  const copy = document.createElement('canvas');
  copy.width = Math.ceil(r[2] * canvas.width); copy.height = Math.ceil(r[3] * canvas.height);
  copy.getContext('2d')!.drawImage(canvas, Math.floor(r[0] * canvas.width), Math.floor(r[1] * canvas.height), copy.width, copy.height, 0, 0, copy.width, copy.height);
  canvas.width = copy.width; canvas.height = copy.height;
  canvas.getContext('2d')!.drawImage(copy, 0, 0);
  copy.width = copy.height = 0;
}
