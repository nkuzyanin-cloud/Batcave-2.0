import { forwardRef, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState } from 'react';
import type { ReaderView } from '../models';
import type { PageSource } from './source';
import { RenderedPage } from './RenderedPage';
import { fragmentLayout, nearestFragment, type Position } from './fragments';

export interface GuideState { step: number; total: number; zoom: number; label?: string }
export interface GuideHandle { next: () => void; previous: () => void; zoom: (delta: number) => void }
export const GuidedReader = forwardRef<GuideHandle, {
  source: PageSource;
  cropMargins?: boolean;
  page: number;
  direction: 'ltr' | 'rtl';
  doubleTap: boolean;
  enabled: boolean;
  initial?: ReaderView;
  onPage: (page: number) => void;
  onLoaded: (page: number) => void;
  onError: (error: string) => void;
  onToggle: () => void;
  onView: (view: ReaderView) => void;
  onState: (state: GuideState) => void;
}>(function GuidedReader({ source, cropMargins, page, direction, doubleTap, enabled, initial, onPage, onLoaded, onError, onToggle, onView, onState }, ref) {
  const stage = useRef<HTMLDivElement>(null);
  const valid = initial?.mode === 'guided' && initial.page === page;
  const [zoom, setZoom] = useState(valid ? Math.max(1.25, Math.min(3.5, initial.zoom)) : 1.85);
  const [size, setSize] = useState({ width: window.innerWidth, height: Math.max(200, window.innerHeight - 150) });
  const [ratio, setRatio] = useState(source.ratio);
  const layout = useMemo(() => fragmentLayout(size.width, size.height, ratio, zoom, direction === 'rtl'), [size, ratio, zoom, direction]);
  const [pan, setPan] = useState<Position>(() => valid ? { x: initial.x * layout.maxX, y: initial.y * layout.maxY } : layout.stops[0]);
  const [moving, setMoving] = useState(false);
  const [loadedPage, setLoadedPage] = useState<number>();
  const loaded = loadedPage === page;
  const restore = useRef(valid ? { x: initial.x, y: initial.y } : undefined);
  const reverse = useRef(false);
  const lastPage = useRef(page);
  const anchor = useRef({ x: valid ? initial.x : (direction === 'rtl' ? -1 : 1), y: valid ? initial.y : 1 });
  const current = useRef({ zoom, pan, layout, page });
  current.current = { zoom, pan, layout, page };
  const step = nearestFragment(layout.stops, pan);
  const clamp = (p: Position, limits = current.current.layout) => ({
    x: Math.max(-limits.maxX, Math.min(limits.maxX, p.x)),
    y: Math.max(-limits.maxY, Math.min(limits.maxY, p.y)),
  });
  useEffect(() => {
    const node = stage.current!;
    const observer = new ResizeObserver(() => setSize({ width: node.clientWidth, height: node.clientHeight }));
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    setPan({ x: anchor.current.x * layout.maxX, y: anchor.current.y * layout.maxY });
  }, [layout]);
  useEffect(() => {
    if (lastPage.current !== page) {
      lastPage.current = page;
      restore.current = undefined;
      anchor.current = { x: direction === 'rtl' ? -1 : 1, y: reverse.current ? -1 : 1 };
      if (reverse.current) anchor.current.x *= -1;
      setPan(reverse.current ? layout.stops[layout.stops.length - 1] : layout.stops[0]);
      reverse.current = false;
    }
  }, [page, direction, layout]);
  const pageReady = useCallback((p: number, r: number) => {
    setRatio(r);
    setLoadedPage(p);
    if (restore.current) anchor.current = restore.current;
  }, []);
  useEffect(() => {
    anchor.current = { x: layout.maxX ? Math.max(-1, Math.min(1, pan.x / layout.maxX)) : 0, y: layout.maxY ? Math.max(-1, Math.min(1, pan.y / layout.maxY)) : 0 };
    if (loaded) onView({ page, mode: 'guided', zoom, ...anchor.current });
  }, [pan, zoom, page, loaded, layout, onView]);
  useEffect(() => onState({ step, total: layout.stops.length, zoom }), [step, layout.stops.length, zoom, onState]);
  function navigate(delta: number) {
    if (!loaded) return;
    const next = step + delta;
    if (next < 0 || next >= layout.stops.length) {
      const target = page + delta;
      if (target < 0 || target >= source.count) return;
      reverse.current = delta < 0;
      restore.current = undefined;
      onPage(target);
    } else {
      restore.current = undefined;
      setPan(layout.stops[next]);
    }
  }
  function changeZoom(value: number) {
    restore.current = undefined;
    setZoom(Math.max(1.25, Math.min(3.5, value)));
  }
  useImperativeHandle(ref, () => ({ next: () => navigate(1), previous: () => navigate(-1), zoom: (delta) => changeZoom(zoom + delta) }));
  const points = useRef(new Map<number, Position>());
  const gesture = useRef({ x: 0, y: 0, pan: { x: 0, y: 0 }, scale: zoom, distance: 0, moved: false, pinch: false, time: 0 });
  const tap = useRef(0);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => () => clearTimeout(timer.current), []);
  useEffect(() => { clearTimeout(timer.current); tap.current = 0; }, [page, zoom, direction, enabled]);
  function distance() {
    const p = Array.from(points.current.values());
    return p.length === 2 ? Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y) : 0;
  }
  return <div ref={stage} className="reader-stage guided-stage" data-testid="guided-stage"
    onPointerDown={(e) => {
      if (!enabled || !loaded) return;
      e.currentTarget.setPointerCapture(e.pointerId);
      points.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (points.current.size === 1) gesture.current = { x: e.clientX, y: e.clientY, pan, scale: zoom, distance: 0, moved: false, pinch: false, time: Date.now() };
      if (points.current.size === 2) { gesture.current.distance = distance(); gesture.current.scale = zoom; gesture.current.pinch = true; clearTimeout(timer.current); }
      setMoving(true);
    }}
    onPointerMove={(e) => {
      if (!points.current.has(e.pointerId)) return;
      points.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
      const g = gesture.current;
      if (points.current.size === 2) { changeZoom(g.scale * distance() / Math.max(1, g.distance)); g.moved = true; }
      else if (!g.pinch) {
        const dx = e.clientX - g.x, dy = e.clientY - g.y;
        if (Math.hypot(dx, dy) > 8) { g.moved = true; restore.current = undefined; setPan(clamp({ x: g.pan.x + dx, y: g.pan.y + dy })); }
      }
    }}
    onPointerUp={(e) => {
      points.current.delete(e.pointerId);
      if (points.current.size) return;
      setMoving(false);
      const g = gesture.current;
      if (g.pinch) return;
      const dx = e.clientX - g.x, dy = e.clientY - g.y;
      if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.3 && Date.now() - g.time < 400) {
        // Determine the starting stop; a swipe must advance exactly once.
        const start = nearestFragment(layout.stops, g.pan);
        const delta = (dx < 0 ? 1 : -1) * (direction === 'rtl' ? -1 : 1);
        const target = start + delta;
        if (target >= 0 && target < layout.stops.length) setPan(layout.stops[target]);
        else {
          setPan(g.pan);
          const nextPage = Math.max(0, Math.min(source.count - 1, page + delta));
          if (nextPage !== page) { reverse.current = delta < 0; onPage(nextPage); }
        }
        return;
      }
      if (g.moved || Date.now() - g.time > 500) return;
      const now = Date.now();
      if (doubleTap && now - tap.current < 280) {
        clearTimeout(timer.current); tap.current = 0; changeZoom(zoom < 2.4 ? 2.5 : 1.85);
      } else {
        tap.current = now;
        const box = stage.current!.getBoundingClientRect();
        const x = (e.clientX - box.left) / box.width;
        timer.current = setTimeout(() => {
          if (x < 0.28) navigate(direction === 'rtl' ? 1 : -1);
          else if (x > 0.72) navigate(direction === 'rtl' ? -1 : 1);
          else onToggle();
        }, doubleTap ? 280 : 0);
      }
    }}
    onPointerCancel={() => { points.current.clear(); setMoving(false); clearTimeout(timer.current); }}
    onWheel={(e) => {
      if (e.ctrlKey) changeZoom(zoom - e.deltaY * 0.005);
      else { restore.current = undefined; setPan(clamp({ x: pan.x - e.deltaX, y: pan.y - e.deltaY })); }
    }}>
    <div className={`guided-transform ${moving ? 'moving' : ''}`} data-testid="guided-transform" style={{ transform: `translate(${pan.x}px,${pan.y}px) scale(${zoom})` }}>
      <RenderedPage cropMargins={cropMargins} source={source} index={page} onLoaded={onLoaded} onError={onError} onRatio={pageReady} sharp />
    </div>
  </div>;
});
