export type ShapeRect = [number, number, number, number];
export type Point = [number, number];
export type FrameShape = { type: 'rect' } | { type: 'polygon'; points: Point[] } | { type: 'ellipse'; box?: ShapeRect };
export const rectangleShape = (): FrameShape => ({ type: 'rect' });
export const quadShape = (): FrameShape => ({ type: 'polygon', points: [[0,0],[1,0],[1,1],[0,1]] });
const finite = (n: unknown): n is number => typeof n === 'number' && Number.isFinite(n);
export function validShape(value: unknown): value is FrameShape {
  const s = value as FrameShape;
  if (!s || typeof s !== 'object') return false;
  if (s.type === 'rect') return true;
  if (s.type === 'ellipse') {
    if (s.box === undefined) return true;
    const b = s.box;
    return Array.isArray(b) && b.length === 4 && b.every(finite) && b.every(n => Math.abs(n) <= 20000) && b[2] > 0 && b[3] > 0 && ellipseIntersects(b);
  }
  if (s.type !== 'polygon' || !Array.isArray(s.points) || s.points.length < 3 || s.points.length > 32 || !s.points.every(p => Array.isArray(p) && p.length === 2 && p.every(finite) && p.every(n => n >= -1e-7 && n <= 1+1e-7))) return false;
  let sign = 0, area = 0, turn = 0;
  for (let i = 0; i < s.points.length; i++) {
    const a=s.points[i], b=s.points[(i+1)%s.points.length], c=s.points[(i+2)%s.points.length];
    const cross=(b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0]);
    if (Math.abs(cross)>1e-9) { const next=Math.sign(cross); if(sign && next!==sign)return false; sign=next; }
    turn+=Math.atan2(cross,(b[0]-a[0])*(c[0]-b[0])+(b[1]-a[1])*(c[1]-b[1]));
    area+=a[0]*b[1]-a[1]*b[0];
    if (Math.hypot(b[0]-a[0],b[1]-a[1])<1e-8) return false;
  }
  return Math.abs(area)>.00001 && sign!==0 && Math.abs(Math.abs(turn)-Math.PI*2)<.00001;
}
function ellipseIntersects([x,y,w,h]:ShapeRect) {
  const cx=x+w/2,cy=y+h/2,px=Math.max(0,Math.min(1,cx)),py=Math.max(0,Math.min(1,cy));
  return ((px-cx)/(w/2))**2+((py-cy)/(h/2))**2<1;
}
export function validShapes(shapes: unknown, count: number) {
  return shapes===undefined || Array.isArray(shapes) && shapes.length===count && shapes.every(validShape);
}
export function shapePath(s:FrameShape={type:'rect'},r:ShapeRect=[0,0,1,1]) {
  const [x,y,w,h]=r;
  if(s.type==='polygon')return s.points.map((p,i)=>`${i?'L':'M'}${x+p[0]*w} ${y+p[1]*h}`).join(' ')+' Z';
  if(s.type==='ellipse') {const b=s.box??[0,0,1,1],cx=x+(b[0]+b[2]/2)*w,cy=y+(b[1]+b[3]/2)*h,rx=b[2]*w/2,ry=b[3]*h/2;return `M${cx-rx} ${cy} A${rx} ${ry} 0 1 0 ${cx+rx} ${cy} A${rx} ${ry} 0 1 0 ${cx-rx} ${cy} Z`;}
  return `M${x} ${y} H${x+w} V${y+h} H${x} Z`;
}
export function shapeClip(s:FrameShape={type:'rect'}) {
  if(s.type==='polygon')return `polygon(${s.points.map(p=>`${p[0]*100}% ${p[1]*100}%`).join(',')})`;
  if(s.type==='ellipse'){const b=s.box??[0,0,1,1];return `ellipse(${b[2]*50}% ${b[3]*50}% at ${(b[0]+b[2]/2)*100}% ${(b[1]+b[3]/2)*100}%)`;}
  return 'inset(0)';
}
// Retain the original contour when a page crop intersects its bounding box.
export function reframeShape(s:FrameShape,from:ShapeRect,to:ShapeRect):FrameShape|undefined {
  if(s.type==='rect')return s;
  const point=(p:Point):Point=>[(from[0]+p[0]*from[2]-to[0])/to[2],(from[1]+p[1]*from[3]-to[1])/to[3]];
  if(s.type==='ellipse'){const b=s.box??[0,0,1,1],p=point([b[0],b[1]]),box:ShapeRect=[...p,b[2]*from[2]/to[2],b[3]*from[3]/to[3]];return ellipseIntersects(box)?{type:'ellipse',box}:undefined;}
  let points=s.points.map(point);
  for(const [axis,edge,less] of [[0,0,false],[0,1,true],[1,0,false],[1,1,true]] as const){
    const output:Point[]=[];
    for(let i=0;i<points.length;i++){const a=points[i],b=points[(i+1)%points.length],inside=(p:Point)=>less?p[axis]<=edge:p[axis]>=edge;const ai=inside(a),bi=inside(b);if(ai)output.push(a);if(ai!==bi){const t=(edge-a[axis])/(b[axis]-a[axis]);output.push([a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])]);}}
    points=output;
  }
  points=points.filter((p,i)=>Math.hypot(p[0]-points[(i+points.length-1)%points.length][0],p[1]-points[(i+points.length-1)%points.length][1])>1e-8).map(p=>[Math.max(0,Math.min(1,p[0])),Math.max(0,Math.min(1,p[1]))]);
  const result:FrameShape={type:'polygon',points};return validShape(result)?result:undefined;
}
export function moveVertex(s:FrameShape,r:ShapeRect,index:number,p:Point):{rect:ShapeRect;shape:FrameShape}|undefined {
  if(s.type!=='polygon'||!s.points[index])return;
  const points=s.points.map(q=>[r[0]+q[0]*r[2],r[1]+q[1]*r[3]] as Point);points[index]=p;
  const x=Math.min(...points.map(q=>q[0])),y=Math.min(...points.map(q=>q[1])),w=Math.max(...points.map(q=>q[0]))-x,h=Math.max(...points.map(q=>q[1]))-y;
  if(w<.004||h<.004)return;
  const shape:FrameShape={type:'polygon',points:points.map(q=>[(q[0]-x)/w,(q[1]-y)/h])};
  return validShape(shape)?{rect:[x,y,w,h],shape}:undefined;
}
