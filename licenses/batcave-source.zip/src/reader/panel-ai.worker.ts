import * as ort from 'onnxruntime-web/wasm';
import { cleanDetections, decodeDetections } from './panel-detection';
let session: ort.InferenceSession | undefined;
self.onmessage = async (event: MessageEvent) => {
  try {
    const { type, base, pixels, width, height } = event.data;
    if(type==='init') {
      ort.env.wasm.numThreads=1;
      ort.env.wasm.proxy=false;
      ort.env.wasm.wasmPaths=base;
      session=await ort.InferenceSession.create(new URL('best.onnx',base).href,{executionProviders:['wasm']});
      self.postMessage({ready:true});
    } else {
      if(!session) throw Error('Модель не загружена.');
      const outputs=await session.run({[session.inputNames[0]]:new ort.Tensor('float32',pixels,[1,3,640,640])});
      const output=outputs[session.outputNames[0]];
      if(output.dims.length!==3 || output.dims[1]!==5) throw Error('Неподдерживаемая модель кадров.');
      const frames=cleanDetections(decodeDetections(output.data as Float32Array,output.dims[2],width,height));
      Object.values(outputs).forEach(t=>t.dispose());
      self.postMessage({frames});
    }
  } catch(e) { self.postMessage({error:e instanceof Error?e.message:String(e)}); }
};
