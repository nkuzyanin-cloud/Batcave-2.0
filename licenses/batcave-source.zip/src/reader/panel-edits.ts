import type { PanelEdits, PanelFrameEdit, PanelRect, PanelViewEdit } from '../models';
import type { PanelStep } from './panels';

export const MIN_FRAME_SIZE = .015;
export const MIN_FRAME_ZOOM = .4;
export const MAX_FRAME_ZOOM = 4;
const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));

export function validFrameEdit(edit: PanelFrameEdit) {
  const r = edit.bounds;
  return (edit.hidden === undefined || typeof edit.hidden === 'boolean') && Number.isInteger(edit.page) && edit.page >= 0 && edit.page < 5000 &&
    Number.isInteger(edit.panel) && edit.panel >= 0 && edit.panel < 100 &&
    Array.isArray(r) && r.length === 4 && r.every(Number.isFinite) &&
    r[0] >= 0 && r[1] >= 0 && r[2] >= MIN_FRAME_SIZE && r[3] >= MIN_FRAME_SIZE &&
    r[0] + r[2] <= 1.000001 && r[1] + r[3] <= 1.000001 &&
    Array.isArray(edit.views) && edit.views.length <= 100 &&
    new Set(edit.views.map(v => v.part)).size === edit.views.length &&
    edit.views.every(v => Number.isInteger(v.part) && v.part >= 0 && v.part < 100 &&
      Number.isFinite(v.zoom) && v.zoom >= MIN_FRAME_ZOOM && v.zoom <= MAX_FRAME_ZOOM &&
      Number.isFinite(v.x) && Number.isFinite(v.y) && Math.abs(v.x) <= .9 && Math.abs(v.y) <= .9);
}

export function frameEdit(edits: PanelEdits | undefined, fingerprint: string, page: number, panel: number) {
  if (edits?.fingerprint !== fingerprint) return undefined;
  const edit = edits.frames.find(e => e.page === page && e.panel === panel);
  return edit && validFrameEdit(edit) ? edit : undefined;
}

export function editedPanelStep(step: PanelStep, edit: PanelFrameEdit | undefined, rtl: boolean): PanelStep {
  if (!edit || step.overview) return step;
  const [x, y, w, h] = edit.bounds;
  const [ox, oy, ow, oh] = step.bounds;
  const [fx, fy, fw, fh] = step.focus;
  // Preserve each camera window's relative position when the user repairs a
  // boundary. This supports tall passes as well as legacy horizontal halves.
  void rtl;
  return { ...step, bounds: edit.bounds, focus: [x + (fx - ox) / ow * w, y + (fy - oy) / oh * h, fw / ow * w, fh / oh * h] };
}

export function fitView(part: number): PanelViewEdit { return { part, zoom: 1, x: 0, y: 0 }; }

export function normalizeView(view: PanelViewEdit): PanelViewEdit {
  return { part: view.part, zoom: clamp(view.zoom, MIN_FRAME_ZOOM, MAX_FRAME_ZOOM),
    x: clamp(view.x, -.9, .9), y: clamp(view.y, -.9, .9) };
}

export function moveBounds(bounds: PanelRect, dx: number, dy: number): PanelRect {
  const [x, y, w, h] = bounds;
  return [clamp(x + dx, 0, 1 - w), clamp(y + dy, 0, 1 - h), w, h];
}

export function resizeBounds(bounds: PanelRect, edge: string, dx: number, dy: number): PanelRect {
  let [x, y, w, h] = bounds;
  const right = x + w, bottom = y + h;
  if (edge.includes('w')) { x = clamp(x + dx, 0, right - MIN_FRAME_SIZE);w = right - x; }
  if (edge.includes('e')) w = clamp(w + dx, MIN_FRAME_SIZE, 1 - x);
  if (edge.includes('n')) { y = clamp(y + dy, 0, bottom - MIN_FRAME_SIZE);h = bottom - y; }
  if (edge.includes('s')) h = clamp(h + dy, MIN_FRAME_SIZE, 1 - y);
  return [x, y, w, h];
}

export function replaceFrameEdit(edits: PanelEdits | undefined, fingerprint: string,
  page: number, panel: number, edit: PanelFrameEdit | null): PanelEdits | undefined {
  const frames = (edits?.fingerprint === fingerprint ? edits.frames : [])
    .filter(e => e.page !== page || e.panel !== panel);
  if (edit) frames.push(edit);
  frames.sort((a, b) => a.page - b.page || a.panel - b.panel);
  return frames.length ? { fingerprint, frames } : undefined;
}
