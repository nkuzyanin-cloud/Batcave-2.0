import type { Format } from '../models';
import { inspectPage, samplePage } from './page-quality';
import { openSource } from './source';
import { parsePanelMap, type PanelMap, type Rect } from './panels';
export const aborted = () => new DOMException('Отменено','AbortError');
function check(signal: AbortSignal) { if(signal.aborted) throw aborted(); }

export async function recognizePanels(blob: Blob, format: Format, hash: string,
  onProgress: (message: string)=>void, signal: AbortSignal): Promise<PanelMap> {
  check(signal);
  const worker=new Worker(new URL('./panel-ai.worker.ts',import.meta.url),{type:'module'});
  let source: Awaited<ReturnType<typeof openSource>> | undefined;
  const canvas=document.createElement('canvas'), small=document.createElement('canvas');
  small.width=small.height=640;
  function request(message: object, transfer: Transferable[]=[]): Promise<{frames: Rect[]}> {
    check(signal);
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>finish(Error('Распознавание слишком долго отвечает. Можно сохранить комикс без кадров.')),90000);
      const abort=()=>finish(aborted());
      const failed=()=>finish(Error('Не удалось запустить распознавание на этом устройстве.'));
      const received=(e: MessageEvent)=>e.data.error ? finish(Error(e.data.error)) : finish(undefined,e.data);
      function finish(error?: Error, data?: {frames:Rect[]}) {
        clearTimeout(timer);signal.removeEventListener('abort',abort);
        worker.removeEventListener('message',received);worker.removeEventListener('error',failed);
        error?reject(error):resolve(data!);
      }
      signal.addEventListener('abort',abort,{once:true});
      worker.addEventListener('message',received);worker.addEventListener('error',failed);
      worker.postMessage(message,transfer);
    });
  }
  try {
    onProgress('Загрузка распознавания кадров…');
    const base=new URL('panel-ai/',new URL(import.meta.env.BASE_URL,document.baseURI)).href;
    await request({type:'init',base});
    source=await openSource(blob,format);
    const map: PanelMap={version:1,sha256:hash,pageCount:source.count,detector:'inkwell-v1',pages:[]};
    for(let index=0;index<source.count;index++) {
      check(signal);onProgress(`Распознавание кадров: ${index+1} / ${source.count}`);
      // Bound the image to a 640px longest edge: no full-resolution scans in RAM.
      await source.render(index,canvas,Math.min(640,640/source.ratio),signal);
      check(signal);
      const width=canvas.width,height=canvas.height;
      const factor=Math.min(640/width,640/height), w=Math.round(width*factor),h=Math.round(height*factor);
      const ctx=small.getContext('2d',{willReadFrequently:true})!;
      ctx.fillStyle='rgb(114,114,114)';ctx.fillRect(0,0,640,640);
      ctx.drawImage(canvas,Math.floor((640-w)/2),Math.floor((640-h)/2),w,h);
      const bytes=ctx.getImageData(0,0,640,640).data,n=640*640,pixels=new Float32Array(n*3);
      for(let i=0;i<n;i++) {pixels[i]=bytes[i*4]/255;pixels[n+i]=bytes[i*4+1]/255;pixels[n*2+i]=bytes[i*4+2]/255;}
      const {frames}=await request({type:'page',width,height,pixels},[pixels.buffer]);
      const quality = inspectPage(samplePage(canvas), frames);
      const kept = frames.filter((_, i) => !quality.blank.includes(i) && !quality.duplicate.includes(i));
      map.pages.push({width,height,kind:kept.length?'story':'cover',frames:kept.length?kept:[[0,0,1,1]]});
      // Yield between pages; the neural network runs in the worker, not UI.
      await new Promise<void>(resolve=>setTimeout(resolve,0));
    }
    check(signal);return parsePanelMap(map,hash,source.count);
  } finally {
    worker.terminate();canvas.width=canvas.height=small.width=small.height=0;
    await source?.close().catch(()=>{});
  }
}
