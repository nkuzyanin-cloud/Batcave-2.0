import {useEffect, useLayoutEffect, useRef, useState} from 'react';
import type {PageSource} from './source';

const STEP = 64, THUMB_WIDTH = 48, CACHE_LIMIT = 24;

/** Only a small window of page previews exists, even in a 5,000 page book.
 * The reading canvas has priority: previews pause while it loads or UI hides. */
export function PageStrip({source, current, active, onSelect}: {
  source: PageSource; current: number; active: boolean; onSelect: (page: number) => void;
}) {
  const root = useRef<HTMLDivElement>(null);
  const cache = useRef(new Map<number, string>());
  const failed = useRef(new Set<number>());
  const [revision, setRevision] = useState(0);
  const [viewport, setViewport] = useState({left: current * STEP, width: 375});
  const padding = Math.max(0, (viewport.width - THUMB_WIDTH) / 2);
  const first = Math.max(0, Math.floor((viewport.left - padding) / STEP) - 2);
  const last = Math.min(source.count - 1, Math.ceil((viewport.left + viewport.width - padding) / STEP) + 2);

  useLayoutEffect(() => {
    const node = root.current!;
    const observer = new ResizeObserver(() => {
      node.scrollLeft = current * STEP;
      setViewport({left: node.scrollLeft, width: node.clientWidth});
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, [source, current]);

  useLayoutEffect(() => {
    if (active) root.current?.scrollTo({left: current * STEP, behavior: 'instant'});
  }, [active, current]);

  useEffect(() => {
    const previews = cache.current, errors = failed.current;
    return () => {
      previews.forEach(url => URL.revokeObjectURL(url));
      previews.clear(); errors.clear();
    };
  }, [source]);

  useEffect(() => {
    if (!active) return;
    const controller = new AbortController();
    const pages = Array.from({length: last - first + 1}, (_, i) => first + i)
      .sort((a, b) => Math.abs(a - current) - Math.abs(b - current));
    void (async () => {
      for (const page of pages) {
        if (controller.signal.aborted) break;
        if (cache.current.has(page) || failed.current.has(page)) continue;
        const canvas = document.createElement('canvas');
        try {
          await source.render(page, canvas, 120, controller.signal);
          if (controller.signal.aborted) break;
          const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/jpeg', .7));
          if (controller.signal.aborted) break;
          if (!blob) throw Error('Preview unavailable');
          cache.current.set(page, URL.createObjectURL(blob));
          // Evict only previews outside the mounted window, never an on-screen img.
          for (const [key, url] of cache.current) {
            if (cache.current.size <= CACHE_LIMIT) break;
            if (key < first || key > last) { URL.revokeObjectURL(url); cache.current.delete(key); }
          }
          setRevision(v => v + 1);
        } catch {
          if (!controller.signal.aborted) { failed.current.add(page); setRevision(v => v + 1); }
        } finally { canvas.width = canvas.height = 0; }
      }
    })();
    return () => controller.abort();
  }, [source, active, first, last, current]);

  return <nav className="reader-filmstrip" aria-label="Миниатюры страниц" ref={root}
    data-preview-count={cache.current.size} data-revision={revision}
    onScroll={e => setViewport({left: e.currentTarget.scrollLeft, width: e.currentTarget.clientWidth})}>
    <div className="reader-filmstrip-track" style={{width: Math.max(viewport.width, 2 * padding + (source.count - 1) * STEP + THUMB_WIDTH)}}>
      {Array.from({length: Math.max(0, last - first + 1)}, (_, n) => first + n).map(page =>
        <button key={page} className="reader-page-preview" style={{left: padding + page * STEP}}
          aria-label={`Страница ${page + 1}`} aria-current={page === current ? 'page' : undefined}
          tabIndex={page === current ? 0 : -1} onClick={() => onSelect(page)}
          onKeyDown={e => {
            if (!['ArrowLeft','ArrowRight','Home','End'].includes(e.key)) return;
            e.preventDefault(); e.stopPropagation();
            const next = e.key === 'Home' ? 0 : e.key === 'End' ? source.count - 1 :
              Math.max(0, Math.min(source.count - 1, page + (e.key === 'ArrowRight' ? 1 : -1)));
            onSelect(next);
            requestAnimationFrame(() => root.current?.querySelector<HTMLButtonElement>('[aria-current="page"]')?.focus({preventScroll:true}));
          }}>
          <span className="reader-preview-image">{cache.current.has(page) ?
            <img src={cache.current.get(page)} alt="" draggable={false}/> :
            <span className="reader-preview-placeholder" aria-hidden="true">{failed.current.has(page) ? '—' : page + 1}</span>}</span>
          <span className="reader-preview-number">{page + 1}</span>
        </button>)}
    </div>
  </nav>;
}
