import type {ReaderView,Settings} from '../models';

export interface PageCameraView {zoom:number;x:number;y:number}
export interface PageCameraSize {width:number;height:number;pageWidth:number;pageHeight:number}
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
export function pageLimits(size:PageCameraSize,zoom:number){return {x:Math.max(0,(size.pageWidth*zoom-size.width)/2),y:Math.max(0,(size.pageHeight*zoom-size.height)/2)};}
export function boundedPage(view:PageCameraView,size:PageCameraSize):PageCameraView{
 const zoom=clamp(view.zoom,1,4),limits=pageLimits(size,zoom);
 return {zoom,x:clamp(view.x,-limits.x,limits.x),y:clamp(view.y,-limits.y,limits.y)};
}
// The document point under the fingers/cursor stays under that focal point.
export function anchoredPage(view:PageCameraView,zoom:number,from:{x:number;y:number},to=from):PageCameraView{
 zoom=clamp(zoom,1,4);const ratio=zoom/view.zoom;
 return {zoom,x:to.x-(from.x-view.x)*ratio,y:to.y-(from.y-view.y)*ratio};
}
interface Options {
 page:number;enabled:()=>boolean;settings:()=>Settings;initial?:ReaderView;
 onView:(view:ReaderView)=>void;onToggle:()=>void;onTurn:(delta:number)=>void;
}
type Point={x:number;y:number};
type Gesture={origin:Point;pan:PageCameraView;mid:Point;distance:number;pinched:boolean;moved:boolean;time:number;sample:number;vx:number;vy:number};

/** One compositor transform per animation frame; no React render per pointer move. */
export class PageCamera {
 private view:PageCameraView={zoom:1,x:0,y:0};
 private size:PageCameraSize={width:0,height:0,pageWidth:0,pageHeight:0};
 private points=new Map<number,Point>();
 private gesture?:Gesture;
 private loaded=false;
 private destroyed=false;
 private frame=0;
 private animation=0;
 private target?:PageCameraView;
 private tapTimer?:ReturnType<typeof setTimeout>;
 private wheelTimer?:ReturnType<typeof setTimeout>;
 private lastTap?:{time:number;point:Point};
 private observer:ResizeObserver;
 private initial?:ReaderView;
 constructor(private stage:HTMLElement,private layer:HTMLElement,private options:Options){
  this.initial=options.initial;
  this.observer=new ResizeObserver(()=>this.measure());this.observer.observe(stage);
  const canvas=layer.querySelector('canvas');if(canvas)this.observer.observe(canvas);
  stage.addEventListener('pointerdown',this.down);stage.addEventListener('pointermove',this.move);
  stage.addEventListener('pointerup',this.up);stage.addEventListener('pointercancel',this.cancel);
  stage.addEventListener('lostpointercapture',this.cancel);stage.addEventListener('wheel',this.wheel,{passive:false});
  stage.addEventListener('gesturestart',this.preventNative,{passive:false});stage.addEventListener('gesturechange',this.preventNative,{passive:false});
 }
 private reduced(){const m=this.options.settings().motion;return m==='off'||m==='system'&&matchMedia('(prefers-reduced-motion: reduce)').matches;}
 ready(){this.loaded=true;this.measure();}
 private measure(){
  if(!this.loaded||this.destroyed)return;
  const canvas=this.layer.querySelector('canvas'),old=pageLimits(this.size,this.view.zoom);
  const nx=old.x?this.view.x/old.x:0,ny=old.y?this.view.y/old.y:0;
  this.size={width:this.stage.clientWidth,height:this.stage.clientHeight,pageWidth:canvas?.offsetWidth??0,pageHeight:canvas?.offsetHeight??0};
  if(!this.size.pageWidth||!this.size.pageHeight)return;
  this.stop();
  if(this.initial){const v=this.initial;this.initial=undefined;const limits=pageLimits(this.size,clamp(v.zoom,1,4));this.view=boundedPage({zoom:v.zoom,x:v.x*limits.x,y:v.y*limits.y},this.size);}
  else {const limits=pageLimits(this.size,this.view.zoom);this.view=boundedPage({...this.view,x:nx*limits.x,y:ny*limits.y},this.size);}
  if(this.points.size)this.rebase(true);
  this.paint();
 }
 private paint=()=>{
  this.frame=0;if(this.destroyed||!this.loaded)return;
  const {x,y,zoom}=this.view;
  this.layer.style.transform=`translate3d(${x}px,${y}px,0) scale(${zoom})`;
  this.stage.dataset.zoom=String(zoom);this.stage.dataset.panX=String(x);this.stage.dataset.panY=String(y);
  const limits=pageLimits(this.size,zoom);
  this.options.onView({page:this.options.page,mode:'single',zoom,x:limits.x?x/limits.x:0,y:limits.y?y/limits.y:0});
 };
 private schedule(){if(!this.frame)this.frame=requestAnimationFrame(this.paint);}
 private set(view:PageCameraView){this.view=boundedPage(view,this.size);this.schedule();}
 private stop(){cancelAnimationFrame(this.animation);this.animation=0;this.target=undefined;this.stage.dataset.moving='false';}
 private clearTap(){clearTimeout(this.tapTimer);this.tapTimer=undefined;}
 private point(e:{clientX:number;clientY:number}):Point{const b=this.stage.getBoundingClientRect();return {x:e.clientX-b.left-b.width/2,y:e.clientY-b.top-b.height/2};}
 private span(){const p=[...this.points.values()];return {mid:p.length>1?{x:(p[0].x+p[1].x)/2,y:(p[0].y+p[1].y)/2}:p[0],distance:p.length>1?Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y):0};}
 private rebase(pinched:boolean){const {mid,distance}=this.span(),now=performance.now();this.gesture={origin:mid,mid,distance,pan:{...this.view},pinched,moved:pinched,time:now,sample:now,vx:0,vy:0};}
 private down=(e:PointerEvent)=>{
  if(!this.options.enabled()||!this.loaded||e.button!==0)return;
  e.preventDefault();this.stop();this.clearTap();
  this.points.set(e.pointerId,this.point(e));this.stage.setPointerCapture(e.pointerId);
  this.rebase(this.points.size>1);this.stage.dataset.moving='true';
 };
 private move=(e:PointerEvent)=>{
  if(!this.points.has(e.pointerId)||!this.gesture)return;
  e.preventDefault();const p=this.point(e);this.points.set(e.pointerId,p);
  const g=this.gesture,now=performance.now(),previous=this.view;
  if(this.points.size>=2){
   const {mid,distance}=this.span();this.set(anchoredPage(g.pan,g.pan.zoom*distance/Math.max(1,g.distance),g.mid,mid));g.moved=true;g.pinched=true;g.vx=g.vy=0;
  }else{
   const dx=p.x-g.origin.x,dy=p.y-g.origin.y;
   if(Math.hypot(dx,dy)>7){g.moved=true;this.lastTap=undefined;}
   this.set({...g.pan,x:g.pan.x+dx,y:g.pan.y+dy});
   const dt=Math.max(1,now-g.sample),weight=dt>80?1:.7;
   g.vx=g.vx*(1-weight)+clamp((this.view.x-previous.x)/dt,-2.5,2.5)*weight;
   g.vy=g.vy*(1-weight)+clamp((this.view.y-previous.y)/dt,-2.5,2.5)*weight;
  }
  g.sample=now;
 };
 private up=(e:PointerEvent)=>{
  if(!this.points.has(e.pointerId)||!this.gesture)return;
  const g=this.gesture,p=this.point(e);this.points.delete(e.pointerId);
  if(this.points.size){this.rebase(true);return;}
  this.gesture=undefined;this.stage.dataset.moving='false';this.paint();
  const dx=p.x-g.origin.x,dy=p.y-g.origin.y,now=performance.now();
  if(!g.pinched&&g.pan.zoom<=1.001&&this.view.zoom<=1.001&&Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.3){this.clearTap();this.lastTap=undefined;this.options.onTurn((dx<0?1:-1)*(this.options.settings().direction==='ltr'?1:-1));return;}
  if(g.pinched||g.moved){this.lastTap=undefined;if(now-g.sample<85)this.coast(g.vx,g.vy);return;}
  if(now-g.time>500)return;
  const last=this.lastTap;
  if(this.options.settings().doubleTap&&last&&now-last.time<280&&Math.hypot(p.x-last.point.x,p.y-last.point.y)<36){this.clearTap();this.lastTap=undefined;this.animate(anchoredPage(this.view,this.view.zoom>1.01?1:2.5,p));}
  else {this.lastTap={time:now,point:p};this.tapTimer=setTimeout(()=>{this.lastTap=undefined;this.options.onToggle();},this.options.settings().doubleTap?280:0);}
 };
 private cancel=(e:PointerEvent)=>{
  if(!this.points.has(e.pointerId))return;
  this.points.delete(e.pointerId);this.clearTap();this.lastTap=undefined;this.stop();
  if(this.points.size)this.rebase(true);else {this.gesture=undefined;this.paint();}
 };
 private animate(goal:PageCameraView){
  this.stop();const from={...this.view},to=boundedPage(goal,this.size);this.target=to;
  if(this.reduced()){this.set(to);this.target=undefined;return;}
  const start=performance.now(),duration=this.options.settings().motion==='fast'?120:210;this.stage.dataset.moving='true';
  const step=(now:number)=>{const t=Math.min(1,(now-start)/duration),ease=1-Math.pow(1-t,3);this.view=boundedPage({zoom:from.zoom+(to.zoom-from.zoom)*ease,x:from.x+(to.x-from.x)*ease,y:from.y+(to.y-from.y)*ease},this.size);this.paint();if(t<1)this.animation=requestAnimationFrame(step);else {this.animation=0;this.target=undefined;this.stage.dataset.moving='false';}};
  this.animation=requestAnimationFrame(step);
 }
 private coast(vx:number,vy:number){
  if(this.reduced()||Math.hypot(vx,vy)<.03)return;
  this.stop();let previous=performance.now();const tau=this.options.settings().motion==='fast'?100:180;this.stage.dataset.moving='true';
  const step=(now:number)=>{const dt=Math.min(40,now-previous);previous=now;const decay=Math.exp(-dt/tau),old=this.view,dx=vx*tau*(1-decay),dy=vy*tau*(1-decay);this.view=boundedPage({...old,x:old.x+dx,y:old.y+dy},this.size);vx=Math.abs(this.view.x-old.x-dx)>.01?0:vx*decay;vy=Math.abs(this.view.y-old.y-dy)>.01?0:vy*decay;this.paint();if(Math.hypot(vx,vy)>.02)this.animation=requestAnimationFrame(step);else {this.animation=0;this.stage.dataset.moving='false';}};
  this.animation=requestAnimationFrame(step);
 }
 private wheel=(e:WheelEvent)=>{
  if(!this.options.enabled()||!this.loaded)return;e.preventDefault();this.clearTap();this.lastTap=undefined;
  const unit=e.deltaMode===1?16:e.deltaMode===2?this.size.height:1;
  if(e.ctrlKey||e.metaKey){const base=this.target??this.view;this.animate(anchoredPage(base,base.zoom*Math.exp(-e.deltaY*unit*.003),this.point(e)));}
  else {this.stop();this.set({...this.view,x:this.view.x-e.deltaX*unit,y:this.view.y-e.deltaY*unit});}
  clearTimeout(this.wheelTimer);this.wheelTimer=setTimeout(()=>this.paint(),150);
 };
 private preventNative=(e:Event)=>{if(this.options.enabled())e.preventDefault();};
 zoom(delta:number){if(this.loaded){const base=this.target??this.view;this.animate(anchoredPage(base,base.zoom+delta,{x:0,y:0}));}}
 reset(){if(this.loaded)this.animate({zoom:1,x:0,y:0});}
 pause(){this.points.clear();this.gesture=undefined;this.clearTap();this.lastTap=undefined;this.stop();if(this.loaded)this.paint();}
 destroy(){this.destroyed=true;this.stop();cancelAnimationFrame(this.frame);clearTimeout(this.tapTimer);clearTimeout(this.wheelTimer);this.observer.disconnect();
  this.stage.removeEventListener('pointerdown',this.down);this.stage.removeEventListener('pointermove',this.move);this.stage.removeEventListener('pointerup',this.up);this.stage.removeEventListener('pointercancel',this.cancel);this.stage.removeEventListener('lostpointercapture',this.cancel);this.stage.removeEventListener('wheel',this.wheel);this.stage.removeEventListener('gesturestart',this.preventNative);this.stage.removeEventListener('gesturechange',this.preventNative);
 }
}
