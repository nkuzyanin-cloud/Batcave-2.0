import { useCallback, useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react';
import type { Settings } from '../models';
import type { panelCamera, Rect } from './panels';

export interface PanelPose {
  camera: ReturnType<typeof panelCamera>;
  bounds: Rect;
  opacity: number;
}

export function motionDuration(motion: Settings['motion'], reduced: boolean) {
  if (motion === 'off' || (motion === 'system' && reduced)) return 0;
  return motion === 'fast' ? 170 : 420;
}

export function useReaderMotion(motion: Settings['motion']) {
  const [reduced, setReduced] = useState(() => matchMedia('(prefers-reduced-motion: reduce)').matches);
  useEffect(() => {
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReduced(media.matches);
    update();media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);
  return motionDuration(motion, reduced);
}

export function shadeRectangles([x, y, w, h]: Rect): Rect[] {
  // Four solid colour quads surround the frame. No SVG mask, clipping path or
  // bitmap is rerasterized as the camera moves. Zero-size quads are valid.
  return [[0, 0, 1, y], [0, y + h, 1, Math.max(0, 1 - y - h)],
    [0, y, x, h], [x + w, y, Math.max(0, 1 - x - w), h]];
}

const cameraTransform = (c: PanelPose['camera']) => `translate3d(${c.x}px,${c.y}px,0) scale(${c.scale})`;
const shadeTransform = (r: Rect, width: number, height: number) =>
  `translate3d(${r[0] * width}px,${r[1] * height}px,0) scale(${r[2] * width / 64},${r[3] * height / 64})`;

export function cameraFlight(from: PanelPose['camera'], to: PanelPose['camera'], baseDuration: number) {
  const vw = to.viewportWidth, vh = to.viewportHeight;
  const a = { x: (vw / 2 - from.x) / from.scale, y: (vh / 2 - from.y) / from.scale };
  const b = { x: (vw / 2 - to.x) / to.scale, y: (vh / 2 - to.y) / to.scale };
  const travel = Math.hypot(a.x - b.x, a.y - b.y) * Math.sqrt(from.scale * to.scale) / Math.max(1, Math.hypot(vw, vh));
  const zoom = Math.abs(Math.log(to.scale / from.scale));
  const duration = baseDuration ? Math.round(baseDuration * Math.max(.7, Math.min(1.65, .72 + travel * .75 + zoom * .35))) : 0;
  const frames: Keyframe[] = [{ transform: cameraTransform(from), offset: 0 }];
  // Long lateral flights gently pull back, keeping the page's geography clear.
  // Zooming from a full page into a panel takes a direct path.
  if (travel > .7 && zoom < .35) {
    const scale = Math.min(from.scale, to.scale) * .94;
    frames.push({ transform: cameraTransform({ ...to, scale, x: vw / 2 - (a.x + b.x) / 2 * scale, y: vh / 2 - (a.y + b.y) / 2 * scale }), offset: .5 });
  }
  frames.push({ transform: cameraTransform(to), offset: 1 });
  return { duration, frames };
}

// Browser animations change only transforms and opacity. They can run on the
// compositor while PDF decoding or the JS thread is busy. Computed transforms
// are read once on interruption, never in a frame-by-frame JS animation loop.
export function usePanelMotion(
  node: RefObject<HTMLDivElement | null>,
  shades: RefObject<(HTMLDivElement | null)[]>,
  target: PanelPose,
  duration: number,
) {
  const last = useRef(target), started = useRef(false), animations = useRef<Animation[]>([]);
  last.current = target;
  const snapshot = useCallback((): PanelPose => {
    const c = last.current.camera;
    if (!started.current || !node.current || !shades.current[2] || !shades.current[3]) return last.current;
    const matrix = new DOMMatrixReadOnly(getComputedStyle(node.current).transform);
    const left = new DOMMatrixReadOnly(getComputedStyle(shades.current[2]).transform);
    const right = new DOMMatrixReadOnly(getComputedStyle(shades.current[3]).transform);
    return {
      camera: { ...c, x: matrix.e, y: matrix.f, scale: matrix.a },
      bounds: [(left.e + left.a * 64) / c.width, left.f / c.height, (right.e - left.e - left.a * 64) / c.width, left.d * 64 / c.height],
      opacity: Number(getComputedStyle(shades.current[2]).opacity),
    };
  }, [node, shades]);
  const cancel = () => { for (const animation of animations.current) animation.cancel();animations.current = []; };
  useLayoutEffect(() => () => cancel(), []);
  const { x, y, scale, width, height } = target.camera;
  const [bx, by, bw, bh] = target.bounds;
  useLayoutEffect(() => {
    const animate = started.current && duration > 0;
    const from = animate ? snapshot() : target;
    const presented = animate ? shades.current.map(shade => shade ? {
      transform: getComputedStyle(shade).transform, opacity: getComputedStyle(shade).opacity,
    } : undefined) : [];
    // Read the presented position BEFORE cancelling the previous animation.
    // Effect cleanup runs only on unmount, so reversals cannot snap to its end.
    cancel();
    started.current = true;
    const transforms = shadeRectangles(target.bounds).map(r => shadeTransform(r, width, height));
    const before = shadeRectangles(from.bounds).map(r => shadeTransform(r, width, height));
    const flight = cameraFlight(from.camera, target.camera, duration);
    const options: KeyframeAnimationOptions = { duration: flight.duration, easing: 'cubic-bezier(.4,0,.2,1)' };
    const created: Animation[] = [];
    if (node.current) {
      node.current.style.transform = cameraTransform(target.camera);
      node.current.dataset.flightDuration = String(animate ? flight.duration : 0);
      if (animate && (from.camera.x !== x || from.camera.y !== y || from.camera.scale !== scale)) created.push(node.current.animate(flight.frames, options));
    }
    shades.current.forEach((shade, i) => {
      if (!shade) return;
      shade.style.transform = transforms[i];shade.style.opacity = String(target.opacity);
      if (animate && (before[i] !== transforms[i] || from.opacity !== target.opacity)) created.push(shade.animate([
        { transform: presented[i]?.transform ?? before[i], opacity: presented[i]?.opacity ?? from.opacity }, { transform: transforms[i], opacity: target.opacity },
      ], options));
    });
    if (!created.length) return;
    animations.current = created;
    const time = document.timeline.currentTime;
    if (time !== null) for (const animation of created) animation.startTime = time;
    created[0].onfinish = () => {
      if (animations.current === created) cancel(); // Inline styles already hold the exact final pose.
    };
  }, [node, shades, snapshot, x, y, scale, width, height, bx, by, bw, bh, target.opacity, duration]);
  return snapshot;
}
