import { useCallback, useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react';
import type { Settings } from '../models';
import type { panelCamera, Rect } from './panels';

export interface PanelPose {
  camera: ReturnType<typeof panelCamera>;
  bounds: Rect;
  opacity: number;
}

export function motionDuration(motion: Settings['motion'], reduced: boolean) {
  if (motion === 'off' || (motion === 'system' && reduced)) return 0;
  return motion === 'fast' ? 170 : 420;
}

export function useReaderMotion(motion: Settings['motion']) {
  const [reduced, setReduced] = useState(() => matchMedia('(prefers-reduced-motion: reduce)').matches);
  useEffect(() => {
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReduced(media.matches);
    update();media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);
  return motionDuration(motion, reduced);
}

export function shadeRectangles([x, y, w, h]: Rect): Rect[] {
  // Four solid colour quads surround the frame. No SVG mask, clipping path or
  // bitmap is rerasterized as the camera moves. Zero-size quads are valid.
  return [[0, 0, 1, y], [0, y + h, 1, Math.max(0, 1 - y - h)],
    [0, y, x, h], [x + w, y, Math.max(0, 1 - x - w), h]];
}

const cameraTransform = (c: PanelPose['camera']) => `translate3d(${c.x}px,${c.y}px,0) scale(${c.scale})`;
const shadeTransform = (r: Rect, width: number, height: number) =>
  `translate3d(${r[0] * width}px,${r[1] * height}px,0) scale(${r[2] * width},${r[3] * height})`;

// Browser animations change only transforms and opacity. They can run on the
// compositor while PDF decoding or the JS thread is busy. Computed transforms
// are read once on interruption, never in a frame-by-frame JS animation loop.
export function usePanelMotion(
  node: RefObject<HTMLDivElement | null>,
  shades: RefObject<(HTMLDivElement | null)[]>,
  target: PanelPose,
  duration: number,
) {
  const last = useRef(target), started = useRef(false), animations = useRef<Animation[]>([]);
  last.current = target;
  const snapshot = useCallback((): PanelPose => {
    const c = last.current.camera;
    if (!started.current || !node.current || !shades.current[2] || !shades.current[3]) return last.current;
    const matrix = new DOMMatrixReadOnly(getComputedStyle(node.current).transform);
    const left = new DOMMatrixReadOnly(getComputedStyle(shades.current[2]).transform);
    const right = new DOMMatrixReadOnly(getComputedStyle(shades.current[3]).transform);
    return {
      camera: { ...c, x: matrix.e, y: matrix.f, scale: matrix.a },
      bounds: [left.a / c.width, left.f / c.height, (right.e - left.a) / c.width, left.d / c.height],
      opacity: Number(getComputedStyle(shades.current[2]).opacity),
    };
  }, [node, shades]);
  const cancel = () => { for (const animation of animations.current) animation.cancel();animations.current = []; };
  useLayoutEffect(() => () => cancel(), []);
  const { x, y, scale, width, height } = target.camera;
  const [bx, by, bw, bh] = target.bounds;
  useLayoutEffect(() => {
    const animate = started.current && duration > 0;
    const from = animate ? snapshot() : target;
    // Read the presented position BEFORE cancelling the previous animation.
    // Effect cleanup runs only on unmount, so reversals cannot snap to its end.
    cancel();
    started.current = true;
    const transforms = shadeRectangles(target.bounds).map(r => shadeTransform(r, width, height));
    const before = shadeRectangles(from.bounds).map(r => shadeTransform(r, width, height));
    const options: KeyframeAnimationOptions = { duration, easing: 'cubic-bezier(.22,.75,.25,1)' };
    const created: Animation[] = [];
    if (node.current) {
      node.current.style.transform = cameraTransform(target.camera);
      if (animate) created.push(node.current.animate([{ transform: cameraTransform(from.camera) }, { transform: cameraTransform(target.camera) }], options));
    }
    shades.current.forEach((shade, i) => {
      if (!shade) return;
      shade.style.transform = transforms[i];shade.style.opacity = String(target.opacity);
      if (animate) created.push(shade.animate([
        { transform: before[i], opacity: from.opacity }, { transform: transforms[i], opacity: target.opacity },
      ], options));
    });
    if (!created.length) return;
    animations.current = created;
    const time = document.timeline.currentTime;
    if (time !== null) for (const animation of created) animation.startTime = time;
    created[0].onfinish = () => {
      if (animations.current === created) cancel(); // Inline styles already hold the exact final pose.
    };
  }, [node, shades, snapshot, x, y, scale, width, height, bx, by, bw, bh, target.opacity, duration]);
  return snapshot;
}
