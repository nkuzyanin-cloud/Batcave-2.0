import { useRef, useState } from 'react';
import { ArrowLeft, BookOpen, Clock, Star } from 'lucide-react';
import { type Comic, errorMessage, paperTime } from '../models';
import { Cover } from '../components/ui';
import { updateReadingResult } from '../storage/db';

export function ReadingSummary({comic,error,onBack,onClose,onChanged}:{comic?:Comic;error:string;onBack:()=>void;onClose:()=>void;onChanged:(c:Comic)=>void}) {
  const [busy,setBusy]=useState(false),[failure,setFailure]=useState('');
  const working=useRef(false);
  async function save(change:{rating?:number;completed?:boolean}) {
    if(!comic || working.current)return;
    working.current=true;setBusy(true);setFailure('');
    try {onChanged(await updateReadingResult(comic.id,change));}
    catch(e){setFailure(errorMessage(e));}
    finally {working.current=false;setBusy(false);}
  }
  const seconds=comic ? Math.floor(comic.seconds+paperTime(comic)) : 0;
  const minutes=Math.floor(seconds/60),hours=Math.floor(minutes/60);
  const time=hours ? `${hours} ч ${minutes%60} м` : minutes ? `${minutes} м` : `${seconds} с`;
  const pages=comic ? new Set(comic.visited.filter(p=>p>=0 && p<comic.pageCount)).size : 0;
  return <section className="reader reading-summary" aria-label="Итоги чтения">
    <header className="summary-header"><button className="icon-button" aria-label="Вернуться к комиксам" disabled={busy} onClick={onClose}><ArrowLeft/></button><h1>История завершена</h1></header>
    <div className="summary-content">
      {!comic && !error && <p role="status"><span className="spinner"/>Сохраняем итоги…</p>}
      {comic && <>
        <div className="summary-cover"><Cover comic={comic}/></div>
        <h2>{comic.title}</h2>
        <div className="summary-stats">
          <div><Clock aria-hidden="true"/><strong>{time}</strong><span>Время чтения</span></div>
          <div><BookOpen aria-hidden="true"/><strong>{pages} / {comic.pageCount}</strong><span>Страниц прочитано</span></div>
        </div>
        <div className="summary-rating"><h3>Ваша оценка</h3><div className="summary-stars" role="group" aria-label="Оценка комикса">
          {[1,2,3,4,5].map(n=><button key={n} disabled={busy} aria-label={`Оценка ${n}`} aria-pressed={comic.rating===n} onClick={()=>void save({rating:n})}><Star fill={comic.rating>=n ? 'currentColor' : 'none'}/></button>)}
        </div><p>{comic.rating ? 'Оценку можно изменить' : 'Можно оценить позже'}</p></div>
        {!comic.completed && <button className="secondary" disabled={busy} onClick={()=>void save({completed:true})}>Отметить прочитанным</button>}
      </>}
      {(error || failure) && <p className="error" role="alert">{error || failure}</p>}
      <div className="summary-actions"><button className="summary-back" disabled={busy} onClick={onBack}>К последней странице</button><button className="primary" disabled={busy || (!comic && !error)} onClick={onClose}>Вернуться в библиотеку</button></div>
    </div>
  </section>;
}
