type ResourceIndex = Record<string, [number, number]>;
let resources: Promise<{ blob: Blob; index: ResourceIndex; start: number }> | undefined;

async function loadResources() {
  if (!resources) {
    resources = (async () => {
      const url = new URL('./pdf/resources.bin', new URL(import.meta.env.BASE_URL, document.baseURI));
      const response = await fetch(url);
      if (!response.ok) throw Error('Не удалось загрузить ресурсы PDF.');
      const blob = await response.blob();
      if (blob.size < 4) throw Error('Повреждён пакет ресурсов PDF.');
      const length = new DataView(await blob.slice(0, 4).arrayBuffer()).getUint32(0, true);
      const start = length + 4;
      if (length > 128_000 || start > blob.size) throw Error('Повреждён пакет ресурсов PDF.');
      const index = JSON.parse(await blob.slice(4, start).text()) as ResourceIndex;
      return { blob, index, start };
    })().catch((error: unknown) => {
      resources = undefined;
      throw error;
    });
  }
  return resources;
}

// PDF.js 6 BinaryDataFactory contract. Return a fresh buffer per request because
// PDF.js may transfer it to its worker. Blob slices avoid decoding unused fonts.
export class PackedPdfDataFactory {
  private wasmUrl: string;
  constructor({ wasmUrl }: { wasmUrl: string }) {
    this.wasmUrl = wasmUrl;
  }
  async fetch({ kind, filename }: { kind: string; filename: string }): Promise<Uint8Array> {
    if (!filename || filename.includes('/') || filename.includes('\\'))
      throw Error('Некорректное имя ресурса PDF.');
    if (kind === 'wasmUrl') {
      const response = await fetch(new URL(filename, this.wasmUrl));
      if (!response.ok) throw Error('Не удалось загрузить декодер PDF.');
      return new Uint8Array(await response.arrayBuffer());
    }
    const folder = kind === 'cMapUrl' ? 'cmaps' : kind === 'standardFontDataUrl' ? 'standard_fonts' : null;
    if (!folder) throw Error('Неизвестный тип ресурса PDF.');
    const { blob, index, start } = await loadResources();
    const entry = index[`${folder}/${filename}`];
    if (!Array.isArray(entry) || entry.length !== 2 ||
      !Number.isSafeInteger(entry[0]) || !Number.isSafeInteger(entry[1]) ||
      entry[0] < 0 || entry[1] <= 0 || start + entry[0] + entry[1] > blob.size)
      throw Error('Ресурс PDF отсутствует или повреждён.');
    return new Uint8Array(await blob.slice(start + entry[0], start + entry[0] + entry[1]).arrayBuffer());
  }
}
