import { forwardRef, useCallback, useEffect, useImperativeHandle, useLayoutEffect, useMemo, useReducer, useRef, useState, type CSSProperties } from 'react';
import { errorMessage, type ReaderView, type Settings, type PanelEdits, type PanelFrameEdit, type PanelViewEdit, type PanelRect } from '../models';
import type { PageSource } from './source';
import type { GuideHandle, GuideState } from './GuidedReader';
import { findPanelStep, panelCamera, horizontalInspection, panelSteps, automaticFocuses, type Rect, type PanelMap } from './panels';
import { PageBuffer } from './page-buffer';
import { usePanelMotion, useReaderMotion, type PanelPose } from './panel-motion';
import { editedPanelStep, fitView, frameEdit, normalizeView } from './panel-edits';
import { inspectPage, samplePage, emptyCloseView } from './page-quality';
import { PanelEditor, type PanelEditMode } from './PanelEditor';

interface DisplayPage { page: number; canvas: HTMLCanvasElement }
interface PageTurn { id: number; outgoing: DisplayPage & { pose: PanelPose }; direction: number }
interface SurfaceHandle { snapshot: () => PanelPose }
interface EditDraft {
  page: number; panel: number; bounds: PanelRect; view: PanelViewEdit; views: PanelViewEdit[]; mode: PanelEditMode;
}

const PanelSurface = forwardRef<SurfaceHandle, { canvas: HTMLCanvasElement; pose: PanelPose; duration: number; current: boolean; crop?: Rect }>(
  function PanelSurface({ canvas, pose, duration, current, crop }, ref) {
    const camera = useRef<HTMLDivElement>(null), paper = useRef<HTMLDivElement>(null);
    const shades = useRef<(HTMLDivElement | null)[]>([]);
    const snapshot = usePanelMotion(camera, shades, pose, duration);
    useImperativeHandle(ref, () => ({ snapshot }), [snapshot]);
    useLayoutEffect(() => {
      const node = paper.current!;node.appendChild(canvas);
      return () => { if (canvas.parentNode === node) node.removeChild(canvas); };
    }, [canvas]);
    const { width, height } = pose.camera;
    return <div ref={camera} className="panel-camera" data-testid={current ? 'panel-camera' : 'panel-outgoing-camera'} style={{ width, height }}>
      <div ref={paper} className="panel-paper" style={crop ? { clipPath: `inset(${crop[1]*100}% ${(1-crop[0]-crop[2])*100}% ${(1-crop[1]-crop[3])*100}% ${crop[0]*100}%)` } : undefined} />
      <div className="panel-shade" aria-hidden="true">
        {['top', 'bottom', 'left', 'right', 'edge-top', 'edge-bottom', 'edge-left', 'edge-right', 'corner-tl', 'corner-tr', 'corner-bl', 'corner-br'].map((side, i) => <div key={side} ref={el => { shades.current[i] = el; }} className={`panel-dim ${side}`} />)}
      </div>
    </div>;
  },
);

export const PanelReader = forwardRef<GuideHandle, {
  source: PageSource; map: PanelMap; page: number; settings: Settings; enabled: boolean; initial?: ReaderView;
  edits?: PanelEdits; fingerprint: string;
  onSaveEdit: (page: number, panel: number, edit: PanelFrameEdit | null) => Promise<void>;
  onEditing: (editing: boolean) => void;
  onPage: (page: number) => void; onLoaded: (page: number) => void; onError: (error: string) => void;
  onToggle: () => void; onView: (view: ReaderView) => void; onState: (state: GuideState) => void;
}>(function PanelReader({ source, map, page, settings, enabled, initial, edits, fingerprint, onSaveEdit, onEditing, onPage, onLoaded, onError, onToggle, onView, onState }, ref) {
  const stage = useRef<HTMLDivElement>(null), scroll = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ width: window.innerWidth, height: Math.max(200,window.innerHeight-150) });
  const [readingSize, setReadingSize] = useState(size);
  const buffer = useMemo(() => new PageBuffer(source, Math.min(2200, window.innerWidth * (window.devicePixelRatio || 1) * 2)), [source]);
  const [revision, changed] = useReducer(n => n + 1, 0);
  const qualityCache = useMemo(() => new Map<number, ReturnType<typeof inspectPage>>(), [buffer, map, readingSize.width, readingSize.height]);
  const quality = useMemo(() => {
    // Analyze a rendered page once. Cached geometry is tiny; pixel thumbnails
    // are discarded immediately. This also repairs previously imported books.
    map.pages.forEach((p, i) => {
      if (qualityCache.has(i)) return;
      const canvas = buffer.get(i); if (!canvas) return;
      const pixels = samplePage(canvas), result = inspectPage(pixels, p.frames);
      if (map.detector && p.kind === 'story') p.frames.forEach((r, panel) => {
        const focuses = automaticFocuses(r, p.height/p.width, readingSize.width, readingSize.height);
        result.emptyViews[panel] = focuses.flatMap((f, part) => part > 0 && emptyCloseView(pixels, f) ? [part] : []);
      });
      qualityCache.set(i, result);
    });
    return new Map(qualityCache);
  }, [qualityCache, revision, buffer, map, readingSize.width, readingSize.height]);
  const steps = useMemo(() => panelSteps(map, settings.direction === 'rtl', settings.panelPageFirst, settings.panelPageLast, readingSize.width, readingSize.height,
    { edits, quality, crop: settings.cropMargins }), [map, settings.direction, settings.panelPageFirst, settings.panelPageLast, settings.cropMargins, readingSize.width, readingSize.height, edits, quality]);
  const [index, setIndex] = useState(() => findPanelStep(steps, page, initial));
  const [shown, setShown] = useState<DisplayPage>();
  const [turn, setTurn] = useState<PageTurn>();
  const [initialSpinner, setInitialSpinner] = useState(false);
  const surface = useRef<SurfaceHandle>(null), turnId = useRef(0), travel = useRef(1);
  const duration = useReaderMotion(settings.motion);
  const valid = initial?.mode === 'panels' && initial.page === page;
  const [zoom, setZoom] = useState(valid ? Math.max(1, Math.min(2.5,initial.zoom)) : 1);
  const [pan, setPan] = useState(valid ? { x: initial.x*size.width, y: 0 } : { x: 0, y: 0 });
  const [moving, setMoving] = useState(false);
  const [draft, setDraft] = useState<EditDraft>();
  const isEditing = !!draft;
  const [undo, setUndo] = useState<{ page: number; panel: number; previous: PanelFrameEdit | null }[]>([]);
  const [undoBusy, setUndoBusy] = useState(false), [undoError, setUndoError] = useState('');
  const [editBusy, setEditBusy] = useState(false), [editError, setEditError] = useState('');
  const [editorMetrics, setEditorMetrics] = useState({ top: 48, bottom: 180 });
  const beginEdit = useRef<() => void>(() => {}), longPress = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const indexRef = useRef(index), expectedPage = useRef(page);
  const previousSteps = useRef(steps), anchor = useRef<ReaderView>(initial ?? { page, mode: 'panels', zoom: 1, x: 0, y: 0 });
  const stride = Math.max(160, Math.round(size.height * 0.6));
  // The book may have hundreds of scroll stops. Navigation and zoom should
  // not recreate their elements on every touch or buffer notification.
  const stops = useMemo(() => Array.from({ length: steps.length }, (_, i) => <div className="panel-stop" key={i} style={{ height: stride }} aria-hidden="true" />), [steps.length, stride]);
  const effectiveIndex = steps !== previousSteps.current ? findPanelStep(steps, page, anchor.current) : index;
  const active = steps[Math.min(effectiveIndex, steps.length - 1)];
  const loaded = shown?.page === active.page;
  const ratio = map.pages[active.page].height / map.pages[active.page].width;
  const correction = frameEdit(edits, fingerprint, active.page, active.panel);
  const resolved = editedPanelStep(active, correction, settings.direction === 'rtl');
  const viewPart = active.viewPart ?? (settings.direction === 'rtl' ? active.parts - 1 - active.part : active.part);
  const customView = !active.overview ? correction?.views.find(v => v.part === viewPart) : undefined;
  const baseView = customView ?? fitView(viewPart);
  const draftFrame = draft ? { page: draft.page, panel: draft.panel, bounds: draft.bounds, views: [] } : undefined;
  const preview = draft ? editedPanelStep(active, draftFrame, settings.direction === 'rtl') : resolved;
  const baseCamera = panelCamera(resolved.focus, ratio, size.width, size.height, baseView.zoom,
    { x: baseView.x * size.width, y: baseView.y * size.height });
  const inspection = horizontalInspection(resolved.bounds, baseCamera, zoom, pan.x);
  const readingPan = zoom > 1 ? inspection.pan : { x: 0, y: 0 };
  const camera = draft ? panelCamera(draft.mode === 'bounds' ? [0, 0, 1, 1] : preview.focus,
    ratio, size.width, size.height, draft.mode === 'bounds' ? 1 : draft.view.zoom,
    draft.mode === 'bounds' ? { x: 0, y: 0 } : { x: draft.view.x * size.width, y: draft.view.y * size.height }) :
    zoom > 1 ? inspection.camera : baseCamera;
  const pose: PanelPose = { camera, bounds: draft?.bounds ?? resolved.bounds,
    opacity: draft?.mode === 'bounds' ? .55 : active.overview ? 0 : settings.panelOpacity };
  const lastPose = useRef(pose);
  if (loaded) lastPose.current = pose;
  const shownPose = loaded ? pose : lastPose.current;
  const current = useRef({ steps, stride, enabled, loaded, zoom, pan: readingPan, panLimit: inspection.limit, size, direction: settings.direction, doubleTap: settings.doubleTap });
  current.current = { steps, stride, enabled: enabled && !draft, loaded, zoom, pan: readingPan, panLimit: inspection.limit, size, direction: settings.direction, doubleTap: settings.doubleTap };
  const frame = useRef<number | undefined>(undefined), tapTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const tap = useRef(0), lastTouch = useRef(0), ignoreScroll = useRef(false);
  const mouseStart = useRef({ x: 0, y: 0 });
  beginEdit.current = () => {
    if (!enabled || draft || !loaded || active.overview) return;
    clearTimeout(tapTimer.current);clearTimeout(longPress.current);tap.current = 0;lastTouch.current = Date.now();
    // Leave the reading anchor unchanged until Save. Draft changes never enter
    // the progress autosave queue or overwrite the original file.
    setEditError('');
    setDraft({ page: active.page, panel: active.panel, bounds: [...resolved.bounds],
      view: normalizeView({ part: viewPart, zoom: zoom * baseView.zoom,
        x: baseView.x + pan.x / size.width, y: baseView.y + pan.y / size.height }),
      views: correction?.views ?? [], mode: 'scale' });
    onEditing(true);
  };
  const deleteFrame = async () => {
    if (!draft || editBusy) return;
    setEditBusy(true); setEditError('');
    const previous = frameEdit(edits, fingerprint, draft.page, draft.panel) ?? null;
    try {
      await onSaveEdit(draft.page, draft.panel, { page: draft.page, panel: draft.panel,
        bounds: previous?.bounds ?? map.pages[draft.page].frames[draft.panel], views: previous?.views ?? [], hidden: true });
      setUndo(u => [...u, { page: draft.page, panel: draft.panel, previous }]);
      setZoom(1); setPan({x:0,y:0}); setDraft(undefined); onEditing(false);
    } catch(e) { setEditError(`Не удалось удалить: ${errorMessage(e)}`); }
    finally { setEditBusy(false); }
  };
  const undoDelete = async () => {
    const item = undo.at(-1); if (!item || undoBusy) return;
    setUndoBusy(true); setUndoError('');
    try {
      await onSaveEdit(item.page, item.panel, item.previous);
      setUndo(u => u.slice(0, -1));
      const view: ReaderView = {page:item.page,mode:'panels',panel:item.panel,part:0,zoom:1,x:0,y:0};
      anchor.current = view; expectedPage.current = item.page; onPage(item.page);
      setZoom(1);setPan({x:0,y:0});
    } catch(e) { setUndoError(`Не удалось восстановить: ${errorMessage(e)}`); }
    finally { setUndoBusy(false); }
  };
  const visiblePanels = [...new Set(steps.filter(s => s.page === active.page && !s.overview).map(s => s.panel))];
  const displayPanel = visiblePanels.indexOf(active.panel) + 1;
  const cancelEdit = () => { if (!editBusy) { ignoreScroll.current = true;setDraft(undefined);setEditError('');onEditing(false); } };
  const saveEdit = async () => {
    if (!draft || editBusy) return;
    setEditBusy(true);setEditError('');
    const views = [...draft.views.filter(v => v.part !== draft.view.part), draft.view]
      .filter(v => Math.abs(v.zoom - 1) > .00001 || Math.abs(v.x) > .00001 || Math.abs(v.y) > .00001);
    const original = map.pages[draft.page].frames[draft.panel];
    const unchangedBounds = draft.bounds.every((v, i) => Math.abs(v - original[i]) < .000001);
    const edit = unchangedBounds && !views.length ? null : { page: draft.page, panel: draft.panel, bounds: draft.bounds, views };
    try {
      await onSaveEdit(draft.page, draft.panel, edit);
      ignoreScroll.current = true;
      setZoom(1);setPan({ x: 0, y: 0 });setDraft(undefined);onEditing(false);
    } catch (e) { setEditError(`Не удалось сохранить: ${errorMessage(e)}`); }
    finally { setEditBusy(false); }
  };
  useEffect(() => buffer.subscribe(changed), [buffer]);
  useEffect(() => () => buffer.dispose(), [buffer]);
  useEffect(() => {
    // Requested page first, visible paper and its outgoing animation pinned.
    // Only then prepare neighbours. Prefetch never records reading progress.
    buffer.keep([active.page, ...(shown ? [shown.page] : []), ...(turn ? [turn.outgoing.page] : []), active.page + travel.current, active.page - travel.current]);
  }, [buffer, active.page, shown, turn]);
  useLayoutEffect(() => {
    const canvas = buffer.get(active.page);
    if (!canvas || shown?.page === active.page) return;
    const snapshot = surface.current?.snapshot();
    setTurn(shown && snapshot && duration > 0 ? {
      id: ++turnId.current, outgoing: { ...shown, pose: snapshot },
      direction: (active.page > shown.page ? 1 : -1) * (settings.direction === 'rtl' ? -1 : 1),
    } : undefined);
    setShown({ page: active.page, canvas });
  }, [buffer, revision, active.page, shown, duration, settings.direction]);
  useEffect(() => {
    const failure = buffer.error(active.page);
    if (failure) onError(errorMessage(failure));
  }, [buffer, revision, active.page, onError]);
  useEffect(() => {
    if (shown?.page === active.page) onLoaded(active.page);
  }, [shown?.page, active.page, onLoaded]);
  useEffect(() => {
    if (!turn) return;
    if (!duration) { setTurn(undefined);return; }
    const id = setTimeout(() => setTurn(t => t?.id === turn.id ? undefined : t), duration + 35);
    return () => clearTimeout(id);
  }, [turn, duration]);
  useEffect(() => {
    if (shown) { setInitialSpinner(false);return; }
    const id = setTimeout(() => setInitialSpinner(true), 350);
    return () => clearTimeout(id);
  }, [shown]);
  useLayoutEffect(() => {
    const node = stage.current!;
    const measure = () => {
      const whole = { width: node.clientWidth, height: node.clientHeight };
      if (!isEditing) setReadingSize(old => old.width === whole.width && old.height === whole.height ? old : whole);
      setSize({ width: whole.width, height: Math.max(120, whole.height - (isEditing ? editorMetrics.top + editorMetrics.bottom : 0)) });
    };
    measure();
    const observer = new ResizeObserver(measure);observer.observe(node);
    return () => observer.disconnect();
  }, [isEditing, editorMetrics.top, editorMetrics.bottom]);

  const select = useCallback((target: number) => {
    clearTimeout(longPress.current);
    const list = current.current.steps;
    const i = Math.max(0,Math.min(list.length-1,target));
    if (i === indexRef.current) return;
    travel.current = i > indexRef.current ? 1 : -1;
    indexRef.current = i;setIndex(i);setZoom(1);setPan({ x: 0, y: 0 });
    const next = list[i];
    if (expectedPage.current !== next.page) { expectedPage.current = next.page;onPage(next.page); }
  }, [onPage]);
  const navigate = useCallback((delta: number) => {
    if (!current.current.enabled || !current.current.loaded) return;
    const target = Math.max(0,Math.min(current.current.steps.length-1,indexRef.current+delta));
    select(target);
    // The camera animates, the scroll position changes immediately. Native
    // scrolling remains available on iOS; no simulated drag or autoplay timer.
    scroll.current?.scrollTo({ top: target*current.current.stride, behavior: 'instant' });
  }, [select]);
  useImperativeHandle(ref, () => ({ next: () => navigate(1), previous: () => navigate(-1), zoom: d => setZoom(z => Math.max(1,Math.min(2.5,z+d))) }), [navigate]);
  useLayoutEffect(() => {
    let target = indexRef.current;
    if (steps !== previousSteps.current) { target = findPanelStep(steps,page,anchor.current);previousSteps.current = steps; }
    if (page !== expectedPage.current) { travel.current = page > expectedPage.current ? 1 : -1;target = findPanelStep(steps,page);expectedPage.current = page;setZoom(1);setPan({ x: 0, y: 0 }); }
    indexRef.current = target;setIndex(target);
    ignoreScroll.current = true;
    scroll.current?.scrollTo({ top: target*stride, behavior: 'instant' });
    const id = requestAnimationFrame(() => { ignoreScroll.current = false; });
    return () => cancelAnimationFrame(id);
  }, [steps, page, stride, isEditing, zoom > 1]);
  useLayoutEffect(() => {
    // Cancel a navigation RAF queued before the second tap. Lock at the same
    // stop and discard native scrolling inertia when entering/leaving zoom.
    if (frame.current !== undefined) { cancelAnimationFrame(frame.current);frame.current = undefined; }
  }, [zoom > 1]);
  useEffect(() => {
    if (pan.x !== readingPan.x || pan.y !== 0) setPan(readingPan);
  }, [pan.x, pan.y, readingPan.x]);
  useEffect(() => {
    if (!loaded || draft) return;
    const view: ReaderView = { page: active.page, mode: 'panels', panel: active.panel, part: active.part, viewPart: active.viewPart, overview: active.overview, zoom, x: readingPan.x/Math.max(1,size.width), y: 0 };
    anchor.current = view;onView(view);
  }, [active, loaded, zoom, readingPan.x, size, onView, draft]);
  useEffect(() => {
    const label = active.overview ? 'Вся страница' : map.pages[active.page].kind === 'cover' ? 'Вся страница' : `Кадр ${displayPanel} / ${visiblePanels.length}${active.parts > 1 ? ` · ${active.part+1}/${active.parts}` : ''}`;
    onState({ step: index, total: steps.length, zoom, label });
  }, [active, index, map, steps.length, zoom, onState, displayPanel, visiblePanels.length]);
  useEffect(() => () => { if (frame.current !== undefined) cancelAnimationFrame(frame.current);clearTimeout(tapTimer.current);clearTimeout(longPress.current); }, []);

  useEffect(() => {
    const node = scroll.current!;
    let gesture = { x: 0, y: 0, lastX: 0, lastY: 0, time: 0, moved: false, pinch: false, distance: 0, zoom: 1, pan: { x: 0, y: 0 } };
    const distance = (t: TouchList) => t.length >= 2 ? Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY) : 0;
    const start = (e: TouchEvent) => {
      lastTouch.current = Date.now();
      clearTimeout(longPress.current);
      if (!current.current.enabled || !current.current.loaded) return;
      const t = e.touches[0];
      if (e.touches.length === 1) {
        gesture = { x: t.clientX, y: t.clientY, lastX: t.clientX, lastY: t.clientY, time: Date.now(), moved: false, pinch: false, distance: 0, zoom: current.current.zoom, pan: current.current.pan };
        longPress.current = setTimeout(() => { gesture.moved = true;beginEdit.current(); }, 520);
      }
      if (e.touches.length === 2) { e.preventDefault();gesture.pinch = true;gesture.distance = distance(e.touches);gesture.zoom = current.current.zoom;clearTimeout(tapTimer.current);setMoving(true); }
    };
    const move = (e: TouchEvent) => {
      if (!current.current.enabled || !current.current.loaded) return;
      const t = e.touches[0];
      if (e.touches.length >= 2 && gesture.distance) { e.preventDefault();setZoom(Math.max(1,Math.min(2.5,gesture.zoom*distance(e.touches)/gesture.distance)));gesture.moved = true;return; }
      const dx = t.clientX-gesture.x, dy = t.clientY-gesture.y;
      gesture.lastX = t.clientX;gesture.lastY = t.clientY;
      if (Math.hypot(dx,dy)>8) { gesture.moved = true;clearTimeout(longPress.current); }
      if (!gesture.pinch && gesture.zoom > 1) {
        e.preventDefault();setMoving(true);
        const limit = current.current.panLimit;
        setPan({ x: Math.max(-limit,Math.min(limit,gesture.pan.x+dx)), y: 0 });
      } else if (Math.abs(dx)>Math.abs(dy)*1.5 && Math.abs(dx)>15) e.preventDefault();
    };
    const end = (e: TouchEvent) => {
      lastTouch.current = Date.now();
      clearTimeout(longPress.current);
      if (e.touches.length) return;
      setMoving(false);
      if (!current.current.enabled || !current.current.loaded || gesture.pinch) return;
      const t = e.changedTouches[0];
      const dx = t.clientX-gesture.x,dy = t.clientY-gesture.y;
      if (gesture.zoom === 1 && Math.abs(dx)>45 && Math.abs(dx)>Math.abs(dy)*1.3) { navigate((dx<0 ? 1 : -1)*(current.current.direction === 'rtl' ? -1 : 1));return; }
      if (gesture.moved || Date.now()-gesture.time>500) return;
      const now = Date.now();
      if (current.current.doubleTap && now-tap.current<280) { clearTimeout(tapTimer.current);setZoom(z => z>1 ? 1 : 1.7);setPan({ x: 0, y: 0 });tap.current = 0; }
      else { tap.current = now;tapTimer.current = setTimeout(onToggle,current.current.doubleTap ? 280 : 0); }
    };
    const cancel = () => { gesture.moved = true;gesture.pinch = true;setMoving(false);clearTimeout(tapTimer.current);clearTimeout(longPress.current); };
    node.addEventListener('touchstart',start,{ passive: false });node.addEventListener('touchmove',move,{ passive: false });node.addEventListener('touchend',end);node.addEventListener('touchcancel',cancel);
    return () => { node.removeEventListener('touchstart',start);node.removeEventListener('touchmove',move);node.removeEventListener('touchend',end);node.removeEventListener('touchcancel',cancel); };
  }, [navigate,onToggle]);
  const leaves = [...(turn ? [{ ...turn.outgoing, current: false, pose: turn.outgoing.pose }] : []), ...(shown ? [{ ...shown, current: true, pose: shownPose }] : [])];
  return <div ref={stage} className={`reader-stage panel-stage ${draft ? 'editing' : ''}`} data-testid="panel-stage" data-panel={active.panel} data-part={active.part} data-view-part={active.viewPart} data-page={active.page} data-visible-page={shown?.page} aria-busy={!loaded}
    role={draft ? 'dialog' : undefined} aria-modal={draft ? true : undefined} aria-label={draft ? 'Правка кадра' : undefined}
    onContextMenu={e => e.preventDefault()} style={{ '--page-duration': `${duration}ms`, '--turn-direction': turn?.direction ?? 1, '--editor-top': `${editorMetrics.top}px`, '--editor-bottom': `${editorMetrics.bottom}px` } as CSSProperties}>
    {leaves.map(leaf => <div key={leaf.page} className={`panel-leaf ${leaf.current ? `current ${turn ? 'entering' : ''}` : 'leaving'}`} data-testid={leaf.current ? 'panel-current' : 'panel-outgoing'} aria-hidden={leaf.current ? undefined : true}>
      <PanelSurface ref={leaf.current ? surface : undefined} canvas={leaf.canvas} crop={!draft && settings.cropMargins ? quality.get(leaf.page)?.crop : undefined} pose={leaf.pose} duration={leaf.current && !moving && !draft ? duration : 0} current={leaf.current} />
    </div>)}
    {!shown && initialSpinner && <span className="page-spinner spinner" />}
    <div ref={scroll} className={`panel-scroll ${zoom>1 ? 'zoomed' : ''}`} data-testid="panel-scroll" aria-label="Прокрутка по кадрам" tabIndex={0}
      onScroll={() => {
        if (ignoreScroll.current || !current.current.enabled || !current.current.loaded || current.current.zoom > 1) return;
        if (frame.current !== undefined) cancelAnimationFrame(frame.current);
        frame.current = requestAnimationFrame(() => {
          frame.current = undefined;
          if (!ignoreScroll.current && current.current.enabled && current.current.loaded && current.current.zoom === 1)
            select(Math.round((scroll.current?.scrollTop ?? 0)/current.current.stride));
        });
      }}
      onClick={e => { if (Date.now()-lastTouch.current>600 && e.detail === 1) onToggle(); }}
      onPointerDown={e => { if (e.pointerType === 'mouse' && e.button === 0) {
        mouseStart.current = { x: e.clientX, y: e.clientY };
        clearTimeout(longPress.current);longPress.current = setTimeout(() => { lastTouch.current = Date.now();beginEdit.current(); }, 520);
      } }}
      onPointerUp={e => { if (e.pointerType === 'mouse') clearTimeout(longPress.current); }}
      onPointerMove={e => { if (e.pointerType === 'mouse' && Math.hypot(e.clientX - mouseStart.current.x, e.clientY - mouseStart.current.y) > 8) clearTimeout(longPress.current); }}
      onPointerLeave={() => clearTimeout(longPress.current)} onPointerCancel={() => clearTimeout(longPress.current)}
      onKeyDown={e => {
        if (['ArrowDown','PageDown',' ','ArrowUp','PageUp'].includes(e.key)) {
          e.preventDefault();if (current.current.zoom === 1) navigate(['ArrowUp','PageUp'].includes(e.key) ? -1 : 1);
        }
        if (current.current.zoom > 1 && ['ArrowLeft','ArrowRight'].includes(e.key)) {
          e.preventDefault();const { pan, panLimit } = current.current;
          setPan({ x: Math.max(-panLimit, Math.min(panLimit, pan.x + (e.key === 'ArrowLeft' ? 40 : -40))), y: 0 });
        }
      }}>
      {stops}
      <div style={{ height: Math.max(0,size.height-stride) }} aria-hidden="true" />
    </div>
    <div className="panel-position" aria-hidden="true">{settings.showPage ? <>{active.page+1}<span> / {map.pageCount}</span><i /></> : null}{active.overview || map.pages[active.page].kind === 'cover' ? 'Вся страница' : `${displayPanel} / ${visiblePanels.length}`}</div>
    {!draft && undo.length > 0 && <div className="panel-undo" role="status"><span>Кадр удалён</span><button type="button" disabled={undoBusy} onClick={() => void undoDelete()}>Отменить удаление</button>{undoError && <span role="alert">{undoError}</span>}</div>}
    {draft && <PanelEditor page={draft.page} panel={draft.panel} bounds={draft.bounds} view={draft.view} mode={draft.mode}
      size={size} camera={camera} busy={editBusy} error={editError}
      onChange={(bounds, view) => setDraft(d => d ? { ...d, bounds, view } : d)}
      onMode={mode => setDraft(d => d ? { ...d, mode } : d)}
      onCancel={cancelEdit} onDelete={() => void deleteFrame()} onSave={() => void saveEdit()}
      onReset={() => setDraft(d => d ? { ...d, bounds: [...map.pages[d.page].frames[d.panel]], view: fitView(d.view.part), views: [] } : d)}
      onMetrics={(top, bottom) => setEditorMetrics(old => old.top === top && old.bottom === bottom ? old : { top, bottom })} />}
  </div>;
});
