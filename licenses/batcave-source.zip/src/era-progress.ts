import type { Comic } from './models';
import { type ChronologicalEraId, isChronologicalEra } from './eras';
import { orderedRoadmap } from './roadmap';

export interface EraPlanEntry { id: string; title: string; done: boolean }
export interface EraPlan { era: ChronologicalEraId; updatedAt: number; entries: EraPlanEntry[] }
export function normalizeEraPlans(raw: unknown): EraPlan[] {
  if (!Array.isArray(raw)) return [];
  const plans: EraPlan[] = [];
  for (const value of raw.slice(0,11)) {
    if (!value || !isChronologicalEra(value.era) || !Number.isSafeInteger(value.updatedAt) || value.updatedAt < 0 || !Array.isArray(value.entries) || plans.some(p => p.era === value.era)) continue;
    const entries: EraPlanEntry[] = [];
    for (const e of value.entries.slice(0,2000)) if (e && typeof e.id === 'string' && /^[a-zA-Z0-9_-]{1,150}$/.test(e.id) && typeof e.title === 'string' && !entries.some(x => x.id === e.id))
      entries.push({id:e.id,title:e.title.slice(0,500),done:e.done === true});
    if (entries.length) plans.push({era:value.era,updatedAt:value.updatedAt,entries});
  }
  return plans;
}
export function advanceEraPlans(comics: Comic[], plans: EraPlan[]): EraPlan[] {
  const books = new Map(comics.map(c => [c.id,c]));
  return plans.map(p => ({...p,entries:p.entries.map(e => ({...e,done:e.done || !!books.get(e.id)?.completed}))}));
}
export function captureEraPlan(comics: Comic[], era: ChronologicalEraId, now = Date.now()): EraPlan {
  const route = orderedRoadmap(comics,era);
  if (!route.length) throw Error('Сначала добавьте основные истории в маршрут этой эры.');
  if (route.length > 2000) throw Error('В маршруте эры может быть не больше 2 000 историй.');
  return {era,updatedAt:now,entries:route.map(c => ({id:c.id,title:c.title.slice(0,500),done:c.completed}))};
}
export function eraProgress(comics: Comic[], plans: EraPlan[] | undefined, era: ChronologicalEraId) {
  const current = orderedRoadmap(comics,era), plan = plans?.find(p => p.era === era);
  const books = new Map(comics.map(c => [c.id,c]));
  const entries = plan ? plan.entries.map(e => ({...e,done:e.done || !!books.get(e.id)?.completed})) : current.map(c => ({id:c.id,title:c.title,done:c.completed}));
  const done = entries.filter(e => e.done).length, total = entries.length;
  return {era,entries,done,total,planned:!!plan,complete:!!plan && total > 0 && done === total,
    changed:!!plan && (current.length !== plan.entries.length || current.some(c => !plan.entries.some(e => e.id === c.id))),
    percent:total ? Math.round(done / total * 100) : 0};
}
