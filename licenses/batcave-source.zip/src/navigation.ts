export type Tab = 'library' | 'archive' | 'settings' | 'achievements' | 'reader';
export interface Route {tab:Tab;id?:string}
export function parseRoute(hash:string):Route {
  const [tab,id]=hash.replace(/^#\/?/,'').split('/');
  if(tab==='profile')return {tab:'library'};
  if(tab==='collection')return {tab:'archive'};
  if(tab==='library'||tab==='archive'||tab==='settings'||tab==='achievements'||tab==='reader')return {tab,id:id||undefined};
  return {tab:'library'};
}
