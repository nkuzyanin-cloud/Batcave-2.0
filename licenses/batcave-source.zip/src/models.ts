export type Format = 'pdf' | 'cbz' | 'image';
export type Physical = 'yes' | 'no' | 'unknown';
export type PanelRect = [number, number, number, number];
export interface PanelViewEdit {
  // Physical half of a wide frame; independent of LTR/RTL reading order.
  part: number;
  zoom: number;
  x: number;
  y: number;
}
export interface PanelFrameEdit {
  page: number;
  panel: number;
  bounds: PanelRect;
  views: PanelViewEdit[];
  hidden?: boolean;
}
export interface PanelEdits {
  fingerprint: string;
  frames: PanelFrameEdit[];
}
export interface ReaderView {
  page: number;
  mode: 'single' | 'guided' | 'panels';
  zoom: number;
  x: number;
  y: number;
  panel?: number;
  part?: number;
  viewPart?: number;
  overview?: 'before' | 'after';
}
export interface Digital {
  assetId: string;
  format: Format;
  name: string;
  size: number;
  fingerprint: string;
}
export interface Comic {
  universeId?: string;
  id: string;
  title: string;
  series: string;
  authors: string;
  year: number | null;
  yearEnd?: number;
  addedAt: number;
  updatedAt: number;
  physical: Physical;
  physicalGroup?: string;
  // Independent paper-edition progress; digital page indices are never reused.
  paperPageCount?: number;
  paperPagesRead?: number;
  paperCompleted?: boolean;
  // Manually entered total paper-reading time; counted only after completion.
  paperSeconds?: number;
  paperTimer?: boolean;
  paperStartedAt?: number;
  edition: string;
  publisher: string;
  editionYear: number | null;
  note: string;
  rating: number;
  completed: boolean;
  completedAt?: number;
  // Explicit digital reading outside the built-in reader, including online reading.
  readDigitally?: boolean;
  // User-created cover-first reading plans, including paper titles.
  inRoadmap?: boolean;
  era?: import('./eras').EraId;
  // Optional reading attached to a stable main-route record, never a copy.
  sideStoryAfter?: string;
  page: number;
  pageCount: number;
  visited: number[];
  seconds: number;
  lastOpened: number;
  digital?: Digital;
  // The edition identity survives removing its local binary file.
  digitalFingerprint?: string;
  coverId?: string;
  photoId?: string;
  tone: string;
  readerView?: ReaderView;
  panelEdits?: PanelEdits;
  // Automatic layouts and their edits have separate identities from legacy maps.
  autoPanels?: import('./reader/panels').PanelMap;
  autoPanelEdits?: PanelEdits;
}
export interface Asset {
  id: string;
  blob: Blob;
}
export interface Settings {
  roadmapEra?: import('./eras').EraId;
  mode: 'single' | 'vertical' | 'guided' | 'panels';
  direction: 'ltr' | 'rtl';
  motion: 'system' | 'full' | 'fast' | 'off';
  readerTheme: 'black' | 'gray' | 'light';
  doubleTap: boolean;
  showPage: boolean;
  cropMargins: boolean;
  panelOpacity: number;
  panelPageFirst: boolean;
  panelPageLast: boolean;
  groupSeries: boolean;
  sort: 'added' | 'title' | 'year';
}
export const defaultSettings: Settings = {
  mode: 'single',
  direction: 'ltr',
  motion: 'system',
  readerTheme: 'black',
  doubleTap: true,
  showPage: true,
  cropMargins: false,
  panelOpacity: 0.75,
  panelPageFirst: false,
  panelPageLast: false,
  groupSeries: false,
  sort: 'added',
};
export function status(c: Comic): 'done' | 'reading' | 'new' {
  if (c.completed) return 'done';
  // An opening timestamp, file import or bookmark alone is not reading.
  const pages = new Set(c.visited.filter(p => Number.isInteger(p) && p >= 0 && p < c.pageCount));
  const paperStarted = c.physical === 'yes' && (paperReadPages(c) > 0 || c.paperStartedAt !== undefined || (c.paperTimer && (c.paperSeconds ?? 0) > 0));
  return pages.size >= 3 || paperStarted ? 'reading' : 'new';
}
export const percent = (c: Comic) =>
  c.completed ? 100 : c.pageCount ? Math.round((c.visited.length / c.pageCount) * 100) : 0;
export function blankComic(title = 'Новый комикс'): Comic {
  const now = Date.now();
  return {
    id: crypto.randomUUID(),
    title,
    series: 'DC',
    authors: '',
    year: null,
    addedAt: now,
    updatedAt: now,
    physical: 'unknown',
    edition: '',
    publisher: '',
    editionYear: null,
    note: '',
    rating: 0,
    completed: false,
    page: 0,
    pageCount: 0,
    visited: [],
    seconds: 0,
    lastOpened: 0,
    tone: '#79a9be',
  };
}
export const PAPER_PAGE_LIMIT = 100000;
export function paperFinished(c: Comic) {
  // Existing explicitly completed paper-only records keep their meaning.
  return c.paperCompleted ?? (c.physical === 'yes' && c.completed && !c.digital &&
    !c.readDigitally && !c.lastOpened && !c.visited.length);
}
export function paperReadPages(c: Comic) {
  const total = c.paperPageCount ?? 0;
  if (!total) return 0;
  return paperFinished(c) ? total : c.paperSeconds !== undefined ? 0 : Math.min(total, c.paperPagesRead ?? 0);
}
export function readPages(c: Comic) {
  // A story in two formats counts once. Without a page correspondence map,
  // the larger confirmed progress is the conservative count, not their sum.
  return Math.max(c.visited.length, paperReadPages(c));
}
export function paperTime(c: Comic, now = Date.now()) {
  const elapsed = c.paperStartedAt === undefined ? 0 : Math.max(0, Math.floor((now - c.paperStartedAt) / 1000));
  return c.paperTimer ? (c.paperSeconds ?? 0) + elapsed : paperFinished(c) ? c.paperSeconds ?? 0 : 0;
}
export function stopPaperSession(c: Comic, now = Date.now()): Comic {
  return { ...c, paperTimer: true, paperSeconds: (c.paperSeconds ?? 0) + (c.paperStartedAt === undefined ? 0 : Math.max(0, Math.floor((now - c.paperStartedAt) / 1000))), paperStartedAt: undefined };
}
export function stats(comics: Comic[], now = Date.now()) {
  return {
    total: comics.length,
    digital: comics.filter((c) => c.digital).length,
    done: comics.filter((c) => c.completed).length,
    reading: comics.filter((c) => status(c) === 'reading').length,
    pages: comics.reduce((n, c) => n + readPages(c), 0),
    paper: new Set(comics.filter((c) => c.physical === 'yes').map((c) => c.physicalGroup || c.id))
      .size,
    seconds: comics.reduce((n, c) => n + c.seconds + paperTime(c, now), 0),
  };
}
export function errorMessage(error: unknown) {
  const msg = error instanceof Error ? error.message : String(error);
  if (/password|encrypted/i.test(msg))
    return 'Файл защищён паролем. Добавьте незашифрованную копию.';
  if (/End of central|Bad format|Invalid signature|invalid.*zip|CRC|checksum/i.test(msg))
    return 'Архив повреждён или не соответствует формату ZIP / CBZ. Выберите другую копию файла.';
  if (/Invalid PDF|Missing PDF/i.test(msg))
    return 'PDF повреждён или не содержит корректного документа.';
  if (/quota|disk|space/i.test(msg))
    return 'Недостаточно места на устройстве. Освободите место или удалите цифровой файл в настройках.';
  if (/memory|allocation|out of/i.test(msg))
    return 'Не хватает памяти для этого файла. Попробуйте меньший файл и закройте другие приложения.';
  return msg || 'Не удалось выполнить действие.';
}
export const bytes = (n: number) =>
  n < 1024 * 1024 ? `${Math.round(n / 1024)} КБ` : `${(n / 1024 / 1024).toFixed(1)} МБ`;
