export const SHELF_SIZE=50;
export const SHELF_PAGE_GOAL=100000;

// Early additions arrive often; the final spine coincides with 100,000 pages.
// Index 0 is the empty shelf; level 1 starts with the first library record.
export const LEVEL_PAGES=Array.from({length:SHELF_SIZE+1},(_,level)=>{
  if(level<=1)return 0;
  if(level<=10)return (level-1)*500;
  if(level<=20)return 4500+(level-10)*1000;
  if(level<=30)return 14500+(level-20)*2000;
  if(level<=40)return 34500+(level-30)*3000;
  if(level<50)return 64500+(level-40)*3500;
  return SHELF_PAGE_GOAL;
});

export function readerLevel(pages:number,hasComics:boolean) {
  const counted=Number.isFinite(pages)?Math.max(0,Math.floor(pages)):0;
  let level=hasComics?1:0;
  if(hasComics)while(level<SHELF_SIZE&&counted>=LEVEL_PAGES[level+1])level++;
  return {level,pages:counted,next:level>0&&level<SHELF_SIZE?LEVEL_PAGES[level+1]:undefined};
}

export function pagesLabel(count:number) {
  const last=count%10,ending=count%100;
  return last===1&&ending!==11?'страница':last>=2&&last<=4&&(ending<12||ending>14)?'страницы':'страниц';
}
