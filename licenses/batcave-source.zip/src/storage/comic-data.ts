import type { Comic } from '../models';

export const editionFingerprint = (c: Comic) => c.digital?.fingerprint ?? c.digitalFingerprint ?? c.autoPanels?.sha256;

// Repair only known legacy states; never infer visits, time or completion.
export function normalizeComic(record: Comic): Comic {
  const c = { ...record };
  c.title = c.title.trim() || c.digital?.name.replace(/\.[^.]+$/, '').trim() || 'Без названия';
  const fingerprint = editionFingerprint(c);
  if (fingerprint) c.digitalFingerprint = fingerprint;
  if (!c.paperTimer && !c.paperCompleted && c.paperSeconds === 0 && (c.paperPagesRead ?? 0) > 0)
    c.paperSeconds = undefined;
  if (c.panelEdits && fingerprint && c.panelEdits.fingerprint !== fingerprint) c.panelEdits = undefined;
  if (c.panelEdits) {
    const frames = c.panelEdits.frames.filter(f => f.page < c.pageCount);
    c.panelEdits = frames.length ? { ...c.panelEdits, frames } : undefined;
  }
  if (c.autoPanels && ((fingerprint && c.autoPanels.sha256 !== fingerprint) || c.autoPanels.pageCount !== c.pageCount)) {
    c.autoPanels = undefined;
    c.autoPanelEdits = undefined;
  }
  if (c.autoPanelEdits && (!c.autoPanels || c.autoPanelEdits.fingerprint !== c.autoPanels.sha256)) c.autoPanelEdits = undefined;
  return c;
}

// Metadata editors send a patch relative to the record they opened, so the
// latest reading state cannot be replaced by an old whole-object snapshot.
const metadataKeys = ['title', 'series', 'authors', 'year', 'yearEnd', 'physical', 'physicalGroup',
  'paperPageCount', 'edition', 'publisher', 'editionYear', 'note', 'rating', 'completed',
  'readDigitally', 'inRoadmap', 'era', 'sideStoryAfter', 'coverId', 'photoId', 'tone'] as const;
export function mergeMetadata(latest: Comic, edited: Comic, base: Comic): Comic {
  const next = { ...latest };
  for (const key of metadataKeys) {
    if (edited[key] === base[key]) continue;
    // Same value is harmless. A different concurrent metadata edit is explicit.
    if (latest[key] !== base[key] && latest[key] !== edited[key])
      throw Error('Карточка изменена в другом окне. Закройте её и откройте заново; ваши данные не перезаписаны.');
    Object.assign(next, { [key]: edited[key] });
  }
  if (edited.completed !== base.completed && !edited.completed) {
    next.paperCompleted = false; next.paperPagesRead = 0;
  }
  // Changing a known paper length keeps already confirmed partial progress.
  if (next.paperPageCount !== latest.paperPageCount)
    next.paperPagesRead = next.paperCompleted ? next.paperPageCount ?? 0
      : Math.min(latest.paperPagesRead ?? 0, next.paperPageCount ?? 0);
  return next;
}
