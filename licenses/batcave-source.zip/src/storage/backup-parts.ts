import { z } from 'zod';
import { ZipWriter, BlobWriter, BlobReader, TextReader, TextWriter, type FileEntry } from '@zip.js/zip.js';
import { sha256 } from '@noble/hashes/sha2.js';
import { checksum, checkedExport, exportSnapshot, parseBackup, prepareRestore, type Backup, type PreparedBackup } from './backup';
import { dbPromise, allComics } from './db';
import { openZip, detectFormat } from '../reader/source';

export const BACKUP_PART_BYTES = 250 * 1024 * 1024;
const JSON_BYTES = 8 * 1024 * 1024;
const CHUNK_BYTES = 16 * 1024 * 1024;
const PAYLOAD_BYTES = BACKUP_PART_BYTES - JSON_BYTES - 1024 * 1024;
const MANIFEST = 'batcave-parts.json';
const hex = (b: Uint8Array) => Array.from(b).map(n => n.toString(16).padStart(2, '0')).join('');
const pieceSchema = z.object({
  assetId: z.string().regex(/^[a-zA-Z0-9_-]{1,150}$/),
  index: z.number().int().min(0).max(99999), part: z.number().int().min(1).max(10000),
  path: z.string().regex(/^chunks\/[a-zA-Z0-9_-]+\/[0-9]{5}$/),
  size: z.number().int().min(1).max(CHUNK_BYTES), sha256: z.string().regex(/^[a-f0-9]{64}$/),
});
const manifestSchema = z.object({
  app: z.literal('BATCAVE'), version: z.literal(2), kind: z.literal('multipart'),
  setId: z.string().regex(/^[a-zA-Z0-9_-]{1,100}$/),
  parts: z.number().int().min(1).max(10000), backup: z.unknown(),
  chunks: z.array(pieceSchema).max(100000),
});
const envelopeSchema = z.object({part: z.number().int().min(1).max(10000), manifest: manifestSchema});
type Piece = z.infer<typeof pieceSchema>;
type Manifest = Omit<z.infer<typeof manifestSchema>, 'backup'> & { backup: Backup };
type Envelope = {part: number; manifest: Manifest};

function parseEnvelope(raw: unknown): Envelope {
  const parsed = envelopeSchema.safeParse(raw);
  if (!parsed.success) throw Error('Некорректная часть резервной копии.');
  const {part, manifest:m} = parsed.data, backup = parseBackup(m.backup);
  if (backup.kind !== 'full' || part > m.parts) throw Error('Повреждён комплект резервной копии.');
  const paths = new Set<string>();
  const ids = new Set(backup.assets.map(a => a.id));
  for (const c of m.chunks) {
    if (!ids.has(c.assetId) || c.part > m.parts || c.path !== `chunks/${c.assetId}/${String(c.index).padStart(5,'0')}` || paths.has(c.path))
      throw Error('Повреждён список файлов резервной копии.');
    paths.add(c.path);
  }
  for (const a of backup.assets) {
    const chunks = m.chunks.filter(c => c.assetId === a.id).sort((a,b) => a.index-b.index);
    if (chunks.reduce((n,c) => n+c.size,0) !== a.size || chunks.some((c,i) => c.index !== i))
      throw Error('В резервной копии отсутствует фрагмент файла.');
  }
  const used = new Set(m.chunks.map(c => c.part));
  if (m.parts > 1 && Array.from({length:m.parts},(_,i)=>i+1).some(n=>!used.has(n)))
    throw Error('Повреждена нумерация частей.');
  return {part,manifest:{...m,backup}};
}

export interface BackupParts {
  count: number; totalBytes: number; names: string[];
  makePart: (index: number, onProgress: (message: string) => void) => Promise<Blob>;
}

// The snapshot holds original Blob references, not decompressed comic pages.
// Only one bounded ZIP is produced when its download button is pressed.
export async function exportParts(onProgress: (message: string) => void, options: {chunkBytes?: number; payloadBytes?: number; signal?: AbortSignal} = {}): Promise<BackupParts> {
  const snapshot = await exportSnapshot(true), chunks: Piece[] = [], assets: Backup['assets'] = [];
  const chunkBytes = Math.min(CHUNK_BYTES, Math.max(1, options.chunkBytes ?? CHUNK_BYTES));
  const payloadBytes = Math.min(PAYLOAD_BYTES, Math.max(chunkBytes, options.payloadBytes ?? PAYLOAD_BYTES));
  let part = 1, payload = 0, totalBytes = 0, processed = 0;
  for (const [id,a] of snapshot.assets) {
    const hash = sha256.create();
    for(let offset=0,index=0;offset<a.blob.size;offset+=chunkBytes,index++) {
      if(options.signal?.aborted)throw new DOMException('Отменено','AbortError');
      const b = new Uint8Array(await a.blob.slice(offset,offset+chunkBytes).arrayBuffer());
      hash.update(b);
      if (payload && payload+b.length>payloadBytes) {part++;payload=0;}
      chunks.push({assetId:id,index,part,path:`chunks/${id}/${String(index).padStart(5,'0')}`,size:b.length,sha256:hex(sha256(b))});
      payload+=b.length; totalBytes+=b.length;
      onProgress(`Проверка файлов · ${Math.round(totalBytes/1024/1024)} МБ`);
    }
    assets.push({id,path:`assets/${id}`,size:a.blob.size,mime:a.blob.type,sha256:hex(hash.digest())});
    processed++; onProgress(`Проверено файлов: ${processed} из ${snapshot.assets.size}`);
  }
  const backup = checkedExport({app:'BATCAVE',version:1,kind:'full',createdAt:Date.now(),comics:snapshot.comics,settings:snapshot.settings,achievements:snapshot.achievements,assets});
  for(const c of backup.comics) if(c.digital) {
    const original=assets.find(a=>a.id===c.digital!.assetId);
    if(!original||original.size!==c.digital.size||original.sha256!==c.digital.fingerprint)
      throw Error(`Файл «${c.title}» не соответствует карточке. Копия не создана.`);
  }
  for(const c of backup.comics) for(const id of [c.digital?.assetId,c.coverId,c.photoId])
    if(id&&!snapshot.assets.has(id))throw Error('Файл из библиотеки отсутствует. Проверьте цифровые копии.');
  const setId = crypto.randomUUID();
  const manifest:Manifest = {app:'BATCAVE',version:2,kind:'multipart',setId,parts:part,backup,chunks};
  const stamp = new Date(backup.createdAt).toISOString().slice(0,10);
  const names = Array.from({length:part},(_,i)=>`BATCAVE-${stamp}-${setId.slice(0,8)}-${String(i+1).padStart(3,'0')}-of-${String(part).padStart(3,'0')}.zip`);
  // Validate even an empty library, before displaying any download controls.
  parseEnvelope({part:1,manifest});
  if (new Blob([JSON.stringify({part:1,manifest})]).size>JSON_BYTES) throw Error('Метаданные библиотеки слишком велики для одной части.');
  let packing = false;
  return {count:part,totalBytes,names,async makePart(index,onProgress) {
    if(!Number.isInteger(index)||index<0||index>=part)throw Error('Неверный номер части.');
    if(packing)throw Error('Дождитесь подготовки текущей части.');
    packing=true;
    const writer=new ZipWriter(new BlobWriter('application/zip'),{level:0});
    try {
      const selected=chunks.filter(c=>c.part===index+1);
      for(const [i,c] of selected.entries()) {
        onProgress(`Часть ${index+1} из ${part} · фрагмент ${i+1} из ${selected.length}`);
        const original=snapshot.assets.get(c.assetId)!.blob;
        await writer.add(c.path,new BlobReader(original.slice(c.index*chunkBytes,c.index*chunkBytes+c.size)));
      }
      await writer.add(MANIFEST,new TextReader(JSON.stringify({part:index+1,manifest})));
      const result=await writer.close();
      if(result.size>BACKUP_PART_BYTES)throw Error('Часть резервной копии превышает 250 МБ.');
      return result;
    } catch(e) {await writer.close().catch(()=>{});throw e;}
    finally {packing=false;}
  }};
}

export async function discardPrepared(prepared?: PreparedBackup) {
  if (!prepared?.staged) return;
  const db=await dbPromise,tx=db.transaction('backupStage','readwrite');
  for(const keys of prepared.staged.values())for(const key of keys)if(key)await tx.store.delete(key);
  await tx.done;
}

// Choose several parts, or one enclosing ZIP. Parts are opened one at a time.
// Verified 16-MB pieces are staged on disk; current books are untouched until
// the existing atomic restore transaction commits the complete validated set.
export async function prepareRestoreParts(files: File[], onProgress: (message: string) => void, signal?: AbortSignal): Promise<PreparedBackup> {
  if(!files.length)throw Error('Выберите резервную копию.');
  if(files.length===1&&/\.json$/i.test(files[0].name))return prepareRestore(files[0],onProgress);
  const staged=new Map<string,string[]>(),session=crypto.randomUUID();
  const {zip:firstZip,entries:firstEntries}=await openZip(files[0]);
  const close: (()=>Promise<unknown>)[]=[()=>firstZip.close()];
  let inputs: {name:string;load:()=>Promise<Blob>}[];
  try {
    if(firstEntries.some(e=>e.filename==='batcave.json')) {
      if(files.length!==1)throw Error('Старая резервная копия выбирается одним ZIP-файлом.');
      await firstZip.close();close.length=0;return prepareRestore(files[0],onProgress);
    }
    if(firstEntries.some(e=>e.filename===MANIFEST)) inputs=files.map(f=>({name:f.name,load:async()=>f}));
    else {
      if(files.length!==1)throw Error('Выберите либо все части, либо один общий ZIP.');
      const nested=firstEntries.filter((e):e is FileEntry=>!e.directory&&!e.filename.startsWith('__MACOSX/')&&!e.filename.split('/').at(-1)?.startsWith('._')&&/\.zip$/i.test(e.filename));
      if(!nested.length)throw Error('В ZIP нет резервной копии BATCAVE или её частей.');
      inputs=nested.map(e=>({name:e.filename,load:async()=>{
        if(e.encrypted||e.uncompressedSize>BACKUP_PART_BYTES)throw Error('Вложенная часть больше 250 МБ или зашифрована.');
        const b=await e.getData(new BlobWriter('application/zip'),{checkSignature:true});if(!b)throw Error('Не удалось прочитать часть копии.');return b;
      }}));
    }
    let common:Manifest|undefined,canonical='',seen=new Set<number>();
    const db=await dbPromise;
    for(const [i,input] of inputs.entries()) {
      if(signal?.aborted)throw new DOMException('Отменено','AbortError');
      onProgress(`Проверка части ${i+1} из ${inputs.length}`);
      const blob=await input.load();
      if(blob.size>BACKUP_PART_BYTES)throw Error('Отдельная часть превышает 250 МБ.');
      const {zip,entries}=await openZip(blob);
      try {
        const e=entries.find(e=>e.filename===MANIFEST);
        if(!e||e.directory||e.encrypted||e.uncompressedSize>JSON_BYTES)throw Error('В части нет корректного списка файлов.');
        const {part,manifest}=parseEnvelope(JSON.parse((await e.getData(new TextWriter(),{checkSignature:true}))!));
        const serialized=JSON.stringify(manifest);
        if(common&&(manifest.setId!==common.setId||serialized!==canonical))throw Error('Выбраны части из разных резервных копий.');
        if(seen.has(part))throw Error(`Часть ${part} выбрана дважды.`);
        if(!common){common=manifest;canonical=serialized;for(const a of common.backup.assets)staged.set(a.id,[]);}
        seen.add(part);
        for(const c of manifest.chunks.filter(c=>c.part===part)) {
          if(signal?.aborted)throw new DOMException('Отменено','AbortError');
          const entry=entries.find(e=>e.filename===c.path);
          if(!entry||entry.directory||entry.encrypted||entry.uncompressedSize!==c.size)throw Error('В части отсутствует или повреждён фрагмент файла.');
          const piece=await entry.getData(new BlobWriter(),{checkSignature:true});
          if(!piece||await checksum(piece)!==c.sha256)throw Error('Контрольная сумма фрагмента не совпадает.');
          const key=`${session}:${c.assetId}:${c.index}`;
          // Track before writing so cancellation/failure can clean the entry.
          staged.get(c.assetId)![c.index]=key;
          await db.put('backupStage',{id:key,blob:piece,createdAt:Date.now()});
        }
      }finally{await zip.close();}
    }
    if(!common)throw Error('Не удалось прочитать резервную копию.');
    const missing=Array.from({length:common.parts},(_,i)=>i+1).filter(n=>!seen.has(n));
    if(missing.length)throw Error(`Не хватает частей: ${missing.join(', ')}. Выберите весь комплект.`);
    const byId=new Map(common.backup.assets.map(a=>[a.id,a]));
    for(const [i,a] of common.backup.assets.entries()) {
      if(signal?.aborted)throw new DOMException('Отменено','AbortError');
      onProgress(`Проверка файла ${i+1} из ${common.backup.assets.length}`);
      const pieces:Blob[]=[];
      for(const key of staged.get(a.id)!) {
        const entry=await db.get('backupStage',key);if(!entry)throw Error('В копии отсутствует фрагмент.');pieces.push(entry.blob);
      }
      const blob=new Blob(pieces,{type:a.mime});
      if(blob.size!==a.size||await checksum(blob)!==a.sha256)throw Error('Контрольная сумма файла не совпадает.');
      for(const c of common.backup.comics.filter(c=>c.digital?.assetId===a.id)) {
        if(c.digital!.size!==a.size||c.digital!.fingerprint!==a.sha256||await detectFormat(blob,c.digital!.name)!==c.digital!.format)
          throw Error('Цифровой файл не соответствует карточке.');
      }
    }
    for(const c of common.backup.comics)for(const key of [c.digital?.assetId,c.coverId,c.photoId])
      if(key&&!byId.has(key))throw Error('В копии отсутствует вложение комикса.');
    const local=await allComics();
    const conflicts=common.backup.comics.filter(c=>local.some(l=>l.id===c.id||(l.digital&&c.digital&&l.digital.fingerprint===c.digital.fingerprint))).length;
    return {data:common.backup,assets:new Map(),staged,conflicts};
  }catch(e){await discardPrepared({data:undefined as unknown as Backup,assets:new Map(),staged,conflicts:0});throw e;}
  finally {for(const dispose of close)await dispose();}
}
