import {dbPromise} from './db';

const key=(universeId:string)=>`route-disclosures-v1:${universeId}`;
const normalize=(value:unknown)=>new Set<string>(Array.isArray(value)?value.filter((id):id is string=>typeof id==='string'):[]);

export async function getCollapsedSections(universeId:string) {
  return normalize(await (await dbPromise).get('config',key(universeId)));
}

// Merge one disclosure in a transaction so independent chapter changes in
// another window cannot overwrite each other with stale snapshots.
export async function saveSectionDisclosure(universeId:string,chapterId:string,collapsed:boolean) {
  const db=await dbPromise,tx=db.transaction('config','readwrite');
  void tx.done.catch(()=>{});
  const ids=normalize(await tx.store.get(key(universeId)));
  if(collapsed)ids.add(chapterId);else ids.delete(chapterId);
  await tx.store.put([...ids],key(universeId));
  await tx.done;
}
