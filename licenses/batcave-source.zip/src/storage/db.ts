import { openDB, type DBSchema } from 'idb';
import { type Comic, type Asset, type Settings, type ReaderView, type PanelFrameEdit, defaultSettings, paperFinished, stopPaperSession } from '../models';
import { isUntouchedLegacySeed } from '../data/catalog';
import { replaceFrameEdit, validFrameEdit } from '../reader/panel-edits';
import { parsePanelMap, type PanelMap } from '../reader/panels';
import { completionDate, completionStamp } from '../completion';
interface Schema extends DBSchema {
  comics: { key: string; value: Comic };
  assets: { key: string; value: Asset };
  config: { key: string; value: unknown };
}
export const dbPromise = openDB<Schema>('batcave-reader', 1, {
  upgrade(db) {
    db.createObjectStore('comics', { keyPath: 'id' });
    db.createObjectStore('assets', { keyPath: 'id' });
    db.createObjectStore('config');
  },
  blocked() {
    window.dispatchEvent(new Event('batcave-blocked'));
  },
  blocking() {
    void dbPromise.then((db) => db.close());
  },
});
export async function initialize() {
  const db = await dbPromise;
  const tx = db.transaction(['comics', 'config'], 'readwrite');
  if (!(await tx.objectStore('config').get('initialized'))) {
    await tx.objectStore('config').put(true, 'initialized');
  }
  if (!(await tx.objectStore('config').get('minimal-ui-v1'))) {
    for (const c of await tx.objectStore('comics').getAll()) {
      if (isUntouchedLegacySeed(c)) await tx.objectStore('comics').delete(c.id);
    }
    await tx.objectStore('config').put(true, 'minimal-ui-v1');
  }
  if (!(await tx.objectStore('config').get('completion-date-v1'))) {
    for (const c of await tx.objectStore('comics').getAll())
      if(c.completed && c.completedAt===undefined)
        await tx.objectStore('comics').put({...c,completedAt:completionDate(c)});
    await tx.objectStore('config').put(true,'completion-date-v1');
  }
  await tx.done;
}
export async function allComics() {
  return (await dbPromise).getAll('comics');
}
export async function getAsset(id: string) {
  return (await dbPromise).get('assets', id);
}
export async function saveSettings(s: Settings) {
  await (await dbPromise).put('config', s, 'settings');
}
export async function getSettings(): Promise<Settings> {
  return {
    ...defaultSettings,
    ...((await (await dbPromise).get('config', 'settings')) as Partial<Settings> | undefined),
  };
}
export async function saveComic(comic: Comic, assets: Asset[] = [], remove: string[] = [], preservePaperTimer = false) {
  const db = await dbPromise;
  const tx = db.transaction(['comics', 'assets'], 'readwrite');
  if (comic.sideStoryAfter) {
    const anchor = await tx.objectStore('comics').get(comic.sideStoryAfter);
    if (!anchor || anchor.sideStoryAfter || anchor.id===comic.id) {
      await tx.done;throw Error('Основной комикс был удалён или перемещён. Откройте окно заново.');
    }
  }
  for (const a of assets) await tx.objectStore('assets').put(a);
  for (const id of remove) await tx.objectStore('assets').delete(id);
  let edited = comic;
  const latest = await tx.objectStore('comics').get(comic.id);
  if (preservePaperTimer) {
    if (latest?.paperTimer) edited = { ...comic, paperTimer: true, paperSeconds: latest.paperSeconds, paperStartedAt: latest.paperStartedAt };
    if (edited.paperStartedAt !== undefined && (paperFinished(edited) || edited.physical !== 'yes')) edited = stopPaperSession(edited);
  }
  const now=Date.now();
  await tx.objectStore('comics').put({ ...edited, completedAt:completionStamp(edited,latest,now), updatedAt: now });
  await tx.done;
}
export async function paperSession(id: string, start: boolean, now = Date.now()) {
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  const c = await tx.store.get(id);
  if (!c) { await tx.done; throw Error('Сначала сохраните книгу.'); }
  if (start && (c.physical !== 'yes' || paperFinished(c))) { await tx.done; throw Error('Издание уже прочитано или не отмечено как бумажное.'); }
  // One session at a time. Switching books settles the previous session atomically.
  if (start) for (const other of await tx.store.getAll()) {
    if (other.id !== id && other.paperStartedAt !== undefined) await tx.store.put({ ...stopPaperSession(other, now), updatedAt: now });
  }
  const result = start ? { ...c, paperTimer: true, paperSeconds: c.paperSeconds ?? 0, paperStartedAt: c.paperStartedAt ?? now } : stopPaperSession(c, now);
  await tx.store.put({ ...result, updatedAt: now });
  await tx.done;
  return result;
}
export async function completePaperSession(id: string, done: boolean, total: number | undefined, now = Date.now()) {
  if (total !== undefined && (!Number.isInteger(total) || total < 1 || total > 100000)) throw Error('Укажите целое количество страниц.');
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  const c = await tx.store.get(id);
  if (!c) { await tx.done; throw Error('Книга была удалена.'); }
  const digitalDone = c.completed && (!!c.readDigitally || (c.pageCount > 0 && c.visited.length === c.pageCount) || (!paperFinished(c) && !!c.digital));
  const result = { ...(done ? stopPaperSession(c, now) : c), paperPageCount: total, paperPagesRead: done ? total ?? 0 : 0, paperCompleted: done, completed: done || digitalDone, ...(digitalDone ? { readDigitally: true } : {}), updatedAt: now };
  const dated={...result,completedAt:completionStamp(result,c,now)};
  await tx.store.put(dated); await tx.done;
  return dated;
}
export async function updateProgress(id: string, page: number, loaded: boolean, seconds = 0) {
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  const c = await tx.store.get(id);
  if (c) {
    const p = Math.min(Math.max(0, page), Math.max(0, c.pageCount - 1));
    const visited = loaded
      ? Array.from(new Set([...c.visited, p])).sort((a, b) => a - b)
      : c.visited;
    const now=Date.now(),completed=c.completed || (c.pageCount > 0 && visited.length === c.pageCount);
    await tx.store.put({
      ...c,
      page: p,
      visited,
      seconds: c.seconds + Math.max(0, seconds),
      completed,
      completedAt:completionStamp({...c,completed},c,now),
      lastOpened: now,
      updatedAt: now,
    });
  }
  await tx.done;
}
export async function deleteDigital(c: Comic) {
  const db = await dbPromise;
  const tx = db.transaction(['comics', 'assets'], 'readwrite');
  const latest = await tx.objectStore('comics').get(c.id);
  if (latest) {
    if (latest.digital) await tx.objectStore('assets').delete(latest.digital.assetId);
    await tx.objectStore('comics').put({
      ...latest,
      ...(latest.digital && latest.completed ? { readDigitally: true } : {}),
      digital: undefined, readerView: undefined, updatedAt: Date.now(),
    });
  }
  await tx.done;
}
export async function saveReaderView(id: string, view: ReaderView) {
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  const c = await tx.store.get(id);
  if (c?.digital && c.page === view.page)
    await tx.store.put({ ...c, readerView: view });
  await tx.done;
}
export async function savePanelEdit(id: string, fingerprint: string, page: number, panel: number, edit: PanelFrameEdit | null) {
  if (!Number.isInteger(page) || page < 0 || !Number.isInteger(panel) || panel < 0 || panel >= 100 ||
      (edit && (!validFrameEdit(edit) || edit.page !== page || edit.panel !== panel)))
    throw Error('Некорректная правка кадра.');
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  const c = await tx.store.get(id);
  if (!c?.digital || c.digital.fingerprint !== fingerprint || page >= c.pageCount) {
    tx.abort();await tx.done.catch(() => {});
    throw Error('Комикс изменился или был удалён. Правка не сохранена.');
  }
  if(c.autoPanels && panel >= c.autoPanels.pages[page].frames.length) {
    await tx.done;throw Error('Кадр отсутствует в разметке.');
  }
  const key = c.autoPanels ? 'autoPanelEdits' : 'panelEdits';
  const panelEdits = replaceFrameEdit(c[key], fingerprint, page, panel, edit);
  const updated = { ...c, updatedAt: Date.now() };
  if (panelEdits) updated[key] = panelEdits;else delete updated[key];
  // Merge into the latest record in one transaction. Active-time/progress
  // writes may run alongside the editor and must never be overwritten.
  await tx.store.put(updated);await tx.done;
  return panelEdits;
}
export async function saveAutomaticPanels(id: string, map: PanelMap) {
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  const c = await tx.store.get(id);
  if (!c?.digital || c.digital.fingerprint !== map.sha256 || c.pageCount !== map.pageCount) {
    await tx.done;throw Error('Комикс изменился или был удалён.');
  }
  parsePanelMap(map,c.digital.fingerprint,c.pageCount);
  if(c.autoPanels) { await tx.done;return c; }
  // Copy corrections by spatial overlap, never by indices from a different map.
  // The untouched legacy corrections remain available in the original field.
  const frames: PanelFrameEdit[]=[];
  if(c.panelEdits?.fingerprint===map.sha256) for(const edit of c.panelEdits.frames) {
    const candidates=map.pages[edit.page]?.frames;
    if(!candidates) continue;
    const scores=candidates.map(r=>{
      const b=edit.bounds;
      const n=Math.max(0,Math.min(b[0]+b[2],r[0]+r[2])-Math.max(b[0],r[0])) * Math.max(0,Math.min(b[1]+b[3],r[1]+r[3])-Math.max(b[1],r[1]));
      return n/(b[2]*b[3]+r[2]*r[3]-n);
    });
    const best=Math.max(...scores), panel=scores.indexOf(best);
    if(best>=.5 && !frames.some(f=>f.page===edit.page && f.panel===panel)) frames.push({...edit,panel,views:[]});
  }
  const updated={...c,autoPanels:map,autoPanelEdits:frames.length?{fingerprint:map.sha256,frames}:undefined,
    readerView:undefined,updatedAt:Date.now()};
  await tx.store.put(updated);await tx.done;return updated;
}
export async function deleteComic(c: Comic) {
  const db = await dbPromise;
  const tx = db.transaction(['comics', 'assets'], 'readwrite');
  const latest = await tx.objectStore('comics').get(c.id);
  await tx.objectStore('comics').delete(c.id);
  for (const child of await tx.objectStore('comics').getAll())
    if (child.sideStoryAfter === c.id)
      await tx.objectStore('comics').put({...child, sideStoryAfter:undefined, inRoadmap:true, updatedAt:Date.now()});
  for (const id of [latest?.digital?.assetId, latest?.coverId, latest?.photoId])
    if (id) await tx.objectStore('assets').delete(id);
  await tx.done;
}
export async function setSideStory(id:string, afterId:string, attach:boolean) {
  const db = await dbPromise, tx = db.transaction('comics','readwrite');
  const all = await tx.store.getAll(), comic = all.find(c=>c.id===id), anchor = all.find(c=>c.id===afterId);
  if (!comic || (attach && (!anchor || anchor.sideStoryAfter || id===afterId || all.some(c=>c.sideStoryAfter===id)))) {
    await tx.done; throw Error('Комикс или основной пункт маршрута изменился. Откройте окно заново.');
  }
  if (!attach && comic.sideStoryAfter!==afterId) {await tx.done;throw Error('Комикс уже перемещён. Откройте окно заново.');}
  const updated = {...comic, sideStoryAfter: attach ? afterId : undefined, inRoadmap:!attach, updatedAt:Date.now()};
  await tx.store.put(updated);await tx.done;return updated;
}
export async function resetProgress() {
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  for (const c of await tx.store.getAll())
    await tx.store.put({
      ...c,
      page: 0,
      visited: [],
      completed: false,
      completedAt: undefined,
      readDigitally: undefined,
      paperPagesRead: 0,
      paperSeconds: 0,
      paperStartedAt: undefined,
      paperCompleted: false,
      seconds: 0,
      lastOpened: 0,
      readerView: undefined,
      updatedAt: Date.now(),
    });
  await tx.done;
}
export async function usage() {
  const db = await dbPromise;
  let local = 0;
  for await (const cursor of db.transaction('assets').store) {
    local += cursor.value.blob.size;
  }
  const estimate = await navigator.storage?.estimate?.().catch(() => ({}) as StorageEstimate);
  return { local, estimate };
}
