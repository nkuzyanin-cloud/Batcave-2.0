import { openDB, type DBSchema, type IDBPTransaction } from 'idb';
import { type Comic, type Asset, type Settings, type ReaderView, type PanelFrameEdit, defaultSettings, paperFinished, stopPaperSession } from '../models';
import { isUntouchedLegacySeed } from '../data/catalog';
import { replaceFrameEdit, validFrameEdit } from '../reader/panel-edits';
import { parsePanelMap, type PanelMap } from '../reader/panels';
import { completionDate, completionStamp } from '../completion';
import { comicEra } from '../eras';
import { normalizeComic, mergeMetadata, editionFingerprint } from './comic-data';
interface Schema extends DBSchema {
  comics: { key: string; value: Comic };
  assets: { key: string; value: Asset };
  config: { key: string; value: unknown };
  backupStage: { key: string; value: { id: string; blob: Blob; createdAt: number } };
}
export const dbPromise = openDB<Schema>('batcave-reader', 2, {
  upgrade(db) {
    if (!db.objectStoreNames.contains('comics')) db.createObjectStore('comics', { keyPath: 'id' });
    if (!db.objectStoreNames.contains('assets')) db.createObjectStore('assets', { keyPath: 'id' });
    if (!db.objectStoreNames.contains('config')) db.createObjectStore('config');
    if (!db.objectStoreNames.contains('backupStage')) db.createObjectStore('backupStage', { keyPath: 'id' });
  },
  blocked() {
    window.dispatchEvent(new Event('batcave-blocked'));
  },
  blocking() {
    void dbPromise.then((db) => db.close());
  },
});
export async function initialize() {
  const db = await dbPromise;
  const tx = db.transaction(['comics', 'config'], 'readwrite');
  void tx.done.catch(() => {});
  if (!(await tx.objectStore('config').get('initialized'))) {
    await tx.objectStore('config').put(true, 'initialized');
  }
  if (!(await tx.objectStore('config').get('minimal-ui-v1'))) {
    for (const c of await tx.objectStore('comics').getAll()) {
      if (isUntouchedLegacySeed(c)) await tx.objectStore('comics').delete(c.id);
    }
    await tx.objectStore('config').put(true, 'minimal-ui-v1');
  }
  if (!(await tx.objectStore('config').get('completion-date-v1'))) {
    for (const c of await tx.objectStore('comics').getAll())
      if(c.completed && c.completedAt===undefined)
        await tx.objectStore('comics').put({...c,completedAt:completionDate(c)});
    await tx.objectStore('config').put(true,'completion-date-v1');
  }
  if (!(await tx.objectStore('config').get('comic-integrity-114'))) {
    for (const c of await tx.objectStore('comics').getAll())
      await tx.objectStore('comics').put(normalizeComic(c));
    await tx.objectStore('config').put(true, 'comic-integrity-114');
  }
  await tx.done;
  // Interrupted restores never touch live assets. Remove only abandoned
  // temporary pieces older than a day, keeping other active tabs' sessions.
  const cleanup = db.transaction('backupStage', 'readwrite');
  let cursor = await cleanup.store.openCursor();
  while (cursor) {
    if (cursor.value.createdAt < Date.now() - 24 * 60 * 60 * 1000) await cursor.delete();
    cursor = await cursor.continue();
  }
  await cleanup.done;
}
export async function allComics() {
  return (await dbPromise).getAll('comics');
}
export async function getComic(id:string) {return (await dbPromise).get('comics',id);}
export async function updateReadingResult(id:string,change:{rating?:number;completed?:boolean}) {
  if(change.rating!==undefined && (!Number.isInteger(change.rating)||change.rating<1||change.rating>5)) throw Error('Оценка должна быть от 1 до 5.');
  const db=await dbPromise,tx=db.transaction('comics','readwrite'),latest=await tx.store.get(id);
  void tx.done.catch(() => {});
  if(!latest){await tx.done;throw Error('Комикс не найден.');}
  const next={...latest,...(change.rating===undefined ? {} : {rating:change.rating}),...(change.completed ? {completed:true,readDigitally:true} : {})};
  const now=Date.now(),updated={...next,completedAt:completionStamp(next,latest,now),updatedAt:now};
  await tx.store.put(updated);await tx.done;return updated;
}
export async function getAsset(id: string) {
  return (await dbPromise).get('assets', id);
}
export async function saveSettings(s: Settings) {
  await (await dbPromise).put('config', s, 'settings');
}
export async function getSettings(): Promise<Settings> {
  return {
    ...defaultSettings,
    ...((await (await dbPromise).get('config', 'settings')) as Partial<Settings> | undefined),
  };
}
type AssetTransaction = IDBPTransaction<Schema, ('comics' | 'assets')[], 'readwrite'>;
async function removeUnusedAssets(tx: AssetTransaction, ids: (string | undefined)[]) {
  const referenced = new Set((await tx.objectStore('comics').getAll())
    .flatMap(c => [c.digital?.assetId, c.coverId, c.photoId]).filter(Boolean));
  for (const id of new Set(ids)) if (id && !referenced.has(id)) await tx.objectStore('assets').delete(id);
}
export async function saveComic(comic: Comic, assets: Asset[] = [], remove: string[] = [], preservePaperTimer = false, base?: Comic) {
  if (!comic.title.trim()) throw Error('Укажите название комикса.');
  const db = await dbPromise;
  const tx = db.transaction(['comics', 'assets'], 'readwrite');
  void tx.done.catch(() => {});
  const latest = await tx.objectStore('comics').get(comic.id);
  if (base && !latest) { await tx.done; throw Error('Комикс был удалён в другом окне. Изменения не сохранены.'); }
  let edited = base && latest ? mergeMetadata(latest, comic, base) : { ...comic };
  if (preservePaperTimer && latest && !base) edited = { ...edited,
    digital: latest.digital, digitalFingerprint: latest.digitalFingerprint, page: latest.page,
    pageCount: latest.pageCount, visited: latest.visited, seconds: latest.seconds,
    lastOpened: latest.lastOpened, readerView: latest.readerView, panelEdits: latest.panelEdits,
    autoPanels: latest.autoPanels, autoPanelEdits: latest.autoPanelEdits,
    rating: latest.rating, completed: latest.completed };
  let era=comicEra(edited);
  if (edited.sideStoryAfter) {
    const anchor = await tx.objectStore('comics').get(edited.sideStoryAfter);
    if (!anchor || anchor.sideStoryAfter || anchor.id===edited.id) {
      await tx.done;throw Error('Основной комикс был удалён или перемещён. Откройте окно заново.');
    }
    era=comicEra(anchor);
  }
  if (preservePaperTimer) {
    if (latest?.paperTimer) edited = { ...edited, paperTimer: true, paperSeconds: latest.paperSeconds, paperStartedAt: latest.paperStartedAt };
    if (edited.paperStartedAt !== undefined && (paperFinished(edited) || edited.physical !== 'yes')) edited = stopPaperSession(edited);
  }
  edited = normalizeComic(edited);
  const now=Date.now();
  for (const a of assets) await tx.objectStore('assets').put(a);
  await tx.objectStore('comics').put({ ...edited, era, completedAt:completionStamp(edited,latest,now), updatedAt: now });
  if(latest && !comic.sideStoryAfter && comicEra(latest)!==era) for(const child of await tx.objectStore('comics').getAll()) if(child.sideStoryAfter===comic.id)
    await tx.objectStore('comics').put({...child,era});
  await removeUnusedAssets(tx, remove);
  await tx.done;
}
export async function attachComicFile(incoming: Comic, assets: Asset[], target?: Comic, preserveProgress = false) {
  if (!incoming.title.trim() || !incoming.digital) throw Error('Укажите название и файл комикса.');
  const db = await dbPromise, tx = db.transaction(['comics', 'assets'], 'readwrite');
  void tx.done.catch(() => {});
  const records = await tx.objectStore('comics').getAll();
  const latest = records.find(c => c.id === incoming.id);
  if (target && !latest) { await tx.done; throw Error('Комикс был удалён. Файл не прикреплён.'); }
  if (records.some(c => c.id !== incoming.id && c.digital?.fingerprint === incoming.digital!.fingerprint)) {
    await tx.done; throw Error('Этот файл уже добавлен в библиотеку.');
  }
  if (target && latest && editionFingerprint(target) !== editionFingerprint(latest)) {
    await tx.done; throw Error('Файл комикса изменён в другом окне. Откройте карточку заново.');
  }
  const hash = incoming.digital.fingerprint, same = !!latest && editionFingerprint(latest) === hash;
  const keep = same || (!!target && !!latest && preserveProgress);
  let next: Comic = { ...(latest ?? incoming), digital: incoming.digital, digitalFingerprint: hash,
    coverId: latest?.coverId ?? incoming.coverId, pageCount: incoming.pageCount,
    autoPanels: same ? latest?.autoPanels ?? incoming.autoPanels : incoming.autoPanels,
    autoPanelEdits: same ? latest?.autoPanelEdits : undefined,
    panelEdits: keep && latest?.panelEdits?.fingerprint === hash ? latest.panelEdits : undefined,
    readerView: same ? latest?.readerView : undefined,
    ...(keep && latest ? { page: Math.min(latest.page, incoming.pageCount - 1),
      visited: latest.visited.filter(p => p < incoming.pageCount), seconds: latest.seconds, lastOpened: latest.lastOpened }
      : { page: 0, visited: [], seconds: 0, lastOpened: 0 }),
    updatedAt: Date.now() };
  next = normalizeComic(next);
  for (const a of assets) await tx.objectStore('assets').put(a);
  await tx.objectStore('comics').put(next);
  await removeUnusedAssets(tx, [latest?.digital?.assetId, ...assets.map(a => a.id)]);
  await tx.done; return next;
}
export async function paperSession(id: string, start: boolean, now = Date.now()) {
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  void tx.done.catch(() => {});
  const c = await tx.store.get(id);
  if (!c) { await tx.done; throw Error('Сначала сохраните книгу.'); }
  if (start && (c.physical !== 'yes' || paperFinished(c))) { await tx.done; throw Error('Издание уже прочитано или не отмечено как бумажное.'); }
  // One session at a time. Switching books settles the previous session atomically.
  if (start) for (const other of await tx.store.getAll()) {
    if (other.id !== id && other.paperStartedAt !== undefined) await tx.store.put({ ...stopPaperSession(other, now), updatedAt: now });
  }
  const result = start ? { ...c, paperTimer: true, paperSeconds: c.paperSeconds ?? 0, paperStartedAt: c.paperStartedAt ?? now } : stopPaperSession(c, now);
  await tx.store.put({ ...result, updatedAt: now });
  await tx.done;
  return result;
}
export async function completePaperSession(id: string, done: boolean, total: number | undefined, now = Date.now()) {
  if (total !== undefined && (!Number.isInteger(total) || total < 1 || total > 100000)) throw Error('Укажите целое количество страниц.');
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  void tx.done.catch(() => {});
  const c = await tx.store.get(id);
  if (!c) { await tx.done; throw Error('Книга была удалена.'); }
  const digitalDone = c.completed && (!!c.readDigitally || (c.pageCount > 0 && c.visited.length === c.pageCount) || (!paperFinished(c) && !!c.digital));
  const result = { ...(done ? stopPaperSession(c, now) : c), paperPageCount: total, paperPagesRead: done ? total ?? 0 : 0, paperCompleted: done, completed: done || digitalDone, ...(digitalDone ? { readDigitally: true } : {}), updatedAt: now };
  const dated={...result,completedAt:completionStamp(result,c,now)};
  await tx.store.put(dated); await tx.done;
  return dated;
}
export async function updateProgress(id: string, page: number, loaded: boolean, seconds = 0) {
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  void tx.done.catch(() => {});
  const c = await tx.store.get(id);
  if (c) {
    const p = Math.min(Math.max(0, page), Math.max(0, c.pageCount - 1));
    const visited = loaded
      ? Array.from(new Set([...c.visited, p])).sort((a, b) => a - b)
      : c.visited;
    const now=Date.now(),completed=c.completed || (c.pageCount > 0 && visited.length === c.pageCount);
    await tx.store.put({
      ...c,
      page: p,
      visited,
      seconds: c.seconds + Math.max(0, seconds),
      completed,
      completedAt:completionStamp({...c,completed},c,now),
      lastOpened: now,
      updatedAt: now,
    });
  }
  await tx.done;
}
export async function deleteDigital(c: Comic) {
  const db = await dbPromise;
  const tx = db.transaction(['comics', 'assets'], 'readwrite');
  void tx.done.catch(() => {});
  const latest = await tx.objectStore('comics').get(c.id);
  if (latest) {
    await tx.objectStore('comics').put({
      ...latest,
      digitalFingerprint: editionFingerprint(latest),
      ...(latest.digital && latest.completed ? { readDigitally: true } : {}),
      digital: undefined, readerView: undefined, updatedAt: Date.now(),
    });
    await removeUnusedAssets(tx, [latest.digital?.assetId]);
  }
  await tx.done;
}
export async function saveReaderView(id: string, view: ReaderView) {
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  void tx.done.catch(() => {});
  const c = await tx.store.get(id);
  if (c?.digital && c.page === view.page)
    await tx.store.put({ ...c, readerView: view });
  await tx.done;
}
export async function savePanelEdit(id: string, fingerprint: string, page: number, panel: number, edit: PanelFrameEdit | null) {
  if (!Number.isInteger(page) || page < 0 || !Number.isInteger(panel) || panel < 0 || panel >= 100 ||
      (edit && (!validFrameEdit(edit) || edit.page !== page || edit.panel !== panel)))
    throw Error('Некорректная правка кадра.');
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  void tx.done.catch(() => {});
  const c = await tx.store.get(id);
  if (!c?.digital || c.digital.fingerprint !== fingerprint || page >= c.pageCount) {
    tx.abort();await tx.done.catch(() => {});
    throw Error('Комикс изменился или был удалён. Правка не сохранена.');
  }
  if(c.autoPanels && panel >= c.autoPanels.pages[page].frames.length) {
    await tx.done;throw Error('Кадр отсутствует в разметке.');
  }
  const key = c.autoPanels ? 'autoPanelEdits' : 'panelEdits';
  const panelEdits = replaceFrameEdit(c[key], fingerprint, page, panel, edit);
  const updated = { ...c, updatedAt: Date.now() };
  if (panelEdits) updated[key] = panelEdits;else delete updated[key];
  // Merge into the latest record in one transaction. Active-time/progress
  // writes may run alongside the editor and must never be overwritten.
  await tx.store.put(updated);await tx.done;
  return panelEdits;
}
export async function saveAutomaticPanels(id: string, map: PanelMap) {
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  void tx.done.catch(() => {});
  const c = await tx.store.get(id);
  if (!c?.digital || c.digital.fingerprint !== map.sha256 || c.pageCount !== map.pageCount) {
    await tx.done;throw Error('Комикс изменился или был удалён.');
  }
  parsePanelMap(map,c.digital.fingerprint,c.pageCount);
  if(c.autoPanels) { await tx.done;return c; }
  // Copy corrections by spatial overlap, never by indices from a different map.
  // The untouched legacy corrections remain available in the original field.
  const frames: PanelFrameEdit[]=[];
  if(c.panelEdits?.fingerprint===map.sha256) for(const edit of c.panelEdits.frames) {
    const candidates=map.pages[edit.page]?.frames;
    if(!candidates) continue;
    const scores=candidates.map(r=>{
      const b=edit.bounds;
      const n=Math.max(0,Math.min(b[0]+b[2],r[0]+r[2])-Math.max(b[0],r[0])) * Math.max(0,Math.min(b[1]+b[3],r[1]+r[3])-Math.max(b[1],r[1]));
      return n/(b[2]*b[3]+r[2]*r[3]-n);
    });
    const best=Math.max(...scores), panel=scores.indexOf(best);
    if(best>=.5 && !frames.some(f=>f.page===edit.page && f.panel===panel)) frames.push({...edit,panel,views:[]});
  }
  const updated={...c,autoPanels:map,autoPanelEdits:frames.length?{fingerprint:map.sha256,frames}:undefined,
    readerView:undefined,updatedAt:Date.now()};
  await tx.store.put(updated);await tx.done;return updated;
}
export async function deleteComic(c: Comic) {
  const db = await dbPromise;
  const tx = db.transaction(['comics', 'assets'], 'readwrite');
  void tx.done.catch(() => {});
  const latest = await tx.objectStore('comics').get(c.id);
  await tx.objectStore('comics').delete(c.id);
  for (const child of await tx.objectStore('comics').getAll())
    if (child.sideStoryAfter === c.id)
      await tx.objectStore('comics').put({...child, sideStoryAfter:undefined, inRoadmap:true, updatedAt:Date.now()});
  await removeUnusedAssets(tx, [latest?.digital?.assetId, latest?.coverId, latest?.photoId]);
  await tx.done;
}
export async function setSideStory(id:string, afterId:string, attach:boolean) {
  const db = await dbPromise, tx = db.transaction('comics','readwrite');
  void tx.done.catch(() => {});
  const all = await tx.store.getAll(), comic = all.find(c=>c.id===id), anchor = all.find(c=>c.id===afterId);
  if (!comic || (attach && (!anchor || anchor.sideStoryAfter || id===afterId || all.some(c=>c.sideStoryAfter===id)))) {
    await tx.done; throw Error('Комикс или основной пункт маршрута изменился. Откройте окно заново.');
  }
  if (!attach && comic.sideStoryAfter!==afterId) {await tx.done;throw Error('Комикс уже перемещён. Откройте окно заново.');}
  const updated = {...comic, era:attach ? comicEra(anchor!) : comicEra(comic), sideStoryAfter: attach ? afterId : undefined, inRoadmap:!attach, updatedAt:Date.now()};
  await tx.store.put(updated);await tx.done;return updated;
}
export async function resetProgress() {
  const db = await dbPromise;
  const tx = db.transaction('comics', 'readwrite');
  void tx.done.catch(() => {});
  for (const c of await tx.store.getAll())
    await tx.store.put({
      ...c,
      page: 0,
      visited: [],
      completed: false,
      completedAt: undefined,
      readDigitally: undefined,
      paperPagesRead: 0,
      paperSeconds: 0,
      paperStartedAt: undefined,
      paperCompleted: false,
      seconds: 0,
      lastOpened: 0,
      readerView: undefined,
      updatedAt: Date.now(),
    });
  await tx.done;
}
export async function usage() {
  const db = await dbPromise;
  let local = 0;
  for await (const cursor of db.transaction('assets').store) {
    local += cursor.value.blob.size;
  }
  const estimate = await navigator.storage?.estimate?.().catch(() => ({}) as StorageEstimate);
  return { local, estimate };
}
