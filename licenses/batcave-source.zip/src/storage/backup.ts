import { UNIVERSES_KEY, normalizeUniverses, universeSchema, comicUniverse } from '../universes';
import { ACHIEVEMENT_KEY, mergeAchievementStates, normalizeAchievementState } from '../achievements';
import {validShape,type FrameShape} from '../reader/frame-shapes';
import { z } from 'zod';
import { ZipWriter, BlobWriter, BlobReader, TextReader, TextWriter } from '@zip.js/zip.js';
import { sha256 } from '@noble/hashes/sha2.js';
import { dbPromise, allComics, settleAchievements, notifyAchievementChange } from './db';
import { openZip, detectFormat } from '../reader/source';
import { type Comic, type Asset, type Settings, PAPER_PAGE_LIMIT, stopPaperSession } from '../models';
import { validFrameEdit } from '../reader/panel-edits';
import { parsePanelMap } from '../reader/panels';
import { completionDate } from '../completion';
import { comicEra, CHRONOLOGICAL_ERAS } from '../eras';
import { normalizeComic, editionFingerprint } from './comic-data';
import { defaultSettings } from '../models';
export const BACKUP_LIMIT = 300 * 1024 * 1024;
const id = z
  .string()
  .min(1)
  .max(150)
  .regex(/^[a-zA-Z0-9_-]+$/);
const text = z.string().max(20000);
const natural = z.number().int().min(0).max(Number.MAX_SAFE_INTEGER);
const year = z.number().int().min(1800).max(2200).nullable();
const frameEditSchema = z.object({
  page: z.number().int().min(0).max(4999),
  panel: z.number().int().min(0).max(99),
  bounds: z.tuple([z.number(), z.number(), z.number(), z.number()]),
  hidden: z.boolean().optional(),
  views: z.array(z.object({ part: z.number().int(), zoom: z.number(), x: z.number(), y: z.number() })).max(100),
}).refine(validFrameEdit, 'Некорректные границы или масштаб кадра');
const comicSchema = z
  .object({
    id,
    // Older imports could save a blank title; normalize that known legacy bug.
    title: text,
    series: text,
    authors: text,
    year,
    yearEnd: year.optional(),
    addedAt: natural,
    routeOrder: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER).optional(),
    updatedAt: natural,
    physical: z.enum(['yes', 'no', 'unknown']),
    paperPageCount: z.number().int().min(1).max(PAPER_PAGE_LIMIT).optional(),
    paperPagesRead: z.number().int().min(0).max(PAPER_PAGE_LIMIT).optional(),
    paperCompleted: z.boolean().optional(),
    paperSeconds: z.number().int().min(0).max(1e12).optional(),
    paperTimer: z.boolean().optional(),
    paperStartedAt: natural.optional(),
    physicalGroup: z.string().min(1).max(300).optional(),
    edition: text,
    publisher: text,
    editionYear: year,
    note: text,
    rating: z.number().int().min(0).max(5),
    completed: z.boolean(),
    completedAt: natural.optional(),
    readDigitally: z.boolean().optional(),
    inRoadmap: z.boolean().optional(),
    era: z.string().regex(/^[a-zA-Z0-9_-]{1,150}$/).optional(),
    universeId: z.string().regex(/^[a-zA-Z0-9_-]{1,150}$/).optional(),
    sideStoryAfter: id.optional(),
    page: z.number().int().min(0).max(4999),
    pageCount: z.number().int().min(0).max(5000),
    visited: z.array(z.number().int().min(0).max(4999)).max(5000),
    seconds: z.number().min(0).max(1e12),
    lastOpened: natural,
    digital: z
      .object({
        assetId: id,
        format: z.enum(['pdf', 'cbz', 'image']),
        name: text,
        size: natural,
        fingerprint: z.string().regex(/^[a-f0-9]{64}$/),
      })
      .optional(),
    digitalFingerprint: z.string().regex(/^[a-f0-9]{64}$/).optional(),
    coverId: id.optional(),
    photoId: id.optional(),
    tone: z.string().regex(/^#[a-fA-F0-9]{6}$/),
    readerView: z.object({
      page: z.number().int().min(0).max(4999),
      mode: z.enum(['single', 'guided', 'panels']),
      zoom: z.number().min(0.25).max(4),
      x: z.number().min(-1).max(1),
      y: z.number().min(-1).max(1),
      panel: z.number().int().min(0).max(100).optional(),
      part: z.number().int().min(0).max(100).optional(),
      viewPart: z.number().int().min(0).max(100).optional(),
      overview: z.enum(['before', 'after']).optional(),
    }).optional(),
    autoPanels: z.object({
      version: z.literal(1),sha256:z.string().regex(/^[a-f0-9]{64}$/),pageCount:z.number().int().min(1).max(5000),
      detector:z.literal('inkwell-v1'),
      pages:z.array(z.object({width:z.number().positive(),height:z.number().positive(),kind:z.enum(['story','cover','text']),
        frames:z.array(z.tuple([z.number(),z.number(),z.number(),z.number()])).min(1).max(100),shapes:z.array(z.custom<FrameShape>(validShape)).max(100).optional()})).max(5000),
    }).refine(m=>{try{parsePanelMap(m,m.sha256,m.pageCount);return true;}catch{return false;}},'Повреждена разметка').optional(),
    autoPanelEdits: z.object({fingerprint:z.string().regex(/^[a-f0-9]{64}$/),frames:z.array(frameEditSchema).max(10000)
      .refine(frames=>new Set(frames.map(e=>`${e.page}:${e.panel}`)).size===frames.length)}).optional(),
    panelEdits: z.object({
      fingerprint: z.string().regex(/^[a-f0-9]{64}$/),
      frames: z.array(frameEditSchema).max(10000).refine(
        frames => new Set(frames.map(e => `${e.page}:${e.panel}`)).size === frames.length,
        'Повторяющиеся правки одного кадра',
      ),
    }).optional(),
  })
  .refine(
    (c) =>
      c.visited.every((p) => p < c.pageCount) &&
      new Set(c.visited).size === c.visited.length &&
      (c.pageCount === 0 ? c.page === 0 : c.page < c.pageCount),
    'Повреждён прогресс чтения',
  ).refine(c => (c.paperPagesRead ?? 0) <= (c.paperPageCount ?? 0), 'Повреждён прогресс бумажного издания').refine(c => !c.panelEdits ||
    ((c.digital?.fingerprint ?? c.digitalFingerprint) && c.panelEdits.fingerprint !== (c.digital?.fingerprint ?? c.digitalFingerprint)) ||
    c.panelEdits.frames.every(e => e.page < c.pageCount), 'Правка не соответствует страницам комикса')
  .refine(c=>!c.autoPanels || (c.autoPanels.pageCount===c.pageCount && (!c.digital || c.autoPanels.sha256===c.digital.fingerprint)))
  .refine(c=>!c.autoPanelEdits || (c.autoPanels && c.autoPanelEdits.fingerprint===c.autoPanels.sha256 && c.autoPanelEdits.frames.every(e=>e.page<c.pageCount && e.panel<c.autoPanels!.pages[e.page].frames.length)))
  .transform(c => normalizeComic(c as Comic));
const settingsSchema = z.object({
  roadmapEra: z.string().regex(/^[a-zA-Z0-9_-]{1,150}$/).optional(),
  mode: z.enum(['single', 'vertical', 'guided', 'panels']),
  direction: z.enum(['ltr', 'rtl']),
  motion: z.enum(['system', 'full', 'fast', 'off']),
  readerTheme: z.enum(['black', 'gray', 'light']),
  warmScreen: z.boolean().default(false),
  doubleTap: z.boolean(),
  showPage: z.boolean(),
  cropMargins: z.boolean().default(false),
  panelOpacity: z.number().min(0).max(1).default(0.75),
  panelPageFirst: z.boolean().default(false),
  panelPageLast: z.boolean().default(false),
  groupSeries: z.boolean(),
  sort: z.enum(['added', 'title', 'year']),
});
const assetSchema = z.object({
  id,
  path: z.string().regex(/^assets\/[a-zA-Z0-9_-]+$/),
  size: natural,
  mime: z.string().max(100),
  sha256: z.string().regex(/^[a-f0-9]{64}$/),
});
const schema = z
  .object({
    app: z.literal('BATCAVE'),
    version: z.literal(1),
    kind: z.enum(['metadata', 'full']),
    createdAt: natural,
    comics: z.array(comicSchema).max(10000),
    settings: settingsSchema,
    universes:z.array(universeSchema).max(1000).optional(),
    achievements: z.object({
      version:z.literal(2), initializedAt:natural,
      earned:z.array(z.object({id:z.string().max(100),at:natural,legacy:z.boolean().optional()})).max(100),
      pending:z.array(z.array(z.string().max(100)).max(100)).max(100),
      eraPlans:z.array(z.object({era:z.enum(CHRONOLOGICAL_ERAS.map(e=>e.id) as [typeof CHRONOLOGICAL_ERAS[number]['id'],...typeof CHRONOLOGICAL_ERAS[number]['id'][]]),updatedAt:natural,entries:z.array(z.object({id,title:z.string().max(500),done:z.boolean()})).min(1).max(2000)})).max(11).optional(),
    }).optional(),
    assets: z.array(assetSchema).max(30000),
  })
  .refine(
    (b) =>
      new Set(b.comics.map((c) => c.id)).size === b.comics.length &&
      new Set(b.assets.map((a) => a.id)).size === b.assets.length &&
      new Set(b.assets.map((a) => a.path)).size === b.assets.length,
    'Дубликаты идентификаторов в резервной копии',
  );
export type Backup = z.infer<typeof schema>;
export function parseBackup(value: unknown): Backup {
  const r = schema.safeParse(value);
  if (!r.success)
    throw Error(
      'Некорректная резервная копия BATCAVE или неподдерживаемая версия. Библиотека не изменена.',
    );
  if (r.data.kind === 'metadata' && r.data.assets.length)
    throw Error('В JSON не должно быть файлов.');
  return r.data;
}
export async function checksum(blob: Blob, signal?: AbortSignal) {
  const h = sha256.create();
  for (let offset = 0; offset < blob.size; offset += 4 * 1024 * 1024) {
    if (signal?.aborted) throw new DOMException('Отменено', 'AbortError');
    h.update(new Uint8Array(await blob.slice(offset, offset + 4 * 1024 * 1024).arrayBuffer()));
  }
  return Array.from(h.digest())
    .map((n) => n.toString(16).padStart(2, '0'))
    .join('');
}
export async function exportMetadata() {
  const snapshot = await exportSnapshot(false);
  const data = checkedExport({ app: 'BATCAVE', version: 1, kind: 'metadata',
    createdAt: Date.now(), comics: snapshot.comics, settings: snapshot.settings, universes:snapshot.universes, achievements:snapshot.achievements, assets: [] });
  return new Blob(
    [JSON.stringify(data, null, 2)],
    { type: 'application/json' },
  );
}
export async function exportFull(onProgress: (message: string) => void) {
  const snapshot = await exportSnapshot(true), comics = snapshot.comics;
  const keys = Array.from(
    new Set(
      comics
        .flatMap((c) => [c.digital?.assetId, c.coverId, c.photoId])
        .filter((x): x is string => !!x),
    ),
  );
  let total = 0;
  for (const key of keys) {
    const a = snapshot.assets.get(key);
    if (!a)
      throw Error('Файл из библиотеки отсутствует. Проверьте цифровые копии перед экспортом.');
    total += a.blob.size;
  }
  if (total > BACKUP_LIMIT)
    throw Error(
      'Полная копия ограничена 300 МБ, чтобы не перегрузить память iPhone. Экспортируйте JSON и сохраните оригиналы отдельно.',
    );
  const writer = new ZipWriter(new BlobWriter('application/zip'), { level: 0 });
  const assets: Backup['assets'] = [];
  try {
    for (const [i, key] of keys.entries()) {
      onProgress(`Упаковка файла ${i + 1} из ${keys.length}`);
      const a = snapshot.assets.get(key)!;
      const path = `assets/${key}`;
      assets.push({
        id: key,
        path,
        size: a.blob.size,
        mime: a.blob.type,
        sha256: await checksum(a.blob),
      });
      await writer.add(path, new BlobReader(a.blob));
    }
    await writer.add(
      'batcave.json',
      new TextReader(
        JSON.stringify(checkedExport({
          app: 'BATCAVE',
          version: 1,
          kind: 'full',
          createdAt: Date.now(),
          comics,
          settings: snapshot.settings,
          universes:snapshot.universes,
          achievements:snapshot.achievements,
          assets,
        })),
      ),
    );
    return await writer.close();
  } catch (e) {
    await writer.close().catch(() => {});
    throw e;
  }
}
export function checkedExport(value: unknown): Backup {
  try { return parseBackup(value); }
  catch {
    const raw = value as { comics: Comic[] };
    const invalid = raw.comics.find(c => !comicSchema.safeParse(c).success);
    throw Error(`Не удалось проверить резервную копию${invalid ? `: «${invalid.title}»` : ''}. Данные на устройстве не изменены.`);
  }
}
export async function exportSnapshot(full: boolean) {
  const db = await dbPromise, tx = db.transaction(['comics', 'assets', 'config'], 'readonly');
  const comics = (await tx.objectStore('comics').getAll()).map(normalizeComic);
  const settings = { ...defaultSettings, ...(await tx.objectStore('config').get('settings') as Partial<Settings> | undefined) };
  const achievements = normalizeAchievementState(await tx.objectStore('config').get(ACHIEVEMENT_KEY));
  const universes=normalizeUniverses(await tx.objectStore('config').get(UNIVERSES_KEY),comics);
  const assets = new Map<string, Asset>();
  if (full) for (const id of new Set(comics.flatMap(c => [c.digital?.assetId, c.coverId, c.photoId]).filter((id): id is string => !!id))) {
    const asset = await tx.objectStore('assets').get(id);
    if (asset) assets.set(id, asset);
  }
  await tx.done; return { comics, settings, achievements, assets, universes };
}
export interface PreparedBackup {
  data: Backup;
  assets: Map<string, Asset>;
  conflicts: number;
  staged?: Map<string, string[]>;
}
export async function prepareRestore(
  file: File,
  onProgress: (message: string) => void,
): Promise<PreparedBackup> {
  if (file.size > BACKUP_LIMIT + 8 * 1024 * 1024)
    throw Error('Архив больше 308 МБ. Восстановление на iPhone ограничено по памяти.');
  let data: Backup;
  const assets = new Map<string, Asset>();
  if (/\.json$/i.test(file.name)) {
    if (file.size > 8 * 1024 * 1024) throw Error('JSON слишком большой.');
    data = parseBackup(JSON.parse(await file.text()));
    if (data.kind !== 'metadata') throw Error('Полная копия должна быть ZIP-архивом.');
  } else {
    const { zip, entries } = await openZip(file);
    try {
      const manifest = entries.find((e) => e.filename === 'batcave.json');
      if (!manifest || manifest.directory || manifest.uncompressedSize > 8 * 1024 * 1024)
        throw Error('В архиве нет корректного batcave.json.');
      const content = await manifest.getData(new TextWriter(), { checkSignature: true });
      data = parseBackup(JSON.parse(content!));
      if (data.kind !== 'full') throw Error('В архиве нет полной резервной копии.');
      if (data.assets.reduce((n, a) => n + a.size, 0) > BACKUP_LIMIT)
        throw Error('Данные в архиве больше 300 МБ.');
      for (const [i, a] of data.assets.entries()) {
        onProgress(`Проверка файла ${i + 1} из ${data.assets.length}`);
        const e = entries.find((e) => e.filename === a.path);
        if (!e || e.directory || e.encrypted || e.uncompressedSize !== a.size)
          throw Error('Файлы резервной копии отсутствуют или повреждены.');
        const blob = await e.getData(new BlobWriter(a.mime), { checkSignature: true });
        if (!blob || (await checksum(blob)) !== a.sha256)
          throw Error('Контрольная сумма файла не совпадает. Библиотека не изменена.');
        assets.set(a.id, { id: a.id, blob });
      }
      for (const c of data.comics) {
        for (const key of [c.digital?.assetId, c.coverId, c.photoId])
          if (key && !assets.has(key)) throw Error('В полной копии отсутствует вложение.');
        if (c.digital) {
          const blob = assets.get(c.digital.assetId)!.blob;
          if (
            blob.size !== c.digital.size ||
            (await checksum(blob)) !== c.digital.fingerprint ||
            (await detectFormat(blob, c.digital.name)) !== c.digital.format
          )
            throw Error('Цифровой файл не соответствует метаданным.');
        }
      }
    } finally {
      await zip.close();
    }
  }
  const local = await allComics();
  const conflicts = data.comics.filter((c) =>
    local.some(
      (l) =>
        l.id === c.id ||
        (l.digital && c.digital && l.digital.fingerprint === c.digital.fingerprint),
    ),
  ).length;
  return { data, assets, conflicts };
}
export async function restore(
  prepared: PreparedBackup,
  policy: 'keep' | 'replace',
  restoreSettings: boolean,
) {
  const db = await dbPromise;
  // Read the current records and write decisions inside one serialized transaction.
  const tx = db.transaction(['comics', 'assets', 'config', 'backupStage'], 'readwrite');
  void tx.done.catch(() => {});
  try {
  const existing = (await tx.objectStore('comics').getAll()).map(normalizeComic);
  const existingAssets = new Set(await tx.objectStore('assets').getAllKeys());
  const result = new Map(existing.map((c) => [c.id, c]));
  const written = new Set<string>();
  const hasAsset = (id: string) => prepared.assets.has(id) || !!prepared.staged?.has(id);
  const writeAsset = async (id: string) => {
    if (written.has(id)) return;
    let asset = prepared.assets.get(id);
    if (!asset && prepared.staged?.has(id)) {
      const chunks: Blob[] = [];
      for (const key of prepared.staged.get(id)!) {
        const piece = await tx.objectStore('backupStage').get(key);
        if (!piece) throw Error('Временные файлы копии отсутствуют. Выберите копию заново.');
        chunks.push(piece.blob);
      }
      const info = prepared.data.assets.find(a => a.id === id)!;
      asset = { id, blob: new Blob(chunks, {type: info.mime}) };
    }
    if (!asset) throw Error('В копии отсутствует файл.');
    await tx.objectStore('assets').put(asset); written.add(id);
  };
  // Fingerprint deduplication may keep an existing record's different ID.
  const ids = new Map(prepared.data.comics.map(c => [c.id, existing.find(old => old.id === c.id ||
    (old.digital && c.digital && old.digital.fingerprint === c.digital.fingerprint))?.id || c.id]));
  let imported = 0,
    skipped = 0,
    hydrated = 0;
  for (const raw of prepared.data.comics) {
    const incoming = raw.paperStartedAt !== undefined ? stopPaperSession(raw as Comic, prepared.data.createdAt) : raw as Comic;
    const old = existing.find(
      (c) =>
        c.id === incoming.id ||
        (c.digital && incoming.digital && c.digital.fingerprint === incoming.digital.fingerprint),
    );
    if (old && policy === 'keep') {
      skipped++;
      if (
        incoming.digital &&
        hasAsset(incoming.digital.assetId) &&
        ((!old.digital && (!editionFingerprint(old) || editionFingerprint(old) === incoming.digital.fingerprint)) ||
          (old.digital && old.digital.fingerprint === incoming.digital.fingerprint &&
            !existingAssets.has(old.digital.assetId)))
      ) {
        await writeAsset(incoming.digital.assetId);
        result.set(old.id, normalizeComic({
          ...old,
          digital: incoming.digital,
          digitalFingerprint: incoming.digital.fingerprint,
          pageCount: incoming.pageCount,
          page: Math.min(old.page, Math.max(0, incoming.pageCount - 1)),
          visited: old.visited.filter((p) => p < incoming.pageCount),
        }));
        hydrated++;
      }
      continue;
    }
    const c: Comic = { ...incoming, id: old?.id || incoming.id,
      ...(incoming.sideStoryAfter ? {sideStoryAfter: ids.get(incoming.sideStoryAfter) || incoming.sideStoryAfter} : {}) };
    for (const key of ['coverId', 'photoId'] as const) {
      const aid = c[key];
      if (aid && hasAsset(aid)) await writeAsset(aid);
      else if (aid && !existingAssets.has(aid)) c[key] = undefined;
    }
    if (c.digital) {
      if (hasAsset(c.digital.assetId)) await writeAsset(c.digital.assetId);
      else if (
        old?.digital?.fingerprint === c.digital.fingerprint &&
        existingAssets.has(old.digital.assetId)
      )
        c.digital = old.digital;
      else {
        if (c.completed) c.readDigitally = true;
        c.digitalFingerprint = c.digital.fingerprint;
        c.digital = undefined;
      }
    }
    result.set(c.id, normalizeComic(c));
    imported++;
  }
  // A missing or nested anchor must not strand a restored story.
  for (const c of result.values())
    result.set(c.id,{...c,completedAt:c.completed ? completionDate(c) : undefined});
  for (const c of result.values()) if (c.sideStoryAfter &&
    (c.sideStoryAfter === c.id || !result.has(c.sideStoryAfter) || result.get(c.sideStoryAfter)?.sideStoryAfter || comicUniverse(c)!==comicUniverse(result.get(c.sideStoryAfter)!)))
    result.set(c.id, {...c, sideStoryAfter:undefined, inRoadmap:true});
  for(const c of result.values()) if(c.sideStoryAfter) {
    const anchor=result.get(c.sideStoryAfter);
    result.set(c.id,{...c,era:comicEra(anchor ?? c)});
  }
  const referenced = new Set(
    Array.from(result.values())
      .flatMap((c) => [c.digital?.assetId, c.coverId, c.photoId])
      .filter(Boolean),
  );
  for (const c of result.values()) await tx.objectStore('comics').put(c);
  for (const aid of existingAssets)
    if (!referenced.has(aid)) await tx.objectStore('assets').delete(aid);
  const currentUniverses=normalizeUniverses((await tx.objectStore('config').get(UNIVERSES_KEY))??[],existing);
  const incomingUniverses=prepared.data.universes??[];
  const mergedUniverses=new Map(currentUniverses.map(u=>[u.id,u]));
  for(const u of incomingUniverses) if(!mergedUniverses.has(u.id)||policy==='replace')mergedUniverses.set(u.id,u);
  await tx.objectStore('config').put(normalizeUniverses([...mergedUniverses.values()],[...result.values()]),UNIVERSES_KEY);
  if (restoreSettings)
    await tx.objectStore('config').put(prepared.data.settings as Settings, 'settings');
  const awardState = mergeAchievementStates(await tx.objectStore('config').get(ACHIEVEMENT_KEY), prepared.data.achievements);
  if (awardState) await tx.objectStore('config').put(awardState, ACHIEVEMENT_KEY);
  await settleAchievements(tx);
  await tx.objectStore('config').put(true, 'initialized');
  if (prepared.staged) for (const keys of prepared.staged.values())
    for (const key of keys) await tx.objectStore('backupStage').delete(key);
  await tx.done;
  notifyAchievementChange();
  return { imported, skipped, hydrated };
  } catch(error) {
    try { tx.abort(); } catch {}
    await tx.done.catch(() => {});
    throw error;
  }
}
export function download(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}
