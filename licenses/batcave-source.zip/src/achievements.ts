import { type Comic, paperFinished, readPages, stats } from './models';

export type AchievementKind = 'stories' | 'pages' | 'library' | 'paper' | 'ratings' | 'special';
export type MedalTier = 'bronze' | 'silver' | 'gold' | 'platinum';
export interface AchievementDefinition {
  id: string; name: string; hint: string; kind: AchievementKind;
  goal: number; art: number; tier: MedalTier;
}
export interface Achievement extends AchievementDefinition {
  value: number; earned: boolean; earnedAt?: number; legacy?: boolean;
}
export interface AchievementAward { id: string; at: number; legacy?: boolean }
export interface AchievementState {
  version: 2; initializedAt: number; earned: AchievementAward[]; pending: string[][];
}
export const ACHIEVEMENT_KEY = 'achievements-v2';
export const achievementKinds: Array<{ id: AchievementKind; label: string }> = [
  { id: 'stories', label: 'Прочитанные истории' }, { id: 'pages', label: 'Между страницами' },
  { id: 'library', label: 'Цифровой архив' }, { id: 'paper', label: 'Бумажная коллекция' },
  { id: 'ratings', label: 'Свой взгляд' }, { id: 'special', label: 'Особые' },
];
const tiers: MedalTier[] = ['bronze','bronze','silver','silver','silver','gold','gold','gold','platinum','platinum'];
const series = (kind: AchievementKind, goals: number[], names: string[], arts: number[], condition: (n: number) => string) =>
  goals.map((goal, i): AchievementDefinition => ({
    id: kind === 'stories' && goal === 1 ? 'first' : `${kind}-${goal}`,
    name: names[i], hint: condition(goal), kind, goal,
    art: arts[i % arts.length], tier: tiers[Math.round(i * 9 / Math.max(1,goals.length - 1))],
  }));
const num = (n: number) => n.toLocaleString('ru-RU');
export const achievementCatalog: AchievementDefinition[] = [
  ...series('stories',[1,3,5,10,25,50,100,150,250,500],
    ['Первое дело','Продолжение следует','Вошёл во вкус','Десять раскрытых дел','Опытный сыщик','Ночной дозор','Живая энциклопедия','Хранитель хроник','Легенда архива','За гранью легенды'],
    [0,1,1,4,1,4,8,11,8,11], n => `Прочитать комиксов: ${num(n)}`),
  ...series('pages',[100,500,1000,2500,5000,10000,20000,35000,50000,100000],
    ['За обложкой','Ещё одну страницу','В глубине сюжета','Между мирами','Потерял счёт','Бумажный океан','На другом берегу','Бесконечная история','Вселенная в кадрах','За последней страницей'],
    [2,2,2,3,8,3,3,8,11,8], n => `Прочитать страниц: ${num(n)}`),
  ...series('library',[1,5,10,25,50,100],
    ['Первый файл','Личный архив','Архивариус','Секретное хранилище','Память города','Архив без границ'],
    [5,5,4,5,4,11], n => `Добавить цифровых изданий: ${num(n)}. Удаление локального файла не отменяет полученную награду.`),
  ...series('paper',[1,5,10,25,50,100],
    ['Место на полке','Запах типографии','Коллекционер','Корешок к корешку','Частный музей','Библиотека мечты'],
    [6,2,6,6,11,6], n => `Собрать бумажных изданий: ${num(n)}. Общий том учитывается один раз.`),
  ...series('ratings',[1,10,25,100],
    ['Есть мнение','Свой вердикт','Придирчивый читатель','Голос критика'],
    [7], n => `Поставить оценки комиксам: ${num(n)}. Подойдёт любая оценка.`),
  { id:'special-tome', name:'Большая история', hint:'Прочитать комикс объёмом от 300 страниц. Учитывается подтверждённое число прочитанных страниц.', kind:'special', goal:300, art:8, tier:'gold' },
  { id:'special-formats', name:'По обе стороны обложки', hint:'Завершить хотя бы один комикс на бумаге и хотя бы один в цифре. Можно одну историю в обоих форматах.', kind:'special', goal:2, art:9, tier:'silver' },
  { id:'special-decades', name:'Сквозь эпохи', hint:'Прочитать комиксы из трёх разных десятилетий. Используется год выхода истории в карточке.', kind:'special', goal:3, art:10, tier:'gold' },
  { id:'special-classics', name:'Из золотого фонда', hint:'Прочитать три комикса, впервые вышедших до 1990 года.', kind:'special', goal:3, art:11, tier:'gold' },
];
const knownIds = new Set(achievementCatalog.map(a => a.id));
export function normalizeAchievementState(raw: unknown): AchievementState | undefined {
  if (!raw || typeof raw !== 'object') return;
  const s = raw as Partial<AchievementState>;
  if (s.version !== 2 || !Number.isSafeInteger(s.initializedAt) || s.initializedAt! < 0 || !Array.isArray(s.earned)) return;
  const earned: AchievementAward[] = [];
  for (const a of s.earned) if (a && knownIds.has(a.id) && Number.isSafeInteger(a.at) && a.at >= 0 && !earned.some(e => e.id === a.id))
    earned.push({ id:a.id, at:a.at, ...(a.legacy ? {legacy:true} : {}) });
  const awarded = new Set(earned.map(a => a.id)), seen = new Set<string>();
  const pending = Array.isArray(s.pending) ? s.pending.slice(0,40).flatMap(group => {
    if (!Array.isArray(group)) return [];
    const ids = group.filter(id => typeof id === 'string' && awarded.has(id) && !seen.has(id) && !!seen.add(id));
    return ids.length ? [ids] : [];
  }) : [];
  return { version:2, initializedAt:s.initializedAt!, earned, pending };
}
export function achievements(comics: Comic[], state?: AchievementState): Achievement[] {
  const s = stats(comics), finished = comics.filter(c => c.completed);
  const values: Record<AchievementKind,number> = {
    stories:s.done, pages:s.pages, library:comics.filter(c => c.digital || c.digitalFingerprint).length,
    paper:s.paper, ratings:comics.filter(c => c.rating >= 1 && c.rating <= 5).length, special:0,
  };
  const years = finished.map(c => c.year).filter((y): y is number => y !== null && Number.isInteger(y) && y >= 1800 && y <= 2200);
  const specials: Record<string,number> = {
    'special-tome':finished.reduce((max,c) => Math.max(max,readPages(c)),0),
    'special-formats':Number(finished.some(c => c.physical === 'yes' && paperFinished(c))) +
      Number(finished.some(c => c.readDigitally || (c.pageCount > 0 && new Set(c.visited).size >= c.pageCount) || c.physical !== 'yes')),
    'special-decades':new Set(years.map(y => Math.floor(y / 10))).size,
    'special-classics':years.filter(y => y < 1990).length,
  };
  const earned = new Map(state?.earned.map(a => [a.id,a]));
  return achievementCatalog.map(a => {
    const value = Math.min(a.goal,specials[a.id] ?? values[a.kind]), award = earned.get(a.id);
    return { ...a, value:award ? a.goal : value, earned:!!award || value >= a.goal, earnedAt:award?.at, legacy:award?.legacy };
  });
}
export function advanceAchievements(comics: Comic[], raw: unknown, now = Date.now()): AchievementState {
  const previous = normalizeAchievementState(raw), earned = previous?.earned ?? [];
  const ids = new Set(earned.map(a => a.id));
  const added = achievements(comics).filter(a => a.earned && !ids.has(a.id)).map(a => a.id);
  return { version:2, initializedAt:previous?.initializedAt ?? now,
    earned:[...earned,...added.map(id => ({id,at:now,...(!previous ? {legacy:true} : {})}))],
    pending:[...(previous?.pending ?? []), ...(!previous ? (added.length ? [added] : []) : added.map(id => [id]))] };
}
export function mergeAchievementStates(current: unknown, incoming: unknown): AchievementState | undefined {
  const a = normalizeAchievementState(current), b = normalizeAchievementState(incoming);
  if (!b) return a;
  const earned = new Map((a?.earned ?? []).map(e => [e.id,e]));
  for (const e of b.earned) if (!earned.has(e.id) || earned.get(e.id)!.at > e.at) earned.set(e.id,e);
  return { version:2, initializedAt:Math.min(a?.initializedAt ?? b.initializedAt,b.initializedAt), earned:[...earned.values()], pending:a?.pending ?? [] };
}
export function nextAchievements(medals: Achievement[], limit = 2) {
  return medals.filter(a => !a.earned).sort((a,b) => b.value / b.goal - a.value / a.goal || achievementCatalog.findIndex(x => x.id === a.id) - achievementCatalog.findIndex(x => x.id === b.id)).slice(0,limit);
}
