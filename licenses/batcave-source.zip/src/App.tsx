import { useCallback, useEffect, useLayoutEffect, useRef, useState, lazy } from 'react';
import { createPortal } from 'react-dom';
import { useAppUpdates } from './updates';
import { useAppViewport } from './viewport';
import {
  BookOpen,
  Library,
  UserRound,
  Settings as SettingsIcon,
  Search,
  Plus,
  ArrowLeft,
  ChevronRight,
  X,
  Monitor,
} from 'lucide-react';
import {
  type Comic,
  type Settings,
  defaultSettings,
  blankComic,
  errorMessage,
} from './models';
import { initialize, allComics, getSettings, saveSettings } from './storage/db';
import { Bat, Card, Empty, Modal, CollectionIcon } from './components/ui';
import { inCollection } from './collection';
import { Profile } from './components/Profile';
import { Roadmap } from './components/Roadmap';
import { orderedRoadmap } from './roadmap';
import { BookOpening } from './components/BookOpening';
import { SideStoriesDialog } from './components/SideStoriesDialog';
const Editor = lazy(() => import('./components/Editor').then((m) => ({ default: m.Editor })));
const Importer = lazy(() => import('./components/Importer').then((m) => ({ default: m.Importer })));
const SettingsPanel = lazy(() =>
  import('./components/Settings').then((m) => ({ default: m.SettingsPanel })),
);
const loadReader = () => import('./reader/Reader').then((m) => ({ default: m.Reader }));
const Reader = lazy(loadReader);
type Tab = 'library' | 'collection' | 'profile' | 'settings' | 'reader';
function route() {
  const parts = location.hash.replace(/^#\/?/, '').split('/');
  return {
    tab: (['library', 'collection', 'profile', 'settings', 'reader'].includes(parts[0])
      ? parts[0]
      : 'library') as Tab,
    id: parts[1],
  };
}
export default function App() {
  const [comics, setComics] = useState<Comic[]>([]);
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [current, setCurrent] = useState(route);
  const [query, setQuery] = useState('');
  const [paperQuery, setPaperQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [opening, setOpening] = useState<{ comic: Comic; rect: DOMRect }>();
  const finishOpening = useCallback(() => setOpening(undefined), []);
  const [addingLibrary, setAddingLibrary] = useState(false);
  const [addingCollection, setAddingCollection] = useState(false);
  const [editing, setEditing] = useState<Comic>();
  const [sideAnchor, setSideAnchor] = useState<string>();
  const [importing, setImporting] = useState<{ file: File; target?: Comic }>();
  const updates = useAppUpdates();
  useAppViewport();
  const main = useRef<HTMLElement>(null);
  const libraryScroll = useRef(0);
  const readerOrigin=useRef<Tab>('library');
  const settingsOrigin=useRef<Tab>('profile');
  useLayoutEffect(() => {
    if (!loading && current.tab === 'library' && main.current) main.current.scrollTop = libraryScroll.current;
  }, [loading, current.tab]);
  const input = useRef<HTMLInputElement>(null);
  const attachTarget = useRef<Comic | undefined>(undefined);
  const refresh = useCallback(async () => {
    setComics(await allComics());
    setSettings(await getSettings());
  }, []);
  useEffect(() => { if (!loading) void loadReader().catch(() => {}); }, [loading]);
  useEffect(() => {
    void initialize()
      .then(refresh)
      .then(() => setLoading(false))
      .catch((e) => {
        setError(errorMessage(e));
        setLoading(false);
      });
    const listener = () => {
      setCurrent(route());
      void refresh().catch((e) => setError(errorMessage(e)));
    };
    window.addEventListener('hashchange', listener);
    return () => window.removeEventListener('hashchange', listener);
  }, [refresh]);
  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const apply = () =>
      (document.documentElement.dataset.motion =
        settings.motion === 'system' ? (reduced.matches ? 'off' : 'full') : settings.motion);
    apply();
    reduced.addEventListener('change', apply);
    return () => reduced.removeEventListener('change', apply);
  }, [settings.motion]);
  function navigate(tab: Tab, id?: string) {
    if (tab !== 'library') setSideAnchor(undefined);
    if (tab !== current.tab) setSearchOpen(false);
    location.hash = `/${tab}${id ? `/${id}` : ''}`;
  }
  function setConfig(s: Settings) {
    setSettings(s);
    void saveSettings(s).catch((e) => setError(`Настройки не сохранены: ${errorMessage(e)}`));
  }
  function attach(target?: Comic) {
    attachTarget.current = target;
    input.current?.click();
  }
  function read(c: Comic, rect?: DOMRect) {
    if (!c.digital) return;
    if (rect && document.documentElement.dataset.motion !== 'off') setOpening({ comic: c, rect });
    readerOrigin.current=current.tab==='reader' ? 'library' : current.tab;
    setEditing(undefined);
    navigate('reader', c.id);
  }
  const library = orderedRoadmap(comics);
  const collection = comics.filter(inCollection);
  const searchQuery = current.tab === 'collection' ? paperQuery : query;
  const visible = (current.tab === 'collection' ? [...collection].sort((a,b)=>b.addedAt-a.addedAt || a.id.localeCompare(b.id)) : library)
    .filter(c=>`${c.title} ${c.series} ${c.authors}`.toLocaleLowerCase('ru').includes(searchQuery.toLocaleLowerCase('ru')));
  const reading = comics.find((c) => c.id === current.id);
  const updateNotice = updates.state === 'ready' && !updates.noticeDismissed && !editing && !importing && !addingLibrary && !addingCollection && !sideAnchor && current.tab !== 'settings' && createPortal(<div className={`app-update-notice ${current.tab === 'reader' ? 'reader-update-notice' : ''}`} role="status">
    <div><strong>Обновление готово</strong><p>{current.tab === 'reader' ? 'Закройте комикс, чтобы применить обновление.' : 'Примените его сейчас или закройте и заново откройте BATCAVE.'}</p></div>
    <button className="icon-button" aria-label="Скрыть уведомление об обновлении" onClick={updates.dismiss}><X size={18} /></button>
    {current.tab !== 'reader' && <button className="primary" onClick={updates.apply}>Обновить приложение</button>}
  </div>, document.body);

  if (loading)
    return (
      <div className="boot">
        <Bat />
        <span className="spinner" />
        <p>Открываем архив…</p>
      </div>
    );
  if (current.tab === 'reader' && reading?.digital)
    return (
      <>
      <Reader
        comic={reading}
        settings={settings}
        onSettings={setConfig}
        onClose={() => {
          navigate(readerOrigin.current);
          void refresh();
        }}
      />
      {updateNotice}
      {opening && <BookOpening {...opening} onDone={finishOpening} />}
      </>
    );
  const title = {
    library: 'Библиотека',
    collection: 'Моя коллекция',
    profile: 'Прогресс',
    settings: 'Настройки',
    reader: 'Библиотека',
  }[current.tab];
  return (
    <>{createPortal(<div className={`app tab-${current.tab}`}>
      <input
        ref={input}
        hidden
        type="file"
        data-testid="comic-file-input"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) setImporting({ file, target: attachTarget.current });
          e.target.value = '';
        }}
      />
      <header className="app-header">
        <a href="#/library" className="brand" aria-label="BATCAVE — библиотека">
          <Bat />
          <span>BATCAVE</span>
        </a>
        <div className="header-actions">
        {(current.tab === 'library' || current.tab === 'collection') && <>
          <button className="icon-button" aria-label="Открыть поиск" aria-expanded={searchOpen || !!searchQuery} onClick={() => setSearchOpen((v) => !v)}><Search size={20} /></button>
          {(current.tab !== 'collection' || collection.length > 0) && <button className="add-icon" aria-label={current.tab === 'collection' ? 'Добавить в коллекцию' : 'Добавить комикс'} onClick={() => current.tab === 'collection' ? setAddingCollection(true) : setAddingLibrary(true)}><Plus size={21} /></button>}
        </>}
        {current.tab==='profile' && <button className="icon-button" aria-label="Открыть коллекцию" onClick={()=>navigate('collection')}><CollectionIcon size={22}/></button>}
        {current.tab==='library' || current.tab==='settings'
          ? <button className="icon-button" aria-label="Открыть профиль" onClick={()=>navigate('profile')}><UserRound size={22}/></button>
          : <button className="icon-button" aria-label="Открыть настройки" onClick={()=>{settingsOrigin.current=current.tab;navigate('settings');}}><SettingsIcon size={20}/></button>}
        </div>
      </header>
      <main ref={main} key={current.tab} className="screen" onScroll={e => {if(current.tab === 'library') libraryScroll.current = e.currentTarget.scrollTop;}}>
        <div className={`page-heading ${current.tab === 'library' ? 'sr-only' : ''}`}>
          <div className="heading-title">
            {current.tab !== 'library' && (
              <button
                className="icon-button"
                aria-label="Назад"
                onClick={() => navigate(current.tab==='collection' ? 'profile' : current.tab==='settings' ? settingsOrigin.current : 'library')}
              >
                <ArrowLeft size={20} />
              </button>
            )}
            <h1>{title}{current.tab==='collection' && <small> · {collection.length}</small>}</h1>
          </div>
        </div>
        {error && (
          <div className="error" role="alert">
            {error}
            <button aria-label="Скрыть ошибку" onClick={() => setError('')}>
              ×
            </button>
          </div>
        )}
        {(current.tab === 'library' ||
          current.tab === 'collection' ||
          current.tab === 'reader') && (
          <>
            {(searchOpen || searchQuery) && <div className="search-row">
              <label className="search"><Search size={17} /><input autoFocus placeholder={current.tab === 'collection' ? 'Поиск в коллекции' : 'Поиск комиксов'} aria-label="Поиск комиксов" value={searchQuery} onChange={(e) => current.tab === 'collection' ? setPaperQuery(e.target.value) : setQuery(e.target.value)} />
              </label>
              <button className="icon-button" aria-label="Закрыть поиск" onClick={() => { setSearchOpen(false); current.tab === 'collection' ? setPaperQuery('') : setQuery(''); }}><X size={18} /></button>
            </div>}
            {current.tab!=='collection' && <h2 className="gallery-heading">Путь Бэтмена</h2>}
            {!visible.length ? (
              <Empty
                title={
                  current.tab === 'collection' && !collection.length
                    ? 'Коллекция пока пуста'
                    : (current.tab === 'collection' ? collection.length : library.length)
                      ? 'Ничего не найдено'
                      : 'Ваш первый комикс'
                }
              >
                <p>
                  {current.tab === 'collection' && !collection.length
                    ? 'Все ваши комиксы в одном месте.'
                    : (current.tab === 'collection' ? collection.length : library.length)
                      ? 'Измените поиск или фильтр.'
                      : 'Добавьте обложку или файл комикса.'}
                </p>
                {!(current.tab === 'collection' ? collection.length : library.length) && (
                  <button
                    className="primary"
                    onClick={() =>
                      current.tab === 'collection'
                        ? setAddingCollection(true)
                        : setAddingLibrary(true)
                    }
                  >
                    <Plus size={17} />
                    {current.tab === 'collection' ? 'Добавить в коллекцию' : 'Добавить комикс'}
                  </button>
                )}
              </Empty>
            ) : current.tab !== 'collection' ? (
              <Roadmap comics={visible} all={library} archive={comics} onRead={read} onEdit={setEditing} onSideStories={c=>setSideAnchor(c.id)} />
            ) : (
              <section className="catalog-group">
                <div className="comic-grid collection-grid">
                  {visible.map(c=><Card key={c.id} comic={c} paper={c.physical==='yes'} collection onClick={rect=>c.digital ? read(c,rect) : setEditing(c)} onEdit={()=>setEditing(c)}/>) }
                </div>
              </section>
            )}
          </>
        )}
        {current.tab === 'profile' && <Profile comics={comics} onEdit={setEditing} />}
        {current.tab === 'settings' && (
          <SettingsPanel
            settings={settings}
            onChange={setConfig}
            comics={comics}
            onRefresh={refresh}
            offline={updates.offline}
            updates={updates}
          />
        )}
      </main>
    </div>, document.body)}
      {updateNotice}
      {sideAnchor && current.tab==='library' && !editing && !importing && comics.some(c=>c.id===sideAnchor) && <SideStoriesDialog
        key={sideAnchor} afterId={sideAnchor} nextId={library[library.findIndex(c=>c.id===sideAnchor)+1]?.id}
        comics={comics} onClose={()=>setSideAnchor(undefined)} onSaved={refresh} onRead={read} onEdit={setEditing}
        onAdd={()=>setEditing({...blankComic(''),sideStoryAfter:sideAnchor,inRoadmap:false})}
      />}
      {addingLibrary && <Modal title="Добавить в маршрут" onClose={() => setAddingLibrary(false)}>
        <div className="collection-add-options">
          <button onClick={() => {setAddingLibrary(false);setEditing({...blankComic(''),inRoadmap:true});}}>
            <BookOpen size={22}/><span>Сначала обложка<small>Файл комикса можно добавить позже</small></span><ChevronRight size={17}/>
          </button>
          <button onClick={() => {setAddingLibrary(false);attach();}}>
            <Monitor size={22}/><span>Загрузить комикс<small>PDF, CBZ или изображение</small></span><ChevronRight size={17}/>
          </button>
        </div>
      </Modal>}
      {addingCollection && (
        <Modal title="Добавить в коллекцию" onClose={() => setAddingCollection(false)}>
          <div className="collection-add-options">
            <button onClick={() => {
              setAddingCollection(false);
              setEditing({ ...blankComic(''), physical: 'yes' });
            }}><Library size={22} /><span>Бумажное издание<small>Книга на вашей полке</small></span><ChevronRight size={17} /></button>
            <button onClick={() => {
              setAddingCollection(false);
              setEditing({ ...blankComic(''), completed: true, readDigitally: true });
            }}><Monitor size={22} /><span>Прочитанный комикс<small>Читали онлайн или в другом приложении</small></span><ChevronRight size={17} /></button>
          </div>
        </Modal>
      )}
      {editing && (
        <Editor
          key={editing.id}
          comic={editing}
          draft={!comics.some((c) => c.id === editing.id)}
          onClose={() => setEditing(undefined)}
          onSaved={refresh}
          onRead={read}
          onAttach={(c) => {
            setEditing(undefined);
            attach(c);
          }}
        />
      )}
      {importing && (
        <Importer
          file={importing.file}
          target={importing.target}
          onClose={() => setImporting(undefined)}
          onSaved={refresh}
        />
      )}
    </>
  );
}
