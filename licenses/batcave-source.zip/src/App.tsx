import { UniverseEditor } from './components/Universes';
import { comicUniverse, BATMAN_ID, STANDALONE_ID, type Universe } from './universes';
import {LibraryHome,AllSeriesDialog} from './components/LibraryHome';
import {searchComics,standaloneComics} from './library-home';
import {parseRoute,type Tab,type Route} from './navigation';
import { EraPathDialog } from './components/EraPathDialog';
import { type ChronologicalEraId } from './eras';
import { achievements } from './achievements';
import { AchievementsDialog } from './components/AchievementsDialog';
import { useAchievementNotifications, AchievementNotification } from './achievement-notifications';
import { useCallback, useEffect, useLayoutEffect, useRef, useState, lazy } from 'react';
import { createPortal } from 'react-dom';
import { useAppUpdates } from './updates';
import { useAppViewport } from './viewport';
import { DEFAULT_ERA, type EraId } from './eras';
import { EraPicker } from './components/EraPicker';
import {
  BookOpen,
  Settings as SettingsIcon,
  Search,
  Plus,
  ArrowLeft,
  ChevronRight,
  X,
  Monitor,
} from 'lucide-react';
import {
  type Comic,
  type Settings,
  defaultSettings,
  blankComic,
  errorMessage,
} from './models';
import { initialize, allComics, getSettings, saveSettings, getUniverses, moveSeriesComic, deleteComic } from './storage/db';
import { Bat, Card, Empty, Modal } from './components/ui';
import { SeriesRoute } from './components/SeriesRoute';
import { orderedSeriesTimeline } from './roadmap';
import { BookOpening } from './components/BookOpening';
const Editor = lazy(() => import('./components/Editor').then((m) => ({ default: m.Editor })));
const Importer = lazy(() => import('./components/Importer').then((m) => ({ default: m.Importer })));
const SettingsPanel = lazy(() =>
  import('./components/Settings').then((m) => ({ default: m.SettingsPanel })),
);
const loadReader = () => import('./reader/Reader').then((m) => ({ default: m.Reader }));
const Reader = lazy(loadReader);
const route=()=>parseRoute(location.hash);
export default function App() {
  const [comics, setComics] = useState<Comic[]>([]);
  const [universes,setUniverses]=useState<Universe[]>([]);
  const [universeEdit,setUniverseEdit]=useState<{value?:Universe}>();
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [achievementView,setAchievementView] = useState<{id?:string}>();
  const [eraView,setEraView] = useState<{era?:ChronologicalEraId}>();
  const [error, setError] = useState('');
  const [current, setCurrent] = useState(route);
  const [query, setQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [opening, setOpening] = useState<{ comic: Comic; rect: DOMRect }>();
  const finishOpening = useCallback(() => setOpening(undefined), []);
  const [addingLibrary, setAddingLibrary] = useState(false);
  const [allSeries,setAllSeries]=useState(false);
  const [addUniverseId,setAddUniverseId]=useState(STANDALONE_ID);
  const [addEra,setAddEra]=useState<EraId>();
  const attachEra=useRef<EraId|undefined>(undefined);
  const [editing, setEditing] = useState<Comic>();
  const [importing, setImporting] = useState<{ file: File; target?: Comic; era:EraId; universeId?:string }>();
  const updates = useAppUpdates();
  const awards = useAchievementNotifications(!loading, current.tab === 'reader' || current.tab === 'settings' || !!editing || !!importing || addingLibrary || allSeries || !!universeEdit || !!achievementView || !!eraView || (updates.state === 'ready' && !updates.noticeDismissed));
  const medals = achievements(comics,awards.state);
  const openAchievements = (id?:string) => setAchievementView({id});
  useAppViewport();
  const main = useRef<HTMLElement>(null);
  const scrollPositions=useRef(new Map<string,number>());
  const routeKey=`${current.tab}/${current.id??''}`;
  const readerOrigin=useRef<Route>({tab:'library'});
  const settingsOrigin=useRef<Route>({tab:'library'});
  useLayoutEffect(() => {
    if (!loading && main.current) {
      main.current.scrollTop = scrollPositions.current.get(routeKey)??0;
      main.current.toggleAttribute('data-scrolled',main.current.scrollTop>0);
    }
  }, [loading,routeKey]);
  const input = useRef<HTMLInputElement>(null);
  const attachTarget = useRef<Comic | undefined>(undefined);
  const refresh = useCallback(async () => {
    setComics(await allComics());
    setUniverses(await getUniverses());
    setSettings(await getSettings());
  }, []);
  useEffect(() => { if (!loading) void loadReader().catch(() => {}); }, [loading]);
  useEffect(() => {
    void initialize()
      .then(refresh)
      .then(() => setLoading(false))
      .catch((e) => {
        setError(errorMessage(e));
        setLoading(false);
      });
    const listener = () => {
      setCurrent(route());
      void refresh().catch((e) => setError(errorMessage(e)));
    };
    window.addEventListener('hashchange', listener);
    return () => window.removeEventListener('hashchange', listener);
  }, [refresh]);
  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const apply = () =>
      (document.documentElement.dataset.motion =
        settings.motion === 'system' ? (reduced.matches ? 'off' : 'full') : settings.motion);
    apply();
    reduced.addEventListener('change', apply);
    return () => reduced.removeEventListener('change', apply);
  }, [settings.motion]);
  function navigate(tab: Tab, id?: string) {
    if (tab !== current.tab) setSearchOpen(false);
    location.hash = `/${tab}${id ? `/${id}` : ''}`;
  }
  function setConfig(s: Settings) {
    setSettings(s);
    void saveSettings(s).catch((e) => setError(`Настройки не сохранены: ${errorMessage(e)}`));
  }
  function attach(target?: Comic) {
    attachTarget.current = target;
    attachEra.current=target?undefined:addEra;
    input.current?.click();
  }
  function read(c: Comic, rect?: DOMRect) {
    if (!c.digital) return;
    if (rect && document.documentElement.dataset.motion !== 'off') setOpening({ comic: c, rect });
    readerOrigin.current=current.tab==='reader' ? {tab:'library'} : current;
    setEditing(undefined);
    navigate('reader', c.id);
  }
  const activeUniverse=universes.find(u=>u.id===current.id);
  const seriesComics=comics.filter(c=>comicUniverse(c)===activeUniverse?.id);
  const selectedEra=activeUniverse?.chapters.find(p=>p.id===settings.roadmapEra)?.id ?? activeUniverse?.chapters[0]?.id ?? DEFAULT_ERA;
  const library = activeUniverse?.chapters.flatMap(ch=>orderedSeriesTimeline(seriesComics,ch.id))??[];
  function selectEra(era:EraId) {
    setQuery('');setSearchOpen(false);
    setConfig({...settings,roadmapEra:era});
    requestAnimationFrame(()=>document.getElementById(`route-section-${era}`)?.scrollIntoView({block:'start',behavior:document.documentElement.dataset.motion==='off'?'instant':'smooth'}));
  }
  const archive=current.id===STANDALONE_ID?standaloneComics(comics):current.tab==='archive'&&activeUniverse?seriesComics:comics;
  const visible=searchComics(current.tab==='archive'?[...archive].sort((a,b)=>b.addedAt-a.addedAt||a.id.localeCompare(b.id)):library,query);
  const shownUniverses=universes.filter(u=>u.id!==STANDALONE_ID);
  function openSeries(id:string){setQuery('');setSearchOpen(false);setAllSeries(false);navigate('library',id);}
  function beginAdd(era?:EraId){setAddEra(era);setAddUniverseId(activeUniverse?.id??(current.tab==='library'&&current.id?current.id:STANDALONE_ID));setAddingLibrary(true);}
  function draftComic(){const id=activeUniverse?.id??addUniverseId,u=universes.find(u=>u.id===id);return {...blankComic(''),universeId:id,era:addEra??(activeUniverse?selectedEra:u?.chapters[0].id??'main'),inRoadmap:!!u,series:u?.title??''};}
  function closeReader(){navigate(readerOrigin.current.tab,readerOrigin.current.id);void refresh();}
  const reading = comics.find((c) => c.id === current.id);
  const updateNotice = updates.state === 'ready' && !updates.noticeDismissed && !editing && !importing && !addingLibrary && !allSeries && current.tab !== 'settings' && createPortal(<div className={`app-update-notice ${current.tab === 'reader' ? 'reader-update-notice' : ''}`} role="status">
    <div><strong>Обновление готово</strong><p>{current.tab === 'reader' ? 'Закройте комикс, чтобы применить обновление.' : 'Примените его сейчас или закройте и заново откройте COMICS.'}</p></div>
    <button className="icon-button" aria-label="Скрыть уведомление об обновлении" onClick={updates.dismiss}><X size={18} /></button>
    {current.tab !== 'reader' && <button className="primary" onClick={updates.apply}>Обновить приложение</button>}
  </div>, document.body);

  if (loading)
    return (
      <div className="boot">
        <Bat />
        <span className="spinner" />
        <p>Открываем архив…</p>
      </div>
    );
  if (current.tab === 'reader' && reading?.digital)
    return (
      <>
      <Reader
        onFinishClose={closeReader}
        comic={reading}
        settings={settings}
        onSettings={setConfig}
        onClose={closeReader}
      />
      {updateNotice}
      {opening && <BookOpening {...opening} onDone={finishOpening} />}
      </>
    );
  const title = {
    library: 'Моя библиотека',
    archive: current.id===STANDALONE_ID?'Без серии':activeUniverse?activeUniverse.title:'Все комиксы',
    settings: 'Настройки',
    reader: 'Библиотека',
  }[current.tab];
  return (
    <>{createPortal(<div className={`app tab-${current.tab}`}>
      <input
        ref={input}
        hidden
        type="file"
        data-testid="comic-file-input"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) {const target=attachTarget.current,id=target?.universeId??activeUniverse?.id??addUniverseId,u=universes.find(u=>u.id===id);setImporting({file,target,era:target?.era??attachEra.current??(activeUniverse?selectedEra:u?.chapters[0].id??'main'),universeId:id});}
          e.target.value = '';
        }}
      />
      <header className="app-header">
        <a href="#/library" className="brand" aria-label="Моя библиотека" onClick={()=>{setQuery('');setSearchOpen(false);}}>
          <BookOpen size={25} />
          <span>COMICS</span>
        </a>
        <div className="header-actions">
        {(current.tab==='library'||current.tab==='archive')&&<>
          <button className="icon-button" aria-label="Открыть поиск" aria-expanded={searchOpen||!!query} onClick={()=>setSearchOpen(v=>!v)}><Search size={20}/></button>
          <button className="add-icon" aria-label="Добавить комикс" onClick={()=>beginAdd()}><Plus size={21}/></button>
        </>}
        {current.tab!=='settings'&&<button className="icon-button" aria-label="Открыть настройки" onClick={()=>{settingsOrigin.current=current;navigate('settings');}}><SettingsIcon size={20}/></button>}
        </div>
      </header>
      <main ref={main} key={`${current.tab}-${current.id??'home'}`} className="screen" onScroll={e => {
        e.currentTarget.toggleAttribute('data-scrolled',e.currentTarget.scrollTop>0);
        scrollPositions.current.set(routeKey,e.currentTarget.scrollTop);
      }}>
        {!(current.tab==='library'&&activeUniverse)&&<div className="page-heading">
          <div className="heading-title">
            {(current.tab !== 'library' || !!activeUniverse) && (
              <button
                className="icon-button"
                aria-label="Назад"
                onClick={() => {if(current.tab==='settings')navigate(settingsOrigin.current.tab,settingsOrigin.current.id);else{setQuery('');setSearchOpen(false);navigate('library',current.tab==='archive'?activeUniverse?.id:undefined);}}}
              >
                <ArrowLeft size={20} />
              </button>
            )}
            <h1>{title}</h1>
          </div>
        </div>}
        {error && (
          <div className="error" role="alert">
            {error}
            <button aria-label="Скрыть ошибку" onClick={() => setError('')}>
              ×
            </button>
          </div>
        )}
        {(current.tab==='library'||current.tab==='archive')&&(searchOpen||query)&&<div className="search-row library-search"><label className="search"><Search size={17}/><input autoFocus type="search" placeholder={activeUniverse?'Поиск в серии':'Название, серия или автор'} aria-label="Поиск комиксов" value={query} onChange={e=>setQuery(e.target.value)}/></label><button className="icon-button" aria-label="Закрыть поиск" onClick={()=>{setQuery('');setSearchOpen(false);}}><X size={18}/></button></div>}
        {current.tab==='library'&&!activeUniverse&&<LibraryHome comics={comics} universes={shownUniverses} medals={medals} query={query} onRead={read} onEdit={setEditing} onSeries={openSeries} onAllSeries={()=>setAllSeries(true)} onArchive={standalone=>{setQuery('');setSearchOpen(false);navigate('archive',standalone?STANDALONE_ID:undefined);}} onAchievements={()=>openAchievements()} onAddSeries={()=>setUniverseEdit({})}/>}
        {current.tab==='library'&&activeUniverse&&<section className="series-view" aria-label={`Комиксы серии ${activeUniverse.title}`}>
          <div className="series-heading"><button className="icon-button" aria-label="Моя библиотека" onClick={()=>{setQuery('');navigate('library');}}><ArrowLeft size={19}/></button><h1>{activeUniverse.title}</h1><button className="series-settings" onClick={()=>setUniverseEdit({value:activeUniverse})}>Изменить</button></div>
          <EraPicker value={selectedEra} onChange={selectEra} comics={seriesComics} chapters={activeUniverse.chapters} title={activeUniverse.id===BATMAN_ID?'Эры и подборки':'Разделы маршрута'} triggerLabel="Разделы маршрута"/>
          <SeriesRoute key={activeUniverse.id} universe={activeUniverse} comics={seriesComics} query={query} onRead={read} onEdit={setEditing} onAdd={beginAdd}
            onMove={async(id,era,beforeId)=>{await moveSeriesComic(id,activeUniverse.id,era,beforeId);await refresh();}}
            onDelete={async id=>{await deleteComic(id);await refresh();}}/>
          <button className="library-series-archive" onClick={()=>{setQuery('');navigate('archive',activeUniverse.id);}}>Все комиксы серии <span>{seriesComics.length}</span><ChevronRight size={16}/></button>
        </section>}
        {current.tab==='archive'&&<>
          {visible.length?<section className="catalog-group"><div className="comic-grid collection-grid">{visible.map(c=><Card key={c.id} comic={c} collection paper={c.physical==='yes'} onClick={rect=>c.digital?read(c,rect):setEditing(c)} onEdit={()=>setEditing(c)}/>)}</div></section>:<Empty title={query?'Ничего не найдено':'Здесь пока нет комиксов'}><p>{query?'Измените поисковый запрос.':'Добавьте файл или создайте карточку комикса.'}</p>{!query&&<button className="primary" onClick={()=>beginAdd()}><Plus size={17}/>Добавить комикс</button>}</Empty>}
        </>}
        {current.tab==='reader'&&<Empty title="Файл комикса недоступен"><p>Откройте карточку комикса и прикрепите файл заново.</p><button className="primary" onClick={()=>reading?setEditing(reading):navigate('library')}>{reading?'Открыть карточку':'Моя библиотека'}</button></Empty>}
        {current.tab === 'settings' && (
          <SettingsPanel
            settings={settings}
            onChange={setConfig}
            comics={comics}
            onRefresh={refresh}
            offline={updates.offline}
            updates={updates}
          />
        )}
      </main>
    </div>, document.body)}
      {achievementView && <AchievementsDialog medals={medals} initialId={achievementView.id} onClose={() => setAchievementView(undefined)} onEra={era=>{setAchievementView(undefined);setEraView({era});}}/>}
      {eraView && <EraPathDialog comics={comics} state={awards.state} medals={medals} initialEra={eraView.era} onClose={()=>setEraView(undefined)} onContinue={era=>{setEraView(undefined);setConfig({...settings,roadmapEra:era});setQuery('');setSearchOpen(false);navigate('library',BATMAN_ID);}}/>}
      {awards.show && awards.notice && <AchievementNotification ids={awards.notice} state={awards.state} onClose={awards.dismiss} onOpen={openAchievements}/>}
      {updateNotice}
      {universeEdit && <UniverseEditor universe={universeEdit.value} onClose={()=>setUniverseEdit(undefined)} onSaved={refresh}/>}
      {allSeries&&<AllSeriesDialog universes={shownUniverses} comics={comics} onClose={()=>setAllSeries(false)} onOpen={openSeries} onAdd={()=>{setAllSeries(false);setUniverseEdit({});}}/>}
      {addingLibrary&&<Modal title="Добавить" onClose={()=>setAddingLibrary(false)}>
        {!activeUniverse&&<label className="library-add-target">Серия<select aria-label="Добавить в серию" value={addUniverseId} onChange={e=>setAddUniverseId(e.target.value)}><option value={STANDALONE_ID}>Без серии</option>{shownUniverses.map(u=><option key={u.id} value={u.id}>{u.title}</option>)}</select></label>}
        <div className="collection-add-options">
          <button onClick={()=>{setAddingLibrary(false);attach();}}><Monitor size={22}/><span>Загрузить комикс<small>PDF, CBZ или изображение</small></span><ChevronRight size={17}/></button>
          <button onClick={()=>{setAddingLibrary(false);setEditing(draftComic());}}><BookOpen size={22}/><span>Создать карточку<small>Обложка, бумажное издание или прочитанный комикс</small></span><ChevronRight size={17}/></button>
          {!activeUniverse&&<button onClick={()=>{setAddingLibrary(false);setUniverseEdit({});}}><Plus size={22}/><span>Новая серия<small>Своя обложка и дорожная карта</small></span><ChevronRight size={17}/></button>}
        </div>
      </Modal>}
      {editing && (
        <Editor
          key={editing.id}
          comic={editing}
          universes={universes}
          relatedComics={comics}
          draft={!comics.some((c) => c.id === editing.id)}
          onClose={() => setEditing(undefined)}
          onSaved={refresh}
          onRead={read}
          onAttach={(c) => {
            setEditing(undefined);
            attach(c);
          }}
        />
      )}
      {importing && (
        <Importer
          file={importing.file}
          era={importing.era}
          universeId={importing.universeId}
          target={importing.target}
          onClose={() => setImporting(undefined)}
          onSaved={refresh}
        />
      )}
    </>
  );
}
