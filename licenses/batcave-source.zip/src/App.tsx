import { UniverseEditor,UniverseCover,DeleteSeriesDialog } from './components/Universes';
import { comicUniverse, BATMAN_ID, STANDALONE_ID, type Universe } from './universes';
import {LibraryHome,AllSeriesDialog} from './components/LibraryHome';
import {searchComics,standaloneComics,routeProgress} from './library-home';
import {parseRoute,type Tab,type Route} from './navigation';
import { EraPathDialog } from './components/EraPathDialog';
import { type ChronologicalEraId } from './eras';
import { achievements } from './achievements';
import { AchievementsPage } from './components/AchievementsPage';
import { useAchievementNotifications, AchievementNotification } from './achievement-notifications';
import { useCallback, useEffect, useLayoutEffect, useRef, useState, lazy } from 'react';
import { createPortal } from 'react-dom';
import { useAppUpdates } from './updates';
import { useAppViewport } from './viewport';
import { DEFAULT_ERA, type EraId } from './eras';
import { AppIcon } from './components/AppIcon';
import {
  BookOpen,
  Bookmark,
  Settings as SettingsIcon,
  Search,
  Plus,
  ArrowLeft,
  ChevronRight,
  X,
  Monitor,
  Pencil,
  Ellipsis,
  UserRound,
  Library,
  Trash2,
} from 'lucide-react';
import {
  type Comic,
  type Settings,
  defaultSettings,
  blankComic,
  errorMessage,
} from './models';
import { initialize, allComics, getSettings, saveSettings, getUniverses, moveSeriesComic, deleteComic } from './storage/db';
import { Bat, Card, Empty, Modal } from './components/ui';
import { SeriesRoute } from './components/SeriesRoute';
import { orderedSeriesTimeline } from './roadmap';
import { ReadingProgress } from './components/ReadingProgress';
import { BookOpening } from './components/BookOpening';
const Editor = lazy(() => import('./components/Editor').then((m) => ({ default: m.Editor })));
const Importer = lazy(() => import('./components/Importer').then((m) => ({ default: m.Importer })));
const SettingsPanel = lazy(() =>
  import('./components/Settings').then((m) => ({ default: m.SettingsPanel })),
);
const loadReader = () => import('./reader/Reader').then((m) => ({ default: m.Reader }));
const Reader = lazy(loadReader);
const route=()=>parseRoute(location.hash);
export default function App() {
  const [comics, setComics] = useState<Comic[]>([]);
  const [universes,setUniverses]=useState<Universe[]>([]);
  const [universeEdit,setUniverseEdit]=useState<{value?:Universe}>();
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [eraView,setEraView] = useState<{era?:ChronologicalEraId}>();
  const [error, setError] = useState('');
  const [current, setCurrent] = useState(route);
  const [query, setQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [opening, setOpening] = useState<{ comic: Comic; rect: DOMRect }>();
  const finishOpening = useCallback(() => setOpening(undefined), []);
  const [addingLibrary, setAddingLibrary] = useState(false);
  const [allSeries,setAllSeries]=useState(false);
  const [seriesMenu,setSeriesMenu]=useState(false);
  const [deletingSeries,setDeletingSeries]=useState<Universe>();
  const [addUniverseId,setAddUniverseId]=useState(STANDALONE_ID);
  const [addEra,setAddEra]=useState<EraId>();
  const attachEra=useRef<EraId|undefined>(undefined);
  const [editing, setEditing] = useState<Comic>();
  const [importing, setImporting] = useState<{ file: File; target?: Comic; era:EraId; universeId?:string }>();
  const updates = useAppUpdates();
  const awards = useAchievementNotifications(!loading, current.tab === 'reader' || current.tab === 'settings' || !!editing || !!importing || addingLibrary || allSeries || seriesMenu || !!deletingSeries || !!universeEdit || current.tab === 'achievements' || !!eraView || !!opening || !!error || (updates.state === 'ready' && !updates.noticeDismissed));
  const medals = achievements(comics,awards.state);
  const openAchievements = (id?:string) => {setQuery('');navigate('achievements',id);};
  useAppViewport();
  const main = useRef<HTMLElement>(null);
  const scrollPositions=useRef(new Map<string,number>());
  const routeKey=`${current.tab}/${current.id??''}`;
  const readerOrigin=useRef<Route>({tab:'library'});
  const settingsOrigin=useRef<Route>({tab:'library'});
  const restoreScroll=useCallback(() => {
    if (!loading && main.current) {
      main.current.scrollTop = scrollPositions.current.get(routeKey)??0;
      main.current.toggleAttribute('data-scrolled',main.current.scrollTop>0);
      main.current.closest('.app')?.toggleAttribute('data-scrolled',main.current.scrollTop>4);
    }
  }, [loading,routeKey]);
  // A series restores its position after its saved disclosures are loaded.
  useLayoutEffect(()=>{if(current.tab!=='library'||!current.id)restoreScroll();},[restoreScroll,current.tab,current.id]);
  const input = useRef<HTMLInputElement>(null);
  const attachTarget = useRef<Comic | undefined>(undefined);
  const refresh = useCallback(async () => {
    setComics(await allComics());
    setUniverses(await getUniverses());
    setSettings(await getSettings());
  }, []);
  useEffect(() => { if (!loading) void loadReader().catch(() => {}); }, [loading]);
  useEffect(() => {
    void initialize()
      .then(refresh)
      .then(() => setLoading(false))
      .catch((e) => {
        setError(errorMessage(e));
        setLoading(false);
      });
    const listener = () => {
      setCurrent(route());
      void refresh().catch((e) => setError(errorMessage(e)));
    };
    window.addEventListener('hashchange', listener);
    return () => window.removeEventListener('hashchange', listener);
  }, [refresh]);
  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const apply = () =>
      (document.documentElement.dataset.motion =
        settings.motion === 'system' ? (reduced.matches ? 'off' : 'full') : settings.motion);
    apply();
    reduced.addEventListener('change', apply);
    return () => reduced.removeEventListener('change', apply);
  }, [settings.motion]);
  function navigate(tab: Tab, id?: string) {
    if(tab===current.tab&&id===current.id)return;
    setSearchOpen(false);
    history.pushState({comicsParent:current},'',`#/${tab}${id?`/${id}`:''}`);
    setCurrent({tab,id});
    void refresh().catch(e=>setError(errorMessage(e)));
  }
  function backTo(tab:Tab,id?:string){
    setQuery('');setSearchOpen(false);
    const parent=history.state?.comicsParent;
    if(parent?.tab===tab&&parent.id===id){history.back();return;}
    history.replaceState(null,'',`#/${tab}${id?`/${id}`:''}`);
    setCurrent({tab,id});void refresh().catch(e=>setError(errorMessage(e)));
  }
  function openSettings(){
    if(current.tab==='settings')return;
    settingsOrigin.current=current;navigate('settings');
  }
  function setConfig(s: Settings) {
    setSettings(s);
    void saveSettings(s).catch((e) => setError(`Настройки не сохранены: ${errorMessage(e)}`));
  }
  function attach(target?: Comic) {
    attachTarget.current = target;
    attachEra.current=target?undefined:addEra;
    input.current?.click();
  }
  function read(c: Comic, rect?: DOMRect) {
    if (!c.digital) return;
    if (!c.completed && rect && document.documentElement.dataset.motion !== 'off') setOpening({ comic: c, rect });
    const origin=current.tab==='reader' ? readerOrigin.current : current;
    readerOrigin.current=origin;
    setEditing(undefined);setSearchOpen(false);
    // Reading is a temporary child. Closing traverses back to its parent;
    // pushing another copy would leave the closed reader behind that parent.
    const url=`#/reader/${c.id}`;
    if(current.tab==='reader')history.replaceState({comicsReaderOrigin:origin},'',url);
    else history.pushState({comicsReaderOrigin:origin},'',url);
    setCurrent({tab:'reader',id:c.id});
  }
  const activeUniverse=(current.tab==='library'||current.tab==='archive')?universes.find(u=>u.id===current.id):undefined;
  const seriesComics=comics.filter(c=>comicUniverse(c)===activeUniverse?.id);
  const selectedEra=activeUniverse?.chapters.find(p=>p.id===settings.roadmapEra)?.id ?? activeUniverse?.chapters[0]?.id ?? DEFAULT_ERA;
  const library = activeUniverse?.chapters.flatMap(ch=>orderedSeriesTimeline(seriesComics,ch.id))??[];
  const archive=current.id===STANDALONE_ID?standaloneComics(comics):current.tab==='archive'&&activeUniverse?seriesComics:comics;
  const visible=searchComics(current.tab==='archive'?[...archive].sort((a,b)=>b.addedAt-a.addedAt||a.id.localeCompare(b.id)):library,query);
  const shownUniverses=universes.filter(u=>u.id!==STANDALONE_ID);
  function openSeries(id:string){setQuery('');setSearchOpen(false);setAllSeries(false);navigate('library',id);}
  function beginAdd(era?:EraId){setAddEra(era);setAddUniverseId(activeUniverse?.id??(current.tab==='library'&&current.id?current.id:STANDALONE_ID));setAddingLibrary(true);}
  function draftComic(){const id=activeUniverse?.id??addUniverseId,u=universes.find(u=>u.id===id);return {...blankComic(''),universeId:id,era:addEra??(activeUniverse?selectedEra:u?.chapters[0].id??'main'),inRoadmap:!!u,series:u?.title??''};}
  function closeReader(){
    if(history.state?.comicsReaderOrigin){history.back();return;}
    // Direct reader links have no in-app parent entry to traverse to.
    const origin=readerOrigin.current;
    history.replaceState(null,'',`#/${origin.tab}${origin.id?`/${origin.id}`:''}`);
    setCurrent(origin);void refresh();
  }
  const reading = comics.find((c) => c.id === current.id);
  const updateNotice = updates.state === 'ready' && !updates.noticeDismissed && !editing && !importing && !addingLibrary && !allSeries && current.tab !== 'settings' && createPortal(<div className={`app-update-notice ${current.tab === 'reader' ? 'reader-update-notice' : ''}`} role="status">
    <div><strong>Обновление готово</strong><p>{current.tab === 'reader' ? 'Закройте комикс, чтобы применить обновление.' : 'Примените его сейчас или закройте и заново откройте COMICS.'}</p></div>
    <button className="icon-button" aria-label="Скрыть уведомление об обновлении" onClick={updates.dismiss}><X size={18} /></button>
    {current.tab !== 'reader' && <button className="primary" onClick={updates.apply}>Обновить приложение</button>}
  </div>, document.body);

  if (loading)
    return (
      <div className="boot">
        <Bat />
        <span className="spinner" />
        <p>Открываем архив…</p>
      </div>
    );
  if (current.tab === 'reader' && reading?.digital)
    return (
      <>
      <Reader
        key={reading.id}
        onFinishClose={closeReader}
        comic={reading}
        settings={settings}
        onSettings={setConfig}
        onClose={closeReader}
      />
      {updateNotice}
      {opening && <BookOpening {...opening} onDone={finishOpening} />}
      </>
    );
  const title = {
    library: 'Моя библиотека',
    archive: current.id===STANDALONE_ID?'Без серии':activeUniverse?activeUniverse.title:'Все комиксы',
    settings: 'Настройки',
    achievements: 'Профиль',
    reader: 'Библиотека',
  }[current.tab];
  return (
    <>{createPortal(<div className={`app tab-${current.tab}`}>
      <input
        ref={input}
        hidden
        type="file"
        data-testid="comic-file-input"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) {const target=attachTarget.current,id=target?.universeId??activeUniverse?.id??addUniverseId,u=universes.find(u=>u.id===id);setImporting({file,target,era:target?.era??attachEra.current??(activeUniverse?selectedEra:u?.chapters[0].id??'main'),universeId:id});}
          e.target.value = '';
        }}
      />
      <header className={`app-header ${current.tab==='library'&&activeUniverse?'series-header':''}`}>
        <div className="app-heading">
          {current.tab==='library'&&!activeUniverse&&<AppIcon className="library-brand-mark" icon={Bookmark} size={25}/>}
          {(activeUniverse||current.tab!=='library')&&<button className="icon-button" aria-label={current.tab==='library'?'Моя библиотека':'Назад'} onClick={()=>current.tab==='settings'?backTo(settingsOrigin.current.tab,settingsOrigin.current.id):current.tab==='achievements'&&current.id?backTo('achievements'):backTo('library',current.tab==='archive'?activeUniverse?.id:undefined)}><AppIcon icon={ArrowLeft}/></button>}
          <h1 aria-label={current.tab==='library'?(activeUniverse?.title??'Моя библиотека'):undefined}>{current.tab==='library'?(activeUniverse?.title??'Библиотека'):title}</h1>
        </div>
        <div className="header-actions">
          {current.tab==='library'&&activeUniverse?<button className="icon-button" aria-label="Меню серии" aria-haspopup="dialog" aria-expanded={seriesMenu} onClick={()=>setSeriesMenu(true)}><AppIcon icon={Ellipsis}/></button>:(current.tab==='library'||current.tab==='archive')&&<>
            <button className="icon-button" aria-label="Открыть поиск" aria-expanded={searchOpen||!!query} onClick={()=>setSearchOpen(v=>!v)}><AppIcon icon={Search}/></button>
            <button className="icon-button add-icon" aria-label="Добавить комикс" onClick={()=>beginAdd()}><AppIcon icon={Plus}/></button>
          </>}
        </div>
      </header>
      <main ref={main} key={`${current.tab}-${current.tab==='achievements'?'page':current.id??'home'}`} className="screen" onScroll={e => {
        e.currentTarget.toggleAttribute('data-scrolled',e.currentTarget.scrollTop>0);
        scrollPositions.current.set(routeKey,e.currentTarget.scrollTop);
        e.currentTarget.closest('.app')?.toggleAttribute('data-scrolled',e.currentTarget.scrollTop>4);
      }}>
        {error && (
          <div className="error" role="alert">
            {error}
            <button aria-label="Скрыть ошибку" onClick={() => setError('')}>
              ×
            </button>
          </div>
        )}
        {(current.tab==='library'||current.tab==='archive')&&(searchOpen||query)&&<div className="search-row library-search"><label className="search"><Search size={17}/><input autoFocus type="search" placeholder={activeUniverse?'Поиск в серии':'Название, серия или автор'} aria-label="Поиск комиксов" value={query} onChange={e=>setQuery(e.target.value)}/></label><button className="icon-button" aria-label="Закрыть поиск" onClick={()=>{setQuery('');setSearchOpen(false);}}><X size={18}/></button></div>}
        {current.tab==='library'&&!activeUniverse&&<LibraryHome comics={comics} universes={shownUniverses} query={query} onRead={read} onEdit={setEditing} onSeries={openSeries} onAllSeries={()=>setAllSeries(true)} onArchive={standalone=>{setQuery('');setSearchOpen(false);navigate('archive',standalone?STANDALONE_ID:undefined);}} onAddSeries={()=>setUniverseEdit({})}/>}
        {current.tab==='library'&&activeUniverse&&<section className="series-view" aria-label={`Комиксы серии ${activeUniverse.title}`}>
          {!query&&<div className="series-overview"><UniverseCover universe={activeUniverse} comics={seriesComics}/><div className="series-overview-copy"><h2>{activeUniverse.title}</h2><p>Комиксов: {seriesComics.length} · {seriesComics.length>0&&seriesComics.every(c=>c.completed)?'Все прочитаны':`Прочитано: ${seriesComics.filter(c=>c.completed).length}`}</p><ReadingProgress label="Прогресс серии" value={routeProgress(seriesComics)} completed={seriesComics.length?seriesComics.filter(c=>c.completed).length/seriesComics.length*100:0}/></div></div>}
          <SeriesRoute key={activeUniverse.id} universe={activeUniverse} comics={seriesComics} query={query} onReady={restoreScroll} onRead={read} onEdit={setEditing} onAdd={beginAdd}
            onMove={async(id,era,beforeId)=>{await moveSeriesComic(id,activeUniverse.id,era,beforeId);await refresh();}}
            onDelete={async id=>{await deleteComic(id);await refresh();}}/>
          <button className="library-series-archive" onClick={()=>{setQuery('');navigate('archive',activeUniverse.id);}}><AppIcon icon={Library} size={19}/>Все комиксы серии <span>{seriesComics.length}</span><AppIcon icon={ChevronRight} size={17}/></button>
        </section>}
        {current.tab==='archive'&&<>
          {visible.length?<section className="catalog-group"><div className="comic-grid collection-grid">{visible.map(c=><Card key={c.id} comic={c} collection paper={c.physical==='yes'} onClick={rect=>c.digital?read(c,rect):setEditing(c)} onEdit={()=>setEditing(c)}/>)}</div></section>:<Empty title={query?'Ничего не найдено':'Здесь пока нет комиксов'}><p>{query?'Измените поисковый запрос.':'Добавьте файл или создайте карточку комикса.'}</p>{!query&&<button className="primary" onClick={()=>beginAdd()}><Plus size={17}/>Добавить комикс</button>}</Empty>}
        </>}
        {current.tab==='reader'&&<Empty title="Файл комикса недоступен"><p>Откройте карточку комикса и прикрепите файл заново.</p><button className="primary" onClick={()=>reading?setEditing(reading):navigate('library')}>{reading?'Открыть карточку':'Моя библиотека'}</button></Empty>}
        {current.tab==='achievements'&&<AchievementsPage comics={comics} state={awards.state}/>}
        {current.tab === 'settings' && (
          <SettingsPanel
            settings={settings}
            onChange={setConfig}
            comics={comics}
            onRefresh={refresh}
            offline={updates.offline}
            updates={updates}
          />
        )}
      </main>
      <nav className="app-nav" aria-label="Разделы приложения">
        <a href="#/library" aria-label="Моя библиотека" aria-current={current.tab==='library'||current.tab==='archive'?'page':undefined} onClick={e=>{e.preventDefault();backTo('library');}}><AppIcon icon={BookOpen}/><span>Библиотека</span></a>
        <a href="#/achievements" aria-label="Открыть профиль" aria-current={current.tab==='achievements'?'page':undefined} onClick={e=>{e.preventDefault();if(current.tab==='achievements')backTo('achievements');else openAchievements();}}><AppIcon icon={UserRound}/><span>Профиль</span></a>
        <button aria-label="Открыть настройки" aria-current={current.tab==='settings'?'page':undefined} onClick={openSettings}><AppIcon icon={SettingsIcon}/><span>Настройки</span></button>
      </nav>
    </div>, document.body)}
      {eraView && <EraPathDialog comics={comics} state={awards.state} medals={medals} initialEra={eraView.era} onClose={()=>setEraView(undefined)} onContinue={era=>{setEraView(undefined);setConfig({...settings,roadmapEra:era});setQuery('');setSearchOpen(false);navigate('library',BATMAN_ID);}}/>}
      {awards.show && awards.notice && <AchievementNotification ids={awards.notice} onClose={awards.dismiss}/>}
      {updateNotice}
      {universeEdit && <UniverseEditor universe={universeEdit.value} onClose={()=>setUniverseEdit(undefined)} onSaved={refresh}/>}
      {seriesMenu&&activeUniverse&&<Modal title="Серия" className="series-menu-sheet" onClose={()=>setSeriesMenu(false)}><div className="route-menu-actions">
        <button onClick={()=>{setSeriesMenu(false);setUniverseEdit({value:activeUniverse});}}><AppIcon icon={Pencil} size={20}/>Изменить серию</button>
        <button onClick={()=>{setSeriesMenu(false);setSearchOpen(true);}}><AppIcon icon={Search} size={20}/>Открыть поиск</button>
        <button onClick={()=>{setSeriesMenu(false);beginAdd();}}><AppIcon icon={Plus} size={20}/>Добавить комикс</button>
        <button onClick={()=>{setSeriesMenu(false);navigate('archive',activeUniverse.id);}}><AppIcon icon={Library} size={20}/>Все комиксы серии</button>
        <button className="danger" onClick={()=>{setSeriesMenu(false);setDeletingSeries(activeUniverse);}}><AppIcon icon={Trash2} size={20}/>Удалить серию</button>
      </div></Modal>}
      {deletingSeries&&<DeleteSeriesDialog universe={deletingSeries} onClose={()=>setDeletingSeries(undefined)} onDeleted={async()=>{
        await refresh();setDeletingSeries(undefined);setQuery('');setSearchOpen(false);setAddUniverseId(STANDALONE_ID);setAddEra(undefined);
        history.replaceState(null,'','#/library');setCurrent({tab:'library'});
      }}/>}
      {allSeries&&<AllSeriesDialog universes={shownUniverses} comics={comics} onClose={()=>setAllSeries(false)} onOpen={openSeries} onAdd={()=>{setAllSeries(false);setUniverseEdit({});}}/>}
      {addingLibrary&&<Modal title="Добавить" onClose={()=>setAddingLibrary(false)}>
        {!activeUniverse&&<label className="library-add-target">Серия<select aria-label="Добавить в серию" value={addUniverseId} onChange={e=>setAddUniverseId(e.target.value)}><option value={STANDALONE_ID}>Без серии</option>{shownUniverses.map(u=><option key={u.id} value={u.id}>{u.title}</option>)}</select></label>}
        <div className="collection-add-options">
          <button onClick={()=>{setAddingLibrary(false);attach();}}><Monitor size={22}/><span>Загрузить комикс<small>PDF, CBZ или изображение</small></span><ChevronRight size={17}/></button>
          <button onClick={()=>{setAddingLibrary(false);setEditing(draftComic());}}><BookOpen size={22}/><span>Создать карточку<small>Обложка, бумажное издание или прочитанный комикс</small></span><ChevronRight size={17}/></button>
          {!activeUniverse&&<button onClick={()=>{setAddingLibrary(false);setUniverseEdit({});}}><Plus size={22}/><span>Новая серия<small>Своя обложка и дорожная карта</small></span><ChevronRight size={17}/></button>}
        </div>
      </Modal>}
      {editing && (
        <Editor
          key={editing.id}
          comic={editing}
          universes={universes}
          relatedComics={comics}
          draft={!comics.some((c) => c.id === editing.id)}
          onClose={() => setEditing(undefined)}
          onSaved={refresh}
          onRead={read}
          onAttach={(c) => {
            setEditing(undefined);
            attach(c);
          }}
        />
      )}
      {importing && (
        <Importer
          file={importing.file}
          era={importing.era}
          universeId={importing.universeId}
          target={importing.target}
          onClose={() => setImporting(undefined)}
          onSaved={refresh}
        />
      )}
    </>
  );
}
