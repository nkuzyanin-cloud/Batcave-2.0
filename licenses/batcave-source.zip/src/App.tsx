import { useCallback, useEffect, useLayoutEffect, useRef, useState, lazy } from 'react';
import { createPortal } from 'react-dom';
import {
  BookOpen,
  Library,
  UserRound,
  Settings as SettingsIcon,
  Search,
  Plus,
  ArrowLeft,
  ChevronRight,
  SlidersHorizontal,
  X,
  Monitor,
} from 'lucide-react';
import {
  type Comic,
  type Settings,
  defaultSettings,
  status,
  blankComic,
  errorMessage,
} from './models';
import { initialize, allComics, getSettings, saveSettings } from './storage/db';
import { Bat, Card, Empty, Modal } from './components/ui';
import { inCollection, matchesCollection, type CollectionFilter } from './collection';
import { Profile } from './components/Profile';
import { Roadmap } from './components/Roadmap';
import { orderedRoadmap } from './roadmap';
import { BookOpening } from './components/BookOpening';
const Editor = lazy(() => import('./components/Editor').then((m) => ({ default: m.Editor })));
const Importer = lazy(() => import('./components/Importer').then((m) => ({ default: m.Importer })));
const SettingsPanel = lazy(() =>
  import('./components/Settings').then((m) => ({ default: m.SettingsPanel })),
);
const loadReader = () => import('./reader/Reader').then((m) => ({ default: m.Reader }));
const Reader = lazy(loadReader);
const filters = [
  ['all', 'Все'],
  ['reading', 'Читаю'],
  ['new', 'Не начато'],
  ['done', 'Прочитано'],
] as const;
type Tab = 'library' | 'collection' | 'profile' | 'settings' | 'reader';
function route() {
  const parts = location.hash.replace(/^#\/?/, '').split('/');
  return {
    tab: (['library', 'collection', 'profile', 'settings', 'reader'].includes(parts[0])
      ? parts[0]
      : 'library') as Tab,
    id: parts[1],
  };
}
export default function App() {
  const [comics, setComics] = useState<Comic[]>([]);
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [current, setCurrent] = useState(route);
  const [query, setQuery] = useState('');
  const [paperQuery, setPaperQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [opening, setOpening] = useState<{ comic: Comic; rect: DOMRect }>();
  const finishOpening = useCallback(() => setOpening(undefined), []);
  const [filter, setFilter] = useState('all');
  const [collectionFilter, setCollectionFilter] = useState<CollectionFilter>('all');
  const [addingLibrary, setAddingLibrary] = useState(false);
  const [addingCollection, setAddingCollection] = useState(false);
  const [editing, setEditing] = useState<Comic>();
  const [importing, setImporting] = useState<{ file: File; target?: Comic }>();
  const [offline, setOffline] = useState('Подготовка офлайн-режима…');
  const [update, setUpdate] = useState<ServiceWorkerRegistration>();
  const main = useRef<HTMLElement>(null);
  const libraryScroll = useRef(0);
  useLayoutEffect(() => {
    if (!loading && current.tab === 'library' && main.current) main.current.scrollTop = libraryScroll.current;
  }, [loading, current.tab]);
  const input = useRef<HTMLInputElement>(null);
  const attachTarget = useRef<Comic | undefined>(undefined);
  const refresh = useCallback(async () => {
    setComics(await allComics());
    setSettings(await getSettings());
  }, []);
  useEffect(() => { if (!loading) void loadReader().catch(() => {}); }, [loading]);
  useEffect(() => {
    void initialize()
      .then(refresh)
      .then(() => setLoading(false))
      .catch((e) => {
        setError(errorMessage(e));
        setLoading(false);
      });
    const listener = () => {
      setCurrent(route());
      void refresh().catch((e) => setError(errorMessage(e)));
    };
    window.addEventListener('hashchange', listener);
    return () => window.removeEventListener('hashchange', listener);
  }, [refresh]);
  useEffect(() => {
    if (!('serviceWorker' in navigator)) {
      setOffline('Офлайн недоступен в этом браузере');
      return;
    }
    if (import.meta.env.DEV) {
      setOffline('Режим разработки · офлайн доступен в сборке');
      return;
    }
    let alive = true;
    void navigator.serviceWorker
      .register(new URL('./sw.js', document.baseURI), { scope: './' })
      .then((r) => {
        if (r.active) setOffline('Офлайн готов');
        if (r.waiting) setUpdate(r);
        r.addEventListener('updatefound', () => {
          const worker = r.installing;
          worker?.addEventListener('statechange', () => {
            if (worker.state === 'installed') {
              if (navigator.serviceWorker.controller) setUpdate(r);
              else if (alive) setOffline('Офлайн готов');
            }
            if (worker.state === 'redundant' && alive)
              setOffline(
                'Не удалось подготовить офлайн. Подключитесь к сети и откройте приложение заново.',
              );
          });
        });
      })
      .catch(() => setOffline('Офлайн пока не готов. Откройте сайт при стабильном интернете.'));
    const ready = () => {
      if (alive) setOffline('Офлайн готов');
    };
    navigator.serviceWorker.addEventListener('controllerchange', ready);
    return () => {
      alive = false;
      navigator.serviceWorker.removeEventListener('controllerchange', ready);
    };
  }, []);
  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const apply = () =>
      (document.documentElement.dataset.motion =
        settings.motion === 'system' ? (reduced.matches ? 'off' : 'full') : settings.motion);
    apply();
    reduced.addEventListener('change', apply);
    return () => reduced.removeEventListener('change', apply);
  }, [settings.motion]);
  function navigate(tab: Tab, id?: string) {
    if (tab !== current.tab) setSearchOpen(false);
    location.hash = `/${tab}${id ? `/${id}` : ''}`;
  }
  function setConfig(s: Settings) {
    setSettings(s);
    void saveSettings(s).catch((e) => setError(`Настройки не сохранены: ${errorMessage(e)}`));
  }
  function attach(target?: Comic) {
    attachTarget.current = target;
    input.current?.click();
  }
  function read(c: Comic, rect?: DOMRect) {
    if (!c.digital) return;
    if (rect && document.documentElement.dataset.motion !== 'off') setOpening({ comic: c, rect });
    setEditing(undefined);
    navigate('reader', c.id);
  }
  const library = orderedRoadmap(comics).sort((a,b) => settings.sort === 'title' ? a.title.localeCompare(b.title,'ru') : settings.sort === 'year' ? (b.year || 0) - (a.year || 0) : a.addedAt-b.addedAt || a.id.localeCompare(b.id));
  const collection = comics.filter(inCollection);
  const searchQuery = current.tab === 'collection' ? paperQuery : query;
  const visible = (current.tab === 'collection' ? collection.filter(c => matchesCollection(c, collectionFilter)) : library)
    .filter(
      (c) =>
        (`${c.title} ${c.series} ${c.authors}`
          .toLocaleLowerCase('ru')
          .includes(searchQuery.toLocaleLowerCase('ru')) &&
          (current.tab === 'collection' || filter === 'all' || status(c) === filter)),
    )
    .sort((a, b) =>
      settings.sort === 'title'
        ? a.title.localeCompare(b.title, 'ru')
        : settings.sort === 'year'
          ? (b.year || 0) - (a.year || 0)
          : current.tab === 'collection' ? b.addedAt - a.addedAt : a.addedAt - b.addedAt,
    );
  const groups =
    current.tab !== 'collection' && settings.groupSeries
      ? Array.from(new Set(visible.map((c) => c.series || 'Без серии'))).map((name) => ({
          name,
          books: visible.filter((c) => (c.series || 'Без серии') === name),
        }))
      : [{ name: '', books: visible }];
  const reading = comics.find((c) => c.id === current.id);
  if (loading)
    return (
      <div className="boot">
        <Bat />
        <span className="spinner" />
        <p>Открываем архив…</p>
      </div>
    );
  if (current.tab === 'reader' && reading?.digital)
    return (
      <>
      <Reader
        comic={reading}
        settings={settings}
        onSettings={setConfig}
        onClose={() => {
          navigate('library');
          void refresh();
        }}
      />
      {opening && <BookOpening {...opening} onDone={finishOpening} />}
      </>
    );
  const title = {
    library: 'Библиотека',
    collection: 'Коллекция',
    profile: 'Профиль',
    settings: 'Настройки',
    reader: 'Библиотека',
  }[current.tab];
  return (
    <><div className={`app tab-${current.tab}`}>
      <input
        ref={input}
        hidden
        type="file"
        data-testid="comic-file-input"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) setImporting({ file, target: attachTarget.current });
          e.target.value = '';
        }}
      />
      <header className="app-header">
        <a href="#/library" className="brand" aria-label="BATCAVE — библиотека">
          <Bat />
          <span>BATCAVE</span>
        </a>
        <div className="header-actions">
        {(current.tab === 'library' || current.tab === 'collection') && <>
          <button className="icon-button" aria-label="Открыть поиск" aria-expanded={searchOpen || !!searchQuery} onClick={() => setSearchOpen((v) => !v)}><Search size={20} /></button>
          {(current.tab !== 'collection' || collection.length > 0) && <button className="add-icon" aria-label={current.tab === 'collection' ? 'Добавить в коллекцию' : 'Добавить комикс'} onClick={() => current.tab === 'collection' ? setAddingCollection(true) : setAddingLibrary(true)}><Plus size={21} /></button>}
        </>}
        <button
          className="icon-button"
          aria-label="Открыть настройки"
          onClick={() => navigate('settings')}
        >
          <SettingsIcon size={20} />
        </button>
        </div>
      </header>
      <main ref={main} key={current.tab} className="screen" onScroll={e => {if(current.tab === 'library') libraryScroll.current = e.currentTarget.scrollTop;}}>
        <div className={`page-heading ${current.tab !== 'settings' ? 'sr-only' : ''}`}>
          <div className="heading-title">
            {current.tab === 'settings' && (
              <button
                className="icon-button"
                aria-label="Назад"
                onClick={() => navigate('library')}
              >
                <ArrowLeft size={20} />
              </button>
            )}
            <h1>{title}</h1>
          </div>
        </div>
        {error && (
          <div className="error" role="alert">
            {error}
            <button aria-label="Скрыть ошибку" onClick={() => setError('')}>
              ×
            </button>
          </div>
        )}
        {update && (
          <div className="update-banner">
            <span>Доступно обновление</span>
            <button
              onClick={() => {
                navigator.serviceWorker.addEventListener(
                  'controllerchange',
                  () => location.reload(),
                  { once: true },
                );
                update.waiting?.postMessage('ACTIVATE');
              }}
            >
              Обновить
            </button>
          </div>
        )}
        {(current.tab === 'library' ||
          current.tab === 'collection' ||
          current.tab === 'reader') && (
          <>
            {(searchOpen || searchQuery) && <div className="search-row">
              <label className="search"><Search size={17} /><input autoFocus placeholder={current.tab === 'collection' ? 'Поиск в коллекции' : 'Поиск комиксов'} aria-label="Поиск комиксов" value={searchQuery} onChange={(e) => current.tab === 'collection' ? setPaperQuery(e.target.value) : setQuery(e.target.value)} />
              </label>
              <button className="icon-button" aria-label="Закрыть поиск" onClick={() => { setSearchOpen(false); current.tab === 'collection' ? setPaperQuery('') : setQuery(''); }}><X size={18} /></button>
            </div>}
            {current.tab === 'collection' && collection.length > 0 && (
              <div className="library-toolbar">
                <div className="filters collection-filters" role="group" aria-label="Формат коллекции">
                  {([['all', 'Все'], ['paper', 'Бумага'], ['digital', 'Цифра']] as const).map(([value, label]) => (
                    <button key={value} className={collectionFilter === value ? 'active' : ''} aria-label={label} aria-pressed={collectionFilter === value} onClick={() => setCollectionFilter(value)}>
                      {label}<span>{collection.filter(c => matchesCollection(c, value)).length}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            {current.tab !== 'collection' && library.length > 0 && <div className="library-toolbar">
              <div className="filters">
                {filters.map(([value, label]) => <button key={value} className={filter === value ? 'active' : ''} aria-label={label} aria-pressed={filter === value} onClick={() => setFilter(value)}>{label}<span>{value === 'all' ? library.length : library.filter(c => status(c) === value).length}</span></button>)}
              </div>
              <details className="catalog-menu">
                <summary aria-label="Параметры библиотеки"><SlidersHorizontal size={18} /></summary>
                <div className="catalog-menu-content">
                  <label>Сортировка<select aria-label="Сортировка" value={settings.sort} onChange={(e) => setConfig({ ...settings, sort: e.target.value as Settings['sort'] })}>
                    <option value="added">Порядок добавления</option><option value="title">По названию</option><option value="year">По году выхода</option>
                  </select></label>

                </div>
              </details>
            </div>}
            <h2 className="gallery-heading">{current.tab === 'collection' ? <>Моя коллекция <span>· {collection.length}</span></> : 'Путь Бэтмена'}</h2>
            {!visible.length ? (
              <Empty
                title={
                  current.tab === 'collection' && !collection.length
                    ? 'Коллекция пока пуста'
                    : (current.tab === 'collection' ? collection.length : library.length)
                      ? 'Ничего не найдено'
                      : 'Ваш первый комикс'
                }
              >
                <p>
                  {current.tab === 'collection' && !collection.length
                    ? 'Бумажные книги и прочитанные истории.'
                    : (current.tab === 'collection' ? collection.length : library.length)
                      ? 'Измените поиск или фильтр.'
                      : 'Добавьте обложку или файл комикса.'}
                </p>
                {!(current.tab === 'collection' ? collection.length : library.length) && (
                  <button
                    className="primary"
                    onClick={() =>
                      current.tab === 'collection'
                        ? setAddingCollection(true)
                        : setAddingLibrary(true)
                    }
                  >
                    <Plus size={17} />
                    {current.tab === 'collection' ? 'Добавить в коллекцию' : 'Добавить комикс'}
                  </button>
                )}
              </Empty>
            ) : current.tab !== 'collection' ? (
              <Roadmap comics={visible} all={library} onRead={read} onEdit={setEditing} />
            ) : (
              groups.map((group) => (
                <section className="catalog-group" key={group.name}>
                  {group.name && (
                    <h2>
                      {group.name}
                      <small>{group.books.length}</small>
                    </h2>
                  )}
                  <div className={`comic-grid ${current.tab === 'collection' ? 'shelf-grid' : ''}`}>
                    {group.books.map((c) => (
                      <Card
                        key={c.id}
                        comic={c}
                        paper={current.tab === 'collection' && c.physical === 'yes'}
                        collection={current.tab === 'collection'}
                        showFormats={collectionFilter === 'all'}
                        onClick={(rect) => current.tab !== 'collection' && c.digital ? read(c, rect) : setEditing(c)}
                        onEdit={() => setEditing(c)}
                      />
                    ))}
                  </div>
                </section>
              ))
            )}
          </>
        )}
        {current.tab === 'profile' && <Profile comics={comics} onEdit={setEditing} />}
        {current.tab === 'settings' && (
          <SettingsPanel
            settings={settings}
            onChange={setConfig}
            comics={comics}
            onRefresh={refresh}
            offline={offline}
          />
        )}
      </main>
    </div>
      {createPortal(<nav className="bottom-nav" aria-label="Разделы">
        {(
          [
            ['library', BookOpen, 'Библиотека'],
            ['collection', Library, 'Коллекция'],
            ['profile', UserRound, 'Профиль'],
          ] as const
        ).map(([tab, Icon, label]) => (
          <button
            key={tab}
            className={current.tab === tab ? 'active' : ''}
            aria-current={current.tab === tab ? 'page' : undefined}
            onClick={() => navigate(tab)}
          >
            <Icon size={20} strokeWidth={1.7} />
            <span>{label}</span>
          </button>
        ))}
      </nav>, document.body)}
      {addingLibrary && <Modal title="Добавить в маршрут" onClose={() => setAddingLibrary(false)}>
        <div className="collection-add-options">
          <button onClick={() => {setAddingLibrary(false);setEditing({...blankComic(''),inRoadmap:true});}}>
            <BookOpen size={22}/><span>Сначала обложка<small>Файл комикса можно добавить позже</small></span><ChevronRight size={17}/>
          </button>
          <button onClick={() => {setAddingLibrary(false);attach();}}>
            <Monitor size={22}/><span>Загрузить комикс<small>PDF, CBZ или изображение</small></span><ChevronRight size={17}/>
          </button>
        </div>
      </Modal>}
      {addingCollection && (
        <Modal title="Добавить в коллекцию" onClose={() => setAddingCollection(false)}>
          <div className="collection-add-options">
            <button onClick={() => {
              setAddingCollection(false);
              setEditing({ ...blankComic(''), physical: 'yes' });
              setCollectionFilter('all');
            }}><Library size={22} /><span>Бумажное издание<small>Книга на вашей полке</small></span><ChevronRight size={17} /></button>
            <button onClick={() => {
              setAddingCollection(false);
              setEditing({ ...blankComic(''), completed: true, readDigitally: true });
              setCollectionFilter('all');
            }}><Monitor size={22} /><span>Прочитанный комикс<small>Читали онлайн или в другом приложении</small></span><ChevronRight size={17} /></button>
          </div>
        </Modal>
      )}
      {editing && (
        <Editor
          key={editing.id}
          comic={editing}
          draft={!comics.some((c) => c.id === editing.id)}
          onClose={() => setEditing(undefined)}
          onSaved={refresh}
          onRead={read}
          onAttach={(c) => {
            setEditing(undefined);
            attach(c);
          }}
        />
      )}
      {importing && (
        <Importer
          file={importing.file}
          target={importing.target}
          onClose={() => setImporting(undefined)}
          onSaved={refresh}
        />
      )}
    </>
  );
}
