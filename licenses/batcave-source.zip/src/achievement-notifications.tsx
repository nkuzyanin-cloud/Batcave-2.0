import {readerRankAwards,rankArt} from './reader-ranks';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { type AchievementState } from './achievements';
import { getAchievementState, takeAchievementNotice } from './storage/db';


export function useAchievementNotifications(enabled: boolean, blocked: boolean) {
  const [state,setState] = useState<AchievementState>();
  const [notice,setNotice] = useState<string[]>();
  const [visible,setVisible] = useState(document.visibilityState !== 'hidden');
  const consuming = useRef(false);
  useEffect(() => {
    if (!enabled) return;
    let active = true, sequence = 0;
    const update = () => {
      const version = ++sequence;
      void getAchievementState().then(next => { if (active && version === sequence) setState(next); }).catch(() => {});
    };
    const visibility = () => { setVisible(document.visibilityState !== 'hidden'); update(); };
    update();
    window.addEventListener('batcave-achievements',update);
    window.addEventListener('focus',update);
    document.addEventListener('visibilitychange',visibility);
    let channel: BroadcastChannel | undefined;
    try { if (typeof BroadcastChannel !== 'undefined') { channel = new BroadcastChannel('batcave-achievements'); channel.onmessage = update; } } catch {}
    return () => { active = false; window.removeEventListener('batcave-achievements',update); window.removeEventListener('focus',update); document.removeEventListener('visibilitychange',visibility); channel?.close(); };
  },[enabled]);
  useEffect(() => {
    if (!enabled || blocked || !visible || notice || !state?.pending.length || consuming.current) return;
    consuming.current = true;
    void takeAchievementNotice().then(result => {
      setState(result.state);
      // Keep the consumed notice locally if a reader/modal opened during this transaction.
      if (result.notice) setNotice(result.notice);
    }).catch(() => {}).finally(() => { consuming.current = false; });
  },[enabled,blocked,visible,notice,state]);
  return { state, notice, show:enabled && !blocked && visible, dismiss:() => setNotice(undefined) };
}

export function AchievementNotification({ ids, state, onClose, onOpen }: { ids: string[]; state?: AchievementState; onClose:() => void; onOpen:(id?:string) => void }) {
  const [paused,setPaused] = useState(false);
  const close = useRef(onClose); close.current = onClose;
  const medal = readerRankAwards([],state).filter(a=>ids.includes(a.id)).at(-1);
  useEffect(() => { if (paused) return; const timer = window.setTimeout(() => close.current(),4500); return () => clearTimeout(timer); },[ids,paused]);
  if (!medal) return null;
  const summary = false;
  return createPortal(<div className="award-toast" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onFocus={() => setPaused(true)} onBlur={e => {if (!e.currentTarget.contains(e.relatedTarget)) setPaused(false);}}>
    <div className="sr-only" role="status" aria-live="polite">{summary ? `Коллекция обновлена. Зачтено достижений: ${ids.length}` : `Новый ранг. ${medal.name}`}</div>
    <button className="award-toast-open" onClick={() => {onClose();onOpen(summary ? undefined : medal.id);}} aria-label={summary ? 'Посмотреть зачтённые достижения' : `Открыть профиль: ${medal.name}`}>
      <img className="rank-toast-book" src={rankArt(medal.tier)} alt=""/><span><small>{summary ? 'Коллекция обновлена' : 'Новый ранг'}</small><strong>{summary ? `Зачтено наград: ${ids.length}` : medal.name}</strong><span>{summary ? 'Ваши прежние заслуги уже учтены' : medal.hint.split('.')[0]}</span></span>
    </button>
    <button className="award-toast-close" aria-label="Скрыть уведомление о достижении" onClick={onClose}><X size={17}/></button>
  </div>,document.body);
}
