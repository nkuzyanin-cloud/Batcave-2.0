import {readerRanks} from './reader-ranks';
import {RankCelebration} from './components/RankCelebration';
import { useEffect, useRef, useState } from 'react';
import { type AchievementState } from './achievements';
import { getAchievementState, takeAchievementNotice } from './storage/db';


export function useAchievementNotifications(enabled: boolean, blocked: boolean) {
  const [state,setState] = useState<AchievementState>();
  const [notice,setNotice] = useState<string[]>();
  const [visible,setVisible] = useState(document.visibilityState !== 'hidden');
  const consuming = useRef(false);
  useEffect(() => {
    if (!enabled) return;
    let active = true, sequence = 0;
    const update = () => {
      const version = ++sequence;
      void getAchievementState().then(next => { if (active && version === sequence) setState(next); }).catch(() => {});
    };
    const visibility = () => { setVisible(document.visibilityState !== 'hidden'); update(); };
    update();
    window.addEventListener('batcave-achievements',update);
    window.addEventListener('focus',update);
    document.addEventListener('visibilitychange',visibility);
    let channel: BroadcastChannel | undefined;
    try { if (typeof BroadcastChannel !== 'undefined') { channel = new BroadcastChannel('batcave-achievements'); channel.onmessage = update; } } catch {}
    return () => { active = false; window.removeEventListener('batcave-achievements',update); window.removeEventListener('focus',update); document.removeEventListener('visibilitychange',visibility); channel?.close(); };
  },[enabled]);
  useEffect(() => {
    if (!enabled || blocked || !visible || notice || !state?.pending.length || consuming.current) return;
    consuming.current = true;
    void takeAchievementNotice().then(result => {
      setState(result.state);
      // Keep the consumed notice locally if a reader/modal opened during this transaction.
      if (result.notice) setNotice(result.notice);
    }).catch(() => {}).finally(() => { consuming.current = false; });
  },[enabled,blocked,visible,notice,state]);
  return { state, notice, show:enabled && !blocked && visible, dismiss:() => setNotice(undefined) };
}

export function AchievementNotification({ ids, onClose }: { ids: string[]; onClose:() => void }) {
  // One imported batch can contain several ranks: celebrate the highest once.
  const rank = readerRanks.filter(r=>ids.includes(`rank-${r.tier}`)).at(-1);
  return rank ? <RankCelebration rank={rank} onClose={onClose}/> : null;
}
