import type { Comic } from './models';

export type CollectionFilter = 'all' | 'paper' | 'digital';

// Collection is a view of the existing archive, never a second set of records.
export const inCollection = (_comic: Comic) => true;

export function isDigitalStory(comic: Comic) {
  return Boolean(
    comic.digital || comic.readDigitally || comic.lastOpened > 0 || comic.visited.length > 0 ||
    (comic.completed && comic.physical !== 'yes'),
  );
}

export function matchesCollection(comic: Comic, filter: CollectionFilter) {
  return inCollection(comic) && (
    filter === 'all' || (filter === 'paper' ? comic.physical === 'yes' : isDigitalStory(comic))
  );
}
