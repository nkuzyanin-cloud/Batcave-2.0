import type { Comic } from './models';
import { comicEra, type EraId } from './eras';
export const inRoadmap = (c:Comic) => !c.sideStoryAfter && Boolean(c.digital || c.inRoadmap || c.physical !== 'yes');
export function orderedRoadmap(comics:Comic[], era?:EraId) {
  return comics.filter(c=>inRoadmap(c) && (!era || comicEra(c,comics)===era)).sort((a,b)=>a.addedAt-b.addedAt || a.id.localeCompare(b.id));
}
export function sideStories(comics:Comic[], afterId:string) {
  return comics.filter(c => c.sideStoryAfter === afterId).sort((a,b)=>a.addedAt-b.addedAt || a.id.localeCompare(b.id));
}
export function sideStoryCandidates(comics:Comic[], afterId:string, nextId?:string) {
  const anchors = new Set(comics.map(c=>c.sideStoryAfter).filter(Boolean));
  return comics.filter(c=>c.id!==afterId && c.id!==nextId && !c.sideStoryAfter && !anchors.has(c.id));
}

// Present legacy attached stories as ordinary rows, without rewriting their
// links, dates or assets. Paper-only records still respect the existing opt-out.
export function orderedSeriesTimeline(comics:Comic[], era?:EraId) {
  return comics.filter(c=>(inRoadmap(c)||!!c.sideStoryAfter)&&(!era||comicEra(c,comics)===era))
    .sort((a,b)=>a.addedAt-b.addedAt||a.id.localeCompare(b.id));
}
