import type { Comic } from './models';
export const inRoadmap = (c:Comic) => Boolean(c.digital || c.inRoadmap || c.physical !== 'yes');
export function orderedRoadmap(comics:Comic[]) {
  return comics.filter(inRoadmap).sort((a,b)=>a.addedAt-b.addedAt || a.id.localeCompare(b.id));
}
