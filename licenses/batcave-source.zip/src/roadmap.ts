import type { Comic } from './models';
export const inRoadmap = (c:Comic) => !c.sideStoryAfter && Boolean(c.digital || c.inRoadmap || c.physical !== 'yes');
export function orderedRoadmap(comics:Comic[]) {
  return comics.filter(inRoadmap).sort((a,b)=>a.addedAt-b.addedAt || a.id.localeCompare(b.id));
}
export function sideStories(comics:Comic[], afterId:string) {
  return comics.filter(c => c.sideStoryAfter === afterId).sort((a,b)=>a.addedAt-b.addedAt || a.id.localeCompare(b.id));
}
export function sideStoryCandidates(comics:Comic[], afterId:string, nextId?:string) {
  const anchors = new Set(comics.map(c=>c.sideStoryAfter).filter(Boolean));
  return comics.filter(c=>c.id!==afterId && c.id!==nextId && !c.sideStoryAfter && !anchors.has(c.id));
}
