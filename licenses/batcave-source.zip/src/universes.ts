import { z } from 'zod';
import type { Comic } from './models';
import { ERAS } from './eras';

export const UNIVERSES_KEY = 'reading-universes-v1';
export const BATMAN_ID = 'batman';
export const STANDALONE_ID = '__unassigned__';
const safeId = z.string().regex(/^[a-zA-Z0-9_-]{1,150}$/);
export const universeSchema = z.object({
  id: safeId, title: z.string().trim().min(1).max(100),
  cover: z.string().regex(/^data:image\/(jpeg|png|webp);base64,[a-zA-Z0-9+/=]+$/).max(1500000).optional(),
  chapters: z.array(z.object({id:safeId,title:z.string().trim().min(1).max(100)})).min(1).max(100),
  updatedAt: z.number().int().nonnegative(),
}).refine(u=>new Set(u.chapters.map(c=>c.id)).size===u.chapters.length);
export type Universe = z.infer<typeof universeSchema>;
export const batmanUniverse = ():Universe => ({id:BATMAN_ID,title:'Бэтмен',chapters:ERAS.map(e=>({...e})),updatedAt:0});
export const comicUniverse = (c:Comic) => c.universeId || BATMAN_ID;
export function normalizeUniverses(raw:unknown,comics:Comic[]=[]):Universe[] {
  const result:Universe[]=[];
  if(Array.isArray(raw))for(const value of raw){const p=universeSchema.safeParse(value);if(p.success&&!result.some(u=>u.id===p.data.id))result.push(p.data);}
  if(!result.some(u=>u.id===BATMAN_ID))result.unshift(batmanUniverse());
  for(const c of comics){const id=comicUniverse(c);if(id===STANDALONE_ID)continue;if(!result.some(u=>u.id===id))result.push({id,title:c.series.trim()||'Серия',chapters:[{id:c.era||'main',title:'Основной маршрут'}],updatedAt:0});
    const u=result.find(u=>u.id===id)!;if(c.era&&!u.chapters.some(p=>p.id===c.era))u.chapters.push({id:c.era,title:'Другой раздел'});
  }
  return result;
}
