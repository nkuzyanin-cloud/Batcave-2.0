import type { Comic } from './models';

// Legacy records have no completion event; use the last saved record date,
// not lastOpened, which always puts reopened digital books ahead of paper ones.
export function completionDate(c:Comic) {
  return c.completedAt ?? (c.updatedAt || c.lastOpened || c.addedAt);
}
export function completionStamp(next:Comic, previous:Comic | undefined, now:number) {
  return !next.completed ? undefined : previous?.completed
    ? completionDate(previous) : now;
}
export function completedHistory(comics:Comic[]) {
  return comics.filter(c=>c.completed).sort((a,b)=>completionDate(b)-completionDate(a) || b.addedAt-a.addedAt || a.id.localeCompare(b.id));
}
