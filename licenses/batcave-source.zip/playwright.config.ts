import { defineConfig } from '@playwright/test';
const chromiumArgs = process.env.QA_CHROMIUM_ARGS ? JSON.parse(process.env.QA_CHROMIUM_ARGS) as string[] : [];
export default defineConfig({
  testDir: './tests/e2e',
  timeout: 45000,
  expect: { timeout: 10000 },
  workers: 1,
  fullyParallel: false,
  reporter: [['list']],
  use: { baseURL: 'http://127.0.0.1:4173', viewport: { width: 375, height: 812 },
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.2 Mobile/15E148 Safari/604.1',
    deviceScaleFactor: 3, isMobile: true, hasTouch: true, screenshot: 'only-on-failure' },
  projects: [
    { name: 'chromium', use: { browserName: 'chromium', launchOptions: {
      ...(process.env.QA_CHROMIUM ? { executablePath: process.env.QA_CHROMIUM } : {}), args: chromiumArgs,
    } } },
    { name: 'webkit', use: { browserName: 'webkit', launchOptions: {
      ...(process.env.QA_WEBKIT ? { executablePath: process.env.QA_WEBKIT } : {}),
    } } },
  ],
  webServer: { command: 'npm run build && npx vite preview --host 127.0.0.1 --port 4173 --strictPort',
    url: 'http://127.0.0.1:4173', reuseExistingServer: !process.env.CI, timeout: 120000 },
});
