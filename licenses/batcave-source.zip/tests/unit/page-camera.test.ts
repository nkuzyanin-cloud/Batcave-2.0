import {it,expect} from 'vitest';
import {anchoredPage,boundedPage,pageLimits} from '../../src/reader/page-camera';
it('keeps the same document point under a moving pinch midpoint',()=>{
 const from={zoom:1.4,x:23,y:-55},a={x:50,y:-100},b={x:80,y:-75};
 const next=anchoredPage(from,2.7,a,b);
 expect((b.x-next.x)/next.zoom).toBeCloseTo((a.x-from.x)/from.zoom,10);
 expect((b.y-next.y)/next.zoom).toBeCloseTo((a.y-from.y)/from.zoom,10);
});
it('clamps the page without exposing empty space or exceeding backup-compatible zoom',()=>{
 const size={width:375,height:812,pageWidth:375,pageHeight:562.5};
 expect(boundedPage({zoom:1,x:200,y:900},size)).toEqual({zoom:1,x:0,y:0});
 const v=boundedPage({zoom:8,x:100000,y:-100000},size);expect(v.zoom).toBe(4);
 expect(v.x).toBe(pageLimits(size,4).x);expect(v.y).toBe(-pageLimits(size,4).y);
 expect(boundedPage({zoom:0,x:0,y:0},size).zoom).toBe(1);
});
