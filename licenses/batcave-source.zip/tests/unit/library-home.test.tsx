import 'fake-indexeddb/auto';
import {describe,it,expect} from 'vitest';
import {renderToStaticMarkup} from 'react-dom/server';
import {blankComic,stats,type Comic} from '../../src/models';
import {batmanUniverse,comicUniverse,normalizeUniverses,type Universe} from '../../src/universes';
import {continueReading,readingPosition,seriesSummaries,standaloneComics,STANDALONE_ID,searchComics,seriesIssueTitle} from '../../src/library-home';
import {parseRoute} from '../../src/navigation';
import {LibraryHome} from '../../src/components/LibraryHome';
const comic=(patch:Partial<Comic>={}):Comic=>({...blankComic('История'),...patch});
const digital={assetId:'asset',format:'cbz' as const,name:'comic.cbz',size:100,fingerprint:'sha'};
const universe=(id:string):Universe=>({id,title:'Серия '+id,chapters:[{id:'main',title:'Раздел'}],updatedAt:0});
describe('Unified library data',()=>{
 it('resumes the latest unfinished locally readable comic, without mutating records',()=>{
  const entries=[comic({id:'a',digital,lastOpened:100,page:8}),comic({id:'finished',digital,lastOpened:900,completed:true}),comic({id:'removed-file',lastOpened:800}),comic({id:'not-opened',digital,lastOpened:0}),comic({id:'latest',digital,lastOpened:200,page:4})];
  const before=JSON.stringify(entries);expect(continueReading(entries)?.id).toBe('latest');expect(JSON.stringify(entries)).toBe(before);
  expect(continueReading([])).toBeUndefined();expect(continueReading([entries[1],entries[2]])).toBeUndefined();
 });
 it('keeps page indices zero-based and bounds display values',()=>{
  expect(readingPosition(comic({page:4,pageCount:20}))).toEqual({page:5,total:20,percent:25});
  expect(readingPosition(comic({page:99,pageCount:20}))).toEqual({page:20,total:20,percent:100});
  expect(readingPosition(comic({page:0,pageCount:0}))).toEqual({page:0,total:0,percent:0});
 });
 it('counts every record once including paper and non-roadmap titles, retaining series order',()=>{
  const entries=[comic({id:'legacy',completed:true}),comic({id:'paper',universeId:'twd',physical:'yes',inRoadmap:false}),comic({id:'standalone',universeId:STANDALONE_ID,completed:true})];
  const series=[universe('twd'),batmanUniverse(),universe('empty')];const before=JSON.stringify({entries,series});
  expect(seriesSummaries(series,entries).map(s=>[s.universe.id,s.done,s.total,s.percent])).toEqual([['twd',0,1,0],['batman',1,1,100],['empty',0,0,0]]);
  expect(standaloneComics(entries).map(c=>c.id)).toEqual(['standalone']);expect(comicUniverse(entries[0])).toBe('batman');
  expect(JSON.stringify({entries,series})).toBe(before);
 });
 it('does not create a spurious series for standalone records or change legacy ownership',()=>{
  const entries=[comic({universeId:STANDALONE_ID}),comic({id:'old'})];
  expect(normalizeUniverses([],entries).map(u=>u.id)).toEqual(['batman']);expect(entries[1].universeId).toBeUndefined();
 });
 it('finds metadata across the entire archive, not only the selected era',()=>{
  const entries=[comic({id:'x',title:'Длинная история',era:'elsewhere',inRoadmap:false,authors:'Киркман'}),comic({id:'y',series:'Другая серия'})];
  expect(searchComics(entries,' КИРКМАН ').map(c=>c.id)).toEqual(['x']);expect(searchComics(entries,'другая').map(c=>c.id)).toEqual(['y']);
 });
 it('redirects old profile/collection links without adding obsolete screens',()=>{
  expect(parseRoute('#/profile')).toEqual({tab:'library'});expect(parseRoute('#/collection')).toEqual({tab:'archive'});expect(parseRoute('#/library/twd')).toEqual({tab:'library',id:'twd'});expect(parseRoute('#/reader/comic')).toEqual({tab:'reader',id:'comic'});
 });
});
describe('Library home states',()=>{
 const render=(comics:Comic[],universes:Universe[]=[],query='')=>renderToStaticMarkup(<LibraryHome comics={comics} universes={universes} medals={[]} query={query} onRead={()=>{}} onEdit={()=>{}} onSeries={()=>{}} onAllSeries={()=>{}} onArchive={()=>{}} onAchievements={()=>{}} onAddSeries={()=>{}}/>);
 it('renders empty and zero states without a large empty reading card',()=>{
  const html=render([]);expect(html).toContain('Добавьте комикс, чтобы начать читать.');expect(html).not.toContain('class="library-resume"');expect(html).toContain('Статистика');expect(html).toContain('Достижения');
 });
 it('shows two cover-led preview series, and keeps all-series and standalone access',()=>{
  const html=render([comic({universeId:STANDALONE_ID})],Array.from({length:30},(_,n)=>universe(String(n))));
  expect((html.match(/class="library-series"/g)||[]).length).toBe(2);expect(html).toContain('Все серии');expect(html).toContain('Без серии');expect(html).toContain('Все комиксы');
 });
 it('renders genuine statistics and bounded resume position with a missing cover and long title',()=>{
  const c=comic({digital,title:'Очень длинное название '.repeat(15),lastOpened:1,page:4,pageCount:20,visited:[0,1,2,3,4],seconds:3660});
  const done=comic({completed:true,visited:[0,1],pageCount:2});const html=render([c,done]);
  expect(html).toContain('Страница 5 из 20');expect(html).toContain('aria-valuenow="25"');expect(stats([c,done])).toMatchObject({done:1,pages:7,seconds:3660});
  expect(html.indexOf('Продолжить чтение')).toBeLessThan(html.indexOf('id="series-title"'));expect(html.indexOf('id="series-title"')).toBeLessThan(html.indexOf('Статистика'));expect(html.indexOf('Статистика')).toBeLessThan(html.indexOf('Достижения'));
 });
 it('searches standalone and completed comics without showing unrelated home statistics',()=>{
  const html=render([comic({title:'Нужная история',universeId:STANDALONE_ID,completed:true})],[],'нужная');expect(html).toContain('Нужная история');expect(html).not.toContain('id="stats-title"');
 });
});

 it('shortens only shared series prefixes and preserves distinct stories and saved titles',()=>{
  const c=comic({title:'Ходячие мертвецы. Делюкс. Выпуск 2',series:'TWD'});
  expect(seriesIssueTitle(c,'Ходячие мертвецы. Делюкс')).toBe('Выпуск 2');
  expect(c.title).toBe('Ходячие мертвецы. Делюкс. Выпуск 2');
  expect(seriesIssueTitle(comic({title:'Бэтмен. Готика'}),'Бэтмен')).toBe('Готика');
  expect(seriesIssueTitle(comic({title:'Женщина-кошка. Когда в Риме'}),'Бэтмен')).toBe('Женщина-кошка. Когда в Риме');
  expect(seriesIssueTitle(comic({title:'Бэтменхаус'}),'Бэтмен')).toBe('Бэтменхаус');
  expect(seriesIssueTitle(comic({title:'Бэтмен'}),'Бэтмен')).toBe('Бэтмен');
 });
