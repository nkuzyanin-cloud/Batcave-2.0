import 'fake-indexeddb/auto';
import { readFileSync } from 'node:fs';
import { beforeEach, expect, it, vi } from 'vitest';
vi.mock('pdfjs-dist', () => ({ GlobalWorkerOptions: {}, PDFDataRangeTransport: class {}, getDocument: vi.fn() }));
import { blankComic, defaultSettings, stats } from '../../src/models';
import { attachComicFile, dbPromise, deleteComic, deleteDigital, getAsset, getComic, initialize, saveComic, updateProgress, updateReadingResult } from '../../src/storage/db';
import { checksum, exportFull, exportMetadata, parseBackup, prepareRestore, restore } from '../../src/storage/backup';

beforeEach(async () => {
  const db = await dbPromise;
  for (const store of ['comics', 'assets', 'config'] as const) await db.clear(store);
});
const original = () => new File([new Uint8Array(readFileSync('tests/fixtures/sample.cbz'))], 'sample.cbz', { type: 'application/zip' });
const rawBackup = () => parseBackup({ app: 'BATCAVE', version: 1, kind: 'metadata', createdAt: 1, comics: [], settings: defaultSettings, assets: [] });

it('rejects blank titles before any asset or record is saved', async () => {
  const c = { ...blankComic(), title: '  ' };
  await expect(saveComic(c, [{ id: 'orphan', blob: new Blob(['x']) }])).rejects.toThrow('название');
  expect(await (await dbPromise).getAll('comics')).toEqual([]);
  expect(await getAsset('orphan')).toBeUndefined();
});
it('repairs legacy blank titles and obsolete corrections without inventing reading progress', async () => {
  const c = { ...blankComic(), title: '', pageCount: 3, visited: [0, 1], seconds: 123,
    digital: { assetId: 'file', name: 'Old book.cbz', format: 'cbz' as const, size: 1, fingerprint: 'b'.repeat(64) },
    panelEdits: { fingerprint: 'a'.repeat(64), frames: [{ page: 9, panel: 0, bounds: [0, 0, 1, 1] as [number, number, number, number], views: [] }] } };
  await (await dbPromise).put('comics', c); await initialize();
  expect(await getComic(c.id)).toMatchObject({ title: 'Old book', visited: [0, 1], seconds: 123, digitalFingerprint: 'b'.repeat(64) });
  expect((await getComic(c.id))!.panelEdits).toBeUndefined();
  expect(parseBackup(JSON.parse(await (await exportMetadata()).text())).comics[0].title).toBe('Old book');
});
it('merges an edited title with newer pages, time and rating', async () => {
  const base = { ...blankComic(), pageCount: 10 }; await saveComic(base);
  await updateProgress(base.id, 2, true, 30); await updateReadingResult(base.id, { rating: 5 });
  await saveComic({ ...base, title: 'Changed title' }, [], [], true, base);
  expect(await getComic(base.id)).toMatchObject({ title: 'Changed title', visited: [2], seconds: 30, rating: 5 });
});
it('rejects conflicting metadata edits before overwriting assets or resurrecting a deleted record', async () => {
  const base = blankComic(); await saveComic(base);
  await saveComic({ ...base, note: 'Other window' });
  await expect(saveComic({ ...base, note: 'My edit' }, [{ id: 'unused', blob: new Blob(['x']) }], [], true, base)).rejects.toThrow('другом окне');
  expect((await getComic(base.id))!.note).toBe('Other window'); expect(await getAsset('unused')).toBeUndefined();
  await deleteComic(base);
  await expect(saveComic({ ...base, title: 'Edit' }, [], [], true, base)).rejects.toThrow('удалён');
  expect(await getComic(base.id)).toBeUndefined();
});
it('reattaches an identical original with its existing visits, bookmark, time and corrections', async () => {
  const blob = original(), hash = await checksum(blob);
  const c = { ...blankComic(), pageCount: 3, page: 2, visited: [0, 1], seconds: 123,
    digital: { assetId: 'old', name: blob.name, format: 'cbz' as const, size: blob.size, fingerprint: hash },
    panelEdits: { fingerprint: hash, frames: [{ page: 2, panel: 0, bounds: [0, 0, 1, 1] as [number, number, number, number], views: [] }] } };
  await saveComic(c, [{ id: 'old', blob }]); await deleteDigital(c);
  const target = (await getComic(c.id))!; expect(target.digitalFingerprint).toBe(hash);
  await attachComicFile({ ...target, digital: { ...c.digital, assetId: 'new' } }, [{ id: 'new', blob }], target);
  expect(await getComic(c.id)).toMatchObject({ page: 2, visited: [0, 1], seconds: 123, panelEdits: c.panelEdits });
  expect(await getAsset('old')).toBeUndefined(); expect((await getAsset('new'))!.blob.size).toBe(blob.size);
});
it('clears old corrections for a different, shorter edition and round trips its backup', async () => {
  const old = original(), oldHash = await checksum(old);
  const image = new Blob([new Uint8Array(readFileSync('tests/fixtures/page.png'))], { type: 'image/png' }), hash = await checksum(image);
  const c = { ...blankComic('Replacement'), pageCount: 3, seconds: 10,
    digital: { assetId: 'old', name: old.name, format: 'cbz' as const, size: old.size, fingerprint: oldHash },
    panelEdits: { fingerprint: oldHash, frames: [{ page: 2, panel: 0, bounds: [0, 0, 1, 1] as [number, number, number, number], views: [] }] } };
  await saveComic(c, [{ id: 'old', blob: old }]);
  await attachComicFile({ ...c, pageCount: 1, digital: { assetId: 'short', name: 'page.png', format: 'image', size: image.size, fingerprint: hash } }, [{ id: 'short', blob: image }], c);
  expect(await getComic(c.id)).toMatchObject({ pageCount: 1, seconds: 0, visited: [] });
  expect((await getComic(c.id))!.panelEdits).toBeUndefined();
  const data = parseBackup(JSON.parse(await (await exportMetadata()).text())); expect(data.comics[0].digital!.fingerprint).toBe(hash);
  const full = await exportFull(() => {}); await expect(prepareRestore(new File([full], 'backup.zip'), () => {})).resolves.toMatchObject({ data: { kind: 'full' } });
});
it('serializes keep-existing restore with concurrent reading updates', async () => {
  const c = { ...blankComic(), pageCount: 10 }; await saveComic(c);
  await Promise.all([restore({ data: rawBackup(), assets: new Map(), conflicts: 0 }, 'keep', false), updateProgress(c.id, 3, true, 30)]);
  expect(await getComic(c.id)).toMatchObject({ visited: [3], seconds: 30 });
});
it('keeps a shared asset until its last reference is removed, including cover replacement and file deletion', async () => {
  const a = { ...blankComic('A'), coverId: 'shared' }, b = { ...blankComic('B'), coverId: 'shared' };
  await saveComic(a, [{ id: 'shared', blob: new Blob(['cover']) }]); await saveComic(b);
  await saveComic({ ...a, coverId: undefined }, [], ['shared']); expect(await getAsset('shared')).toBeDefined();
  await deleteComic(a); expect(await getAsset('shared')).toBeDefined();
  await deleteComic(b); expect(await getAsset('shared')).toBeUndefined();
  const digital = { assetId: 'shared-file', name: 'book.cbz', format: 'cbz' as const, size: 1, fingerprint: 'a'.repeat(64) };
  const x = { ...blankComic('X'), pageCount: 3, digital }, y = { ...blankComic('Y'), pageCount: 3, digital };
  await saveComic(x, [{ id: 'shared-file', blob: new Blob(['x']) }]); await saveComic(y);
  await deleteDigital(x); expect(await getAsset('shared-file')).toBeDefined();
  await deleteComic(y); expect(await getAsset('shared-file')).toBeUndefined();
});
it('preserves partial legacy paper pages after editing and recovers the old zero-time regression', async () => {
  const c = { ...blankComic(), physical: 'yes' as const, paperPageCount: 100, paperPagesRead: 35 };
  await saveComic(c); await saveComic({ ...c, title: 'Paper' }, [], [], true, c);
  expect(stats([(await getComic(c.id))!]).pages).toBe(35);
  await (await dbPromise).put('comics', { ...c, paperSeconds: 0 }); await initialize();
  expect(stats([(await getComic(c.id))!]).pages).toBe(35);
});
it('validates a full export and restores the original bytes after deletion', async () => {
  const blob = original(), hash = await checksum(blob), c = { ...blankComic('Full backup'), pageCount: 3,
    digital: { assetId: 'original', name: blob.name, format: 'cbz' as const, size: blob.size, fingerprint: hash } };
  await saveComic(c, [{ id: 'original', blob }]); await updateProgress(c.id, 1, true, 27);
  const backup = await exportFull(() => {}), prepared = await prepareRestore(new File([backup], 'backup.zip'), () => {});
  await deleteComic(c); await restore(prepared, 'replace', false);
  expect(await getComic(c.id)).toMatchObject({ visited: [1], seconds: 27, digitalFingerprint: hash });
  expect(await checksum((await getAsset('original'))!.blob)).toBe(hash);
});
it('does not create duplicate digital records when two imports finish together', async () => {
  const blob = original(), hash = await checksum(blob);
  const books = ['A', 'B'].map(title => ({ ...blankComic(title), pageCount: 3,
    digital: { assetId: title, name: blob.name, format: 'cbz' as const, size: blob.size, fingerprint: hash } }));
  const results = await Promise.allSettled(books.map(c => attachComicFile(c, [{ id: c.digital.assetId, blob }])));
  expect(results.filter(r => r.status === 'fulfilled')).toHaveLength(1);
  expect(await (await dbPromise).getAll('comics')).toHaveLength(1);
  expect(await (await dbPromise).getAll('assets')).toHaveLength(1);
});
