import {it,expect} from 'vitest';
import {VisibleReadingTime} from '../../src/reader/visible-time';
it('counts a long visible interval in full without gestures or interval caps',()=>{
 let now=0;const clock=new VisibleReadingTime(()=>now);clock.setVisible(true);
 now=3*60*60*1000;expect(clock.drainSeconds()).toBe(10800);
 now+=2500;clock.setVisible(false);expect(clock.drainSeconds()).toBe(2.5);expect(clock.drainSeconds()).toBe(0);
});
it('settles the final visible fraction on hide, excludes hidden time, and resumes without duplicate seconds',()=>{
 let now=0;const clock=new VisibleReadingTime(()=>now);clock.setVisible(true);
 now=5300;clock.setVisible(false);expect(clock.drainSeconds()).toBe(5.3);
 now+=900000;clock.setVisible(false);expect(clock.drainSeconds()).toBe(0);
 clock.setVisible(true);now+=1000;clock.setVisible(true);now+=1200;
 expect(clock.drainSeconds()).toBe(2.2);expect(clock.drainSeconds()).toBe(0);
});
it('keeps fractional checkpoints exact and ignores backwards monotonic samples',()=>{
 let now=0;const clock=new VisibleReadingTime(()=>now);clock.setVisible(true);let total=0;
 for(const t of [300,600,900,1200]){now=t;total+=clock.drainSeconds();}expect(total).toBeCloseTo(1.2);
 now=1100;expect(clock.drainSeconds()).toBe(0);
});
