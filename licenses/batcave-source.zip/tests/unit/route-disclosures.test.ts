import 'fake-indexeddb/auto';
import {describe,it,expect} from 'vitest';
import {dbPromise} from '../../src/storage/db';
import {getCollapsedSections,saveSectionDisclosure,getExpandedIssueLists,saveExpandedIssueList} from '../../src/storage/route-disclosures';

describe('remembered section disclosures',()=>{
  it('keeps chapters independent across series, merges concurrent writes and saves reopening',async()=>{
    const db=await dbPromise;
    await db.clear('config');await db.put('config',{motion:'off'},'settings');
    expect([...await getCollapsedSections('twd')]).toEqual([]);
    await Promise.all([saveSectionDisclosure('twd','a',true),saveSectionDisclosure('twd','b',true),saveSectionDisclosure('batman','a',true)]);
    expect(await getCollapsedSections('twd')).toEqual(new Set(['a','b']));
    await saveSectionDisclosure('twd','a',false);
    expect(await getCollapsedSections('twd')).toEqual(new Set(['b']));
    expect(await getCollapsedSections('batman')).toEqual(new Set(['a']));
    await saveSectionDisclosure('twd','b',false);expect([...await getCollapsedSections('twd')]).toEqual([]);
    expect(await db.get('config','settings')).toEqual({motion:'off'});
  });
  it('tolerates missing or invalid stored display preferences',async()=>{
    const db=await dbPromise;
    await db.put('config',{bad:true},'route-disclosures-v1:broken');
    expect([...await getCollapsedSections('broken')]).toEqual([]);
    await db.put('config',['a',2,null,'a'],'route-disclosures-v1:mixed');
    expect([...await getCollapsedSections('mixed')]).toEqual(['a']);
  });
});

it('full issue previews merge across windows without changing collapsed chapters or another series',async()=>{
  const db=await dbPromise;await db.clear('config');
  await saveSectionDisclosure('twd','a',true);
  await Promise.all([saveExpandedIssueList('twd','a',true),saveExpandedIssueList('twd','b',true),saveExpandedIssueList('other','a',true)]);
  expect(await getExpandedIssueLists('twd')).toEqual(new Set(['a','b']));
  expect(await getCollapsedSections('twd')).toEqual(new Set(['a']));
  await saveExpandedIssueList('twd','a',false);
  expect(await getExpandedIssueLists('twd')).toEqual(new Set(['b']));
  expect(await getExpandedIssueLists('other')).toEqual(new Set(['a']));
});
