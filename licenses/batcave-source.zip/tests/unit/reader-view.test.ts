import 'fake-indexeddb/auto';
import { it, expect, vi } from 'vitest';
vi.mock('pdfjs-dist', () => ({ GlobalWorkerOptions: {}, PDFDataRangeTransport: class {}, getDocument: vi.fn() }));
import { blankComic, defaultSettings } from '../../src/models';
import { dbPromise, saveComic, saveReaderView, updateProgress, resetProgress, saveSettings } from '../../src/storage/db';
import { exportMetadata, parseBackup } from '../../src/storage/backup';
it('persists the reading viewport and backs it up without changing files or older progress', async () => {
  const c = { ...blankComic('Reader view'), pageCount: 5,
    digital: { assetId: 'original', format: 'pdf' as const, name: 'book.pdf', size: 8, fingerprint: 'a'.repeat(64) } };
  const original = new Blob(['original']);
  await saveComic(c, [{ id: 'original', blob: original }]);
  await updateProgress(c.id, 2, true, 12);
  const view = { page: 2, mode: 'guided' as const, zoom: 2.1, x: -1, y: 0.5 };
  await saveReaderView(c.id, view);
  const db = await dbPromise;
  const saved = await db.get('comics', c.id);
  expect(saved?.readerView).toEqual(view);
  expect(saved?.visited).toEqual([2]);
  expect(saved?.seconds).toBe(12);
  expect(await (await db.get('assets', 'original'))!.blob.text()).toBe('original');
  // Late writes for another page cannot overwrite the current viewport.
  await saveReaderView(c.id, { ...view, page: 1 });
  expect((await db.get('comics', c.id))?.readerView).toEqual(view);
  await saveSettings({ ...defaultSettings, mode: 'guided' });
  const backup = parseBackup(JSON.parse(await (await exportMetadata()).text()));
  expect(backup.settings.mode).toBe('guided');
  expect(backup.comics.find((book) => book.id === c.id)?.readerView).toEqual(view);
  const panelView={ ...view,mode:'panels' as const,panel:3,part:1,overview:'after' as const };
  await saveReaderView(c.id,panelView);
  await saveSettings({ ...defaultSettings,mode:'panels',panelOpacity:1,panelPageFirst:true,panelPageLast:true });
  const panelBackup=parseBackup(JSON.parse(await (await exportMetadata()).text()));
  expect(panelBackup.comics.find(book => book.id===c.id)?.readerView).toEqual(panelView);
  expect(panelBackup.settings).toMatchObject({ mode:'panels',panelOpacity:1,panelPageFirst:true,panelPageLast:true });
  const old=JSON.parse(await (await exportMetadata()).text());
  old.settings.mode='single';delete old.settings.panelOpacity;delete old.settings.panelPageFirst;delete old.settings.panelPageLast;
  expect(parseBackup(old).settings).toMatchObject({ panelOpacity:.75,panelPageFirst:false,panelPageLast:false });
  await resetProgress();
  expect((await db.get('comics', c.id))?.readerView).toBeUndefined();
  expect(await (await db.get('assets', 'original'))!.blob.text()).toBe('original');
});
it('keeps authored contour geometry in metadata backup and restore validation',async()=>{
 const fingerprint='c'.repeat(64),c={...blankComic('Contour backup'),pageCount:1,digital:{assetId:'contour-original',format:'cbz' as const,name:'contour.cbz',size:8,fingerprint},autoPanels:{version:1 as const,detector:'inkwell-v1' as const,sha256:fingerprint,pageCount:1,pages:[{width:100,height:150,kind:'story' as const,frames:[[.1,.2,.6,.5] as [number,number,number,number]],shapes:[{type:'polygon' as const,points:[[0,.2],[1,0],[1,.8],[0,1]] as [number,number][]}]}]}};
 await saveComic(c,[{id:'contour-original',blob:new Blob(['original'])}]);const b=parseBackup(JSON.parse(await(await exportMetadata()).text()));expect(b.comics.find(x=>x.id===c.id)?.autoPanels?.pages[0].shapes).toEqual(c.autoPanels.pages[0].shapes);
});
