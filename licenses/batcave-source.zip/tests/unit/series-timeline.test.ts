import {it,expect} from 'vitest';
import {blankComic} from '../../src/models';
import {orderedSeriesTimeline} from '../../src/roadmap';
it('flattens linked stories into addition order without changing metadata or reading progress',()=>{
 const anchor={...blankComic('Основной'),id:'anchor',era:'early',addedAt:1};
 const next={...blankComic('Следующий'),id:'next',era:'early',addedAt:2};
 const attached={...blankComic('Спецвыпуск'),id:'attached',era:'main',sideStoryAfter:'anchor',addedAt:3,page:8,visited:[0,8],seconds:80,coverId:'cover',digital:{assetId:'original',format:'cbz' as const,name:'comic.cbz',size:123,fingerprint:'hash'}};
 const records=[attached,next,anchor],before=structuredClone(records);
 expect(orderedSeriesTimeline(records,'early').map(c=>c.id)).toEqual(['anchor','next','attached']);
 expect(orderedSeriesTimeline(records,'main')).toEqual([]);
 expect(records).toEqual(before);expect(orderedSeriesTimeline(records)[2]).toBe(attached);
 expect(orderedSeriesTimeline([{...anchor,era:'later'},attached],'later').map(c=>c.id)).toEqual(['anchor','attached']);
});
it('keeps a stable tie order and paper membership; an empty era stays empty',()=>{
 const paper={...blankComic('Бумажный'),id:'paper',physical:'yes' as const,addedAt:0};
 const a={...blankComic('A'),id:'a',era:'main',addedAt:1},b={...a,id:'b'};
 expect(orderedSeriesTimeline([b,paper,a],'main').map(c=>c.id)).toEqual(['a','b']);
 expect(orderedSeriesTimeline([{...paper,inRoadmap:true},b,a]).map(c=>c.id)).toEqual(['paper','a','b']);
 expect(orderedSeriesTimeline([a,b],'empty')).toEqual([]);expect(orderedSeriesTimeline([])).toEqual([]);
});
