import 'fake-indexeddb/auto';
import { describe, it, expect, vi } from 'vitest';
vi.mock('pdfjs-dist', () => ({ GlobalWorkerOptions: {}, PDFDataRangeTransport: class {}, getDocument: vi.fn() }));
import { blankComic, defaultSettings, paperReadPages, stats, status } from '../../src/models';
import { achievements } from '../../src/achievements';
import { parseBackup, restore, exportMetadata } from '../../src/storage/backup';
import { saveComic, updateProgress, deleteDigital, resetProgress, dbPromise } from '../../src/storage/db';
const raw = (c: ReturnType<typeof blankComic>) => ({ app: 'BATCAVE', version: 1, kind: 'metadata', createdAt: 1, comics: [c], settings: defaultSettings, assets: [] });
describe('Truthful paper reading', () => {
  it('ownership and total pages alone count no reading', () => {
    const c = { ...blankComic(), physical: 'yes' as const, paperPageCount: 240 };
    expect(stats([c]).pages).toBe(0);expect(status(c)).toBe('new');
    expect(stats([{ ...c, paperPagesRead: 35 }]).pages).toBe(35);
    expect(status({ ...c, paperPagesRead: 35 })).toBe('reading');
  });
  it('completed paper counts its known length, unknown length never invents pages', () => {
    const c = { ...blankComic(), physical: 'yes' as const, completed: true, paperCompleted: true };
    expect(paperReadPages(c)).toBe(0);
    expect(paperReadPages({ ...c, paperPageCount: 240 })).toBe(240);
    expect(achievements([{ ...c, paperPageCount: 240 }]).find(a => a.id === 'pages-100')!.earned).toBe(true);
  });
  it('uses larger progress once per story; digital completion never implies paper completion', () => {
    const c = { ...blankComic(), pageCount: 99, visited: Array.from({length:99}, (_,i)=>i), completed: true, lastOpened: 1, physical: 'yes' as const, paperPageCount: 240 };
    expect(stats([c]).pages).toBe(99);
    expect(stats([{ ...c, paperPagesRead: 40 }]).pages).toBe(99);
    expect(stats([{ ...c, paperCompleted: true }]).pages).toBe(240);
    expect(stats([{ ...c, paperPagesRead: 150 }]).pages).toBe(150);
  });
  it('supports old completed paper records without altering digital progress', () => {
    const c = { ...blankComic(), physical: 'yes' as const, completed: true, paperPageCount: 128 };
    expect(paperReadPages(c)).toBe(128);
    expect(paperReadPages({ ...c, readDigitally: true })).toBe(0);
    expect(parseBackup(raw(blankComic())).comics[0].paperPageCount).toBeUndefined();
  });
  it('manual time and full paper pages count only when completed; edits never accumulate', () => {
    const c = { ...blankComic(), physical: 'yes' as const, paperPageCount: 72, paperPagesRead: 40, paperCompleted: false, paperSeconds: 5400, seconds: 120 };
    expect(stats([c])).toMatchObject({pages:0,seconds:120});
    expect(stats([{...c,paperCompleted:true}])).toMatchObject({pages:72,seconds:5520});
    expect(stats([{...c,paperCompleted:true,paperSeconds:3600}])).toMatchObject({pages:72,seconds:3720});
    expect(parseBackup(raw(c)).comics[0].paperSeconds).toBe(5400);
    for(const paperSeconds of [-1,1.5,1e12+1,'90']) expect(()=>parseBackup(raw({...c,paperSeconds} as never))).toThrow();
  });
  it('rejects invalid paper backup progress before mutation', () => {
    const c = { ...blankComic(), paperPageCount: 240, paperPagesRead: 50 };
    expect(parseBackup(raw(c)).comics[0].paperPagesRead).toBe(50);
    for(const fields of [{paperPagesRead:241}, {paperPageCount:-1}, {paperPageCount:1.5}, {paperCompleted:'true'}, {paperPageCount:undefined, paperPagesRead:1}])
      expect(()=>parseBackup(raw({...c,...fields} as never))).toThrow();
  });
  it('round trips metadata, keeps conflicts, survives digital progress and deletion, resets only reading', async () => {
    const c = { ...blankComic('Paper backup'), physical: 'yes' as const, paperPageCount: 240, paperPagesRead: 35, paperCompleted: false, paperSeconds: 1200, pageCount: 2,
      digital: {assetId:'paper-digital', name:'paper.png', format:'image' as const, size:4, fingerprint:'a'.repeat(64)} };
    await saveComic(c,[{id:'paper-digital',blob:new Blob(['file'])}]);
    await updateProgress(c.id,0,true,2);await deleteDigital(c);
    let saved = (await (await dbPromise).get('comics',c.id))!;
    expect(saved).toMatchObject({paperPageCount:240,paperPagesRead:35,paperCompleted:false,paperSeconds:1200,visited:[0],seconds:2});
    const data=parseBackup(JSON.parse(await (await exportMetadata()).text()));
    await saveComic({...saved,paperPagesRead:40});
    await restore({data,assets:new Map(),conflicts:1},'keep',false);
    expect((await (await dbPromise).get('comics',c.id))!.paperPagesRead).toBe(40);
    await restore({data,assets:new Map(),conflicts:1},'replace',false);
    expect((await (await dbPromise).get('comics',c.id))!.paperPagesRead).toBe(35);
    await resetProgress();saved=(await (await dbPromise).get('comics',c.id))!;
    expect(saved).toMatchObject({paperPageCount:240,paperPagesRead:0,paperCompleted:false,paperSeconds:0,visited:[],seconds:0,completed:false});
  });
});
