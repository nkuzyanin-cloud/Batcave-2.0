import 'fake-indexeddb/auto';
import {it,expect,vi} from 'vitest';
import {configure} from '@zip.js/zip.js';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {blankComic} from '../../src/models';
import {saveComic,dbPromise} from '../../src/storage/db';
import {exportParts,BACKUP_PART_BYTES} from '../../src/storage/backup-parts';
configure({useWebWorkers:false});
it.skipIf(process.env.QA_LARGE_BACKUP!=='1')('exports more than the old 300-MB limit using production-sized bounded parts',async()=>{
  const db=await dbPromise;for(const store of ['comics','assets','config','backupStage'] as const)await db.clear(store);
  const piece=new Uint8Array(16*1024*1024);piece.fill(147);
  const blob=new Blob(Array.from({length:21},()=>piece));
  await saveComic({...blankComic('Large backup boundary'),coverId:'large'},[{id:'large',blob}]);
  const backup=await exportParts(()=>{});
  expect(backup.totalBytes).toBe(336*1024*1024);expect(backup.count).toBe(2);
  for(let i=0;i<backup.count;i++){const zip=await backup.makePart(i,()=>{});expect(zip.size).toBeGreaterThan(0);expect(zip.size).toBeLessThanOrEqual(BACKUP_PART_BYTES);}
},120000);
