import 'fake-indexeddb/auto';
import {expect,it} from 'vitest';
import {blankComic,status,stats} from '../../src/models';
import {getComic,saveComic,updateProgress} from '../../src/storage/db';

it('does not call an unopened fileless plan reading because of an old opening timestamp or bookmark',()=>{
  expect(status({...blankComic(),lastOpened:100,page:19,seconds:90})).toBe('new');
});
it('starts digital reading at three distinct valid pages, not a jump or repeated frame views',()=>{
  const c={...blankComic(),pageCount:20,page:19,lastOpened:100};
  for(const visited of [[],[0],[0,19],[0,0,19],[0,19,20,-1,1.5]]) expect(status({...c,visited})).toBe('new');
  expect(status({...c,visited:[0,1,19]})).toBe('reading');
  expect(stats([{...c,visited:[0,1,19]},c]).reading).toBe(1);
});
it('completed books remain completed, including short books and fileless paper books',()=>{
  expect(status({...blankComic(),completed:true})).toBe('done');
  expect(status({...blankComic(),completed:true,pageCount:2,visited:[0,1]})).toBe('done');
});
it('paper reading starts with its timer or actual entered page progress, not ownership or manual final time',()=>{
  const c={...blankComic(),physical:'yes' as const,paperPageCount:100};
  expect(status(c)).toBe('new');
  expect(status({...c,paperSeconds:3600})).toBe('new');
  expect(status({...c,paperStartedAt:0,paperTimer:true})).toBe('reading');
  expect(status({...c,paperTimer:true,paperSeconds:60})).toBe('reading');
  expect(status({...c,paperPagesRead:1})).toBe('reading');
});
it('persists page visits without counting repeated pages or timer-only saves towards the threshold',async()=>{
  const c={...blankComic(),pageCount:20};await saveComic(c);
  for(const [page,loaded] of [[0,true],[0,true],[19,false],[19,true]] as const) await updateProgress(c.id,page,loaded);
  expect(status((await getComic(c.id))!)).toBe('new');
  await updateProgress(c.id,1,true);expect(status((await getComic(c.id))!)).toBe('reading');
});
