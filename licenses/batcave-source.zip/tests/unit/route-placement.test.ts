import 'fake-indexeddb/auto';
import {beforeEach,it,expect,vi} from 'vitest';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {blankComic,defaultSettings,type Comic} from '../../src/models';
import {dbPromise,moveSeriesComic,allComics,saveComic} from '../../src/storage/db';
import {orderedSeriesTimeline} from '../../src/roadmap';
import {parseBackup} from '../../src/storage/backup';
import {routeProgress,comicReadFraction} from '../../src/library-home';
const book=(id:string,era='a',patch:Partial<Comic>={}):Comic=>({...blankComic(id),id,universeId:'test',era,addedAt:Number(id.slice(1))||1,...patch});
beforeEach(async()=>{const db=await dbPromise;for(const store of ['comics','assets','config'] as const)await db.clear(store);await db.put('config',[{id:'test',title:'Тест',chapters:[{id:'a',title:'A'},{id:'b',title:'B'}],updatedAt:0}],'reading-universes-v1');});
it('reorders latest records atomically without changing reading, assets or addition dates',async()=>{
  const db=await dbPromise;
  const original=book('b1','a',{page:4,pageCount:10,visited:[0,4],seconds:150,rating:4,coverId:'cover',digital:{assetId:'file',format:'cbz',name:'book.cbz',fingerprint:'a'.repeat(64),size:10}});
  for(const c of [original,book('b2'),book('b3')])await db.put('comics',c);
  await db.put('assets',{id:'file',blob:new Blob(['original'])});
  await moveSeriesComic('b3','test','a','b1');
  expect(orderedSeriesTimeline(await allComics(),'a').map(c=>c.id)).toEqual(['b3','b1','b2']);
  const saved=await db.get('comics','b1');expect(saved).toEqual({...original,routeOrder:1});
  expect(await(await db.get('assets','file'))!.blob.text()).toBe('original');
  const before=await allComics();await expect(moveSeriesComic('b1','test','b','missing')).rejects.toThrow('Место вставки');expect(await allComics()).toEqual(before);
});
it('moving an anchor leaves legacy linked rows in their previous section and moves a child independently',async()=>{
  const db=await dbPromise;for(const c of [book('b1'),book('b2','b',{sideStoryAfter:'b1'}),book('b3','b')])await db.put('comics',c);
  await moveSeriesComic('b1','test','b');
  let records=await allComics();expect(orderedSeriesTimeline(records,'a').map(c=>c.id)).toEqual(['b2']);
  expect(records.find(c=>c.id==='b2')).toMatchObject({era:'a',sideStoryAfter:undefined,addedAt:2});
  expect(orderedSeriesTimeline(records,'b').map(c=>c.id)).toEqual(['b3','b1']);
  await moveSeriesComic('b2','test','b','b3');records=await allComics();expect(orderedSeriesTimeline(records,'b').map(c=>c.id)).toEqual(['b2','b3','b1']);
});
it('new additions append; a metadata edit cannot overwrite a concurrent route move',async()=>{
  const db=await dbPromise;for(const c of [book('b1'),book('b2')])await db.put('comics',c);
  const base=(await db.get('comics','b1'))!;
  await moveSeriesComic('b1','test','b');
  await saveComic({...base,title:'Новое имя'},[],[],true,base);
  expect(await db.get('comics','b1')).toMatchObject({era:'b',title:'Новое имя',routeOrder:0});
  await db.put('comics',book('b3','b',{addedAt:Date.now()}));expect(orderedSeriesTimeline(await allComics(),'b').map(c=>c.id)).toEqual(['b1','b3']);
});
it('backup parsing retains explicit order and still accepts older records',()=>{
  const record=book('b1','a',{routeOrder:3});
  const raw={app:'BATCAVE',version:1,kind:'metadata',createdAt:1,comics:[record,book('b2')],settings:defaultSettings,assets:[]};
  const parsed=parseBackup(raw);expect(parsed.comics[0].routeOrder).toBe(3);expect(parsed.comics[1].routeOrder).toBeUndefined();
});
it('partial reading contributes once, with duplicate and invalid page visits ignored',()=>{
  const half=book('b1','a',{digital:{assetId:'x',format:'cbz',name:'x',size:1,fingerprint:'a'.repeat(64)},pageCount:4,visited:[0,1,1,-1,99]});
  expect(comicReadFraction(half)).toBe(.5);expect(routeProgress([half,book('b2','a',{completed:true})])).toBe(75);expect(routeProgress([])).toBe(0);
});
