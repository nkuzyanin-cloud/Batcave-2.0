import{it,expect}from'vitest';
import{validShape,validShapes,quadShape,moveVertex,reframeShape,shapePath}from'../../src/reader/frame-shapes';
import{parsePrepared,preparedPanelMap,type PreparedComic}from'../../src/reader/prepared';
it('moves exactly one vertex without moving its neighbours',()=>{
 const original=quadShape(),r:[number,number,number,number]=[.1,.2,.6,.5],changed=moveVertex(original,r,1,[.7,.1])!;
 expect(changed).toBeDefined();if(changed.shape.type!=='polygon'||original.type!=='polygon')throw Error('Wrong shape');
 for(const i of [0,2,3]){const p=changed.shape.points[i];expect(changed.rect[0]+p[0]*changed.rect[2]).toBeCloseTo(r[0]+original.points[i][0]*r[2],12);expect(changed.rect[1]+p[1]*changed.rect[3]).toBeCloseTo(r[1]+original.points[i][1]*r[3],12);}
 expect(moveVertex(original,r,1,[.12,.69])).toBeUndefined();
});
it('rejects crossed polygons, stars, invalid ellipses and mismatched arrays',()=>{
 expect(validShape({type:'polygon',points:[[0,0],[1,1],[1,0],[0,1]]})).toBe(false);
 const star=Array.from({length:5},(_,i)=>{const a=(i*2%5)*Math.PI*2/5;return[.5+.45*Math.cos(a),.5+.45*Math.sin(a)];});expect(validShape({type:'polygon',points:star})).toBe(false);
 expect(validShape({type:'ellipse',box:[2,2,1,1]})).toBe(false);expect(validShape({type:'ellipse',box:[0,0,Infinity,1]})).toBe(false);expect(validShapes([quadShape()],2)).toBe(false);
});
it('clips contours against page crops without replacing them with rectangles',()=>{
 const p=reframeShape({type:'polygon',points:[[0,.25],[1,0],[1,.75],[0,1]]},[.1,.1,.8,.8],[.1,.1,.4,.8])!;
 expect(validShape(p)).toBe(true);if(p.type==='polygon')expect(p.points.some(q=>Math.abs(q[0]-1)<1e-6&&Math.abs(q[1]-.125)<1e-6)).toBe(true);
 const e=reframeShape({type:'ellipse'},[0,0,1,1],[0,0,.5,1])!;expect(e).toEqual({type:'ellipse',box:[0,0,2,1]});expect(validShape(e)).toBe(true);expect(reframeShape({type:'ellipse'},[0,0,1,1],[0,0,.05,.05])).toBeUndefined();expect(shapePath(e)).toContain('A');
});
it('reads v2 contours and old v1 files while retaining relative vertices in cropped maps',()=>{
 const f:PreparedComic={app:'BATCAVE Studio',version:2,pages:[{name:'a.png',sha256:'a'.repeat(64),width:1000,height:1500,crop:[.1,.1,.8,.8],frames:[[.2,.2,.3,.3]],shapes:[{type:'polygon',points:[[0,.2],[1,0],[1,.8],[0,1]]}],kind:'story'}]};
 const map=preparedPanelMap(parsePrepared(f,['a.png']),'b'.repeat(64));expect(map.pages[0].shapes).toEqual(f.pages[0].shapes);expect(map.pages[0].frames[0][0]).toBeCloseTo(.125);
 f.pages[0].shapes=[];expect(()=>parsePrepared(f,['a.png'])).toThrow();delete f.pages[0].shapes;f.version=1;expect(()=>parsePrepared(f,['a.png'])).not.toThrow();
});
