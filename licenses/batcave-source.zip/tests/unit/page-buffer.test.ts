import { expect, it, vi } from 'vitest';
import { PageBuffer } from '../../src/reader/page-buffer';
import type { PageSource } from '../../src/reader/source';

function harness() {
  const calls: { page: number; canvas: HTMLCanvasElement; signal: AbortSignal; finish: () => void; fail: () => void }[] = [];
  const canvases: HTMLCanvasElement[] = [];
  let active = 0, peak = 0;
  const source: PageSource = {
    count: 100, ratio: 1.5, close: async () => {},
    render: (page, canvas, _width, signal) => new Promise<void>((resolve, reject) => {
      peak = Math.max(peak, ++active);
      calls.push({ page, canvas, signal: signal!, finish: () => {
        canvas.width = 100;canvas.height = 150;active--;resolve();
      }, fail: () => { active--;reject(Error('Damaged page')); } });
    }),
  };
  const buffer = new PageBuffer(source, 2200, () => {
    const canvas = { width: 0, height: 0, dataset: {}, setAttribute: vi.fn() } as unknown as HTMLCanvasElement;
    canvases.push(canvas);return canvas;
  });
  return { buffer, calls, canvases, peak: () => peak };
}
const flush = async () => { for (let i = 0; i < 5; i++) await Promise.resolve(); };

it('reuses prepared pages, serializes rendering and releases pages outside the three-page window', async () => {
  const { buffer, calls, canvases, peak } = harness();
  buffer.keep([0, 1, 2, 3]);expect(calls.map(c => c.page)).toEqual([0]);
  calls[0].finish();await flush();calls[1].finish();await flush();calls[2].finish();await flush();
  expect(buffer.get(0)).toBe(canvases[0]);expect(buffer.get(3)).toBeUndefined();
  const next = buffer.get(1);
  buffer.keep([1, 2, 3]);expect(buffer.get(1)).toBe(next);
  expect(canvases[0].width).toBe(0);expect(canvases[0].height).toBe(0);
  expect(calls.map(c => c.page)).toEqual([0, 1, 2, 3]);
  calls[3].finish();await flush();expect(peak()).toBe(1);
  expect(canvases.filter(c => c.width > 0)).toHaveLength(3);
  buffer.dispose();expect(canvases.every(c => !c.width && !c.height)).toBe(true);
});

it('cancels obsolete work on a distant jump and prioritizes the newest requested page', async () => {
  const { buffer, calls, canvases, peak } = harness();
  buffer.keep([0, 1, 2]);buffer.keep([50, 51, 49]);
  expect(calls[0].signal.aborted).toBe(true);expect(calls).toHaveLength(1);
  // Some decoders finish after cancellation. Their late result cannot reappear.
  calls[0].finish();await flush();
  expect(canvases[0].width).toBe(0);expect(buffer.get(0)).toBeUndefined();
  expect(calls[1].page).toBe(50);
  calls[1].finish();await flush();expect(buffer.get(50)).toBe(calls[1].canvas);
  buffer.dispose();expect(calls[2].signal.aborted).toBe(true);
  calls[2].finish();await flush();expect(canvases.every(c => !c.width && !c.height)).toBe(true);
  expect(peak()).toBe(1);expect(calls).toHaveLength(3);
});

it('keeps visible paper during neighbour rendering and isolates a damaged prefetched page', async () => {
  const { buffer, calls } = harness();
  const updated = vi.fn();buffer.subscribe(updated);
  buffer.keep([4, 5, 3]);calls[0].finish();await flush();
  const visible = buffer.get(4);expect(visible?.width).toBe(100);
  calls[1].fail();await flush();
  expect(buffer.get(4)).toBe(visible);expect(buffer.error(5)).toBeInstanceOf(Error);
  expect(buffer.get(5)).toBeUndefined();expect(calls[1].canvas.width).toBe(0);
  calls[2].finish();await flush();
  buffer.keep([5, 4, 6]);expect(buffer.get(4)).toBe(visible);
  const notifications = updated.mock.calls.length;
  buffer.dispose();calls[3].finish();await flush();
  expect(updated).toHaveBeenCalledTimes(notifications);
});
