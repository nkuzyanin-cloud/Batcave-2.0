import { expect, it } from 'vitest';
import { shadeRectangles, motionDuration } from '../../src/reader/panel-motion';
import type { Rect } from '../../src/reader/panels';

it('covers only the area outside a frame with four non-overlapping solid quads, including page edges', () => {
  for (const bounds of [[0, 0, 1, 1], [.1, .15, .5, .3], [0, .3, 1, .4], [0, 0, .5, .5], [.5, .5, .5, .5]] as Rect[]) {
    const rects = shadeRectangles(bounds);
    expect(rects.reduce((a, r) => a + r[2] * r[3], 0)).toBeCloseTo(1 - bounds[2] * bounds[3]);
    for (let x = .005; x < 1; x += .01) for (let y = .005; y < 1; y += .01) {
      const inside = x > bounds[0] && x < bounds[0] + bounds[2] && y > bounds[1] && y < bounds[1] + bounds[3];
      const layers = rects.filter(r => x > r[0] && x < r[0] + r[2] && y > r[1] && y < r[1] + r[3]).length;
      expect(layers).toBe(inside ? 0 : 1);
    }
  }
});
it('honours off, fast and the live system motion preference', () => {
  expect(motionDuration('off', false)).toBe(0);expect(motionDuration('system', true)).toBe(0);
  expect(motionDuration('system', false)).toBeGreaterThan(300);
  expect(motionDuration('full', true)).toBe(motionDuration('system', false));
  expect(motionDuration('fast', false)).toBeGreaterThan(0);
  expect(motionDuration('fast', false)).toBeLessThan(motionDuration('full', false));
});
