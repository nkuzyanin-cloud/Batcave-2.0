import {describe,it,expect} from 'vitest';
import {readerLevel,LEVEL_PAGES,pagesLabel} from '../../src/reader-level';
import {blankComic,stats} from '../../src/models';

describe('reader shelf milestones',()=>{
  it('starts empty, adds the first spine for a library record and credits old reading',()=>{
    expect(readerLevel(0,false)).toMatchObject({level:0,next:undefined});
    expect(readerLevel(0,true)).toMatchObject({level:1,next:500});
    expect(readerLevel(499,true).level).toBe(1);
    expect(readerLevel(500,true).level).toBe(2);
    expect(readerLevel(1487,true)).toEqual({level:3,pages:1487,next:1500});
  });
  it('keeps every milestone distinct and reaches exactly 50 at 100,000 without capping statistics',()=>{
    expect(LEVEL_PAGES).toHaveLength(51);
    for(let level=2;level<=50;level++){
      expect(LEVEL_PAGES[level]).toBeGreaterThan(LEVEL_PAGES[level-1]);
      expect(readerLevel(LEVEL_PAGES[level]-1,true).level).toBe(level-1);
      expect(readerLevel(LEVEL_PAGES[level],true).level).toBe(level);
    }
    expect(readerLevel(99999,true)).toMatchObject({level:49,next:100000});
    expect(readerLevel(100000,true)).toEqual({level:50,pages:100000,next:undefined});
    expect(readerLevel(180000,true)).toEqual({level:50,pages:180000,next:undefined});
  });
  it('uses the same confirmed pages as statistics, retaining pages without a digital file and counting two formats once',()=>{
    const comic={...blankComic('История'),pageCount:1000,visited:Array.from({length:500},(_,i)=>i),physical:'yes' as const,paperPageCount:400,paperCompleted:true};
    const total=stats([comic]).pages;expect(total).toBe(500);
    expect(readerLevel(total,true).level).toBe(2);
    expect(stats([{...comic,page:1,lastOpened:999}]).pages).toBe(total);
  });
  it('handles invalid values and Russian remaining-page labels',()=>{
    for(const pages of [-1,NaN,Infinity])expect(readerLevel(pages,true)).toMatchObject({level:1,pages:0});
    expect([1,2,5,11,21,22,114].map(pagesLabel)).toEqual(['страница','страницы','страниц','страниц','страница','страницы','страниц']);
  });
});
