import 'fake-indexeddb/auto';
import {beforeEach,it,expect} from 'vitest';
import {blankComic} from '../../src/models';
import {dbPromise,saveComic,updateProgress,updateReadingResult,getComic} from '../../src/storage/db';
beforeEach(async()=>{const db=await dbPromise;await db.clear('comics');});
it('merges a rating into current progress instead of overwriting a concurrent reading save',async()=>{
  const c={...blankComic(),pageCount:4,seconds:90,coverId:'cover',era:'modern' as const};await saveComic(c);
  await Promise.all([updateProgress(c.id,2,true,12.5),updateReadingResult(c.id,{rating:5})]);
  expect(await getComic(c.id)).toMatchObject({rating:5,seconds:102.5,visited:[2],coverId:'cover',era:'modern',completed:false});
});
it('manual completion keeps actual visited pages and completion date survives rating changes',async()=>{
  const c={...blankComic(),pageCount:5,visited:[0,4],seconds:123};await saveComic(c);
  const completed=await updateReadingResult(c.id,{completed:true});
  expect(completed).toMatchObject({completed:true,readDigitally:true,visited:[0,4],seconds:123});
  expect(completed.completedAt).toBeTypeOf('number');
  expect((await updateReadingResult(c.id,{rating:4})).completedAt).toBe(completed.completedAt);
});
it('rejects invalid ratings and missing comics without modifying stored data',async()=>{
  const c=blankComic();await saveComic(c);
  await expect(updateReadingResult(c.id,{rating:6})).rejects.toThrow();
  await expect(updateReadingResult(c.id,{rating:1.5})).rejects.toThrow();
  await expect(updateReadingResult('missing',{rating:3})).rejects.toThrow();
  expect((await getComic(c.id))!.rating).toBe(0);
});
