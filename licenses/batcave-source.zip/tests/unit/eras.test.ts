import 'fake-indexeddb/auto';
import {beforeEach,it,expect,vi} from 'vitest';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {blankComic,defaultSettings} from '../../src/models';
import {ERAS,comicEra} from '../../src/eras';
import {orderedRoadmap} from '../../src/roadmap';
import {dbPromise,saveComic,setSideStory,allComics,getAsset} from '../../src/storage/db';
import {parseBackup,restore,exportMetadata} from '../../src/storage/backup';
beforeEach(async()=>{const db=await dbPromise;await db.clear('comics');await db.clear('assets');});
it('keeps old comics in early years and leaves other eras empty without seed titles',()=>{
  const c=blankComic('Old');expect(ERAS).toHaveLength(13);
  expect(orderedRoadmap([c],'early')).toEqual([c]);expect(orderedRoadmap([c],'family')).toEqual([]);
  expect(comicEra({...c,era:'modern',sideStoryAfter:'a'},[{...c,id:'a'}])).toBe('early');
});
it('moves an anchor and its branches atomically without losing assets or reading progress',async()=>{
  const anchor={...blankComic('Anchor'),id:'anchor'};
  const side={...blankComic('Side'),id:'side',era:'modern' as const,seconds:77,coverId:'cover'};
  await saveComic(anchor);await saveComic(side,[{id:'cover',blob:new Blob(['keep'])}]);
  await setSideStory(side.id,anchor.id,true);
  await saveComic({...anchor,era:'family'});
  const saved=await allComics();expect(saved.find(c=>c.id===side.id)).toMatchObject({era:'family',seconds:77,coverId:'cover',sideStoryAfter:anchor.id});
  expect(orderedRoadmap(saved,'early')).toHaveLength(0);expect(orderedRoadmap(saved,'family').map(c=>c.id)).toEqual(['anchor']);
  await setSideStory(side.id,anchor.id,false);
  expect(orderedRoadmap(await allComics(),'family')).toHaveLength(2);expect(await(await getAsset('cover'))!.blob.text()).toBe('keep');
});
it.each(['modern','standalone','alternative'] as const)('round-trips %s era metadata and accepts older backups',async(era)=>{
  const c={...blankComic('Modern'),era};await saveComic(c);
  const raw=JSON.parse(await(await exportMetadata()).text());expect(parseBackup(raw).comics[0].era).toBe(era);
  const data=parseBackup({...raw,settings:{...defaultSettings,roadmapEra:era}});
  await restore({data,assets:new Map(),conflicts:0},'replace',true);
  expect((await allComics())[0].era).toBe(era);
  expect(await(await dbPromise).get('config','settings')).toMatchObject({roadmapEra:era});
  const old={...raw,comics:[blankComic('Old')]};expect(parseBackup(old).comics[0].era).toBeUndefined();
});
