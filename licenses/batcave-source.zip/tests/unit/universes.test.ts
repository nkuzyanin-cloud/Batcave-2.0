import 'fake-indexeddb/auto';
import {beforeEach,it,expect,vi} from 'vitest';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {blankComic,stats} from '../../src/models';
import {dbPromise,initialize,getUniverses,saveUniverse,deleteUniverse,saveComic,setSideStory,getAsset,getAchievementState} from '../../src/storage/db';
import {UNIVERSES_KEY,type Universe,comicUniverse} from '../../src/universes';
import {exportMetadata,parseBackup,restore} from '../../src/storage/backup';
import {orderedRoadmap} from '../../src/roadmap';
const u:Universe={id:'walking',title:'Ходячие мертвецы',chapters:[{id:'volume-1',title:'Том 1'}],cover:'data:image/jpeg;base64,YQ==',updatedAt:0};
beforeEach(async()=>{const db=await dbPromise;await db.clear('comics');await db.clear('assets');await db.clear('config');});
it('wraps the existing roadmap without changing identity, files, panels or reading progress; migration is idempotent',async()=>{
 const db=await dbPromise,c={...blankComic('Existing'),era:'family',inRoadmap:true,page:2,pageCount:10,visited:[0,1,2],seconds:125,lastOpened:100};
 await db.put('comics',c);await db.put('assets',{id:'original',blob:new Blob(['untouched'])});
 await db.put('config',{version:2,initializedAt:1,earned:[{id:'era-early',at:2},{id:'first',at:3}],pending:[]},'achievements-v2');
 await initialize();const first=await db.getAll('comics');expect(first[0]).toEqual({...c,universeId:'batman'});expect((await getUniverses())[0].chapters).toHaveLength(13);
 await initialize();expect(await db.getAll('comics')).toEqual(first);expect(await(await getAsset('original'))!.blob.text()).toBe('untouched');expect((await getAchievementState())?.earned).toContainEqual({id:'era-early',at:2});
});
it('deletes a series atomically while preserving latest reading, files and other series',async()=>{
 await initialize();await saveUniverse(u);const db=await dbPromise;
 const c={...blankComic('Keep me'),universeId:u.id,era:'volume-1',inRoadmap:true,routeOrder:2,page:2,pageCount:3,visited:[0,1,2],seconds:880,completed:true,rating:5,coverId:'cover',digital:{assetId:'file',format:'cbz' as const,name:'comic.cbz',size:4,fingerprint:'a'.repeat(64)}};
 await db.put('comics',c);await db.put('assets',{id:'file',blob:new Blob(['file'])});await db.put('assets',{id:'cover',blob:new Blob(['cover'])});
 await db.put('config',['volume-1'],`route-disclosures-v1:${u.id}`);
 const series=(await getUniverses()).find(s=>s.id===u.id)!;
 // A newer reading save must survive a route deletion started from an older view.
 const latest={...c,seconds:999,visited:[0,1,2],note:'latest'};await db.put('comics',latest);
 const before=stats([latest]);await deleteUniverse(u.id,series.updatedAt);
 const after=(await db.get('comics',c.id))!;
 expect(after).toEqual({...latest,universeId:'__unassigned__',era:'early',inRoadmap:false,routeOrder:undefined,sideStoryAfter:undefined,updatedAt:expect.any(Number)});
 expect(stats([after])).toEqual(before);expect(await(await getAsset('file'))!.blob.text()).toBe('file');expect(await(await getAsset('cover'))!.blob.text()).toBe('cover');
 expect(await db.get('config',`route-disclosures-v1:${u.id}`)).toBeUndefined();
 expect((await getUniverses()).map(s=>s.id)).toEqual(['batman']);await initialize();expect((await getUniverses()).some(s=>s.id===u.id)).toBe(false);
 await expect(saveUniverse(series,true)).rejects.toThrow('удалена');
});
it('keeps the built-in series deleted after restart and metadata backup restore',async()=>{
 await initialize();const db=await dbPromise;await deleteUniverse('batman',0);await initialize();expect(await getUniverses()).toEqual([]);
 const data=parseBackup(JSON.parse(await(await exportMetadata()).text()));expect(data.universes).toEqual([]);
 await db.clear('config');await restore({data,assets:new Map(),conflicts:0},'replace',true);await initialize();expect(await getUniverses()).toEqual([]);
});
it('rejects stale and missing series deletes without moving comics',async()=>{
 await initialize();await saveUniverse(u);const db=await dbPromise,c={...blankComic(),universeId:u.id,era:'volume-1'};await db.put('comics',c);
 await expect(deleteUniverse(u.id,-1)).rejects.toThrow('изменена');expect(await db.get('comics',c.id)).toEqual(c);
 await expect(deleteUniverse('missing',0)).rejects.toThrow('удалена');expect((await getUniverses()).some(s=>s.id===u.id)).toBe(true);
});
it('keeps separate routes and rejects cross-series side-story relationships',async()=>{
 await initialize();await saveUniverse(u);
 const a={...blankComic(),universeId:'batman',era:'early',inRoadmap:true},b={...blankComic(),universeId:u.id,era:'volume-1',inRoadmap:true};await saveComic(a);await saveComic(b);
 const all=await(await dbPromise).getAll('comics');expect(orderedRoadmap(all.filter(c=>comicUniverse(c)==='walking'),'volume-1').map(c=>c.id)).toEqual([b.id]);
 await expect(setSideStory(b.id,a.id,true)).rejects.toThrow('той же серии');
 await expect(saveComic({...b,sideStoryAfter:a.id})).rejects.toThrow('той же серии');
});
it('round-trips series covers and custom chapters in metadata backups and rejects deleting populated chapters',async()=>{
 await initialize();await saveUniverse(u);const b={...blankComic(),universeId:u.id,era:'volume-1',inRoadmap:true};await saveComic(b);
 const data=parseBackup(JSON.parse(await(await exportMetadata()).text()));expect(data.universes?.find(x=>x.id===u.id)?.cover).toBe(u.cover);expect(data.comics[0].universeId).toBe(u.id);
 const db=await dbPromise;await db.clear('config');await db.clear('comics');await restore({data,assets:new Map(),conflicts:0},'replace',true);
 expect((await getUniverses()).find(x=>x.id===u.id)?.chapters).toEqual(u.chapters);expect((await db.getAll('comics'))[0].era).toBe('volume-1');
 const restored=(await getUniverses()).find(x=>x.id===u.id)!;await expect(saveUniverse({...restored,chapters:[{id:'other',title:'Other'}]})).rejects.toThrow('перенесите');
 expect(await db.get('config',UNIVERSES_KEY)).toBeDefined();
});
