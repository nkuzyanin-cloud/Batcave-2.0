import {describe,it,expect} from 'vitest';
import {blankComic} from '../../src/models';
import {readerRanks,readerRankAwards} from '../../src/reader-ranks';
import {advanceAchievements,normalizeAchievementState,mergeAchievementStates} from '../../src/achievements';
const library=(stories:number,pages:number,seconds:number)=>Array.from({length:stories},(_,i)=>({...blankComic(),id:`c${i}`,completed:true,pageCount:i?0:pages,visited:i?[]:Array.from({length:pages},(_,j)=>j),seconds:i?0:seconds}));
describe('combined reader ranks',()=>{
 for(const r of readerRanks)it(`${r.tier} needs all three independent thresholds`,()=>{
  const earned=(stories:number,pages:number,seconds:number)=>readerRankAwards(library(stories,pages,seconds)).find(a=>a.tier===r.tier)!.earned;
  expect(earned(r.stories,r.pages,r.hours*3600)).toBe(true);
  expect(earned(r.stories-1,r.pages,r.hours*3600)).toBe(false);
  expect(earned(r.stories,r.pages-1,r.hours*3600)).toBe(false);
  expect(earned(r.stories,r.pages,r.hours*3600-1)).toBe(false);
 });
 it('preserves rank dates and earned ranks through deletion and backup normalization',()=>{
  const s=advanceAchievements(library(5,1000,8*3600),undefined,123);
  expect(s.earned.find(a=>a.id==='rank-bronze')?.at).toBe(123);
  const restored=normalizeAchievementState(JSON.parse(JSON.stringify(s)))!;
  const next=advanceAchievements([],restored,999);
  expect(readerRankAwards([],next)[0].earned).toBe(true);
  expect(next.earned.find(a=>a.id==='rank-bronze')?.at).toBe(123);
  expect(mergeAchievementStates(undefined,next)?.earned).toEqual(next.earned);
 });
 it('restores lower ranks when only a higher award survives in imported state',()=>{
  const s=normalizeAchievementState({version:2,initializedAt:0,earned:[{id:'rank-platinum',at:5}],pending:[]})!;
  expect(readerRankAwards([],s).every(a=>a.earned)).toBe(true);
 });
 it('keeps the current reader bronze until the missing pages and time are met, then preserves their award history',()=>{
  const old=normalizeAchievementState({version:2,initializedAt:1,earned:[{id:'rank-bronze',at:123}],pending:[]})!;
  const comics=library(34,2403,(19*60+8)*60);
  expect(readerRankAwards(comics,old).filter(a=>a.earned).map(a=>a.tier)).toEqual(['bronze']);
  const pagesOnly=library(34,3000,(19*60+8)*60);
  expect(readerRankAwards(pagesOnly,old).filter(a=>a.earned).map(a=>a.tier)).toEqual(['bronze']);
  const finished=library(34,3000,25*3600);
  const updated=advanceAchievements(finished,old,999);
  expect(updated.earned.find(a=>a.id==='rank-bronze')?.at).toBe(123);
  expect(updated.earned.find(a=>a.id==='rank-silver')?.at).toBe(999);
  expect(readerRankAwards(finished,updated).filter(a=>a.earned).map(a=>a.tier)).toEqual(['bronze','silver']);
  const reopened=advanceAchievements(finished,updated,1000);
  expect(reopened.earned).toEqual(updated.earned);
  expect(reopened.pending).toEqual(updated.pending);
 });
});
