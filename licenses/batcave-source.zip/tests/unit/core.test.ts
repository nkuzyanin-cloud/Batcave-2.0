import 'fake-indexeddb/auto';
import { beforeAll, describe, expect, it, vi } from 'vitest';
vi.mock('pdfjs-dist', () => ({
  GlobalWorkerOptions: {},
  PDFDataRangeTransport: class {},
  getDocument: vi.fn(),
}));
import { blankComic, stats, status, percent } from '../../src/models';
import { initialCatalog } from '../../src/data/catalog';
import { detectFormat, comicEntries, naturalCompare, openZip } from '../../src/reader/source';
import {
  initialize,
  allComics,
  saveComic,
  updateProgress,
  deleteDigital,
  deleteComic,
  dbPromise,
  getSettings,
} from '../../src/storage/db';
import {
  parseBackup,
  restore,
  exportMetadata,
  checksum,
  prepareRestore,
} from '../../src/storage/backup';
import { readFileSync } from 'node:fs';
beforeAll(async () => {
  await initialize();
});
describe('Catalog and statistics', () => {
  it('starts empty, initializes once and counts explicit combined editions once', async () => {
    await initialize();
    expect((await allComics()).length).toBe(0);
    expect(stats(initialCatalog()).paper).toBe(2);
    expect(initialCatalog().filter((c) => c.physical === 'unknown').length).toBe(8);
  });
  it('does not invent pages or ratings', () => {
    const s = stats(initialCatalog());
    expect(s.pages).toBe(0);
    expect(s.done).toBe(0);
    expect(s.seconds).toBe(0);
    expect(initialCatalog().every((c) => !c.digital && c.rating === 0)).toBe(true);
  });
  it('counts visited pages, not jumps', () => {
    const c = { ...blankComic(), pageCount: 20, page: 19, visited: [0, 19], lastOpened: 1 };
    expect(percent(c)).toBe(10);
    expect(status(c)).toBe('reading');
  });
});
describe('File validation', () => {
  it('uses natural ordering', () => {
    expect(['10.png', '2.png', '1.png'].sort(naturalCompare)).toEqual(['1.png', '2.png', '10.png']);
  });
  it('accepts correct headers and rejects renamed archives', async () => {
    await expect(detectFormat(new Blob(['%PDF-1.7 content']), 'file.pdf')).resolves.toBe('pdf');
    await expect(detectFormat(new Blob(['Rar!x']), 'book.cbz')).rejects.toThrow('CBR');
    await expect(detectFormat(new Blob(['hello']), 'file.pdf')).rejects.toThrow('содержимому');
    await expect(detectFormat(new Blob([]), 'file.pdf')).rejects.toThrow('пуст');
  });
  it('opens CBZ without extracting all pages', async () => {
    const blob = new Blob([readFileSync('tests/fixtures/sample.cbz')]);
    const { zip, entries } = await openZip(blob);
    try {
      expect(comicEntries(entries).map((x) => x.filename)).toEqual(['1.png', '2.png', '10.png']);
    } finally {
      await zip.close();
    }
  });
  it('rejects damaged and empty archives', async () => {
    await expect(openZip(new Blob([readFileSync('tests/fixtures/broken.cbz')]))).rejects.toThrow();
    const { zip, entries } = await openZip(new Blob([readFileSync('tests/fixtures/empty.cbz')]));
    try {
      expect(() => comicEntries(entries)).toThrow('нет страниц');
    } finally {
      await zip.close();
    }
  });
  it('rejects archive bombs and encrypted pages', () => {
    const entry = {
      directory: false,
      filename: '1.png',
      uncompressedSize: 40 * 1024 ** 2,
      encrypted: false,
    };
    expect(() => comicEntries([entry] as never)).toThrow('слишком большие');
    expect(() =>
      comicEntries([{ ...entry, uncompressedSize: 100, encrypted: true }] as never),
    ).toThrow('паролем');
  });
});
describe('IndexedDB', () => {
  it('persists a file and deduplicates visited pages', async () => {
    const c = {
      ...blankComic('Тест'),
      pageCount: 3,
      digital: {
        assetId: 'test-file',
        name: 'book.png',
        format: 'image' as const,
        size: 10,
        fingerprint: 'a'.repeat(64),
      },
    };
    await saveComic(c, [{ id: 'test-file', blob: new Blob(['1234567890']) }]);
    await updateProgress(c.id, 0, true, 5);
    await updateProgress(c.id, 0, true, 2);
    await updateProgress(c.id, 2, true);
    const record = (await allComics()).find((x) => x.id === c.id)!;
    expect(record.visited).toEqual([0, 2]);
    expect(record.seconds).toBe(7);
    expect(record.completed).toBe(false);
    await updateProgress(c.id, 1, true);
    expect((await allComics()).find((x) => x.id === c.id)!.completed).toBe(true);
    await deleteDigital(record);
    expect(await (await dbPromise).get('assets', 'test-file')).toBeUndefined();
    expect((await allComics()).find((x) => x.id === c.id)!.visited).toEqual([0, 1, 2]);
    await deleteComic(record);
    expect((await allComics()).find((x) => x.id === c.id)).toBeUndefined();
  });
});
describe('Backup integrity and conflict policy', () => {
  beforeAll(async () => {
    await saveComic(blankComic('Backup fixture'));
  });
  it('rejects invalid schema, duplicate IDs and unsafe paths', async () => {
    const raw = JSON.parse(await (await exportMetadata()).text());
    expect(parseBackup(raw).comics.length).toBe(1);
    expect(() => parseBackup({ ...raw, version: 100 })).toThrow();
    expect(() => parseBackup({ ...raw, comics: [raw.comics[0], raw.comics[0]] })).toThrow();
    expect(() =>
      parseBackup({
        ...raw,
        assets: [{ id: 'x', path: '../../x', size: 1, mime: 'image/png', sha256: 'a'.repeat(64) }],
      }),
    ).toThrow();
    expect(() =>
      parseBackup({ ...raw, comics: [{ ...raw.comics[0], visited: [9000] }] }),
    ).toThrow();
  });
  it('metadata restoration keeps current data by default and cannot invent files', async () => {
    const original = (await allComics())[0];
    const old = { ...original, note: 'Current local note' };
    await saveComic(old);
    const raw = parseBackup(JSON.parse(await (await exportMetadata()).text()));
    raw.comics = [
      {
        ...old,
        note: 'Backup note',
        digital: {
          assetId: 'missing-file',
          format: 'pdf',
          name: 'missing.pdf',
          size: 100,
          fingerprint: 'b'.repeat(64),
        },
      },
    ];
    await restore({ data: raw, assets: new Map(), conflicts: 1 }, 'keep', false);
    expect((await allComics()).find((c) => c.id === old.id)!.note).toBe('Current local note');
    await restore({ data: raw, assets: new Map(), conflicts: 1 }, 'replace', false);
    const replaced = (await allComics()).find((c) => c.id === old.id)!;
    expect(replaced.note).toBe('Backup note');
    expect(replaced.digital).toBeUndefined();
  });
  it('hashes data incrementally and rejects non-backup ZIP without mutation', async () => {
    expect(await checksum(new Blob(['abc']))).toBe(
      'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad',
    );
    const before = await allComics();
    await expect(
      prepareRestore(new File([readFileSync('tests/fixtures/sample.cbz')], 'wrong.zip'), () => {}),
    ).rejects.toThrow('batcave.json');
    expect(await allComics()).toEqual(before);
  });
});
import { imageSize } from '../../src/reader/image-size';
describe('Image memory limits', () => {
  it('reads dimensions before decode and rejects oversized PNG', async () => {
    expect(await imageSize(new Blob([readFileSync('tests/fixtures/page.png')]))).toEqual({
      width: 500,
      height: 750,
    });
    const header = new Uint8Array(24);
    header.set([137, 80, 78, 71], 0);
    const v = new DataView(header.buffer);
    v.setUint32(16, 30000);
    v.setUint32(20, 30000);
    await expect(imageSize(new Blob([header]))).rejects.toThrow('слишком большая');
  });
  it('rejects images without a valid dimension header', async () => {
    await expect(imageSize(new Blob(['bad image']))).rejects.toThrow('размеры');
  });
});
it('reads JPEG and WebP dimensions and signatures', async () => {
  for (const name of ['page.jpg', 'page.webp']) {
    const blob = new Blob([readFileSync('tests/fixtures/' + name)]);
    expect(await imageSize(blob)).toEqual({ width: 500, height: 750 });
    await expect(detectFormat(blob, name)).resolves.toBe('image');
  }
});
