import 'fake-indexeddb/auto';
import {expect,it,vi} from 'vitest';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {defaultSettings} from '../../src/models';
import {dbPromise,getSettings,saveSettings} from '../../src/storage/db';
import {exportMetadata,parseBackup} from '../../src/storage/backup';

it('old settings and backups default to normal colours; warmth survives storage and backup',async()=>{
 const db=await dbPromise;
 const legacy={...defaultSettings};delete legacy.warmScreen;
 await db.put('config',legacy,'settings');
 expect((await getSettings()).warmScreen).toBe(false);
 const old=JSON.parse(await(await exportMetadata()).text());delete old.settings.warmScreen;
 expect(parseBackup(old).settings.warmScreen).toBe(false);
 await saveSettings({...await getSettings(),warmScreen:true});
 expect((await getSettings()).warmScreen).toBe(true);
 const raw=JSON.parse(await(await exportMetadata()).text());
 expect(parseBackup(raw).settings.warmScreen).toBe(true);
 expect(()=>parseBackup({...raw,settings:{...raw.settings,warmScreen:'false'}})).toThrow();
});
