import { readFileSync } from 'node:fs';
import { expect, it, vi } from 'vitest';
import { findPanelStep, panelCamera, panelSteps, parsePanelMap, loadPanelMap, YEAR_ONE_HASH } from '../../src/reader/panels';
const raw = JSON.parse(readFileSync('public/panels/year-one.json','utf8'));
const map = parsePanelMap(raw,YEAR_ONE_HASH,99);
it('validates every reviewed page and rejects coordinates for a different edition', async () => {
  expect(map.pages).toHaveLength(99);
  expect(map.pages.reduce((n,p) => n+p.frames.length,0)).toBeGreaterThan(500);
  expect(() => parsePanelMap(raw,'b'.repeat(64),99)).toThrow();
  expect(() => parsePanelMap(raw,YEAR_ONE_HASH,98)).toThrow();
  expect(() => parsePanelMap({ ...raw,pages: [{ ...raw.pages[0],frames: [[.8,0,.5,1]] },...raw.pages.slice(1)] },YEAR_ONE_HASH,99)).toThrow();
  const fetch = vi.fn();vi.stubGlobal('fetch',fetch);
  expect(await loadPanelMap('a'.repeat(64),99)).toBeUndefined();
  expect(fetch).not.toHaveBeenCalled();vi.unstubAllGlobals();
});
it('wide-panel camera positions cover all lettering while preserving the real illuminated boundary', () => {
  const steps = panelSteps(map);
  for (let p=0;p<99;p++) {
    const page = steps.filter(s => s.page===p);
    expect(new Set(page.map(s => s.panel)).size).toBe(map.pages[p].frames.length);
    for (let i=0;i<map.pages[p].frames.length;i++) {
      const stops=page.filter(s => s.panel===i);
      const [x,,w]=map.pages[p].frames[i];
      expect(stops[0].focus[0]).toBeCloseTo(x);
      expect(stops.at(-1)!.focus[0]+stops.at(-1)!.focus[2]).toBeCloseTo(x+w);
      for (let k=1;k<stops.length;k++) expect(stops[k].focus[0]).toBeLessThanOrEqual(stops[k-1].focus[0]+stops[k-1].focus[2]);
      for (const s of stops) expect(s.bounds).toEqual(map.pages[p].frames[i]);
    }
  }
  expect(steps.filter(s => s.page===0)).toHaveLength(1); // covers do not become arbitrary fragments
  const reverse=panelSteps(map,true).filter(s => s.page===6 && s.panel===0);
  expect(reverse[0].focus[0]).toBeGreaterThan(reverse.at(-1)!.focus[0]);
});
it('restores the same panel when full-page options change, including first and last page', () => {
  const saved={ page: 6,mode: 'panels' as const,panel: 2,part: 0,zoom: 1.25,x: 0,y: 0 };
  for (const [first,last] of [[false,false],[true,false],[false,true],[true,true]]) {
    const steps=panelSteps(map,false,first,last);
    expect(steps[findPanelStep(steps,6,saved)]).toMatchObject({ page:6,panel:2,part:0 });
    expect(steps[0].page).toBe(0);expect(steps.at(-1)!.page).toBe(98);
  }
});
it('fits a focused panel inside small portrait and landscape viewports', () => {
  for (const [width,height] of [[320,480],[375,812],[812,375]]) for (const s of panelSteps(map)) {
    const ratio=map.pages[s.page].height/map.pages[s.page].width;
    const c=panelCamera(s.focus,ratio,width,height);
    const [x,y,w,h]=s.focus;
    expect(c.x+x*c.width*c.scale).toBeGreaterThanOrEqual(11.99);
    expect(c.y+y*c.height*c.scale).toBeGreaterThanOrEqual(11.99);
    expect(c.x+(x+w)*c.width*c.scale).toBeLessThanOrEqual(width-11.99);
    expect(c.y+(y+h)*c.height*c.scale).toBeLessThanOrEqual(height-11.99);
  }
});
