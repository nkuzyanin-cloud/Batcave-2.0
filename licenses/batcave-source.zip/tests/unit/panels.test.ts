import { readFileSync } from 'node:fs';
import { expect, it, vi } from 'vitest';
import { findPanelStep, panelCamera, panelSteps, parsePanelMap, loadPanelMap, YEAR_ONE_HASH } from '../../src/reader/panels';
const raw = JSON.parse(readFileSync('public/panels/year-one.json','utf8'));
const map = parsePanelMap(raw,YEAR_ONE_HASH,99);
it('validates every reviewed page and rejects coordinates for a different edition', async () => {
  expect(map.pages).toHaveLength(99);
  expect(map.pages.reduce((n,p) => n+p.frames.length,0)).toBeGreaterThan(500);
  expect(() => parsePanelMap(raw,'b'.repeat(64),99)).toThrow();
  expect(() => parsePanelMap(raw,YEAR_ONE_HASH,98)).toThrow();
  expect(() => parsePanelMap({ ...raw,pages: [{ ...raw.pages[0],frames: [[.8,0,.5,1]] },...raw.pages.slice(1)] },YEAR_ONE_HASH,99)).toThrow();
  const fetch = vi.fn();vi.stubGlobal('fetch',fetch);
  expect(await loadPanelMap('a'.repeat(64),99)).toBeUndefined();
  expect(fetch).not.toHaveBeenCalled();vi.unstubAllGlobals();
});
it('shows each reviewed frame once, complete in both reading directions', () => {
  const steps = panelSteps(map);
  for (let p=0;p<99;p++) {
    const page = steps.filter(s => s.page===p);
    expect(new Set(page.map(s => s.panel)).size).toBe(map.pages[p].frames.length);
    for (let i=0;i<map.pages[p].frames.length;i++) {
      const stops=page.filter(s => s.panel===i);
      expect(stops).toHaveLength(1);
      expect(stops[0].focus).toEqual(map.pages[p].frames[i]);
      const [x,,w]=map.pages[p].frames[i];
      expect(stops[0].focus[0]).toBeCloseTo(x);
      expect(stops.at(-1)!.focus[0]+stops.at(-1)!.focus[2]).toBeCloseTo(x+w);
      for (let k=1;k<stops.length;k++) expect(stops[k].focus[0]).toBeLessThanOrEqual(stops[k-1].focus[0]+stops[k-1].focus[2]);
      for (const s of stops) expect(s.bounds).toEqual(map.pages[p].frames[i]);
    }
  }
  expect(steps.filter(s => s.page===0)).toHaveLength(1); // covers do not become arbitrary fragments
  const reverse=panelSteps(map,true).filter(s => s.page===6 && s.panel===0);
  expect(reverse).toHaveLength(1);
  expect(reverse[0].focus).toEqual(map.pages[6].frames[0]);
});
it('restores the same panel when full-page options change, including first and last page', () => {
  const saved={ page: 6,mode: 'panels' as const,panel: 2,part: 0,zoom: 1.25,x: 0,y: 0 };
  for (const [first,last] of [[false,false],[true,false],[false,true],[true,true]]) {
    const steps=panelSteps(map,false,first,last);
    expect(steps[findPanelStep(steps,6,saved)]).toMatchObject({ page:6,panel:2,part:0 });
    expect(steps[0].page).toBe(0);expect(steps.at(-1)!.page).toBe(98);
  }
});
it('fits a focused panel inside small portrait and landscape viewports', () => {
  for (const [width,height] of [[320,480],[375,812],[812,375]]) for (const s of panelSteps(map)) {
    const ratio=map.pages[s.page].height/map.pages[s.page].width;
    const c=panelCamera(s.focus,ratio,width,height);
    const [x,y,w,h]=s.focus;
    expect(c.x+x*c.width*c.scale).toBeGreaterThanOrEqual(11.99);
    expect(c.y+y*c.height*c.scale).toBeGreaterThanOrEqual(11.99);
    expect(c.x+(x+w)*c.width*c.scale).toBeLessThanOrEqual(width-11.99);
    expect(c.y+(y+h)*c.height*c.scale).toBeLessThanOrEqual(height-11.99);
  }
});

it('keeps a fitting page on screen when focusing its first or last wide strip', () => {
  for (const [width,height] of [[320,568],[375,728],[375,812],[568,320]]) {
    for (const ratio of [.5,1.5,1.55,2]) for (const y of [.01,.26,.51,.76]) {
      const focus:[number,number,number,number]=[.02,y,.96,.23];
      const camera=panelCamera(focus,ratio,width,height);
      if (camera.height*camera.scale <= height-24) {
        expect(camera.y).toBeGreaterThanOrEqual(11.99);
        expect(camera.y+camera.height*camera.scale).toBeLessThanOrEqual(height-11.99);
      }
      if (camera.width*camera.scale <= width-24) {
        expect(camera.x).toBeGreaterThanOrEqual(11.99);
        expect(camera.x+camera.width*camera.scale).toBeLessThanOrEqual(width-11.99);
      }
      expect(camera.y+focus[1]*camera.height*camera.scale).toBeGreaterThanOrEqual(11.99);
      expect(camera.y+(focus[1]+focus[3])*camera.height*camera.scale).toBeLessThanOrEqual(height-11.99);
    }
  }
});
it('does not constrain an explicitly edited zoom or pan to the page',()=>{
  const focus:[number,number,number,number]=[.02,.01,.96,.23];
  for(const [zoom,pan] of [[1,{x:0,y:30}],[1.2,{x:10,y:0}]] as const){
    const c=panelCamera(focus,1.5,375,728,zoom,pan);
    expect(c.y).toBeCloseTo((728-focus[3]*c.height*c.scale)/2-focus[1]*c.height*c.scale+pan.y);
    expect(c.x).toBeCloseTo((375-focus[2]*c.width*c.scale)/2-focus[0]*c.width*c.scale+pan.x);
  }
});
