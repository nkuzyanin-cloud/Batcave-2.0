import 'fake-indexeddb/auto';
import {describe,it,expect,vi} from 'vitest';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {blankComic,defaultSettings,stats} from '../../src/models';
import {dbPromise,saveComic,paperSession,completePaperSession,resetProgress,updateProgress} from '../../src/storage/db';
import {parseBackup,restore} from '../../src/storage/backup';
describe('durable paper sessions',()=>{
 it('start/stop are idempotent and metadata edits preserve the running timestamp',async()=>{
  const c={...blankComic(),physical:'yes' as const,paperPageCount:72,seconds:12,paperSeconds:120};await saveComic(c);
  await paperSession(c.id,true,100000);await paperSession(c.id,true,110000);
  await saveComic({...c,title:'Edited'},[],[],true);
  let saved=(await(await dbPromise).get('comics',c.id))!;
  expect(saved.paperStartedAt).toBe(100000);expect(stats([saved],165000)).toMatchObject({pages:0,seconds:197,reading:1});
  await paperSession(c.id,false,165000);saved=await paperSession(c.id,false,170000);expect(saved.paperSeconds).toBe(185);expect(saved.paperStartedAt).toBeUndefined();
  await completePaperSession(c.id,true,72,180000);saved=(await(await dbPromise).get('comics',c.id))!;expect(stats([saved],190000)).toMatchObject({pages:72,seconds:197});
  await expect(paperSession(c.id,true,190000)).rejects.toThrow();
  await completePaperSession(c.id,false,72,200000);saved=(await(await dbPromise).get('comics',c.id))!;expect(stats([saved],210000)).toMatchObject({pages:0,seconds:197});
 });
 it('switches sessions atomically, completion settles time and retains digital progress',async()=>{
  const a={...blankComic(),physical:'yes' as const,paperPageCount:72};const b={...blankComic(),physical:'yes' as const,pageCount:2};await saveComic(a);await saveComic(b);
  await paperSession(a.id,true,300000);await paperSession(b.id,true,310000);let saved=(await(await dbPromise).get('comics',a.id))!;expect(saved.paperSeconds).toBe(10);expect(saved.paperStartedAt).toBeUndefined();
  await updateProgress(b.id,0,true,20);await updateProgress(b.id,1,true,30);saved=await completePaperSession(b.id,true,72,330000);expect(saved.paperSeconds).toBe(20);expect(saved.visited).toEqual([0,1]);expect(saved.seconds).toBe(50);expect(saved.readDigitally).toBe(true);
  saved=await completePaperSession(b.id,false,72,340000);expect(saved.completed).toBe(true);expect(stats([saved],340000)).toMatchObject({pages:2,seconds:70});
 });
 it('restores active backups paused at backup time, rejects malformed fields and clears timers on reset',async()=>{
  const c={...blankComic(),physical:'yes' as const,paperTimer:true,paperSeconds:10,paperStartedAt:100000};
  const raw={app:'BATCAVE',version:1,kind:'metadata',createdAt:160000,comics:[c],settings:defaultSettings,assets:[]};
  const data=parseBackup(raw);await restore({data,assets:new Map(),conflicts:0},'replace',false);let saved=(await(await dbPromise).get('comics',c.id))!;expect(saved.paperSeconds).toBe(70);expect(saved.paperStartedAt).toBeUndefined();
  for(const fields of [{paperStartedAt:-1},{paperStartedAt:1.5},{paperTimer:'yes'}])expect(()=>parseBackup({...raw,comics:[{...c,...fields}]})).toThrow();
  await paperSession(c.id,true,200000);await resetProgress();saved=(await(await dbPromise).get('comics',c.id))!;expect(saved.paperStartedAt).toBeUndefined();expect(saved.paperSeconds).toBe(0);
 });
});
