import { describe, it, expect } from 'vitest';
import { fragmentLayout, nearestFragment } from '../../src/reader/fragments';
describe('Readable fragment navigation', () => {
  it('covers every point of a portrait page with overlapping viewports', () => {
    const width = 375, height = 664, zoom = 1.85, ratio = 1.57;
    const { stops, maxX, maxY } = fragmentLayout(width, height, ratio, zoom);
    expect(stops[0]).toEqual({ x: maxX, y: maxY });
    expect(stops.at(-1)).toEqual({ x: -maxX, y: -maxY });
    const imageWidth = width * zoom, imageHeight = width * ratio * zoom;
    for (let x = 0; x <= imageWidth; x += 10)
      for (let y = 0; y <= imageHeight; y += 10)
        expect(stops.some((s) => Math.abs(x - imageWidth / 2 + s.x) <= width / 2 && Math.abs(y - imageHeight / 2 + s.y) <= height / 2)).toBe(true);
  });
  it('starts at the top right for RTL and handles landscape and very tall images', () => {
    for (const ratio of [0.5, 1.5, 3, 8]) {
      const ltr = fragmentLayout(375, 664, ratio, 2);
      const rtl = fragmentLayout(375, 664, ratio, 2, true);
      expect(rtl.stops.length).toBe(ltr.stops.length);
      expect(rtl.stops[0].x).toBe(-ltr.stops[0].x);
      expect(rtl.stops[0].y).toBe(ltr.stops[0].y);
      for (const stop of rtl.stops) expect(stop.x).toBeLessThanOrEqual(rtl.maxX);
    }
  });
  it('finds the nearest stop after free panning', () => {
    const { stops } = fragmentLayout(375, 664, 1.57, 1.85);
    stops.forEach((s, i) => expect(nearestFragment(stops, { x: s.x + 1, y: s.y - 1 })).toBe(i));
  });
});
