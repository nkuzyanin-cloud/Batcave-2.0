import 'fake-indexeddb/auto';
import { expect, it, vi } from 'vitest';
vi.mock('pdfjs-dist', () => ({ GlobalWorkerOptions: {}, PDFDataRangeTransport: class {}, getDocument: vi.fn() }));
import { blankComic, type PanelFrameEdit, type PanelRect } from '../../src/models';
import { frameEdit, editedPanelStep, moveBounds, resizeBounds, validFrameEdit } from '../../src/reader/panel-edits';
import { allComics, dbPromise, saveComic, savePanelEdit, saveReaderView, updateProgress, resetProgress } from '../../src/storage/db';
import { exportMetadata, parseBackup, restore } from '../../src/storage/backup';
const hash = 'a'.repeat(64);
const frame: PanelFrameEdit = { page: 1, panel: 3, bounds: [.08, .18, .84, .4], views: [{ part: 0, zoom: .85, x: .12, y: -.08 }] };

it('keeps frame edges inside the original page, with a nonzero size and fixed opposite edge', () => {
  const bounds: PanelRect = [.1, .2, .7, .6];
  expect(moveBounds(bounds, -100, -100)).toEqual([0, 0, .7, .6]);
  expect(moveBounds(bounds, 100, 100)).toEqual([1 - .7, 1 - .6, .7, .6]);
  const bigger = resizeBounds(bounds, 'nw', -.05, -.1);
  expect(bigger[0] + bigger[2]).toBeCloseTo(.8);expect(bigger[1] + bigger[3]).toBeCloseTo(.8);
  for (const edge of ['n', 's', 'e', 'w', 'nw', 'ne', 'sw', 'se']) for (const d of [-100, 100]) {
    const r = resizeBounds(bounds, edge, d, d);
    expect(validFrameEdit({ ...frame, bounds: r })).toBe(true);
  }
});

it('retains scroll identities and assigns the same physical focus to RTL and LTR halves', () => {
  const step = { page: 1, panel: 3, part: 0, parts: 2, bounds: [.04, .18, .92, .4] as PanelRect, focus: [.04, .18, .57, .4] as PanelRect };
  const left = editedPanelStep(step, frame, false);
  const rtlLeft = editedPanelStep({ ...step, part: 1 }, frame, true);
  expect(left.focus).toEqual(rtlLeft.focus);
  expect(left).toMatchObject({ page: 1, panel: 3, part: 0, parts: 2 });
  const full = { ...step, overview: 'before' as const };
  expect(editedPanelStep(full, frame, false)).toBe(full);
  const edits = { fingerprint: hash, frames: [frame] };
  expect(frameEdit(edits, hash, 1, 3)).toEqual(frame);
  expect(frameEdit(edits, 'b'.repeat(64), 1, 3)).toBeUndefined();
});

it('merges concurrent progress, preserves original files and metadata, and resets only the selected frame', async () => {
  const comic = { ...blankComic('Личная книга'), note: 'Моя заметка', photoId: 'photo', seconds: 52, page: 1, pageCount: 4,
    digital: { assetId: 'original', name: 'book.pdf', format: 'pdf' as const, size: 8, fingerprint: hash } };
  await saveComic(comic, [{ id: 'original', blob: new Blob(['original']) }, { id: 'photo', blob: new Blob(['photo']) }]);
  const next = { ...frame, panel: 4 };
  await Promise.all([savePanelEdit(comic.id, hash, 1, 3, frame), updateProgress(comic.id, 1, true, 7),
    saveReaderView(comic.id, { page: 1, mode: 'panels', panel: 3, part: 0, zoom: 1, x: 0, y: 0 })]);
  await savePanelEdit(comic.id, hash, 1, 4, next);
  let latest = (await allComics()).find(c => c.id === comic.id)!;
  expect(latest).toMatchObject({ note: comic.note, photoId: 'photo', seconds: 59, page: 1, visited: [1] });
  expect(latest.readerView?.panel).toBe(3);expect(latest.panelEdits?.frames).toEqual([frame, next]);
  expect(await (await (await dbPromise).get('assets', 'original'))!.blob.text()).toBe('original');
  const before = structuredClone(latest);
  await expect(savePanelEdit(comic.id, 'b'.repeat(64), 1, 3, frame)).rejects.toThrow('изменился');
  await expect((await dbPromise).get('comics', comic.id)).resolves.toEqual(before);
  await expect(savePanelEdit(comic.id, hash, 1, 3, { ...frame, bounds: [-.1, 0, 1, 1] })).rejects.toThrow('Некорректная');
  await savePanelEdit(comic.id, hash, 1, 3, null);
  latest = (await allComics()).find(c => c.id === comic.id)!;
  expect(latest.panelEdits?.frames).toEqual([next]);
  await resetProgress();
  expect((await (await dbPromise).get('comics', comic.id))!.panelEdits?.frames).toEqual([next]);
});

it('exports and restores frame corrections, rejects damaged edits, and accepts older backups', async () => {
  const comic = { ...blankComic('Правки в копии'), pageCount: 4, panelEdits: { fingerprint: hash, frames: [frame] } };
  await saveComic(comic);
  const raw = JSON.parse(await (await exportMetadata()).text());
  const parsed = parseBackup(raw);
  expect(parsed.comics.find(c => c.id === comic.id)?.panelEdits).toEqual(comic.panelEdits);
  const check = (panelEdits: unknown) => () => parseBackup({ ...raw, comics: [{ ...comic, panelEdits }] });
  expect(check({ fingerprint: hash, frames: [{ ...frame, bounds: [.2, .2, 1, 1] }] })).toThrow();
  expect(check({ fingerprint: hash, frames: [frame, frame] })).toThrow();
  expect(check({ fingerprint: hash, frames: [{ ...frame, views: [frame.views[0], frame.views[0]] }] })).toThrow();
  expect(check({ fingerprint: hash, frames: [{ ...frame, page: 4 }] })).toThrow();
  expect(check({ fingerprint: hash, frames: [{ ...frame, views: [{ ...frame.views[0], zoom: Infinity }] }] })).toThrow();
  const old = { ...comic };delete old.panelEdits;
  expect(parseBackup({ ...raw, comics: [old] }).comics[0].panelEdits).toBeUndefined();
  const incoming = { ...comic, panelEdits: { fingerprint: hash, frames: [{ ...frame, panel: 2 }] } };
  const data = parseBackup({ ...raw, comics: [incoming] });
  await restore({ data, assets: new Map(), conflicts: 1 }, 'keep', false);
  expect((await (await dbPromise).get('comics', comic.id))?.panelEdits).toEqual(comic.panelEdits);
  await restore({ data, assets: new Map(), conflicts: 1 }, 'replace', false);
  expect((await (await dbPromise).get('comics', comic.id))?.panelEdits).toEqual(incoming.panelEdits);
});
