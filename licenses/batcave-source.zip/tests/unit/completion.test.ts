import 'fake-indexeddb/auto';
import {beforeEach,it,expect,vi,afterEach} from 'vitest';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {blankComic,defaultSettings} from '../../src/models';
import {completedHistory,completionDate} from '../../src/completion';
import {dbPromise,saveComic,initialize,updateProgress,completePaperSession,resetProgress} from '../../src/storage/db';
import {parseBackup,restore} from '../../src/storage/backup';
beforeEach(async()=>{const db=await dbPromise;await db.clear('comics');await db.clear('config');});
afterEach(()=>vi.restoreAllMocks());
it('sorts by actual completion events, never by subsequent reading or metadata edits',()=>{
 const a={...blankComic('First'),completed:true,completedAt:100,lastOpened:9999,updatedAt:9999},b={...blankComic('Second'),completed:true,completedAt:200,lastOpened:0,updatedAt:200};
 expect(completedHistory([a,b]).map(c=>c.title)).toEqual(['Second','First']);
 delete a.completedAt;delete b.completedAt;a.updatedAt=100;expect(completedHistory([a,b]).map(c=>c.title)).toEqual(['Second','First']);
});
it('stamps digital completion once; reopening, reader checkpoints and card edits preserve its place',async()=>{
 vi.spyOn(Date,'now').mockReturnValue(1000);const c={...blankComic(),pageCount:2};await saveComic(c);
 await updateProgress(c.id,0,true,5);expect((await(await dbPromise).get('comics',c.id))!.completedAt).toBeUndefined();
 vi.mocked(Date.now).mockReturnValue(2000);await updateProgress(c.id,1,true,5);
 let saved=(await(await dbPromise).get('comics',c.id))!;expect(saved.completedAt).toBe(2000);
 vi.mocked(Date.now).mockReturnValue(9000);await updateProgress(c.id,0,true,10);await saveComic({...saved,note:'Edited'},[],[],true);
 saved=(await(await dbPromise).get('comics',c.id))!;expect(saved.completedAt).toBe(2000);
 await saveComic({...saved,completed:false});expect((await(await dbPromise).get('comics',c.id))!.completedAt).toBeUndefined();
 vi.mocked(Date.now).mockReturnValue(10000);await saveComic({...saved,completed:true});expect((await(await dbPromise).get('comics',c.id))!.completedAt).toBe(10000);
});
it('paper completion records its own time, and reset removes completion dates',async()=>{
 const c={...blankComic(),physical:'yes' as const,paperPageCount:72};await saveComic(c);
 let saved=await completePaperSession(c.id,true,72,1000);expect(saved.completedAt).toBe(1000);
 saved=await completePaperSession(c.id,true,72,2000);expect(saved.completedAt).toBe(1000);
 await resetProgress();expect((await(await dbPromise).get('comics',c.id))!.completedAt).toBeUndefined();
});
it('migrates old completed records once without changing reading data or metadata',async()=>{
 const db=await dbPromise,c={...blankComic(),completed:true,updatedAt:123,lastOpened:999,seconds:88,note:'Keep',rating:4};await db.put('comics',c);
 await initialize();expect(await db.get('comics',c.id)).toEqual({...c,completedAt:123});
 await db.put('comics',{...c,completedAt:123,updatedAt:9999});await initialize();expect((await db.get('comics',c.id))!.completedAt).toBe(123);
});
it('completion dates survive JSON backup and recovery; old backups remain compatible',async()=>{
 const c={...blankComic(),completed:true,completedAt:123,updatedAt:789};
 const raw={app:'BATCAVE',version:1,kind:'metadata',createdAt:1,comics:[c],settings:defaultSettings,assets:[]};
 const data=parseBackup(JSON.parse(JSON.stringify(raw)));await restore({data,assets:new Map(),conflicts:0},'replace',false);expect((await(await dbPromise).get('comics',c.id))!.completedAt).toBe(123);
 const old={...c};delete old.completedAt;await restore({data:parseBackup({...raw,comics:[old]}),assets:new Map(),conflicts:0},'replace',false);expect(completionDate((await(await dbPromise).get('comics',c.id))!)).toBe(789);
 expect(()=>parseBackup({...raw,comics:[{...c,completedAt:-1}]})).toThrow();
});
