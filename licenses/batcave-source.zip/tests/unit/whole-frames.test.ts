import { expect, it } from 'vitest';
import type { PanelEdits, ReaderView } from '../../src/models';
import { findPanelStep, panelSteps, type PanelMap, type Rect } from '../../src/reader/panels';
import { editedPanelStep, replaceFrameEdit } from '../../src/reader/panel-edits';

const hash = 'a'.repeat(64);
const tall: Rect = [.65, .02, .3, .94];
const wide: Rect = [.02, .05, .96, .15];
const frames: Rect[] = [tall, wide, [.1, .35, .4, .35]];
const map: PanelMap = { version: 1, sha256: hash, pageCount: 1, detector: 'inkwell-v1',
  pages: [{ width: 948, height: 1514, kind: 'story', frames }] };

it('never adds close-view stops for tall or wide frames, on rotation or with old reviewed maps', () => {
  for (const detector of ['inkwell-v1', undefined] as const) {
    for (const rtl of [true, false]) for (const [w, h] of [[375, 812], [812, 375], [320, 480]]) {
      const steps = panelSteps({ ...map, detector }, rtl, false, false, w, h);
      expect(steps).toHaveLength(frames.length);
      expect(steps.map(s => s.focus)).toEqual(frames);
      expect(steps.every(s => s.parts === 1 && s.part === 0 && s.viewPart === 0)).toBe(true);
    }
  }
});

it('resumes an old half/third bookmark on the same real frame with page overviews enabled', () => {
  for (const [first, last] of [[false, false], [true, false], [false, true], [true, true]]) {
    const steps = panelSteps(map, false, first, last);
    for (const panel of [0, 1, 2]) for (const part of [1, 2, 4]) {
      const old: ReaderView = { page: 0, mode: 'panels', panel, part, viewPart: part, zoom: 1.7, x: .1, y: .2 };
      expect(steps[findPanelStep(steps, 0, old)]).toMatchObject({ page: 0, panel, part: 0, parts: 1, focus: frames[panel] });
      delete old.viewPart;
      expect(steps[findPanelStep(steps, 0, old)]?.panel).toBe(panel);
    }
  }
});

it('preserves edited full-frame boundaries and delete/undo without resurrecting subviews', () => {
  const bounds: Rect = [.63, .01, .35, .97];
  const edit = { page: 0, panel: 0, bounds, views: [{ part: 2, zoom: 2, x: 0, y: .2 }] };
  const edits: PanelEdits = { fingerprint: hash, frames: [edit] };
  const original = structuredClone(map);
  const steps = panelSteps(map, false, false, false, 375, 812, { edits });
  expect(steps).toHaveLength(3);
  expect(editedPanelStep(steps[0], edit, false).focus).toEqual(bounds);
  const hidden = replaceFrameEdit(edits, hash, 0, 0, { ...edit, hidden: true });
  const deleted = panelSteps(map, false, false, false, 375, 812, { edits: hidden });
  expect(deleted.map(s => s.panel)).toEqual([1, 2]);
  const old: ReaderView = { page: 0, mode: 'panels', panel: 0, part: 3, zoom: 1, x: 0, y: 0 };
  expect(deleted[findPanelStep(deleted, 0, old)].panel).toBe(1);
  const restored = replaceFrameEdit(hidden, hash, 0, 0, edit);
  expect(panelSteps(map, false, false, false, 375, 812, { edits: restored })).toEqual(steps);
  expect(restored?.frames[0].views).toEqual(edit.views);
  expect(map).toEqual(original);
});

it('retains blank/duplicate filtering and a whole-page fallback when all frames are hidden', () => {
  const quality = new Map([[0, { crop: [.02, .02, .96, .96] as Rect, blank: [0], duplicate: [1], emptyViews: { 2: [1, 2] } }]]);
  expect(panelSteps(map, false, false, false, 375, 812, { quality }).map(s => s.panel)).toEqual([2]);
  const edits: PanelEdits = { fingerprint: hash, frames: frames.map((bounds, panel) => ({ page: 0, panel, bounds, views: [], hidden: true })) };
  const steps = panelSteps(map, false, true, true, 375, 812, { edits, quality, crop: true });
  expect(steps).toHaveLength(1);
  expect(steps[0]).toMatchObject({ overview: 'before', focus: quality.get(0)!.crop });
});
