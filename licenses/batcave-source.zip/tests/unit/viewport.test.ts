import { describe, expect, it } from 'vitest';
import { focusedScrollDelta, keyboardViewport } from '../../src/viewport';

describe('full-page viewport and keyboard', () => {
  it('does not reserve space for a browser bar in an installed app', () => {
    expect(keyboardViewport(750, 844, false, 1)).toBeUndefined();
    expect(keyboardViewport(500, 844, false, 1)).toBeUndefined();
  });
  it('does not shrink the page merely because a field is focused', () => {
    expect(keyboardViewport(750, 844, true, 1)).toBeUndefined();
  });
  it('uses the visible height while the keyboard covers an editing field', () => {
    expect(keyboardViewport(500, 844, true, 1)).toBe(500);
    expect(keyboardViewport(500, 844, false, 1)).toBeUndefined();
  });
  it('does not mistake pinch zoom or an invalid measurement for a keyboard', () => {
    expect(keyboardViewport(422, 844, true, 2)).toBeUndefined();
    expect(keyboardViewport(0, 844, true, 1)).toBeUndefined();
  });
  it('moves only the inner form scroll enough to reveal a focused field', () => {
    expect(focusedScrollDelta(120,162,100,400)).toBe(0);
    expect(focusedScrollDelta(80,122,100,400)).toBe(-20);
    expect(focusedScrollDelta(380,422,100,400)).toBe(22);
  });
  it('keeps the keyboard height through a temporary blur while switching fields', () => {
    const active=keyboardViewport(420,812,true,1)!==undefined;
    expect(keyboardViewport(420,812,active,1)).toBe(420);
    expect(keyboardViewport(762,812,active,1)).toBeUndefined();
  });
});
