import { describe, expect, it } from 'vitest';
import { keyboardViewport } from '../../src/viewport';

describe('full-page viewport and keyboard', () => {
  it('does not reserve space for a browser bar in an installed app', () => {
    expect(keyboardViewport(750, 844, false, 1)).toBeUndefined();
    expect(keyboardViewport(500, 844, false, 1)).toBeUndefined();
  });
  it('does not shrink the page merely because a field is focused', () => {
    expect(keyboardViewport(750, 844, true, 1)).toBeUndefined();
  });
  it('uses the visible height while the keyboard covers an editing field', () => {
    expect(keyboardViewport(500, 844, true, 1)).toBe(500);
    expect(keyboardViewport(500, 844, false, 1)).toBeUndefined();
  });
  it('does not mistake pinch zoom or an invalid measurement for a keyboard', () => {
    expect(keyboardViewport(422, 844, true, 2)).toBeUndefined();
    expect(keyboardViewport(0, 844, true, 1)).toBeUndefined();
  });
});
