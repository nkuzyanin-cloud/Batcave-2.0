import 'fake-indexeddb/auto';
import {beforeEach,describe,it,expect,vi} from 'vitest';
vi.mock('pdfjs-dist',() => ({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {achievementCatalog,achievements,advanceAchievements,mergeAchievementStates,normalizeAchievementState,ACHIEVEMENT_KEY} from '../../src/achievements';
import {blankComic} from '../../src/models';
import {dbPromise,initialize,saveComic,deleteComic,deleteDigital,updateProgress,getAchievementState,takeAchievementNotice} from '../../src/storage/db';
import {exportMetadata,parseBackup,restore} from '../../src/storage/backup';
beforeEach(async() => {const db=await dbPromise;await db.clear('comics');await db.clear('config');await db.clear('assets');});
const medal=(comics:ReturnType<typeof blankComic>[],id:string) => achievements(comics).find(a=>a.id===id)!;
describe('a long-term collectible catalogue',() => {
  it('has universal milestones without series-specific art',() => {
    expect(achievementCatalog).toHaveLength(46);
    expect(new Set(achievementCatalog.map(a=>a.id)).size).toBe(46);
    expect(new Set(achievementCatalog.map(a=>a.name)).size).toBe(46);
    expect(new Set(achievementCatalog.map(a=>a.art)).size).toBe(46);
    expect(achievementCatalog.find(a=>a.id==='stories-500')?.goal).toBe(500);
    expect(achievementCatalog.find(a=>a.id==='pages-100000')?.goal).toBe(100000);
    expect(achievements([]).every(a=>!a.earned)).toBe(true);
  });
  it('counts confirmed reading time across different series and requires completion for stories',()=>{
    const c={...blankComic(),universeId:'one',seconds:1700,rating:1};
    const d={...blankComic(),universeId:'two',seconds:1900};
    expect(medal([c,d],'time-3600').earned).toBe(true);
    expect(medal([c,d],'first').earned).toBe(false);
    expect(medal([{...c,completed:true},d],'first').earned).toBe(true);
    expect(medal([c],'ratings-1').earned).toBe(true);
    expect(achievements([c,d]).some(a=>a.kind==='eras'||a.kind==='special')).toBe(false);
  });
  it('counts shared paper volumes once',()=>{
    const paper={...blankComic(),physical:'yes' as const,physicalGroup:'one-volume',completed:true,paperCompleted:true};
    expect(medal([paper,{...paper,id:'another'}],'paper-5').value).toBe(1);
  });
});
describe('durable unlocks and notification delivery',() => {
  it('migrates existing achievements once, as a single historical notification',async() => {
    const db=await dbPromise;
    for(let i=0;i<5;i++)await db.put('comics',{...blankComic(),completed:true});
    await initialize();const first=await getAchievementState();
    expect(first?.earned.map(a=>a.id)).toEqual(['first','stories-3','stories-5']);
    expect(first?.pending).toHaveLength(1);expect(first?.pending[0]).toHaveLength(3);
    await initialize();expect(await getAchievementState()).toEqual(first);
    const notices=await Promise.all([takeAchievementNotice(),takeAchievementNotice()]);
    expect(notices.filter(r=>r.notice).length).toBe(1);
    await initialize();expect((await getAchievementState())?.pending).toEqual([]);
  });
  it('keeps earned awards and original dates through deletion and reattachment',async() => {
    await initialize();
    const c={...blankComic(),completed:true,digital:{assetId:'file',format:'image' as const,name:'a.png',size:1,fingerprint:'a'.repeat(64)}};
    await saveComic(c,[{id:'file',blob:new Blob(['a'])}]);
    const first=(await getAchievementState())!;
    expect(first.earned.some(a=>a.id==='library-1')).toBe(true);
    await deleteDigital(c);await deleteComic(c);
    const after=(await getAchievementState())!;
    expect(after.earned).toEqual(first.earned);
    expect(achievements([],after).find(a=>a.id==='first')?.earned).toBe(true);
    await saveComic(c);expect((await getAchievementState())?.earned).toEqual(first.earned);
  });
  it('unlocks from reader checkpoints atomically and never repeats on timer-only writes',async() => {
    await initialize();const c={...blankComic(),pageCount:2};await saveComic(c);
    await updateProgress(c.id,0,true,1);expect((await getAchievementState())?.earned).toEqual([]);
    await updateProgress(c.id,1,true,1);const state=await getAchievementState();
    expect(state?.earned.map(a=>a.id)).toEqual(['first']);
    await takeAchievementNotice();await updateProgress(c.id,1,true,30);
    expect((await getAchievementState())?.pending).toEqual([]);
  });
  it('retains earned-only achievements in JSON backup after deleting every comic',async() => {
    await initialize();const c={...blankComic(),completed:true};await saveComic(c);await deleteComic(c);
    const data=parseBackup(JSON.parse(await(await exportMetadata()).text()));
    expect(data.comics).toEqual([]);expect(data.achievements?.earned.some(a=>a.id==='first')).toBe(true);
    await(await dbPromise).clear('config');
    await restore({data,assets:new Map(),conflicts:0},'keep',false);
    expect((await getAchievementState())?.earned.some(a=>a.id==='first')).toBe(true);
    expect((await getAchievementState())?.pending).toEqual([]);
  });
  it('accepts old backups, sanitizes bad optional state and merges without losing earned medals',() => {
    const a=advanceAchievements([{...blankComic(),completed:true}],undefined,100);
    const b=advanceAchievements([{...blankComic(),physical:'yes'}],undefined,200);
    const merged=mergeAchievementStates(a,b)!;
    expect(merged.earned.map(e=>e.id)).toContain('first');expect(merged.earned.map(e=>e.id)).toContain('paper-1');
    expect(merged.pending).toEqual(a.pending);
    expect(normalizeAchievementState({version:2,initializedAt:0,earned:[{id:'bad',at:1},null],pending:[['bad'],null]} as unknown)).toEqual({version:2,initializedAt:0,earned:[],pending:[]});
    expect(ACHIEVEMENT_KEY).toBe('achievements-v2');
  });
});
