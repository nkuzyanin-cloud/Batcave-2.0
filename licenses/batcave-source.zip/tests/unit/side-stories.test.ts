import 'fake-indexeddb/auto';
import {beforeEach,it,expect,vi} from 'vitest';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {blankComic,defaultSettings,stats} from '../../src/models';
import {inRoadmap,orderedRoadmap,sideStories,sideStoryCandidates} from '../../src/roadmap';
import {inCollection} from '../../src/collection';
import {dbPromise,saveComic,setSideStory,deleteComic,allComics,getAsset} from '../../src/storage/db';
import {parseBackup,restore} from '../../src/storage/backup';
beforeEach(async()=>{const db=await dbPromise;await db.clear('comics');await db.clear('assets');});
it('keeps optional digital and paper stories in collection and statistics without changing main numbering',()=>{
  const a={...blankComic('A'),id:'a',addedAt:1},b={...blankComic('B'),id:'b',addedAt:3};
  const side={...blankComic('Side'),id:'side',addedAt:2,sideStoryAfter:a.id,completed:true,pageCount:2,visited:[0,1],seconds:77};
  expect(orderedRoadmap([side,b,a]).map(c=>c.id)).toEqual(['a','b']);expect(inCollection(side)).toBe(true);
  expect(inRoadmap({...side,inRoadmap:true,digital:{assetId:'f',format:'pdf',name:'f',size:1,fingerprint:'a'.repeat(64)}})).toBe(false);
  expect(sideStories([a,side,b],a.id)).toEqual([side]);expect(stats([a,side,b])).toMatchObject({done:1,pages:2,seconds:77});
  expect(sideStoryCandidates([a,side,b],a.id,b.id)).toEqual([]);
});
it('moves the latest record without duplicating files or overwriting progress, and returns it to the main path',async()=>{
  const a={...blankComic('A'),id:'a'},side={...blankComic('Side'),id:'side',seconds:75,visited:[0],pageCount:2,coverId:'cover',note:'Keep',rating:5};
  await saveComic(a);await saveComic(side,[{id:'cover',blob:new Blob(['image'])}]);
  await setSideStory(side.id,a.id,true);let saved=(await(await dbPromise).get('comics',side.id))!;
  expect(saved).toMatchObject({sideStoryAfter:a.id,seconds:75,visited:[0],coverId:'cover',note:'Keep',rating:5});
  expect(await allComics()).toHaveLength(2);expect(await(await getAsset('cover'))!.blob.text()).toBe('image');
  await setSideStory(side.id,a.id,false);saved=(await(await dbPromise).get('comics',side.id))!;expect(saved.sideStoryAfter).toBeUndefined();expect(inRoadmap(saved)).toBe(true);
});
it('rejects missing, self and nested anchors, and moving a main anchor with children',async()=>{
  const a={...blankComic(),id:'a'},b={...blankComic(),id:'b'},c={...blankComic(),id:'c'};
  await saveComic(a);await saveComic(b);await saveComic(c);await setSideStory(b.id,a.id,true);
  await expect(setSideStory(c.id,b.id,true)).rejects.toThrow();await expect(setSideStory(a.id,c.id,true)).rejects.toThrow();
  await expect(setSideStory(c.id,'missing',true)).rejects.toThrow();await expect(setSideStory(c.id,c.id,true)).rejects.toThrow();
  await expect(saveComic({...c,sideStoryAfter:'missing'})).rejects.toThrow();
  expect(sideStoryCandidates(await allComics(),c.id)).toEqual([]);
});
it('deleting an anchor preserves and exposes child comics, assets and reading time',async()=>{
  const a={...blankComic(),id:'a'},side={...blankComic(),id:'side',sideStoryAfter:a.id,seconds:80,coverId:'cover'};
  await saveComic(a);await saveComic(side,[{id:'cover',blob:new Blob(['cover'])}]);await deleteComic(a);
  const saved=(await(await dbPromise).get('comics',side.id))!;expect(saved).toMatchObject({seconds:80,inRoadmap:true});expect(saved.sideStoryAfter).toBeUndefined();expect(await getAsset('cover')).toBeDefined();
});
it('JSON round trip preserves links and remaps anchors when fingerprint recovery retains a different local ID',async()=>{
  const a={...blankComic('A'),id:'local-a',digital:{assetId:'file',format:'image' as const,name:'page.png',size:1,fingerprint:'a'.repeat(64)}};
  await saveComic(a,[{id:'file',blob:new Blob(['x'])}]);
  const incoming={...a,id:'backup-a'},side={...blankComic('Side'),id:'side',sideStoryAfter:incoming.id,seconds:100};
  const raw={app:'BATCAVE',version:1,kind:'metadata',createdAt:1,comics:[incoming,side],settings:defaultSettings,assets:[]};
  const data=parseBackup(JSON.parse(JSON.stringify(raw)));expect(data.comics[1].sideStoryAfter).toBe(incoming.id);
  await restore({data,assets:new Map(),conflicts:1},'keep',false);expect((await(await dbPromise).get('comics',side.id))!.sideStoryAfter).toBe(a.id);
  expect(()=>parseBackup({...raw,comics:[{...side,sideStoryAfter:3}]})).toThrow();
});
it('old backups stay valid and orphaned restored optional stories remain accessible',async()=>{
  const c={...blankComic('Orphan'),sideStoryAfter:'missing',seconds:42};
  const raw={app:'BATCAVE',version:1,kind:'metadata',createdAt:1,comics:[c],settings:defaultSettings,assets:[]};
  await restore({data:parseBackup(raw),assets:new Map(),conflicts:0},'replace',false);
  const saved=(await(await dbPromise).get('comics',c.id))!;expect(saved.sideStoryAfter).toBeUndefined();expect(inRoadmap(saved)).toBe(true);expect(saved.seconds).toBe(42);
  const old={...c};delete old.sideStoryAfter;expect(parseBackup({...raw,comics:[old]}).comics[0].sideStoryAfter).toBeUndefined();
});
