import { expect, it } from 'vitest';
import { horizontalInspection, panelCamera, type Rect } from '../../src/reader/panels';

function edges(bounds: Rect, camera: ReturnType<typeof panelCamera>) {
  const [x,y,w,h] = bounds;
  return { left: camera.x + x*camera.width*camera.scale,
    right: camera.x + (x+w)*camera.width*camera.scale,
    top: camera.y + y*camera.height*camera.scale,
    bottom: camera.y + (y+h)*camera.height*camera.scale };
}

it('enlarges a panorama and keeps lettering at both vertical edges visible', () => {
  const bounds: Rect = [.03,.18,.94,.28];
  const base = panelCamera(bounds, 1.4, 375, 812);
  const zoomed = horizontalInspection(bounds, base, 1.7);
  expect(zoomed.camera.scale).toBeCloseTo(base.scale*1.7);
  expect(zoomed.limit).toBeGreaterThan(0);
  for (const x of [-10000,0,10000]) {
    const view = horizontalInspection(bounds,base,2.5,x);
    const e = edges(bounds,view.camera);
    expect(e.top).toBeGreaterThanOrEqual(11.99);
    expect(e.bottom).toBeLessThanOrEqual(800.01);
    expect(view.pan.y).toBe(0);
  }
});

it('fits the whole height even at a cropped automatic stop or edited zoom', () => {
  const bounds: Rect = [.1,.04,.8,.91];
  const focus: Rect = [.1,.4,.8,.25];
  for (const [width,height] of [[320,568],[375,812],[812,375]]) {
    const base = panelCamera(focus,1.5,width,height,4,{x:200,y:-400});
    const view = horizontalInspection(bounds,base,2.5,800);
    const e = edges(bounds,view.camera);
    expect(e.top).toBeCloseTo(12);
    expect(e.bottom).toBeCloseTo(height-12);
    expect(view.pan.y).toBe(0);
  }
});

it('clamps horizontal dragging to actual frame edges with no blank overscroll', () => {
  const bounds: Rect = [.02,.2,.96,.15];
  const base = panelCamera(bounds,1.5,375,812);
  const left = horizontalInspection(bounds,base,1.7,10000);
  const right = horizontalInspection(bounds,base,1.7,-10000);
  expect(edges(bounds,left.camera).left).toBeCloseTo(12);
  expect(edges(bounds,right.camera).right).toBeCloseTo(363);
  expect(left.camera.y).toBe(right.camera.y);
  expect(left.pan.x).toBe(-right.pan.x);
});

it('centres height-limited narrow frames and disables meaningless panning', () => {
  const bounds: Rect = [.35,.01,.3,.97];
  const view = horizontalInspection(bounds,panelCamera(bounds,1.5,375,812),2.5,300);
  expect(view.limit).toBe(0);
  expect(view.pan).toEqual({x:0,y:0});
  const e = edges(bounds,view.camera);
  expect(e.left).toBeGreaterThan(12);
  expect(e.right).toBeLessThan(363);
});

it('keeps every part of extremely wide frames reachable with backup-compatible pan', () => {
  const bounds: Rect = [0,.4,1,.015];
  const base = panelCamera([.6,.4,.1,.015],1.5,375,812,4);
  for (const x of [-1e6,1e6]) {
    const view = horizontalInspection(bounds,base,2.5,x);
    const e = edges(bounds,view.camera);
    expect(Math.abs(view.pan.x)/375).toBeLessThanOrEqual(.9);
    expect(x > 0 ? e.left : e.right).toBeCloseTo(x > 0 ? 12 : 363);
    expect(e.top).toBeGreaterThan(12);
    expect(e.bottom).toBeLessThan(800);
  }
});
