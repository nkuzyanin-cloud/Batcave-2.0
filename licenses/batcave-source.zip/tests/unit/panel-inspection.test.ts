import { expect, it } from 'vitest';
import { anchoredPanelInspection, panelInspection, panelCamera, type Rect } from '../../src/reader/panels';

function edges(bounds: Rect, camera: ReturnType<typeof panelCamera>) {
  const [x,y,w,h] = bounds;
  return { left: camera.x + x*camera.width*camera.scale,
    right: camera.x + (x+w)*camera.width*camera.scale,
    top: camera.y + y*camera.height*camera.scale,
    bottom: camera.y + (y+h)*camera.height*camera.scale };
}

it('actually enlarges tall frames in portrait and landscape, with vertical dragging', () => {
  const bounds: Rect = [.35,.01,.3,.97];
  for (const [width,height] of [[375,812],[812,375]]) {
    const base = panelCamera(bounds,1.5,width,height);
    const view = panelInspection(bounds,base,1.7);
    expect(view.camera.scale).toBeCloseTo(base.scale*1.7);
    expect(view.limits.y).toBeGreaterThan(0);
    const top = panelInspection(bounds,base,1.7,{x:1e6,y:1e6});
    const bottom = panelInspection(bounds,base,1.7,{x:-1e6,y:-1e6});
    expect(edges(bounds,top.camera).top).toBeCloseTo(12);
    expect(edges(bounds,bottom.camera).bottom).toBeCloseTo(height-12);
    expect(Math.abs(top.pan.y)/height).toBeLessThanOrEqual(.9);
    expect(Math.abs(bottom.pan.y)/height).toBeLessThanOrEqual(.9);
  }
});

it('still enlarges panoramas and keeps both horizontal ends reachable', () => {
  const bounds: Rect = [.03,.18,.94,.28];
  const base = panelCamera(bounds, 1.4, 375, 812);
  const view = panelInspection(bounds,base,1.7);
  expect(view.camera.scale).toBeCloseTo(base.scale*1.7);
  expect(view.limits.x).toBeGreaterThan(0);
  const left = panelInspection(bounds,base,2.5,{x:1e6,y:1e6});
  const right = panelInspection(bounds,base,2.5,{x:-1e6,y:-1e6});
  expect(edges(bounds,left.camera).left).toBeCloseTo(12);
  expect(edges(bounds,right.camera).right).toBeCloseTo(363);
  expect(left.pan.x).toBe(-right.pan.x);
});

it('has no blank overscroll on either axis at an authored close view', () => {
  const bounds: Rect = [.1,.04,.8,.91];
  for (const [width,height] of [[320,568],[375,812],[812,375]]) {
    const base = panelCamera([.1,.4,.8,.25],1.5,width,height,4,{x:200,y:-400});
    for (const sign of [-1,1]) {
      const view = panelInspection(bounds,base,2.5,{x:sign*1e6,y:sign*1e6});
      const e = edges(bounds,view.camera);
      if(view.limits.x)expect(sign>0?e.left:e.right).toBeCloseTo(sign>0?12:width-12);
      else {expect(e.left).toBeGreaterThanOrEqual(11.99);expect(e.right).toBeLessThanOrEqual(width-11.99);}
      if(view.limits.y)expect(sign>0?e.top:e.bottom).toBeCloseTo(sign>0?12:height-12);
      else {expect(e.top).toBeGreaterThanOrEqual(11.99);expect(e.bottom).toBeLessThanOrEqual(height-11.99);}
      expect(Math.abs(view.pan.x)/width).toBeLessThanOrEqual(.9);
      expect(Math.abs(view.pan.y)/height).toBeLessThanOrEqual(.9);
    }
  }
});

it('keeps the paper point under a double tap instead of recentering the frame', () => {
  const bounds: Rect = [.1,.1,.8,.8];
  const base = panelCamera(bounds,1.5,375,812);
  const point = {x:180,y:400};
  const view = anchoredPanelInspection(bounds,base,base,1.7,point);
  expect(view.camera.scale).toBeCloseTo(base.scale*1.7);
  expect((point.x-view.camera.x)/view.camera.scale).toBeCloseTo((point.x-base.x)/base.scale);
  expect((point.y-view.camera.y)/view.camera.scale).toBeCloseTo((point.y-base.y)/base.scale);
});

it('clamps an edge tap to the actual frame instead of revealing empty space', () => {
  const bounds: Rect = [.35,.01,.3,.97];
  const base = panelCamera(bounds,1.5,375,812);
  const view = anchoredPanelInspection(bounds,base,base,1.7,{x:-10000,y:-10000});
  expect(view.pan.x).toBeCloseTo(-view.limits.x);
  expect(view.pan.y).toBeCloseTo(view.limits.y);
});
