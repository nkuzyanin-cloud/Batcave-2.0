import{describe,it,expect}from'vitest';
import{parsePrepared,preparedPanelMap,type PreparedComic}from'../../src/reader/prepared';
const fixture=():PreparedComic=>({app:'BATCAVE Studio',version:1,pages:[{name:'00001.png',sha256:'a'.repeat(64),width:1000,height:1500,crop:[.1,.1,.8,.8],frames:[[.2,.2,.3,.3]],kind:'story'}]});
describe('prepared CBZ metadata',()=>{
 it('normalizes original-page frames into the authored crop',()=>{const m=parsePrepared(fixture(),['00001.png']),map=preparedPanelMap(m,'b'.repeat(64));expect(map.sha256).toBe('b'.repeat(64));expect(map.pages[0].frames[0]).toEqual([.125,.125,.37499999999999994,.37499999999999994]);expect(map.pages[0].width).toBe(800);});
 it('keeps a full-page reading stop when no frames were authored',()=>{const f=fixture();f.pages[0].frames=[];expect(preparedPanelMap(parsePrepared(f,['00001.png']),'a').pages[0].frames).toEqual([[0,0,1,1]]);});
 it('rejects wrong filenames, missing pages, outside frames and invalid checksums',()=>{expect(()=>parsePrepared(fixture(),['different.png'])).toThrow();for(const change of [(f:PreparedComic)=>{f.pages[0].sha256='bad'},(f:PreparedComic)=>{f.pages[0].frames=[[0,0,1,1]]},(f:PreparedComic)=>{f.pages[0].crop=[0,0,2,1]}]){const f=fixture();change(f);expect(()=>parsePrepared(f,['00001.png'])).toThrow();}});
});
