import 'fake-indexeddb/auto';
import {readFileSync} from 'node:fs';
import {beforeEach,expect,it,vi} from 'vitest';
import {BlobReader,BlobWriter,ZipReader,ZipWriter,configure} from '@zip.js/zip.js';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {blankComic} from '../../src/models';
import {dbPromise,saveComic,deleteComic,getComic,getAsset,updateProgress} from '../../src/storage/db';
import {checksum,restore} from '../../src/storage/backup';
import {exportParts,prepareRestoreParts,discardPrepared} from '../../src/storage/backup-parts';
configure({useWebWorkers:false});
beforeEach(async()=>{const db=await dbPromise;for(const name of ['comics','assets','config','backupStage'] as const)await db.clear(name);});
async function fixture(){
  const blob=new Blob([new Uint8Array(readFileSync('tests/fixtures/sample.cbz'))]),hash=await checksum(blob);
  const comic={...blankComic('Multipart'),pageCount:3,digital:{assetId:'file',format:'cbz' as const,name:'sample.cbz',size:blob.size,fingerprint:hash},coverId:'cover'};
  await saveComic(comic,[{id:'file',blob},{id:'cover',blob:new Blob([new Uint8Array(8192).map((_,i)=>i%251)])}]);
  await updateProgress(comic.id,1,true,123);
  const session=await exportParts(()=>{},{chunkBytes:512,payloadBytes:1024});
  const files=[];for(let i=0;i<session.count;i++)files.push(new File([await session.makePart(i,()=>{})],session.names[i]));
  return {comic,blob,hash,files,session};
}
it('stages reversed parts and atomically restores exact bytes, time and progress',async()=>{
  const f=await fixture();expect(f.files.length).toBeGreaterThan(2);
  const p=await prepareRestoreParts(f.files.toReversed(),()=>{});
  expect(p.assets.size).toBe(0);expect(p.staged!.size).toBe(2);expect(await (await dbPromise).getAllKeys('backupStage')).not.toHaveLength(0);
  await deleteComic(f.comic);await restore(p,'replace',true);
  expect(await getComic(f.comic.id)).toMatchObject({visited:[1],seconds:123});
  expect(await checksum((await getAsset('file'))!.blob)).toBe(f.hash);
  expect(await (await dbPromise).getAllKeys('backupStage')).toHaveLength(0);
});
it('rejects a missing earlier part and cleans sparse staging without changing live books',async()=>{
  const f=await fixture();await expect(prepareRestoreParts(f.files.slice(1),()=>{})).rejects.toThrow('Не хватает частей');
  expect(await getComic(f.comic.id)).toMatchObject({seconds:123});expect(await (await dbPromise).getAllKeys('backupStage')).toHaveLength(0);
});
it('rejects duplicate parts and mixed sets',async()=>{
  const f=await fixture();await expect(prepareRestoreParts([f.files[0],f.files[0]],()=>{})).rejects.toThrow('дважды');
  const g=await fixture();await expect(prepareRestoreParts([f.files[0],g.files[1]],()=>{})).rejects.toThrow('разных');
  expect(await (await dbPromise).getAllKeys('backupStage')).toHaveLength(0);
});
it('restores parts packaged inside one ordinary enclosing ZIP',async()=>{
  const f=await fixture(),writer=new ZipWriter(new BlobWriter(),{level:0});
  for(const file of f.files)await writer.add(`My backups/${file.name}`,new BlobReader(file));
  const p=await prepareRestoreParts([new File([await writer.close()],'all-parts.zip')],()=>{});
  await deleteComic(f.comic);await restore(p,'replace',false);expect(await checksum((await getAsset('file'))!.blob)).toBe(f.hash);
});
it('checks chunk hashes before a restore can alter current data',async()=>{
  const f=await fixture(),reader=new ZipReader(new BlobReader(f.files[0])),writer=new ZipWriter(new BlobWriter(),{level:0});
  let changed=false;
  for(const e of await reader.getEntries())if(!e.directory){let blob=(await e.getData(new BlobWriter()))!;
    if(!changed&&e.filename.startsWith('chunks/')){const b=new Uint8Array(await blob.arrayBuffer());b[0]^=1;blob=new Blob([b]);changed=true;}
    await writer.add(e.filename,new BlobReader(blob));
  }
  await reader.close();const bad=new File([await writer.close()],f.files[0].name);
  await expect(prepareRestoreParts([bad,...f.files.slice(1)],()=>{})).rejects.toThrow('Контрольная сумма');
  expect(await getComic(f.comic.id)).toMatchObject({seconds:123});expect(await (await dbPromise).getAllKeys('backupStage')).toHaveLength(0);
});
it('cancels preparation, releases verified temporary data and leaves current assets intact',async()=>{
  const f=await fixture(),controller=new AbortController();controller.abort();
  await expect(prepareRestoreParts(f.files,()=>{},controller.signal)).rejects.toThrow('Отменено');
  const p=await prepareRestoreParts(f.files,()=>{});await discardPrepared(p);expect(await (await dbPromise).getAllKeys('backupStage')).toHaveLength(0);
  expect(await checksum((await getAsset('file'))!.blob)).toBe(f.hash);
});
it('aborts the entire live restore transaction if staged data disappears',async()=>{
  const f=await fixture(),p=await prepareRestoreParts(f.files,()=>{});await discardPrepared(p);
  await expect(restore(p,'replace',false)).rejects.toThrow('Временные файлы');
  expect(await getComic(f.comic.id)).toMatchObject({seconds:123});expect(await checksum((await getAsset('file'))!.blob)).toBe(f.hash);
});
