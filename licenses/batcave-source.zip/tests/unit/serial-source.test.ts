import {describe, it, expect, vi} from 'vitest';
import {serialSource} from '../../src/reader/serial-source';
import type {PageSource} from '../../src/reader/source';

describe('shared reader render queue', () => {
  it('never overlaps a preview with the page camera and skips cancelled queued work', async () => {
    let release!: () => void;
    const first = new Promise<void>(resolve => { release = resolve; });
    const order: number[] = [];
    const render = vi.fn(async (page: number) => { order.push(page); if (page === 0) await first; });
    const source = serialSource({count: 3, ratio: 1.5, render, close: async () => {}});
    const canvas = {} as HTMLCanvasElement;
    const camera = source.render(0, canvas, 1000);
    const controller = new AbortController();
    const preview = source.render(1, canvas, 120, controller.signal);
    const rejected = expect(preview).rejects.toMatchObject({name: 'AbortError'});
    const next = source.render(2, canvas, 1000);
    controller.abort(); await Promise.resolve();
    expect(order).toEqual([0]);
    release(); await Promise.all([camera, rejected, next]);
    expect(order).toEqual([0, 2]);
  });

  it('a failed preview does not prevent the next page from loading', async () => {
    const render = vi.fn(async (page: number) => { if (page === 0) throw Error('Corrupt thumbnail'); });
    const source = serialSource({count: 2, ratio: 1.5, render, close: async () => {}});
    await expect(source.render(0, {} as HTMLCanvasElement, 120)).rejects.toThrow('Corrupt thumbnail');
    await expect(source.render(1, {} as HTMLCanvasElement, 1000)).resolves.toBeUndefined();
    expect(render).toHaveBeenCalledTimes(2);
  });

  it('closes the underlying document once and prevents renders after close', async () => {
    const close = vi.fn(async () => {}), render = vi.fn(async () => {});
    const source = serialSource({count: 1, ratio: 1.5, render, close} as PageSource);
    const task = source.render(0, {} as HTMLCanvasElement, 120);
    const rejected = expect(task).rejects.toMatchObject({name: 'AbortError'});
    await Promise.all([source.close(), source.close(), rejected]);
    expect(close).toHaveBeenCalledTimes(1); expect(render).not.toHaveBeenCalled();
    await expect(source.render(0, {} as HTMLCanvasElement, 120)).rejects.toMatchObject({name:'AbortError'});
  });
});
