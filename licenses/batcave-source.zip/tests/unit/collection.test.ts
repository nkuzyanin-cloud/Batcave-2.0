import 'fake-indexeddb/auto';
import { describe, it, expect, vi } from 'vitest';
vi.mock('pdfjs-dist', () => ({ GlobalWorkerOptions: {}, PDFDataRangeTransport: class {}, getDocument: vi.fn() }));
import { blankComic, defaultSettings } from '../../src/models';
import { inCollection, matchesCollection } from '../../src/collection';
import { achievements } from '../../src/achievements';
import { saveComic, deleteDigital, dbPromise, getAsset } from '../../src/storage/db';
import { parseBackup, restore } from '../../src/storage/backup';

describe('One collection, independent formats and reading', () => {
  it('shows every saved comic, including unread and cover-first records', () => {
    const unread = blankComic('Unread');
    expect(inCollection(unread)).toBe(true);
    expect(inCollection({ ...unread, completed: true })).toBe(true);
    expect(inCollection({ ...unread, physical: 'yes' })).toBe(true);
    const paper = { ...unread, physical: 'yes' as const, completed: true };
    expect(matchesCollection(paper, 'paper')).toBe(true);
    expect(matchesCollection(paper, 'digital')).toBe(false);
    expect(matchesCollection({ ...paper, readDigitally: true }, 'digital')).toBe(true);
  });
  it('recognizes previous reader progress even if the original file was removed', () => {
    const old = { ...blankComic(), physical: 'yes' as const, completed: true, visited: [0], pageCount: 1 };
    expect(matchesCollection(old, 'digital')).toBe(true);
    expect(matchesCollection({ ...old, visited: [], lastOpened: 1 }, 'digital')).toBe(true);
  });
  it('deleting a completed file preserves online identity, covers, notes and reading data', async () => {
    const c = { ...blankComic('Completed digital and paper'), physical: 'yes' as const, completed: true,
      rating: 4, note: 'Keep', coverId: 'cover-c', photoId: 'photo-c',
      digital: { assetId: 'file-c', format: 'image' as const, name: 'page.png', size: 4, fingerprint: 'a'.repeat(64) } };
    await saveComic(c, [{ id: 'file-c', blob: new Blob(['file']) }, { id: 'cover-c', blob: new Blob(['cover']) }, { id: 'photo-c', blob: new Blob(['photo']) }]);
    await deleteDigital(c);
    const saved = (await dbPromise).get('comics', c.id);
    expect(await saved).toMatchObject({ completed: true, readDigitally: true, note: 'Keep', rating: 4, coverId: c.coverId, photoId: c.photoId });
    expect(matchesCollection((await saved)!, 'digital')).toBe(true);
    expect(await getAsset('file-c')).toBeUndefined();
    expect(await (await getAsset('cover-c'))!.blob.text()).toBe('cover');
    expect(await (await getAsset('photo-c'))!.blob.text()).toBe('photo');
  });
  it('old JSON is accepted, and online identity survives metadata recovery without fake pages', async () => {
    const c = { ...blankComic('Read online'), physical: 'yes' as const, completed: true, readDigitally: true };
    const raw = { app: 'BATCAVE', version: 1, kind: 'metadata', createdAt: 1, comics: [c], settings: defaultSettings, assets: [] };
    const data = parseBackup(raw);
    expect(data.comics[0].readDigitally).toBe(true);
    await restore({ data, assets: new Map(), conflicts: 0 }, 'replace', false);
    const saved = (await (await dbPromise).get('comics', c.id))!;
    expect(saved.visited).toEqual([]);
    expect(saved.seconds).toBe(0);
    expect(saved.digital).toBeUndefined();
    expect(matchesCollection(saved, 'digital')).toBe(true);
    const old = { ...c };delete old.readDigitally;
    expect(parseBackup({ ...raw, comics: [old] }).comics[0].readDigitally).toBeUndefined();
    expect(() => parseBackup({ ...raw, comics: [{ ...c, readDigitally: 'true' }] })).toThrow();
  });
  it('restoring a completed physical-and-digital metadata record keeps digital reading after stripping an unavailable file', async () => {
    const c = { ...blankComic(), completed: true, physical: 'yes' as const,
      digital: { assetId: 'not-backed-up', name: 'old.pdf', format: 'pdf' as const, size: 42, fingerprint: 'c'.repeat(64) } };
    const data = parseBackup({ app: 'BATCAVE', version: 1, kind: 'metadata', createdAt: 1, comics: [c], settings: defaultSettings, assets: [] });
    await restore({ data, assets: new Map(), conflicts: 0 }, 'replace', false);
    const saved = (await (await dbPromise).get('comics', c.id))!;
    expect(saved.digital).toBeUndefined();
    expect(matchesCollection(saved, 'digital')).toBe(true);
  });
});

describe('Achievements from real data', () => {
  it('unlocks nothing in an empty archive', () => expect(achievements([]).every(a => !a.earned && a.value === 0)).toBe(true));
  it('counts unique visited pages, completed records and combined paper copies independently', () => {
    const comics = Array.from({ length: 10 }, (_, i) => ({ ...blankComic(), physical: 'yes' as const, physicalGroup: i < 2 ? 'Combined' : undefined,
      completed: i < 5, pageCount: 100, page: 99, visited: i === 0 ? Array.from({ length: 99 }, (_, n) => n) : [], seconds: 0 }));
    const all = achievements(comics), medal = (id: string) => all.find(a => a.id === id)!;
    expect(medal('stories-5').earned).toBe(true);
    expect(medal('stories-10').value).toBe(5);
    expect(medal('pages-100').value).toBe(99);
    expect(medal('pages-100').earned).toBe(false);
    expect(medal('paper-10').value).toBe(9);
    expect(medal('library-5').value).toBe(0);
  });
});
