import 'fake-indexeddb/auto';
import {beforeEach,it,expect,vi} from 'vitest';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
import {blankComic} from '../../src/models';
import {CHRONOLOGICAL_ERAS} from '../../src/eras';
import {captureEraPlan,eraProgress} from '../../src/era-progress';
import {achievements,mergeAchievementStates} from '../../src/achievements';
import {dbPromise,initialize,saveComic,saveEraPlan,deleteComic,getAchievementState} from '../../src/storage/db';
import {exportMetadata,parseBackup,restore} from '../../src/storage/backup';
const early=(done=false)=>({...blankComic(),era:'early' as const,inRoadmap:true,completed:done});
beforeEach(async()=>{const db=await dbPromise;await db.clear('comics');await db.clear('config');await db.clear('assets');await initialize();});
it('keeps historical era plans separate from universal achievements',async()=>{
  expect(CHRONOLOGICAL_ERAS).toHaveLength(11);
  expect(achievements([]).filter(a=>a.kind==='eras')).toHaveLength(0);
  await expect(saveEraPlan('standalone')).rejects.toThrow();
  await expect(saveEraPlan('alternative')).rejects.toThrow();
  await expect(saveEraPlan('early')).rejects.toThrow('основные истории');
});
it('does not declare an era finished from one imported completed book without an explicit route',async()=>{
  const book=early(true);await saveComic(book);
  expect(achievements([book],await getAchievementState()).find(a=>a.era==='early')).toBeUndefined();
  const p=eraProgress([book],undefined,'early');expect(p.total).toBe(1);expect(p.done).toBe(1);expect(p.complete).toBe(false);
});
it('completes the registered main route, with paper books but without optional side stories',async()=>{
  const a=early(true),b={...early(false),physical:'yes' as const},side={...early(false),sideStoryAfter:a.id,inRoadmap:false};
  await saveComic(a);await saveComic(b);await saveComic(side);await saveEraPlan('early');
  let state=await getAchievementState();expect(state?.eraPlans?.[0].entries).toHaveLength(2);
  expect(state?.earned.some(a=>a.id==='era-early')).toBe(false);
  await saveComic({...b,completed:true,paperCompleted:true});state=await getAchievementState();
  expect(state?.earned.some(a=>a.id==='era-early')).toBe(false);
  expect(eraProgress(await(await dbPromise).getAll('comics'),state?.eraPlans,'early').complete).toBe(true);
  expect(state?.pending.filter(g=>g.includes('era-early'))).toHaveLength(0);
});
it('deleting or moving an unfinished title never shortens the fixed goal',async()=>{
  const a=early(true),b=early(false);await saveComic(a);await saveComic(b);await saveEraPlan('early');
  await deleteComic(b);const state=await getAchievementState(),p=eraProgress([a],state?.eraPlans,'early');
  expect(p.total).toBe(2);expect(p.done).toBe(1);expect(p.complete).toBe(false);expect(p.changed).toBe(true);
  expect(state?.earned.some(a=>a.id==='era-early')).toBe(false);
  await saveComic({...early(true),title:'Another completed story'});
  expect((await getAchievementState())?.earned.some(a=>a.id==='era-early')).toBe(false);
});
it('new additions do not silently redefine the goal; earned eras and dates survive library cleanup',async()=>{
  const a=early(true),b=early(false);await saveComic(a);await saveComic(b);await saveEraPlan('early');
  const extra=early(false);await saveComic(extra);await saveComic({...b,completed:true});
  const db=await dbPromise;const original=(await getAchievementState())!;await db.put('config',{...original,earned:[...original.earned,{id:'era-early',at:123}]},'achievements-v2');
  const state=(await getAchievementState())!,award=state.earned.find(a=>a.id==='era-early');expect(award?.at).toBe(123);
  expect(state.eraPlans?.[0].entries).toHaveLength(2);
  await deleteComic(a);await deleteComic(b);expect((await getAchievementState())?.earned.find(a=>a.id==='era-early')).toEqual(award);
});
it('can explicitly update a changed route, but never accepts an empty route',async()=>{
  const a=early(true),b=early(false);await saveComic(a);await saveComic(b);await saveEraPlan('early');await deleteComic(b);
  await saveEraPlan('early');expect((await getAchievementState())?.earned.some(a=>a.id==='era-early')).toBe(false);
  await deleteComic(a);await expect(saveEraPlan('early')).rejects.toThrow();
  expect((await getAchievementState())?.earned.some(a=>a.id==='era-early')).toBe(false);
});
it('carries the frozen list and its missing unfinished entries through backup and merge',async()=>{
  const a=early(true),b=early(false);await saveComic(a);await saveComic(b);await saveEraPlan('early');await deleteComic(b);
  const data=parseBackup(JSON.parse(await(await exportMetadata()).text()));
  expect(data.achievements?.eraPlans?.[0].entries).toHaveLength(2);
  await(await dbPromise).clear('config');await restore({data,assets:new Map(),conflicts:1},'keep',false);
  const state=(await getAchievementState())!;expect(state.eraPlans?.[0].entries.find(e=>e.id===b.id)?.done).toBe(false);
  const future={...state,eraPlans:[captureEraPlan([a],'early',Date.now()+1000)]};
  expect(mergeAchievementStates(state,future)?.eraPlans?.[0].entries).toHaveLength(1);
});
