import 'fake-indexeddb/auto';
import {openDB} from 'idb';
import {expect,it,vi} from 'vitest';
import {blankComic,defaultSettings} from '../../src/models';
vi.mock('pdfjs-dist',()=>({GlobalWorkerOptions:{},PDFDataRangeTransport:class{},getDocument:vi.fn()}));
it('upgrades an actual version-1 database without changing its books, assets or settings',async()=>{
  const old=await openDB('batcave-reader',1,{upgrade(db){db.createObjectStore('comics',{keyPath:'id'});db.createObjectStore('assets',{keyPath:'id'});db.createObjectStore('config');}});
  const book={...blankComic('Existing library'),pageCount:10,visited:[0,1,2],seconds:531,rating:5};
  await old.put('comics',book);await old.put('assets',{id:'existing',blob:new Blob(['original bytes'])});await old.put('config',defaultSettings,'settings');old.close();
  const {dbPromise}=await import('../../src/storage/db');const db=await dbPromise;
  expect(db.version).toBe(2);expect(db.objectStoreNames.contains('backupStage')).toBe(true);
  expect(await db.get('comics',book.id)).toEqual(book);expect(await (await db.get('assets','existing'))!.blob.text()).toBe('original bytes');expect(await db.get('config','settings')).toEqual(defaultSettings);
});
