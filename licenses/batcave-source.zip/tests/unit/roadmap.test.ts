import {it,expect} from 'vitest';
import {blankComic,stats} from '../../src/models';
import {orderedRoadmap,inRoadmap} from '../../src/roadmap';
it('uses user records only, chronological addition order and optional paper membership',()=>{
 const c=blankComic('Plan'),paper={...blankComic(),physical:'yes' as const,addedAt:1};
 expect(orderedRoadmap([])).toEqual([]);expect(inRoadmap(paper)).toBe(false);expect(inRoadmap({...paper,inRoadmap:true})).toBe(true);
 const old={...c,id:'old',addedAt:1},later={...c,id:'later',addedAt:3};expect(orderedRoadmap([later,paper,old]).map(c=>c.id)).toEqual(['old','later']);
 expect(stats([{...c,inRoadmap:true}]).pages).toBe(0);expect(stats([{...c,inRoadmap:true}]).done).toBe(0);
});
