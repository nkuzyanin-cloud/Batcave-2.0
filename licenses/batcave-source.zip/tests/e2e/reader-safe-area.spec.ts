import {test,expect,type Page} from './runtime';
import {mkdirSync} from 'node:fs';
async function open(page:Page){
 await page.addInitScript(()=>Object.defineProperty(navigator,'standalone',{value:true,configurable:true}));
 await page.goto('/');await expect(page.locator('.app')).toBeVisible();
 await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Загрузить комикс/}).click();await page.locator('[data-testid="comic-file-input"]').setInputFiles('tests/fixtures/four-strips.cbz');await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();await page.getByLabel('Название',{exact:true}).fill('Проверка широких кадров');await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();await expect(page.locator('.modal')).not.toBeVisible();await page.getByRole('button',{name:/Все комиксы/}).click();await page.getByRole('button',{name:/^Читать: Проверка широких кадров/}).click();await expect(page.locator('.reader canvas').first()).toBeVisible();
 // Browser emulation does not expose native iPhone insets. Reserve the real
 // 47/34 CSS px explicitly, leaving the full shell at its native 375x812 size.
 await page.addStyleTag({content:'.reader-stage:not(.editing){top:47px;bottom:34px}'});
 await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();await page.getByLabel('Режим чтения',{exact:true}).selectOption('panels');await page.getByLabel('Вся страница перед кадрами',{exact:true}).check();await page.getByLabel('Вся страница после кадров',{exact:true}).check();await page.getByRole('tab',{name:'Вид',exact:true}).click();await page.getByLabel('Анимации',{exact:true}).selectOption('full');await page.getByLabel('Фон страницы',{exact:true}).selectOption('gray');await page.getByRole('dialog',{name:'Настройки чтения',exact:true}).getByRole('button',{name:'Закрыть',exact:true}).click();await page.keyboard.press('ArrowLeft');await expect(page.locator('.reader-navigation small')).toHaveText('Вся страница');
}
async function settled(page:Page){await page.getByTestId('panel-camera').evaluate(async el=>{for(let i=0;i<3;i++){await new Promise(r=>requestAnimationFrame(r));await Promise.allSettled(el.getAnimations({subtree:true}).map(a=>a.finished));}});}
async function geometry(page:Page){await settled(page);return page.getByTestId('panel-camera').evaluate(el=>{const b=el.getBoundingClientRect(),s=el.closest('.reader-stage')!.getBoundingClientRect();return {left:b.left,right:b.right,top:b.top,bottom:b.bottom,stageTop:s.top,stageBottom:s.bottom,stageWidth:s.width};});}
async function contained(page:Page){const b=await geometry(page);expect(b.left).toBeGreaterThanOrEqual(-.1);expect(b.right).toBeLessThanOrEqual(b.stageWidth+.1);expect(b.top).toBeGreaterThanOrEqual(b.stageTop+11.9);expect(b.bottom).toBeLessThanOrEqual(b.stageBottom-11.9);}

test('overview to first/last wide frame never pushes a fitting page offscreen, including hidden controls and rotation',async({page})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await open(page);await contained(page);
 await page.getByRole('button',{name:'Следующий кадр',exact:true}).click();await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-panel','0');await contained(page);
 mkdirSync('../screenshots',{recursive:true});await page.screenshot({path:'../screenshots/reader-first-strip.png'});
 for(let i=1;i<4;i++){await page.getByRole('button',{name:'Следующий кадр',exact:true}).click();await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-panel',String(i));await contained(page);}
 await page.getByRole('button',{name:'Следующий кадр',exact:true}).click();await expect(page.locator('.reader-navigation small')).toHaveText('Вся страница');await contained(page);
 await page.getByTestId('panel-scroll').tap({position:{x:180,y:220}});await expect(page.locator('.reader')).toHaveClass(/ui-hidden/);await contained(page);
 await page.setViewportSize({width:812,height:375});await contained(page);
 await page.setViewportSize({width:375,height:812});await contained(page);expect(errors).toEqual([]);
});

test('all reader themes paint the page surround, safe areas and browser chrome consistently; library colour restores on exit',async({page})=>{
 await open(page);
 for(const theme of ['black','gray','light']){
  await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();await page.getByRole('tab',{name:'Вид',exact:true}).click();await page.getByLabel('Фон страницы',{exact:true}).selectOption(theme);await page.getByRole('dialog',{name:'Настройки чтения',exact:true}).getByRole('button',{name:'Закрыть',exact:true}).click();
  const colors=await page.evaluate(()=>{const reader=document.querySelector('.reader')!,stage=document.querySelector('.panel-stage')!,leaf=document.querySelector('.panel-leaf.current')!;return {reader:getComputedStyle(reader).backgroundColor,stage:getComputedStyle(stage).backgroundColor,leaf:getComputedStyle(leaf).backgroundColor,root:getComputedStyle(document.documentElement).backgroundColor,variable:getComputedStyle(reader).getPropertyValue('--reader-bg').trim(),meta:document.querySelector<HTMLMetaElement>('meta[name="theme-color"]')!.content,bottom:reader.getBoundingClientRect().bottom,height:innerHeight};});
  expect(colors.stage).toBe(colors.reader);expect(colors.leaf).toBe(colors.reader);expect(colors.root).toBe(colors.reader);expect(colors.meta).toBe(colors.variable);expect(colors.bottom).toBe(colors.height);
 }
 await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();await expect(page.locator('.app')).toBeVisible();expect(await page.locator('meta[name="theme-color"]').getAttribute('content')).toBe('#191b1e');
});
