import {test,expect} from './runtime';
import {seedSeries,record} from './series-fixture';

test('moving between empty, single and grouped sections changes presentation without changing comic records',async({page,context})=>{
 await seedSeries(page);const original=await record(page);
 const tile=(era:string)=>page.locator(`[data-route-section="${era}"]`);
 async function move(id:string,era:string){
  await page.locator(`[data-comic-id="${id}"]`).getByRole('button',{name:/Меню выпуска/}).click();await page.getByRole('button',{name:'Переместить',exact:true}).click();
  await page.getByLabel('Раздел назначения').selectOption(era);await page.getByRole('dialog').getByRole('button',{name:'Переместить',exact:true}).click();
 }
 await expect(tile('b').getByRole('button',{name:/Добавить комикс/})).toBeVisible();
 await move('c0','b');await expect(tile('b')).toHaveClass(/route-single/);await expect(tile('b').locator('.route-volume-open')).not.toHaveAttribute('aria-expanded');
 await expect(tile('b').getByRole('img',{name:'Оценка: 5 из 5'})).toBeVisible();await expect(page.locator('.route-single-add')).toHaveCount(0);
 await move('c2','b');await expect(tile('b').locator('.route-volume-open')).toHaveAttribute('aria-expanded','true');
 await tile('b').locator('.route-volume-open').click();await page.reload();await expect(tile('b').locator('.route-volume-open')).toHaveAttribute('aria-expanded','false');
 await tile('b').locator('.route-volume-open').click();await move('c2','a');await expect(tile('b')).toHaveClass(/route-single/);
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();await expect(tile('b')).toHaveClass(/route-single/);
 const after=await record(page);for(const key of ['visited','seconds','rating','page','completed','digital','coverId'])expect(after[key]).toEqual(original[key]);
});
