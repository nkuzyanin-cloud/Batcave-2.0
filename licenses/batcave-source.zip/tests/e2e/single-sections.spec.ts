import {test,expect} from './runtime';
import {seedSeries,record} from './series-fixture';
import {mkdirSync} from 'node:fs';
test('single sections open directly, empty sections add, groups preserve state and offline records',async({page,context})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await seedSeries(page);const before=await record(page);
 const a=page.locator('[data-route-section="a"]'),b=page.locator('[data-route-section="b"]'),c=page.locator('[data-route-section="c"]');
 await expect(a.locator('.route-section-toggle')).toHaveCount(1);await expect(b.locator('.route-section-toggle')).toHaveCount(0);await expect(b.locator('button')).toHaveCount(1);
 await c.getByRole('button',{name:/Добавить комикс/}).click();await expect(page.getByRole('dialog')).toBeVisible();await page.getByRole('button',{name:'Закрыть',exact:true}).click();
 async function move(id:string,target:string){await page.locator(`[data-comic-id="${id}"] .series-comic-menu`).click();await page.getByRole('button',{name:'Переместить',exact:true}).click();await page.getByLabel('Раздел назначения').selectOption(target);await page.getByRole('dialog').getByRole('button',{name:'Переместить',exact:true}).click();}
 await move('c0','b');await expect(b).toHaveClass(/route-single/);await expect(b.locator('.route-section-toggle')).toHaveCount(0);await expect(b.locator('.route-single-kicker')).toContainText('02');await expect(b.locator('.series-comic-copy>strong')).toHaveText('Мили позади');await expect(b.locator('.series-comic-rating svg.is-filled')).toHaveCount(5);
 await b.locator('.series-comic-row').click();await expect(page.locator('.reading-summary')).toBeVisible();await page.getByRole('button',{name:'Вернуться в библиотеку',exact:true}).click();
 await expect(b).toHaveClass(/route-single/);
 await move('c2','b');await expect(b.locator('.route-section-toggle')).toHaveCount(1);await b.locator('.route-section-toggle').click();await page.reload();await expect(b.locator('.route-section-toggle')).toHaveAttribute('aria-expanded','false');
 await b.locator('.route-section-toggle').click();await move('c2','a');await expect(b).toHaveClass(/route-single/);
 mkdirSync('../reader-single-qa',{recursive:true});await b.scrollIntoViewIfNeeded();await page.screenshot({path:'../reader-single-qa/sections.png'});
 for(const [width,height] of [[320,568],[375,812],[812,375]]){await page.setViewportSize({width,height});await c.scrollIntoViewIfNeeded();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);}
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();await expect(b).toHaveClass(/route-single/);
 const after=await record(page);for(const key of ['visited','seconds','rating','page','completed','digital','coverId'])expect(after[key]).toEqual(before[key]);expect(errors).toEqual([]);
});
