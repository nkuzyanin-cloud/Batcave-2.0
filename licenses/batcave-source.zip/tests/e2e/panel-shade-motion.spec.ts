import {test,expect,type Page} from './runtime';

async function open(page:Page){
 await page.goto('/');await expect(page.locator('.app')).toBeVisible();
 await page.evaluate(async()=>{
  const req=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>req.onsuccess=()=>r(req.result));
  const tx=db.transaction('config','readwrite'),settings=tx.objectStore('config').get('settings');
  settings.onsuccess=()=>tx.objectStore('config').put({...settings.result,mode:'panels',motion:'full',panelPageFirst:false,panelPageLast:false,panelOpacity:.75,warmScreen:true},'settings');
  await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();
 });await page.reload();
 await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();
 await page.getByRole('button',{name:/Загрузить комикс/}).click();
 await page.getByTestId('comic-file-input').setInputFiles('tests/fixtures/shade-edges.cbz');
 await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();
 await page.getByLabel('Название',{exact:true}).fill('Границы затемнения');
 await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();
 await expect(page.locator('.modal')).not.toBeVisible();
 await page.getByRole('button',{name:/Все комиксы/}).click();
 await page.getByRole('button',{name:'Читать: Границы затемнения',exact:true}).click();
 await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-panel','0');
 await expect(page.getByTestId('panel-camera').locator('canvas')).toBeVisible();
}
async function sample(page:Page,fraction:number){
 return page.getByTestId('panel-camera').evaluate((camera,fraction)=>{
  const nodes=[camera,...camera.querySelectorAll('.panel-dim')];
  for(const node of nodes)for(const a of node.getAnimations()){
   a.pause();a.currentTime=Number(a.effect!.getTiming().duration)*fraction;
  }
  const rects=[...camera.querySelectorAll('.panel-dim')].map(el=>{
   const m=new DOMMatrixReadOnly(getComputedStyle(el).transform);
   return {x:m.e,y:m.f,w:m.a*64,h:m.d*64,matrix:getComputedStyle(el).transform};
  });
  const [top,bottom,left,right]=rects;
  const gaps=[
   top.y+top.h-left.y,top.y+top.h-right.y,
   left.y+left.h-bottom.y,right.y+right.h-bottom.y,
  ];
  const width=Number((camera as HTMLElement).style.width.replace('px',''));
  const coverage=left.x<=0&&top.x<=0&&bottom.x<=0&&right.x+right.w>=width;
  return {gaps,coverage,rects,camera:getComputedStyle(camera).transform,animations:camera.getAnimations().length};
 },fraction);
}
test('all four dimming edges stay joined through zero-sized edges and interrupted/reversed flights',async({page},info)=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await open(page);
 for(const direction of ['ArrowRight','ArrowLeft','ArrowRight','ArrowRight','ArrowRight','ArrowRight','ArrowLeft']){
  await page.keyboard.press(direction);
  await expect.poll(()=>page.getByTestId('panel-camera').evaluate(el=>el.getAnimations().length)).toBeGreaterThan(0);
  for(const progress of [.05,.2,.4,.6,.85]){
   const s=await sample(page,progress);
   expect(s.coverage).toBe(true);
   expect(Math.max(...s.gaps.map(Math.abs)),JSON.stringify({direction,progress,...s})).toBeLessThan(.05);
  }
  await page.screenshot({path:info.outputPath('flight-'+direction+'-'+Date.now()+'.png')});
 }
 expect(errors).toEqual([]);
});
