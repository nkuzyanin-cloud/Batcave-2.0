import {test,expect,type Page} from './runtime';
import {seedSeries,record} from './series-fixture';

const tile=(page:Page,era:string)=>page.locator(`[data-route-section="${era}"]`);
const list=(page:Page,era:string)=>page.locator(`[data-route-issue-section="${era}"]`);
async function move(page:Page,id:string,era:string){
 await page.locator(`[data-comic-id="${id}"]`).getByRole('button',{name:/Меню выпуска/}).click();await page.getByRole('button',{name:'Переместить',exact:true}).click();await page.getByLabel('Раздел назначения').selectOption(era);await page.getByRole('dialog').getByRole('button',{name:'Переместить',exact:true}).click();
}

test('group menu adds to the right section, menus edit real ratings, deletion requires confirmation',async({page})=>{
 await seedSeries(page);
 await tile(page,'a').getByRole('button',{name:/Меню раздела/}).click();await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Создать карточку/}).click();await expect(page.getByLabel('Эра комикса')).toHaveValue('a');await page.getByRole('button',{name:'Закрыть',exact:true}).click();
 await list(page,'a').locator('[data-comic-id="c0"] .series-comic-menu').click();await page.getByRole('button',{name:'Редактировать',exact:true}).click();await page.getByRole('button',{name:'Оценка 4',exact:true}).click();await page.getByRole('button',{name:'Сохранить',exact:true}).click();await expect(list(page,'a').getByRole('img',{name:'Оценка: 4 из 5'})).toBeVisible();
 const before=await record(page,'c5');await list(page,'a').locator('[data-comic-id="c5"] .series-comic-menu').click();await page.getByRole('button',{name:'Удалить комикс',exact:true}).click();await page.getByRole('button',{name:'Отмена',exact:true}).click();expect(await record(page,'c5')).toEqual(before);
 await list(page,'a').locator('[data-comic-id="c5"] .series-comic-menu').click();await page.getByRole('button',{name:'Удалить комикс',exact:true}).click();await page.getByRole('button',{name:'Удалить',exact:true}).click();await expect(list(page,'a').locator('.series-timeline-entry')).toHaveCount(5);expect(await record(page,'c5')).toBeUndefined();
});

test('native hold transfers a comic onto a single tile, and cancellation preserves records',async({page,context,browserName})=>{
 test.skip(browserName!=='chromium','Native touch via CDP.');await seedSeries(page);await move(page,'c0','b');const before=await record(page,'c1');
 const cdp=await context.newCDPSession(page);await list(page,'a').locator('[data-comic-id="c1"]').scrollIntoViewIfNeeded();
 const from=await page.locator('[data-comic-id="c1"] .series-cover-handle').boundingBox();await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{id:0,x:from!.x+12,y:from!.y+15}]});await expect(page.locator('[data-route-ghost]')).toBeVisible();
 await page.locator('.screen').evaluate(el=>el.scrollTop=0);const target=await tile(page,'b').locator('.cover').boundingBox();
 await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{id:0,x:target!.x+20,y:target!.y+20}]});await expect(tile(page,'b')).toHaveClass(/is-drop-before/);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
 await expect(list(page,'b').locator('[data-comic-id]').first()).toHaveAttribute('data-comic-id','c1');await expect(page.getByRole('dialog')).toHaveCount(0);
 const after=await record(page,'c1');for(const key of ['visited','seconds','rating','page','completed','digital'])expect(after[key]).toEqual(before[key]);
 await list(page,'b').locator('[data-comic-id="c1"]').scrollIntoViewIfNeeded();const cover=await list(page,'b').locator('[data-comic-id="c1"] .series-cover-handle').boundingBox();await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{id:2,x:cover!.x+10,y:cover!.y+15}]});await expect(page.locator('[data-route-ghost]')).toBeVisible();await cdp.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});await expect(page.locator('[data-route-ghost]')).toHaveCount(0);expect(await record(page,'c1')).toEqual(after);
});

test('full list and its scroll position survive reading and returning to the series',async({page})=>{
 await seedSeries(page);await list(page,'a').locator('[data-comic-id="c5"]').scrollIntoViewIfNeeded();const scroll=await page.locator('.screen').evaluate(el=>el.scrollTop);
 await list(page,'a').locator('[data-comic-id="c5"] .series-comic-row').click();await expect(page.locator('.reading-summary')).toBeVisible();await page.getByRole('button',{name:'Вернуться в библиотеку',exact:true}).click();
 await expect(list(page,'a').locator('.series-timeline-entry')).toHaveCount(6);await expect.poll(()=>page.locator('.screen').evaluate(el=>el.scrollTop)).toBeCloseTo(scroll,0);
});
