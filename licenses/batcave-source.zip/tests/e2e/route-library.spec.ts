import {test,expect,type Page} from './runtime';
import {readFileSync,mkdirSync} from 'node:fs';

async function seed(page:Page,count=8,split=6){
  await page.goto('/');await expect(page.locator('.app')).toBeVisible();
  const cover=readFileSync('tests/fixtures/cover-walking-dead.webp').toString('base64');
  const file=readFileSync('tests/fixtures/sample.cbz').toString('base64');
  await page.evaluate(async({count,split,cover,file})=>{
    const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
    const tx=db.transaction(['comics','config','assets'],'readwrite');tx.objectStore('comics').clear();
    tx.objectStore('config').put([{id:'twd',title:'Ходячие мертвецы',chapters:[{id:'a',title:'Дни минувшего будущего'},{id:'b',title:'Мили позади'},{id:'empty',title:'Безопасность за решёткой'}],updatedAt:0}],'reading-universes-v1');
    tx.objectStore('config').put({mode:'single',motion:'full',direction:'ltr',readerTheme:'black',doubleTap:true,showPage:true,cropMargins:false,panelOpacity:.75,panelPageFirst:false,panelPageLast:false,groupSeries:false,sort:'added',roadmapEra:'a'},'settings');
    for(let i=0;i<count;i++)tx.objectStore('comics').put({id:'c'+i,title:'Ходячие мертвецы. Делюкс. Выпуск '+(i+1),series:'TWD',authors:'',year:null,addedAt:i+1,updatedAt:i+1,physical:'unknown',edition:'',publisher:'',editionYear:null,note:'',rating:i===0?4:0,completed:i<split,page:i===split?1:0,pageCount:3,visited:i<split?[0,1,2]:i===split?[0]:[],seconds:100,lastOpened:i===split?10:0,tone:'#52616b',universeId:'twd',era:i<split?'a':'b',inRoadmap:true,digital:{assetId:'comic-file',format:'cbz',name:'test.cbz',size:100,fingerprint:'a'.repeat(64)},coverId:'test-cover'});
    tx.objectStore('assets').put({id:'test-cover',blob:new Blob([Uint8Array.from(atob(cover),c=>c.charCodeAt(0))],{type:'image/webp'})});
    tx.objectStore('assets').put({id:'comic-file',blob:new Blob([Uint8Array.from(atob(file),c=>c.charCodeAt(0))],{type:'application/zip'})});
    await new Promise<void>((r,j)=>{tx.oncomplete=()=>r();tx.onerror=()=>j(tx.error);});db.close();
  },{count,split,cover,file});
  await page.goto('/#/library/twd');await page.reload();await expect(page.locator('.route-section')).toHaveCount(3);
  for(let n=0;n<10;n++){const close=page.getByRole('button',{name:'Скрыть уведомление о достижении'});if(await close.isVisible())await close.click();else break;}
}
const order=(page:Page,era:string)=>page.locator(`[data-route-section="${era}"] [data-comic-id]`).evaluateAll(nodes=>nodes.map(n=>(n as HTMLElement).dataset.comicId));
const records=(page:Page)=>page.evaluate(async()=>{const q=indexedDB.open('batcave-reader'),db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const req=db.transaction('comics').objectStore('comics').getAll();return await new Promise<any[]>(r=>req.onsuccess=()=>{db.close();r(req.result);});});

test('continuous chapters, real stars, disclosures, section-specific additions, flat header',async({page})=>{
  await seed(page);
  const rated=page.locator('[data-comic-id="c0"]');await expect(rated.getByRole('img',{name:'Оценка: 4 из 5'})).toBeVisible();
  expect(await rated.locator('.series-comic-rating svg.is-filled').count()).toBe(4);expect(await rated.locator('.series-comic-rating svg').count()).toBe(5);
  await expect(page.locator('[data-comic-id="c1"] .series-comic-rating')).toHaveCount(0);
  const headings=await page.locator('.route-section-name').allTextContents();expect(headings).toEqual(['Дни минувшего будущего','Мили позади','Безопасность за решёткой']);
  await expect(page.getByRole('progressbar',{name:'Прогресс раздела Мили позади',exact:true})).toHaveAttribute('aria-valuenow','16.7');
  const section=page.locator('[data-route-section="a"]');
  await section.locator('.route-section-toggle svg').click();
  await expect(section.locator('.route-section-toggle')).toHaveAttribute('aria-expanded','false');
  await expect(section.locator('.series-timeline')).toBeHidden();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('[data-route-section="b"] .series-timeline')).toBeVisible();
  await section.locator('.route-section-toggle').click();
  await expect(section.locator('.series-timeline')).toBeVisible();
  await expect(page.locator('.series-timeline-entry')).toHaveCount(8);
  expect(await page.locator('.app-header').evaluate(el=>({blur:getComputedStyle(el).backdropFilter,bg:getComputedStyle(el).backgroundColor}))).toEqual({blur:'none',bg:'rgb(17, 18, 20)'});
  await expect(page.locator('.app-header button')).toHaveCount(2);
  await page.getByRole('button',{name:'Добавить комикс в раздел «Мили позади»',exact:true}).click();
  await page.getByRole('button',{name:/Создать карточку/}).click();await expect(page.getByLabel('Эра комикса')).toHaveValue('b');
  await page.getByLabel('Название',{exact:true}).fill('Новый выпуск');await page.getByRole('button',{name:'Добавить комикс',exact:true}).last().click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('[data-route-section="b"] .series-timeline-entry')).toHaveCount(3);await expect(page.locator('[data-route-section="b"] .series-timeline-entry').last()).toContainText('Новый выпуск');
  await page.setViewportSize({width:320,height:568});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
});

test('menu edits and moves preserve state, cover drag reorders, order survives offline reload and reading',async({page,context})=>{
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await seed(page,4,2);
  await page.getByRole('button',{name:'Меню выпуска: Ходячие мертвецы. Делюкс. Выпуск 1',exact:true}).click();await page.getByRole('button',{name:'Редактировать',exact:true}).click();
  await page.getByRole('button',{name:'Оценка 5',exact:true}).click();await page.getByRole('button',{name:'Сохранить',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('[data-comic-id="c0"] .series-comic-rating svg.is-filled')).toHaveCount(5);
  const before=(await records(page)).find(c=>c.id==='c1');
  await page.getByRole('button',{name:'Меню выпуска: Ходячие мертвецы. Делюкс. Выпуск 2',exact:true}).click();await page.getByRole('button',{name:'Переместить',exact:true}).click();
  await page.getByLabel('Раздел назначения').selectOption('b');await page.getByLabel('Место в разделе').selectOption('c3');await page.getByRole('dialog').getByRole('button',{name:'Переместить',exact:true}).click();
  await expect.poll(()=>order(page,'b')).toEqual(['c2','c1','c3']);
  const after=(await records(page)).find(c=>c.id==='c1');for(const key of ['digital','coverId','visited','seconds','page','rating','addedAt','completed'])expect(after[key]).toEqual(before[key]);
  for(let n=0;n<10;n++){const close=page.getByRole('button',{name:'Скрыть уведомление о достижении'});if(await close.isVisible())await close.click();else break;}
  // Hold an actual cover; do not invoke app callbacks from the test.
  const from=await page.locator('[data-comic-id="c3"] .series-cover-handle').boundingBox();
  await page.locator('[data-comic-id="c3"]').scrollIntoViewIfNeeded();
  const f=await page.locator('[data-comic-id="c3"] .series-cover-handle').boundingBox();await page.mouse.move(f!.x+20,f!.y+25);await page.mouse.down();await expect(page.locator('[data-route-ghost]')).toBeVisible();
  const dest=await page.locator('[data-comic-id="c2"]').boundingBox();await page.mouse.move(dest!.x+100,dest!.y+15,{steps:5});await expect(page.locator('[data-comic-id="c2"]')).toHaveClass(/is-drop-before/);await page.mouse.up();
  await expect.poll(()=>order(page,'b')).toEqual(['c3','c2','c1']);
  await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();await expect.poll(()=>order(page,'b')).toEqual(['c3','c2','c1']);
  await page.locator('[data-comic-id="c1"] .series-comic-copy').click();await expect(page.locator('.reading-summary')).toBeVisible();await page.getByRole('button',{name:'К последней странице',exact:true}).click();await expect(page.locator('.reader-canvas')).toBeVisible();await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();await expect(page.locator('.route-section')).toHaveCount(3);
  expect(errors).toEqual([]);
});

test('touch hold moves across chapters; a normal swipe scrolls without a move or opening an editor',async({page,context,browserName})=>{
  test.skip(browserName!=='chromium','CDP native touch');await seed(page,4,2);
  const cdp=await context.newCDPSession(page),from=await page.locator('[data-comic-id="c1"] .series-cover-handle').boundingBox();
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{id:0,x:from!.x+20,y:from!.y+25}]});
  await expect(page.locator('[data-route-ghost]')).toBeVisible();
  const target=await page.locator('[data-route-section="b"] .route-section-heading').boundingBox();
  await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{id:0,x:100,y:target!.y+20}]});
  await expect(page.locator('[data-comic-id="c2"]')).toHaveClass(/is-drop-before/);
  await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await expect.poll(()=>order(page,'b')).toEqual(['c1','c2','c3']);await expect(page.getByRole('dialog')).toHaveCount(0);
  const before=await records(page);
  await page.locator('.screen').evaluate(el=>el.scrollTop=0);
  const cover=await page.locator('[data-comic-id="c0"] .series-cover-handle').boundingBox();
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{id:1,x:cover!.x+20,y:cover!.y+60}]});
  await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{id:1,x:cover!.x+20,y:cover!.y-80}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
  await expect(page.locator('[data-route-ghost]')).toHaveCount(0);await expect(page.getByRole('dialog')).toHaveCount(0);expect(await records(page)).toEqual(before);
  mkdirSync('../series-qa/screenshots',{recursive:true});await page.screenshot({path:'../series-qa/screenshots/series-continuous-route.png'});
});

test('edge autoscroll, cancellation, delete menu and all top headers stay functional',async({page,context,browserName})=>{
  test.skip(browserName!=='chromium','CDP native touch');await seed(page,16,14);
  const before=await records(page),cdp=await context.newCDPSession(page);
  const cover=await page.locator('[data-comic-id="c0"] .series-cover-handle').boundingBox();
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{id:1,x:cover!.x+20,y:cover!.y+25}]});
  await expect(page.locator('[data-route-ghost]')).toBeVisible();
  await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{id:1,x:110,y:775}]});
  await expect.poll(()=>page.locator('.screen').evaluate(el=>el.scrollTop)).toBeGreaterThan(300);
  await cdp.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});await expect(page.locator('[data-route-ghost]')).toHaveCount(0);expect(await records(page)).toEqual(before);
  await page.locator('[data-comic-id="c15"]').scrollIntoViewIfNeeded();await page.getByRole('button',{name:'Меню выпуска: Ходячие мертвецы. Делюкс. Выпуск 16',exact:true}).click();
  expect(await page.locator('.modal-backdrop').evaluate(el=>getComputedStyle(el).backdropFilter)).toBe('none');
  await page.getByRole('button',{name:'Удалить комикс',exact:true}).click();await page.getByRole('button',{name:'Отмена',exact:true}).click();await expect(page.locator('.series-timeline-entry')).toHaveCount(16);
  await page.getByRole('button',{name:'Меню выпуска: Ходячие мертвецы. Делюкс. Выпуск 16',exact:true}).click();await page.getByRole('button',{name:'Удалить комикс',exact:true}).click();await page.getByRole('button',{name:'Удалить',exact:true}).click();await expect(page.locator('.series-timeline-entry')).toHaveCount(15);
  for(const hash of ['#/library','#/archive','#/settings']){
    await page.goto('/'+hash);await expect(page.locator('.app-header')).toBeVisible();
    expect(await page.locator('.app-header').evaluate(el=>getComputedStyle(el).backdropFilter)).toBe('none');
  }
});


test('disclosures only hide their own list, keyboard works, search reveals matches and footer is complete',async({page})=>{
  await seed(page,4,2);
  const original=await records(page),url=page.url();
  const first=page.locator('[data-route-section="a"]'),second=page.locator('[data-route-section="b"]');
  await first.locator('.route-section-name').click();
  await expect(first.locator('.route-section-toggle')).toHaveAttribute('aria-expanded','false');
  await expect(first.locator('.route-section-body')).toBeHidden();
  await expect(second.locator('.route-section-body')).toBeVisible();
  expect(page.url()).toBe(url);await expect(page.getByRole('dialog')).toHaveCount(0);
  await second.locator('.route-section-toggle').focus();await page.keyboard.press('Space');
  await expect(second.locator('.route-section-body')).toBeHidden();
  await page.keyboard.press('Enter');await expect(second.locator('.route-section-body')).toBeVisible();
  await page.getByRole('button',{name:'Меню серии',exact:true}).click();
  await page.getByRole('button',{name:'Открыть поиск',exact:true}).click();
  await page.getByRole('searchbox',{name:'Поиск комиксов'}).fill('Выпуск 1');
  await expect(first.locator('[data-comic-id="c0"]')).toBeVisible();
  await expect(first.locator('.route-section-toggle')).toHaveAttribute('aria-expanded','true');
  await first.locator('.route-section-toggle svg').click();await expect(first.locator('.route-section-body')).toBeHidden();
  await page.getByRole('button',{name:'Закрыть поиск',exact:true}).click();
  await expect(first.locator('.route-section-toggle')).toHaveAttribute('aria-expanded','false');
  await first.locator('.route-section-toggle').click();
  expect(await records(page)).toEqual(original);
  const sectionFont=await first.locator('.route-section-name').evaluate(el=>parseFloat(getComputedStyle(el).fontSize));
  const issueFont=await first.locator('.series-comic-copy>strong').first().evaluate(el=>parseFloat(getComputedStyle(el).fontSize));
  expect(sectionFont).toBeGreaterThan(issueFont);
  for(const size of [{width:375,height:812},{width:320,height:568}]){
    await page.setViewportSize(size);
    await page.evaluate(()=>document.documentElement.style.setProperty('--safe-bottom','34px'));
    const nav=await page.locator('.app-nav').boundingBox();expect(nav!.y+nav!.height).toBeLessThanOrEqual(size.height);
    expect(await page.locator('.app-nav').evaluate(el=>getComputedStyle(el).paddingBottom)).toBe('34px');
    for(const tab of await page.locator('.app-nav>button,.app-nav>a').all())await expect(tab).toBeInViewport({ratio:1});
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  }
  await page.setViewportSize({width:375,height:812});
  mkdirSync('../qa-1.20.1',{recursive:true});await page.screenshot({path:'../qa-1.20.1/series.png'});
});
