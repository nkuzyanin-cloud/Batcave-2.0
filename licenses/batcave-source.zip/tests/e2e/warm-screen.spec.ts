import {test,expect,type Page} from './runtime';

async function openReader(page:Page,file='sample.cbz',mode='single'){
 await page.goto('/');await expect(page.locator('.app')).toBeVisible();
 await page.evaluate(async mode=>{
  const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
  const tx=db.transaction('config','readwrite'),req=tx.objectStore('config').get('settings');
  req.onsuccess=()=>tx.objectStore('config').put({...req.result,mode,motion:'off'},'settings');
  await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();
 },mode);await page.reload();
 await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();
 await page.getByRole('button',{name:/Загрузить комикс/}).click();
 await page.getByTestId('comic-file-input').setInputFiles('tests/fixtures/'+file);
 await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();
 await page.getByLabel('Название',{exact:true}).fill('Проверка тёплого экрана');
 await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();
 await expect(page.locator('.modal')).not.toBeVisible();
 await page.getByRole('button',{name:/Все комиксы/}).click();
 await page.getByRole('button',{name:'Читать: Проверка тёплого экрана',exact:true}).click();
 await expect(page.locator('.reader canvas').first()).toBeVisible();
 await page.locator('.free-page-stage, .panel-scroll').first().tap({position:{x:180,y:310}});
 await expect(page.getByRole('button',{name:'Тёплый экран',exact:true})).toBeVisible();
}
test('warmth changes displayed pixels, leaves original/camera intact and persists offline',async({page,context},info)=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await openReader(page,'colour-calibration.cbz');
 const button=page.getByRole('button',{name:'Тёплый экран',exact:true});
 await expect(button).toHaveAttribute('aria-pressed','false');
 const camera=page.getByTestId('page-transform'),canvas=page.locator('.reader-canvas').first();
 const before=await camera.boundingBox(),original=await canvas.evaluate((el:HTMLCanvasElement)=>el.toDataURL());
 const settings=page.getByRole('button',{name:'Настройки чтения',exact:true});
 expect((await button.boundingBox())!.x).toBeLessThan((await settings.boundingBox())!.x);
 const off=await canvas.screenshot();
 await button.click();await expect(button).toHaveAttribute('aria-pressed','true');
 await expect(page.locator('.reader-warm-layer')).toHaveCSS('opacity','1');
 expect(await camera.boundingBox()).toEqual(before);
 expect(await canvas.evaluate((el:HTMLCanvasElement)=>el.toDataURL())).toBe(original);
 const on=await canvas.screenshot();expect(on.equals(off)).toBe(false);await page.screenshot({path:info.outputPath('warm-screen.png')});
 const sample=await page.evaluate(async({off,on})=>{
  async function pixels(data:string){
   const bitmap=await createImageBitmap(await(await fetch('data:image/png;base64,'+data)).blob());
   const c=document.createElement('canvas');c.width=bitmap.width;c.height=bitmap.height;
   const ctx=c.getContext('2d')!;ctx.drawImage(bitmap,0,0);bitmap.close();return ctx.getImageData(0,0,c.width,c.height).data;
  }
  const a=await pixels(off),b=await pixels(on);
  for(let i=0;i<a.length;i+=16)if(a[i]>240&&a[i+1]>240&&a[i+2]>240)
   return {before:[a[i],a[i+1],a[i+2]],after:[b[i],b[i+1],b[i+2]]};
  throw Error('No white paper in fixture');
 },{off:off.toString('base64'),on:on.toString('base64')});
 expect(sample.after[0]).toBeGreaterThanOrEqual(sample.before[0]-2);
 expect(sample.after[2]).toBeLessThan(sample.before[2]*.8);
 await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();
 await expect(page.locator('.reader-warm-layer')).toHaveCount(0);
 await page.getByRole('button',{name:'Читать: Проверка тёплого экрана',exact:true}).click();
 await expect(page.locator('.reader')).toHaveClass(/warm-screen/);
 await page.locator('.free-page-stage').tap({position:{x:180,y:310}});
 await expect(button).toHaveAttribute('aria-pressed','true');
 await settings.click();await page.getByRole('tab',{name:'Вид',exact:true}).click();
 await expect(page.getByRole('checkbox',{name:'Тёплый экран',exact:true})).toBeChecked();
 await page.getByRole('checkbox',{name:'Тёплый экран',exact:true}).uncheck();
 await page.getByRole('dialog',{name:'Настройки чтения',exact:true}).getByRole('button',{name:'Закрыть',exact:true}).click();
 await expect(button).toHaveAttribute('aria-pressed','false');await button.click();
 await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();
 await expect(page.locator('.app')).toBeVisible();
 await page.getByRole('button',{name:'Читать: Проверка тёплого экрана',exact:true}).click();
 await expect(page.locator('.reader')).toHaveClass(/warm-screen/);expect(errors).toEqual([]);
});

test('warmth works across modes and keeps controls inside a small viewport',async({page})=>{
 await openReader(page);
 await page.getByRole('button',{name:'Тёплый экран',exact:true}).click();
 for(const mode of ['guided','vertical','single']){
  await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();
  await page.getByLabel('Режим чтения',{exact:true}).selectOption(mode);
  await page.getByRole('dialog',{name:'Настройки чтения',exact:true}).getByRole('button',{name:'Закрыть',exact:true}).click();
  await expect(page.locator('.reader')).toHaveClass(/warm-screen/);
  await expect(page.locator('.reader canvas').first()).toBeVisible();
 }
 for(const size of [{width:320,height:568},{width:812,height:375},{width:375,height:812}]){
  await page.setViewportSize(size);
  for(const name of ['Тёплый экран','Настройки чтения']){
   const b=await page.getByRole('button',{name,exact:true}).boundingBox();expect(b!.x).toBeGreaterThanOrEqual(0);expect(b!.x+b!.width).toBeLessThanOrEqual(size.width);
  }
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
 }
});
test('panel mode keeps its camera and can turn frames while warmth is active',async({page})=>{
 await openReader(page,'four-strips.cbz','panels');
 const camera=page.getByTestId('panel-camera'),before=await camera.boundingBox();
 await page.getByRole('button',{name:'Тёплый экран',exact:true}).click();
 expect(await camera.boundingBox()).toEqual(before);
 await page.locator('.panel-scroll').tap({position:{x:180,y:310}});
 await page.keyboard.press('ArrowRight');
 await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-panel','1');
 await expect(page.locator('.reader')).toHaveClass(/warm-screen/);
});
