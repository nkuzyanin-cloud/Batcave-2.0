import {test,expect,type Page} from './runtime';
async function editor(page:Page){
 await page.goto('/');await expect(page.getByRole('heading',{name:'Моя библиотека',exact:true})).toBeVisible();
 await page.getByRole('button',{name:'Открыть серию: Бэтмен',exact:true}).click();await page.getByRole('button',{name:'Изменить',exact:true}).click();return page.getByRole('dialog',{name:'Изменить серию',exact:true});
}
const saved=(page:Page)=>page.evaluate(async()=>{const r=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(res=>r.onsuccess=()=>res(r.result));const q=db.transaction('config').objectStore('config').get('reading-universes-v1');return await new Promise<any>(res=>q.onsuccess=()=>{db.close();res(q.result.find((u:any)=>u.id==='batman'));});});

test('user JPEG uploads, saves, survives reload and offline, and can be replaced or removed',async({page,context})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));let dialog=await editor(page);
 const before=await saved(page);
 await dialog.locator('input[type=file]').setInputFiles('tests/fixtures/series-cover.jpeg');
 const preview=dialog.getByAltText('Выбранная обложка');await expect(preview).toBeVisible();await expect(preview).toHaveAttribute('src',/^data:image\/jpeg;base64,/);
 await expect.poll(()=>preview.evaluate((el:HTMLImageElement)=>el.complete&&el.naturalWidth>0)).toBe(true);
 await dialog.getByRole('button',{name:'Сохранить',exact:true}).click();await expect(dialog).not.toBeVisible();
 const current=await saved(page);expect(current.cover).toMatch(/^data:image\/jpeg;base64,/);expect(current.cover.length).toBeGreaterThan(1000);expect(current.chapters).toEqual(before.chapters);
 await page.reload();await expect(page.locator('.series-heading')).toBeVisible();await page.getByRole('button',{name:'Моя библиотека',exact:true}).click();const card=page.getByRole('button',{name:'Открыть серию: Бэтмен',exact:true});await expect(card.locator('img')).toHaveAttribute('src',current.cover);await expect.poll(()=>card.locator('img').evaluate((el:HTMLImageElement)=>el.complete&&el.naturalWidth>0)).toBe(true);
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();await expect(card.locator('img')).toHaveAttribute('src',current.cover);await context.setOffline(false);
 for(const file of ['page.png','page.webp']){
  await card.click();await page.getByRole('button',{name:'Изменить',exact:true}).click();dialog=page.getByRole('dialog',{name:'Изменить серию',exact:true});await dialog.locator('input[type=file]').setInputFiles('tests/fixtures/'+file);await expect(dialog.getByAltText('Выбранная обложка')).toHaveAttribute('src',/^data:image\/jpeg;base64,/);await dialog.getByRole('button',{name:'Сохранить',exact:true}).click();await expect(dialog).not.toBeVisible();expect((await saved(page)).cover).not.toBe('data:,');await page.getByRole('button',{name:'Моя библиотека',exact:true}).click();
 }
 await card.click();await page.getByRole('button',{name:'Изменить',exact:true}).click();dialog=page.getByRole('dialog',{name:'Изменить серию',exact:true});await dialog.getByRole('button',{name:'Убрать обложку',exact:true}).click();await dialog.getByRole('button',{name:'Сохранить',exact:true}).click();await expect(dialog).not.toBeVisible();expect((await saved(page)).cover).toBeUndefined();expect(errors).toEqual([]);
});
