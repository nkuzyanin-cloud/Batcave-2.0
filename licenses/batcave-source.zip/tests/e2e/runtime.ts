import {test as base,chromium,webkit} from '@playwright/test';
export {expect,type Page} from '@playwright/test';
// Isolated processes also support single-process headless Chromium in CI.
export const test=base.extend({context:async({browserName,baseURL,viewport,userAgent,isMobile,hasTouch,deviceScaleFactor},use,info)=>{
 const browser=await(browserName==='webkit'?webkit:chromium).launch(info.project.use.launchOptions);
 const context=await browser.newContext({baseURL,viewport,userAgent,isMobile,hasTouch,deviceScaleFactor,acceptDownloads:true});
 try{await use(context);}finally{await context.close().catch(()=>{});await browser.close().catch(()=>{});}
}});
