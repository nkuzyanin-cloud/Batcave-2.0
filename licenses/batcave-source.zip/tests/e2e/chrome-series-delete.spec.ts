import {test,expect,type Page} from './runtime';
import {seedSeries,record} from './series-fixture';

async function cleanHeader(page:Page){
 const layers=await page.locator('.app-header,.app-header *').evaluateAll(nodes=>nodes.map(el=>{
  const s=getComputedStyle(el);return {filter:s.filter,backdrop:s.backdropFilter,shadow:s.textShadow,transform:s.transform};
 }));
 expect(layers.every(s=>s.filter==='none'&&s.backdrop==='none'&&s.shadow==='none'&&s.transform==='none')).toBe(true);
}

test('compact full-name disclosures, aligned statistics and plain headers across screens',async({page})=>{
 await seedSeries(page);await cleanHeader(page);
 for(const width of [375,320]){
  await page.setViewportSize({width,height:812});
  const header=page.locator('.route-section-toggle').first(),box=await header.boundingBox();
  expect(box!.height).toBeLessThanOrEqual(width===375?90:110);expect(box!.height).toBeGreaterThanOrEqual(76);
  await expect(header).toContainText('Дни минувшего будущего');await header.click();await expect(header).toHaveAttribute('aria-expanded','false');await header.click();
  await page.locator('main').evaluate(el=>el.scrollTop=el.scrollHeight);await cleanHeader(page);
 }
 await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();
 for(const width of [375,320,640]){
  await page.setViewportSize({width,height:812});await cleanHeader(page);
  const boxes=await page.locator('.library-stats>div').evaluateAll(nodes=>nodes.map(el=>{
   const dd=el.querySelector('dd')!.getBoundingClientRect(),dt=el.querySelector('dt')!.getBoundingClientRect();
   return {valueTop:dd.top,valueBottom:dd.bottom,captionTop:dt.top,captionBottom:dt.bottom};
  }));
  for(const k of ['valueTop','valueBottom','captionTop','captionBottom'] as const)expect(Math.max(...boxes.map(b=>b[k]))-Math.min(...boxes.map(b=>b[k]))).toBeLessThan(1);
 }
 await page.getByRole('link',{name:'Открыть достижения',exact:true}).click();await cleanHeader(page);
 await page.getByRole('button',{name:'Открыть настройки',exact:true}).click();await cleanHeader(page);
});

test('series menu cancellation and confirmed removal retain comics, progress and asset bytes',async({page})=>{
 await seedSeries(page);const before=await record(page);
 const bytes=async()=>page.evaluate(async()=>{const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const req=db.transaction('assets').objectStore('assets').getAll();const rows=await new Promise<any[]>(r=>req.onsuccess=()=>r(req.result));db.close();return await Promise.all(rows.map(async a=>[a.id,Array.from(new Uint8Array(await a.blob.arrayBuffer()))]));});
 const originals=await bytes();
 await page.getByRole('button',{name:'Меню серии'}).click();await page.getByRole('button',{name:'Удалить серию',exact:true}).click();
 await expect(page.getByRole('dialog',{name:'Удалить серию?'})).toContainText('Все комиксы останутся');
 await page.getByRole('button',{name:'Отмена',exact:true}).click();await expect(page.locator('.series-view')).toBeVisible();expect(await record(page)).toEqual(before);
 await page.getByRole('button',{name:'Меню серии'}).click();await page.getByRole('button',{name:'Удалить серию',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Удалить серию',exact:true}).click();
 await expect(page).toHaveURL(/#\/library$/);await expect(page.getByRole('button',{name:/Открыть серию: Ходячие/})).toHaveCount(0);
 const after=await record(page);expect(after).toEqual({...before,universeId:'__unassigned__',era:'early',inRoadmap:false,routeOrder:undefined,sideStoryAfter:undefined,updatedAt:expect.any(Number)});
 expect(await bytes()).toEqual(originals);
 await page.reload();await expect(page.getByRole('button',{name:/Открыть серию: Ходячие/})).toHaveCount(0);
 await page.getByRole('button',{name:/Без серии/}).click();await expect(page.getByText(before.title,{exact:true}).first()).toBeVisible();
});
