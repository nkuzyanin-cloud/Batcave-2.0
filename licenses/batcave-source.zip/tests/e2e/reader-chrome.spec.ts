import {test, expect, type Page} from './runtime';
import {mkdirSync} from 'node:fs';

async function open(page: Page, file = 'sample.cbz', mode = 'single') {
  await page.goto('/');
  await expect(page.getByRole('heading', {name: 'Моя библиотека', exact: true})).toBeVisible();
  await page.evaluate(async mode => {
    const q = indexedDB.open('batcave-reader');
    const db = await new Promise<IDBDatabase>(r => q.onsuccess = () => r(q.result));
    const tx = db.transaction('config', 'readwrite');
    const old = tx.objectStore('config').get('settings');
    old.onsuccess = () => tx.objectStore('config').put({...old.result, mode, motion: 'off', readerTheme: 'black', cropMargins: false, panelPageFirst: true}, 'settings');
    await new Promise<void>(r => tx.oncomplete = () => r()); db.close();
  }, mode);
  await page.reload();
  await page.getByRole('button', {name: 'Добавить комикс', exact: true}).click();
  await page.getByRole('button', {name: /Загрузить комикс/}).click();
  await page.locator('[data-testid="comic-file-input"]').setInputFiles('tests/fixtures/' + file);
  await expect(page.getByText('Файл проверен', {exact: true})).toBeVisible();
  await page.getByLabel('Название', {exact: true}).fill('Проверка панели чтения — очень длинное название выпуска');
  await page.getByRole('button', {name: 'Сохранить в библиотеку', exact: true}).click();
  await expect(page.locator('.modal')).not.toBeVisible();
  await page.getByRole('button', {name: /Все комиксы/}).click();
  await page.getByRole('button', {name: /^Читать: Проверка панели/}).click();
  await expect(page.locator('.reader canvas').first()).toBeVisible();
  for (let n=0;n<4;n++) {
    const notice=page.getByRole('button',{name:'Скрыть уведомление о достижении'});
    if (await notice.isVisible()) await notice.click(); else break;
  }
}

async function toggle(page: Page) {
  const surface = page.locator('.free-page-stage, .panel-scroll').first();
  await surface.tap({position: {x: 185, y: 310}});
}

test('hidden by default; previews, seek, settings, resume and offline read use real stored pages', async ({page, context}) => {
  const errors: string[] = []; page.on('pageerror', e => errors.push(e.message));
  await open(page);
  await expect(page.locator('.reader')).toHaveClass(/ui-hidden/);
  await expect(page.getByRole('button',{name:'Настройки чтения',exact:true})).not.toBeVisible();
  expect(await page.locator('.reader-filmstrip img').count()).toBe(0);
  const before = await page.getByTestId('page-transform').boundingBox();
  await toggle(page);
  await expect(page.locator('.reader')).not.toHaveClass(/ui-hidden/);
  await expect(page.locator('.reader-filmstrip img')).toHaveCount(3);
  const after = await page.getByTestId('page-transform').boundingBox();
  expect(after).toEqual(before);
  expect(await page.locator('.reader').evaluate(root => Array.from(root.querySelectorAll('*')).filter(el => {
    const s = getComputedStyle(el); return s.backdropFilter !== 'none' && s.backdropFilter !== '';
  }).length)).toBe(0);
  await expect(page.getByRole('button',{name:'Кадры',exact:true})).toHaveCount(0);
  await expect(page.locator('.panel-position')).toHaveCount(0);
  await page.getByRole('button',{name:'Страница 3',exact:true}).click();
  await expect(page.locator('.reader-canvas')).toHaveAttribute('data-page','2');
  await expect(page.getByRole('button',{name:'Страница 3',exact:true})).toHaveAttribute('aria-current','page');
  await page.getByRole('slider',{name:'Перейти к странице'}).fill('1');
  await expect(page.locator('.reader-canvas')).toHaveAttribute('data-page','1');
  await page.getByRole('button',{name:'Все страницы: 2 из 3',exact:true}).click();
  await expect(page.getByRole('dialog',{name:'Страницы комикса',exact:true})).toBeVisible();
  await page.getByRole('dialog',{name:'Страницы комикса',exact:true}).getByRole('button',{name:'Страница 1',exact:true}).click();
  await expect(page.locator('.reader-canvas')).toHaveAttribute('data-page','0');
  await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();
  await expect(page.getByRole('dialog',{name:'Настройки чтения',exact:true})).toBeVisible();
  await page.getByRole('dialog',{name:'Настройки чтения',exact:true}).getByRole('button',{name:'Закрыть',exact:true}).click();
  await page.getByRole('button',{name:'Следующая страница',exact:true}).click();
  await expect(page.locator('.reader-canvas')).toHaveAttribute('data-page','1');
  await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();
  await page.getByRole('button',{name:/^Читать: Проверка панели/}).click();
  await expect(page.locator('.reader-canvas')).toHaveAttribute('data-page','1');
  await expect(page.locator('.reader')).toHaveClass(/ui-hidden/);
  await toggle(page);
  await page.waitForFunction(()=>!!navigator.serviceWorker.controller);
  await context.setOffline(true);
  await page.getByRole('button',{name:'Следующая страница',exact:true}).click();
  await expect(page.locator('.reader-canvas')).toHaveAttribute('data-page','2');
  await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();
  await expect(page.locator('.reader')).toHaveCount(0);
  await page.reload();
  await expect(page.locator('.app')).toBeVisible();
  expect(errors).toEqual([]);
});

test('340 pages keep a bounded preview window; small and landscape screens stay within the viewport', async ({page}) => {
  await open(page, 'grid-340.cbz'); await toggle(page);
  const strip = page.locator('.reader-filmstrip');
  await expect.poll(()=>strip.locator('img').count()).toBeGreaterThan(0);
  await strip.evaluate(el=>el.scrollLeft=180*64);
  await expect(page.getByRole('button',{name:'Страница 181',exact:true})).toBeVisible();
  await page.getByRole('button',{name:'Страница 181',exact:true}).click();
  await expect(page.locator('.reader-canvas')).toHaveAttribute('data-page','180');
  expect(await strip.locator('button').count()).toBeLessThan(14);
  expect(Number(await strip.getAttribute('data-preview-count'))).toBeLessThanOrEqual(24);
  for (const viewport of [{width:320,height:568},{width:812,height:375},{width:375,height:812}]) {
    await page.setViewportSize(viewport);
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
    const bounds=await page.locator('.reader-controls').boundingBox();
    expect(bounds!.x).toBeGreaterThanOrEqual(0); expect(bounds!.x+bounds!.width).toBeLessThanOrEqual(viewport.width);
    expect(bounds!.y+bounds!.height).toBeLessThanOrEqual(viewport.height+.1);
  }
});

test('frame mode keeps its camera and gestures without a frame indicator; single page has a disabled seek', async ({page}) => {
  const errors: string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await open(page,'four-strips.cbz','panels');
  await expect(page.getByTestId('panel-stage')).toBeVisible();
  await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-panel','0');
  const before=await page.getByTestId('panel-camera').boundingBox();
  await toggle(page);
  await expect(page.locator('.reader-controls')).toBeVisible();
  await expect(page.getByRole('slider',{name:'Перейти к странице'})).toBeDisabled();
  await expect(page.locator('.panel-position')).toHaveCount(0);
  expect(await page.getByTestId('panel-camera').boundingBox()).toEqual(before);
  mkdirSync('../reader-qa/screenshots',{recursive:true});
  await page.screenshot({path:'../reader-qa/screenshots/reader-frames-controls.png'});
  await toggle(page);
  await expect(page.locator('.reader-controls')).not.toBeVisible();
  await page.keyboard.press('ArrowRight');
  await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-panel','1');
  expect(errors).toEqual([]);
});

test('PDF previews and rapid page navigation share the document without render errors', async ({page}) => {
  const errors: string[]=[]; page.on('pageerror',e=>errors.push(e.message));
  await open(page,'sample.pdf'); await toggle(page);
  await expect.poll(()=>page.locator('.reader-filmstrip img').count()).toBeGreaterThan(0);
  const seek=page.getByRole('slider',{name:'Перейти к странице'});
  const last=await seek.getAttribute('max');
  for (let i=0;i<4;i++) {await seek.fill(last!);await seek.fill('0');}
  await expect(page.locator('.reader-canvas')).toHaveAttribute('data-page','0');
  await expect(page.locator('.reader-canvas')).toBeVisible();
  await expect(page.locator('.reader-error')).toHaveCount(0);
  await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();
  await expect(page.locator('.reader')).toHaveCount(0);
  expect(errors).toEqual([]);
});
