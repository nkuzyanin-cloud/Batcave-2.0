import {test,expect,type Page} from './runtime';

async function setLibrary(page:Page,pages:number,exists=true,motion='off'){
 await page.evaluate(async({pages,exists,motion})=>{
  const request=indexedDB.open('batcave-reader'),db=await new Promise<IDBDatabase>((r,j)=>{request.onsuccess=()=>r(request.result);request.onerror=()=>j(request.error);});
  const tx=db.transaction(['comics','config'],'readwrite'),store=tx.objectStore('comics');store.clear();
  const parts=exists?Array.from({length:Math.max(1,Math.ceil(pages/100000))},(_,i)=>Math.min(100000,Math.max(0,pages-i*100000))):[];
  for(const [i,count] of parts.entries())store.put({id:'shelf-test-'+i,title:'История '+i,series:'',authors:'',year:null,addedAt:1,updatedAt:1,physical:count?'yes':'unknown',paperPageCount:count||undefined,paperCompleted:count>0,edition:'',publisher:'',editionYear:null,note:'',rating:0,completed:count>0,page:0,pageCount:0,visited:[],seconds:0,lastOpened:0,tone:'#52616b',universeId:'__unassigned__',era:'main'});
  tx.objectStore('config').put({motion},'settings');
  await new Promise<void>((r,j)=>{tx.oncomplete=()=>r();tx.onerror=()=>j(tx.error);});db.close();
 },{pages,exists,motion});
 await page.reload();await expect(page.locator('.reader-shelf')).toBeVisible();
 for(let i=0;i<12;i++){
  const close=page.getByRole('button',{name:'Скрыть уведомление о достижении'});
  try{await close.waitFor({state:'visible',timeout:120});await close.click();}catch{break;}
 }
}

test('empty shelf, first record, old reading and the exact final milestone',async({page})=>{
 await page.goto('/');await expect(page.locator('.app')).toBeVisible();
 await setLibrary(page,0,false);await expect(page.locator('.reader-shelf')).toHaveAttribute('data-reader-level','0');await expect(page.locator('.reader-shelf-spine')).toHaveCount(0);await expect(page.locator('.reader-shelf-next')).toHaveText('Добавьте первый комикс');
 await setLibrary(page,0);await expect(page.locator('.reader-shelf-spine')).toHaveCount(1);
 await setLibrary(page,1487);await expect(page.locator('.reader-shelf-spine')).toHaveCount(3);await expect(page.locator('.reader-shelf-next')).toHaveText('До уровня 4 — 13 страниц');
 await expect(page.locator('#stats-title')).toHaveClass('sr-only');
 const stats=await page.locator('.library-statistics').boundingBox(),resume=await page.locator('.library-resume-section').boundingBox();expect(stats!.y+stats!.height).toBeLessThan(resume!.y);
 await setLibrary(page,99999);await expect(page.locator('.reader-shelf-spine')).toHaveCount(49);await expect(page.locator('.reader-shelf-next')).toHaveText('До уровня 50 — 1 страница');
 await setLibrary(page,100000);await expect(page.locator('.reader-shelf-spine')).toHaveCount(50);await expect(page.locator('.reader-shelf-next')).toHaveText('Полка собрана');
 await setLibrary(page,120000);await expect(page.locator('.reader-shelf-spine')).toHaveCount(50);await expect(page.locator('.library-stats')).toContainText('120');
});

test('fifty distinct image slices fit the mini screen and remain available offline',async({page,context})=>{
 await page.goto('/');await expect(page.locator('.app')).toBeVisible();await setLibrary(page,100000);
 const spines=page.locator('.reader-shelf-spine');await expect(spines).toHaveCount(50);
 const slices=await spines.evaluateAll(els=>els.map(el=>({image:getComputedStyle(el).backgroundImage,position:getComputedStyle(el).backgroundPosition,animation:getComputedStyle(el).animationName})));
 expect(new Set(slices.map(s=>s.position)).size).toBe(50);expect(new Set(slices.map(s=>s.image)).size).toBe(1);expect(slices[0].position).toBe('0% 100%');expect(slices.at(-1)!.position).toBe('100% 100%');
 const url=await spines.first().evaluate(el=>getComputedStyle(el).backgroundImage.slice(5,-2));
 for(const [width,height] of [[375,812],[320,568],[812,375]]){
  await page.setViewportSize({width,height});
  const books=await page.locator('.reader-shelf-books').boundingBox(),first=await spines.first().boundingBox(),last=await spines.last().boundingBox();
  expect(Math.abs(first!.x-books!.x)).toBeLessThan(1);expect(Math.abs(last!.x+last!.width-books!.x-books!.width)).toBeLessThan(1);expect(first!.height/first!.width).toBeGreaterThan(10);
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  const nav=await page.locator('.app-nav').boundingBox();expect(nav!.y+nav!.height).toBeLessThanOrEqual(height);
  for(const item of await page.locator('.app-nav > *').all())await expect(item).toBeInViewport({ratio:1});
 }
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);
 await expect.poll(()=>page.evaluate(async(url)=>Boolean(await caches.match(url)),url)).toBe(true);
 await context.setOffline(true);await page.reload();await expect(spines).toHaveCount(50);
 expect(await page.evaluate(url=>new Promise<boolean>(resolve=>{const image=new Image();image.onload=()=>resolve(image.naturalWidth>1000);image.onerror=()=>resolve(false);image.src=url;}),url)).toBe(true);
 await expect(page.locator('.reader-shelf-spine[data-new]')).toHaveCount(0);
});

test('reduced motion suppresses shelf animations and search restores the same earned state',async({page})=>{
 await page.goto('/');await expect(page.locator('.app')).toBeVisible();
 await page.evaluate(()=>sessionStorage.setItem('comics-shelf-seen-v1','0'));
 await page.emulateMedia({reducedMotion:'reduce'});await setLibrary(page,1487,true,'full');
 expect(await page.locator('.reader-shelf-spine').evaluateAll(els=>els.every(el=>getComputedStyle(el).animationName==='none'))).toBe(true);
 await page.getByRole('button',{name:'Открыть поиск',exact:true}).click();await page.getByRole('searchbox',{name:'Поиск комиксов'}).fill('История');await expect(page.locator('.reader-shelf')).toHaveCount(0);
 await page.getByRole('button',{name:'Закрыть поиск',exact:true}).click();await expect(page.locator('.reader-shelf-spine')).toHaveCount(3);
});
