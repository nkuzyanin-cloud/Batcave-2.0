import {expect,type Page} from './runtime';
import {readFileSync} from 'node:fs';
export async function seedSeries(page:Page){
  await page.goto('/');await expect(page.locator('.app')).toBeVisible();
  const file=readFileSync('tests/fixtures/sample.cbz').toString('base64');
  const cover=readFileSync('tests/fixtures/cover-walking-dead.webp').toString('base64');
  await page.evaluate(async({file,cover})=>{
    const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
    const tx=db.transaction(['comics','config','assets'],'readwrite');tx.objectStore('comics').clear();
    tx.objectStore('config').put([{id:'twd',title:'Ходячие мертвецы. Делюкс',chapters:[{id:'a',title:'Дни минувшего будущего'},{id:'b',title:'Мили позади'},{id:'c',title:'Безопасность за решёткой'}],updatedAt:0}],'reading-universes-v1');
    tx.objectStore('config').put({mode:'single',motion:'full',direction:'ltr',readerTheme:'black',doubleTap:true,showPage:true,cropMargins:false,panelOpacity:.75,panelPageFirst:false,panelPageLast:false,groupSeries:false,sort:'added',roadmapEra:'a'},'settings');
    for(let i=0;i<6;i++)tx.objectStore('comics').put({id:'c'+i,title:'Ходячие мертвецы. Делюкс. Выпуск '+(i+1),series:'TWD',authors:'',year:null,addedAt:i+1,updatedAt:i+1,physical:'unknown',edition:'',publisher:'',editionYear:null,note:'',rating:i===0?5:0,completed:i!==1,page:i===1?0:2,pageCount:3,visited:i===1?[]:[0,1,2],seconds:i===0?660:100,lastOpened:i+1,tone:'#52616b',universeId:'twd',era:'a',inRoadmap:true,digital:{assetId:'comic-file',format:'cbz',name:'test.cbz',size:100,fingerprint:'a'.repeat(64)},coverId:'test-cover'});
    for(const [id,data,type] of [['comic-file',file,'application/zip'],['test-cover',cover,'image/webp']])tx.objectStore('assets').put({id,blob:new Blob([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],{type})});
    await new Promise<void>((r,j)=>{tx.oncomplete=()=>r();tx.onerror=()=>j(tx.error);});db.close();
  },{file,cover});
  await page.reload();await expect(page.getByRole('button',{name:/Открыть серию: Ходячие/})).toBeVisible();
  for(let n=0;n<12;n++){const close=page.getByRole('button',{name:'Скрыть уведомление о достижении'});try{await close.waitFor({state:'visible',timeout:200});await close.click();}catch{break;}}
  await page.getByRole('button',{name:/Открыть серию: Ходячие/}).click();await expect(page.locator('.series-timeline-entry')).toHaveCount(6);
}
export async function record(page:Page,id='c0') {return page.evaluate(async(id)=>{const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const req=db.transaction('comics').objectStore('comics').get(id);return await new Promise<any>(r=>req.onsuccess=()=>{db.close();r(req.result);});},id);}

