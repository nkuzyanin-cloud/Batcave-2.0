import {test,expect,type Page} from './runtime';
import {seedSeries,record} from './series-fixture';
import {mkdirSync} from 'node:fs';

async function saveAward(page:Page,tier:string,pending:string[][]=[]){
 await page.evaluate(async({tier,pending})=>{
  const q=indexedDB.open('batcave-reader');
  const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
  const tx=db.transaction('config','readwrite');
  tx.objectStore('config').put({version:2,initializedAt:1,earned:[{id:`rank-${tier}`,at:123}],pending},'achievements-v2');
  await new Promise<void>((r,j)=>{tx.oncomplete=()=>r();tx.onerror=()=>j(tx.error);});db.close();
  window.dispatchEvent(new Event('batcave-achievements'));
 },{tier,pending});
}

test('each rank uses the profile book; replay fits mobile and landscape and restores focus',async({page,context})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await seedSeries(page);const before=await record(page);
 await page.getByRole('link',{name:'Открыть профиль',exact:true}).click();
 const cases=[['bronze','Бронза','1 000','5','8 ч'],['silver','Серебро','3 000','20','25 ч'],['gold','Золото','8 000','50','65 ч'],['platinum','Платина','18 000','100','150 ч']];
 mkdirSync('../celebration-qa',{recursive:true});
 for(const [tier,name,pages,stories,hours] of cases){
  await saveAward(page,tier);
  const replay=page.getByRole('button',{name:`Посмотреть награду: ${name}`,exact:true});
  await expect(replay).toBeVisible();const src=await replay.locator('img').getAttribute('src');
  await replay.click();const dialog=page.getByRole('dialog',{name:'Новый ранг',exact:true});
  await expect(dialog.locator('.rank-celebration-name')).toHaveText(name);
  await expect(dialog.locator('img')).toHaveAttribute('src',src!);
  await expect.poll(()=>dialog.locator('img').evaluate((img:HTMLImageElement)=>img.complete&&img.naturalWidth>0)).toBe(true);
  await expect(dialog.locator('dd')).toHaveText([pages,stories,hours]);
  await expect(dialog).not.toContainText('Новая глава');await expect(dialog).not.toContainText('Следующий ранг');
  for(const [w,h] of [[320,568],[375,812],[812,375]]){
   await page.setViewportSize({width:w,height:h});
   const button=dialog.getByRole('button',{name:'Продолжить',exact:true});
   await expect(button).toBeInViewport({ratio:1});
   const box=await dialog.boundingBox();expect(box!.x).toBeGreaterThanOrEqual(0);expect(box!.y).toBeGreaterThanOrEqual(0);
   expect(box!.x+box!.width).toBeLessThanOrEqual(w);expect(box!.y+box!.height).toBeLessThanOrEqual(h);
   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  }
  await page.setViewportSize({width:375,height:812});
  // Settle the entrance, then capture the actual app rather than a mockup.
  await page.waitForTimeout(1200);await page.screenshot({path:`../celebration-qa/${tier}.png`});
  await page.keyboard.press('Escape');await expect(dialog).toHaveCount(0);await expect(replay).toBeFocused();
 }
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();
 await page.getByRole('button',{name:'Посмотреть награду: Платина',exact:true}).click();
 await expect.poll(()=>page.locator('.rank-celebration img').evaluate((img:HTMLImageElement)=>img.complete&&img.naturalWidth>0)).toBe(true);
 await page.getByRole('button',{name:'Продолжить',exact:true}).click();expect(await record(page)).toEqual(before);expect(errors).toEqual([]);
});

test('rank celebration waits for the reader, remains until dismissed, and does not repeat after restart',async({page})=>{
 await seedSeries(page);
 await page.getByRole('button',{name:/^Читать: Ходячие.*Выпуск 2/}).click();
 await expect(page.locator('.reader canvas').first()).toBeVisible();
 await saveAward(page,'silver',[['rank-bronze','rank-silver']]);
 await expect(page.locator('.rank-celebration')).toHaveCount(0);
 await page.evaluate(()=>location.hash='/library');
 const dialog=page.getByRole('dialog',{name:'Новый ранг',exact:true});
 await expect(dialog.locator('.rank-celebration-name')).toHaveText('Серебро');
 await page.waitForTimeout(4700);await expect(dialog).toBeVisible();
 await page.keyboard.press('Tab');await expect(dialog.getByRole('button',{name:'Закрыть',exact:true})).toBeFocused();
 await page.keyboard.press('Tab');await expect(dialog.getByRole('button',{name:'Продолжить',exact:true})).toBeFocused();
 await page.keyboard.press('Tab');await expect(dialog.getByRole('button',{name:'Закрыть',exact:true})).toBeFocused();
 await dialog.getByRole('button',{name:'Продолжить',exact:true}).click();
 await page.reload();await expect(page.locator('.app')).toBeVisible();await expect(dialog).toHaveCount(0);
});

test('reduced motion and the app animation switch keep the dialog readable without moving effects',async({page})=>{
 await seedSeries(page);await page.getByRole('link',{name:'Открыть профиль',exact:true}).click();await saveAward(page,'gold');
 await page.emulateMedia({reducedMotion:'reduce'});
 await page.getByRole('button',{name:'Посмотреть награду: Золото',exact:true}).click();
 const book=page.locator('.rank-celebration-float');await expect(book).toHaveCSS('animation-name','none');
 await expect(page.locator('.rank-celebration-particles')).toBeHidden();
 await page.getByRole('button',{name:'Продолжить',exact:true}).click();
 await page.emulateMedia({reducedMotion:'no-preference'});
 await page.evaluate(async()=>{
  const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
  const tx=db.transaction('config','readwrite'),store=tx.objectStore('config'),req=store.get('settings');
  req.onsuccess=()=>store.put({...req.result,motion:'off'},'settings');
  await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();
 });
 await page.reload();await expect(page.locator('html')).toHaveAttribute('data-motion','off');
 await page.getByRole('button',{name:'Посмотреть награду: Золото',exact:true}).click();
 await expect(book).toHaveCSS('animation-name','none');await expect(page.locator('.rank-celebration-particles')).toBeHidden();
 await page.getByRole('button',{name:'Закрыть',exact:true}).click();
});
