import {test,expect,type Page} from './runtime';
import {readFileSync,mkdirSync} from 'node:fs';

async function seed(page:Page){
  await page.goto('/');await expect(page.locator('.app')).toBeVisible();
  const file=readFileSync('tests/fixtures/sample.cbz').toString('base64');
  const cover=readFileSync('tests/fixtures/cover-walking-dead.webp').toString('base64');
  await page.evaluate(async({file,cover})=>{
    const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
    const tx=db.transaction(['comics','config','assets'],'readwrite');tx.objectStore('comics').clear();
    tx.objectStore('config').put([{id:'twd',title:'Ходячие мертвецы. Делюкс',chapters:[{id:'a',title:'Дни минувшего будущего'},{id:'b',title:'Мили позади'},{id:'c',title:'Безопасность за решёткой'}],updatedAt:0}],'reading-universes-v1');
    tx.objectStore('config').put({mode:'single',motion:'full',direction:'ltr',readerTheme:'black',doubleTap:true,showPage:true,cropMargins:false,panelOpacity:.75,panelPageFirst:false,panelPageLast:false,groupSeries:false,sort:'added',roadmapEra:'a'},'settings');
    for(let i=0;i<6;i++)tx.objectStore('comics').put({id:'c'+i,title:'Ходячие мертвецы. Делюкс. Выпуск '+(i+1),series:'TWD',authors:'',year:null,addedAt:i+1,updatedAt:i+1,physical:'unknown',edition:'',publisher:'',editionYear:null,note:'',rating:i===0?5:0,completed:i!==1,page:i===1?0:2,pageCount:3,visited:i===1?[]:[0,1,2],seconds:i===0?660:100,lastOpened:i+1,tone:'#52616b',universeId:'twd',era:'a',inRoadmap:true,digital:{assetId:'comic-file',format:'cbz',name:'test.cbz',size:100,fingerprint:'a'.repeat(64)},coverId:'test-cover'});
    for(const [id,data,type] of [['comic-file',file,'application/zip'],['test-cover',cover,'image/webp']])tx.objectStore('assets').put({id,blob:new Blob([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],{type})});
    await new Promise<void>((r,j)=>{tx.oncomplete=()=>r();tx.onerror=()=>j(tx.error);});db.close();
  },{file,cover});
  await page.reload();await expect(page.getByRole('button',{name:/Открыть серию: Ходячие/})).toBeVisible();
  for(let n=0;n<12;n++){const close=page.getByRole('button',{name:'Скрыть уведомление о достижении'});try{await close.waitFor({state:'visible',timeout:200});await close.click();}catch{break;}}
  await page.getByRole('button',{name:/Открыть серию: Ходячие/}).click();await expect(page.locator('.series-timeline-entry')).toHaveCount(6);
}
async function record(page:Page,id='c0') {return page.evaluate(async(id)=>{const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const req=db.transaction('comics').objectStore('comics').get(id);return await new Promise<any>(r=>req.onsuccess=()=>{db.close();r(req.result);});},id);}

// Native back uses the same history traversal as Safari's edge-back gesture.
test('completed comic opens saved result; closing and native back never reopen the reader',async({page})=>{
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await seed(page);
  const before=await record(page);
  await page.locator('[data-comic-id="c0"] .series-comic-copy').click();
  await expect(page.getByRole('heading',{name:'История завершена',exact:true})).toBeVisible();
  await expect(page.locator('.summary-stats')).toContainText('11 м');await expect(page.locator('.summary-stats')).toContainText('3 / 3');
  expect(await record(page)).toEqual(before);await expect(page.locator('.reader canvas')).toHaveCount(0);
  await page.reload();await expect(page.locator('.reading-summary')).toBeVisible();expect(await record(page)).toEqual(before);
  await page.getByRole('button',{name:'Вернуться в библиотеку',exact:true}).click();await expect(page).toHaveURL(/#\/library\/twd$/);
  await page.goBack();await expect(page.getByRole('heading',{name:'Моя библиотека',exact:true})).toBeVisible();
  await page.getByRole('button',{name:/Открыть серию: Ходячие/}).click();await page.locator('[data-comic-id="c0"] .series-comic-copy').click();
  await page.getByRole('button',{name:'К последней странице',exact:true}).click();await expect(page.locator('.reader canvas').first()).toBeVisible();
  await expect(page.getByRole('button',{name:'Все страницы: 3 из 3'})).toBeVisible();
  await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();await expect(page).toHaveURL(/#\/library\/twd$/);
  await page.goBack();await expect(page.getByRole('heading',{name:'Моя библиотека',exact:true})).toBeVisible();expect(errors).toEqual([]);
});

test('unfinished reading, completion, saved rating and summary reopen stay connected',async({page})=>{
  await seed(page);await page.locator('[data-comic-id="c1"] .series-comic-copy').click();await expect(page.locator('.reader canvas').first()).toBeVisible();
  await page.locator('.free-page-stage').tap({position:{x:170,y:260}});
  for(let n=2;n<=3;n++){await page.getByRole('button',{name:'Следующая страница',exact:true}).click();await expect(page.getByRole('button',{name:`Все страницы: ${n} из 3`})).toBeVisible();await expect.poll(async()=>(await record(page,'c1')).visited.length).toBe(n);}
  await page.getByRole('button',{name:'Завершить чтение',exact:true}).click();await expect(page.locator('.reading-summary')).toBeVisible();
  await page.getByRole('button',{name:'Оценка 4',exact:true}).click();await expect.poll(async()=>(await record(page,'c1')).rating).toBe(4);
  await page.getByRole('button',{name:'Вернуться в библиотеку',exact:true}).click();await expect(page).toHaveURL(/#\/library\/twd$/);
  await page.locator('[data-comic-id="c1"] .series-comic-copy').click();await expect(page.locator('.reading-summary')).toBeVisible();await expect(page.getByRole('button',{name:'Оценка 4',exact:true})).toHaveAttribute('aria-pressed','true');
  await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();await expect(page).toHaveURL(/#\/library\/twd$/);await page.goBack();await expect(page).toHaveURL(/(?:#\/library)?$/);
});

test('editor stays within the phone while focusing and scrolling fields; shell and compact empty chapters stay visible',async({page,context,browserName})=>{
  await seed(page);mkdirSync('../qa-1.19',{recursive:true});
  await page.screenshot({path:'../qa-1.19/series-top.png'});
  const footer=page.locator('.series-footer');await expect(footer).toBeInViewport();
  await page.locator('.screen').evaluate(el=>el.scrollTop=el.scrollHeight);await expect(footer).toBeInViewport();
  await expect(page.locator('.route-section-vacant')).toHaveCount(2);
  expect(await page.locator('.route-section-vacant').first().evaluate(el=>el.getBoundingClientRect().height)).toBeLessThan(90);
  await page.screenshot({path:'../qa-1.19/series-bottom.png'});
  await page.locator('[data-comic-id="c0"]').scrollIntoViewIfNeeded();await page.getByRole('button',{name:'Меню выпуска: Ходячие мертвецы. Делюкс. Выпуск 1',exact:true}).click();await page.getByRole('button',{name:'Редактировать',exact:true}).click();
  for(const width of [375,320,390]){
    await page.setViewportSize({width,height:812});
    const dialog=page.getByRole('dialog',{name:'Редактирование',exact:true});
    for(const label of ['Название','Авторы','Год произведения']){
      const field=dialog.getByLabel(label,{exact:true});await field.focus();
      const bounds=await dialog.evaluate(el=>({left:el.getBoundingClientRect().left,right:el.getBoundingClientRect().right,scrollWidth:el.scrollWidth,width:el.clientWidth,x:el.scrollLeft}));
      expect(bounds.left).toBeGreaterThanOrEqual(0);expect(bounds.right).toBeLessThanOrEqual(width);expect(bounds.scrollWidth).toBe(bounds.width);expect(bounds.x).toBe(0);
    }
  }
  if(browserName==='chromium'){
    const cdp=await context.newCDPSession(page);
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{id:1,x:250,y:500}]});
    await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{id:1,x:80,y:505}]});
    await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
    expect(await page.getByRole('dialog').evaluate(el=>({x:el.scrollLeft,left:el.getBoundingClientRect().left}))).toEqual({x:0,left:0});
    expect(await page.evaluate(()=>scrollX)).toBe(0);
  }
  await page.getByRole('button',{name:'Бумажная версия',exact:true}).click();
  await expect(page.getByRole('dialog').locator('fieldset.editor-format')).toBeInViewport();
  await page.screenshot({path:'../qa-1.19/editor.png'});
  await page.getByLabel('Название',{exact:true}).fill('Изменённый выпуск');await page.getByRole('button',{name:'Сохранить',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);expect((await record(page)).title).toBe('Изменённый выпуск');
});

test('result and return survive offline reload; direct reader link closes to home',async({page,context})=>{
  await seed(page);await page.waitForFunction(()=>!!navigator.serviceWorker.controller);
  await page.locator('[data-comic-id="c0"] .series-comic-copy').click();await expect(page.locator('.reading-summary')).toBeVisible();
  await context.setOffline(true);await page.reload();await expect(page.locator('.reading-summary')).toBeVisible();await page.getByRole('button',{name:'Вернуться в библиотеку',exact:true}).click();await expect(page).toHaveURL(/#\/library\/twd$/);await page.goBack();await expect(page.getByRole('heading',{name:'Моя библиотека',exact:true})).toBeVisible();
  await page.evaluate(()=>history.replaceState(null,'','#/reader/c0'));await page.reload();await expect(page.locator('.reading-summary')).toBeVisible();await page.getByRole('button',{name:'Вернуться в библиотеку',exact:true}).click();await expect(page).toHaveURL(/#\/library$/);
});
