import {test,expect} from './runtime';
import {seedSeries} from './series-fixture';
import {mkdirSync} from 'node:fs';

test('achievements are a routed page with filters, detail history and offline restart',async({page,context})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await seedSeries(page);await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();
 await expect(page.locator('.library-home .library-achievements')).toHaveCount(0);
 const stats=await page.locator('.library-statistics').boundingBox(),resume=await page.locator('.library-resume-section').boundingBox();expect(stats!.y+stats!.height).toBeLessThan(resume!.y);
 await page.getByRole('link',{name:'Открыть достижения',exact:true}).click();
 await expect(page).toHaveURL(/#\/achievements$/);await expect(page.getByRole('heading',{name:'Достижения',exact:true})).toBeVisible();
 await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('body')).not.toHaveClass(/modal/);
 const view=page.locator('.achievements-page'),total=await view.locator('.award-tile').count();expect(total).toBeGreaterThan(40);
 await expect(page.getByRole('link',{name:'Открыть достижения',exact:true})).toHaveAttribute('aria-current','page');
 await view.getByRole('button',{name:'Открыты',exact:true}).click();const earned=await view.locator('.award-tile').count();expect(earned).toBeGreaterThan(0);expect(earned).toBeLessThan(total);
 await view.getByRole('button',{name:'В процессе',exact:true}).click();await expect(view.locator('.award-tile')).toHaveCount(total-earned);
 await view.locator('[data-achievement="pages-1000"]').click();await expect(page).toHaveURL(/#\/achievements\/pages-1000$/);
 await expect(view.locator('.award-detail')).toContainText('В глубине сюжета');await page.goBack();
 await expect(view.getByRole('button',{name:'В процессе',exact:true})).toHaveAttribute('aria-pressed','true');await expect(view.locator('.award-tile')).toHaveCount(total-earned);
 await view.getByRole('button',{name:'Все',exact:true}).click();await view.locator('[data-achievement="first"]').click();
 await expect(view.locator('.award-detail')).toContainText('Достижение получено');await page.getByRole('button',{name:'Назад',exact:true}).click();await expect(view.locator('.award-tile')).toHaveCount(total);
 await page.getByRole('button',{name:'Открыть настройки',exact:true}).click();await page.getByRole('button',{name:'Назад',exact:true}).click();await expect(page).toHaveURL(/#\/achievements$/);
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();await expect(view.locator('.award-tile')).toHaveCount(total);
 await view.locator('[data-achievement="first"]').click();await page.reload();await expect(view.locator('.award-detail')).toContainText('Достижение получено');expect(errors).toEqual([]);
});

test('achievement page and detail fit safe areas and keep the last item above the footer',async({page})=>{
 await seedSeries(page);await page.getByRole('link',{name:'Открыть достижения',exact:true}).click();
 await page.evaluate(()=>{document.documentElement.style.setProperty('--safe-top','44px');document.documentElement.style.setProperty('--safe-bottom','34px');});
 for(const [width,height] of [[375,812],[320,568],[812,375]]){
  await page.setViewportSize({width,height});await page.locator('.award-tile').last().scrollIntoViewIfNeeded();
  const nav=page.locator('.app-nav'),main=page.locator('main.screen');
  const n=await nav.boundingBox(),m=await main.boundingBox(),last=await page.locator('.award-tile').last().boundingBox();
  expect(m!.y+m!.height).toBeCloseTo(n!.y,0);expect(n!.y+n!.height).toBeLessThanOrEqual(height);expect(last!.y+last!.height).toBeLessThanOrEqual(n!.y);
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  for(const item of await nav.locator(':scope > *').all())await expect(item).toBeInViewport({ratio:1});
 }
 await page.setViewportSize({width:375,height:812});await page.locator('.screen').evaluate(el=>el.scrollTop=0);mkdirSync('../qa-1.20.3',{recursive:true});await page.screenshot({path:'../qa-1.20.3/achievements.png'});
 await page.locator('[data-achievement="first"]').click();await page.screenshot({path:'../qa-1.20.3/achievement-detail.png'});
});

test('notification waits behind reader and opens the achievement page',async({page})=>{
 await seedSeries(page);await page.getByRole('button',{name:/^Читать: Ходячие.*Выпуск 2/}).click();await expect(page.locator('.reader canvas').first()).toBeVisible();
 await page.evaluate(async()=>{
  const q=indexedDB.open('batcave-reader'),db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
  const tx=db.transaction('config','readwrite'),store=tx.objectStore('config'),req=store.get('achievements-v2');
  req.onsuccess=()=>{const state=req.result;if(!state.earned.some((a:{id:string})=>a.id==='first'))state.earned.push({id:'first',at:Date.now()});state.pending=[['first']];store.put(state,'achievements-v2');};
  await new Promise<void>((r,j)=>{tx.oncomplete=()=>r();tx.onerror=()=>j(tx.error);});db.close();window.dispatchEvent(new Event('batcave-achievements'));
 });
 await expect(page.locator('.award-toast')).not.toBeVisible();await page.evaluate(()=>location.hash='/library');
 await page.getByRole('button',{name:'Открыть достижение: Первая история',exact:true}).click();
 await expect(page).toHaveURL(/#\/achievements\/first$/);await expect(page.locator('[data-achievement-detail="first"]')).toContainText('Достижение получено');await expect(page.getByRole('dialog')).toHaveCount(0);
});
