import {test,expect} from '@playwright/test';

async function seed(page:import('@playwright/test').Page) {
  await page.goto('/');await expect(page.locator('.app')).toBeVisible();
  await page.evaluate(async() => {
    const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(resolve=>q.onsuccess=()=>resolve(q.result));
    const tx=db.transaction(['comics','config'],'readwrite');tx.objectStore('config').delete('achievements-v2');
    for(let i=0;i<5;i++) {
      const pages=i===4?167:200;
      tx.objectStore('comics').put({id:`award-${i}`,title:['Бэтмен. Год первый','Человек, который смеётся','Долгий Хэллоуин','Тёмная победа','Чёрное и белое'][i],series:'DC',authors:'',year:1987+i,addedAt:100+i,updatedAt:200+i,physical:i<2?'yes':'no',edition:'',publisher:'',editionYear:null,note:'',rating:4,completed:true,completedAt:200+i,inRoadmap:true,readDigitally:true,page:pages-1,pageCount:pages,visited:Array.from({length:pages},(_,p)=>p),seconds:9120,lastOpened:1,digitalFingerprint:String(i+1).repeat(64),tone:'#79a9be'});
    }
    await new Promise<void>((resolve,reject)=>{tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});db.close();
  });
  await page.goto('/#/profile');await page.reload();await expect(page.locator('.profile-era-hero')).toBeVisible();
}
test('collectible profile, filters, conditions, narrow screens and offline assets',async({page,context})=>{
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await seed(page);
  await expect(page.locator('.award-toast')).toContainText('Зачтено наград');
  await page.getByRole('button',{name:'Скрыть уведомление о достижении'}).click();
  await expect(page.locator('.profile-era-stop')).toHaveCount(3);
  await page.screenshot({path:'test-results/achievements-profile.png'});
  await page.locator('.profile-recent-awards .profile-section-heading button').click();
  const dialog=page.getByRole('dialog',{name:'Достижения',exact:true});
  await expect(dialog.locator('.award-tile')).toHaveCount(51);
  await dialog.evaluate(el=>Promise.all(el.getAnimations({subtree:true}).map(a=>a.finished)));
  const before=await dialog.locator('header').boundingBox();
  await dialog.locator('.sheet-scroll').evaluate(el=>el.scrollTop=el.scrollHeight);
  expect((await dialog.locator('header').boundingBox())!.y).toBeCloseTo(before!.y,1);
  await dialog.locator('.sheet-scroll').evaluate(el=>el.scrollTop=0);
  await page.screenshot({path:'test-results/achievements-collection.png'});
  await dialog.getByRole('button',{name:'Получены',exact:true}).click();
  const count=await dialog.locator('.award-tile').count();expect(count).toBeGreaterThan(0);expect(count).toBeLessThan(20);
  await dialog.getByRole('button',{name:'В процессе',exact:true}).click();
  await expect(dialog.locator('.award-tile')).toHaveCount(51-count);
  await dialog.getByRole('button',{name:'Все',exact:true}).click();
  await dialog.locator('[data-achievement="pages-1000"]').click();
  await expect(dialog.locator('.award-detail')).toContainText('В глубине сюжета');
  await expect(dialog.locator('.award-detail')).toContainText('967');
  await page.screenshot({path:'test-results/achievements-detail.png'});
  await dialog.getByRole('button',{name:'К коллекции',exact:true}).click();
  await page.setViewportSize({width:320,height:568});
  const box=await dialog.boundingBox();expect(box!.x).toBeGreaterThanOrEqual(0);expect(box!.x+box!.width).toBeLessThanOrEqual(320);
  expect(await dialog.evaluate(el=>el.scrollWidth<=el.clientWidth+1)).toBe(true);
  await dialog.getByRole('button',{name:'Закрыть',exact:true}).click();
  expect(await page.locator('.app main').evaluate(el=>el.scrollWidth<=el.clientWidth+1)).toBe(true);
  await page.reload();await expect(page.locator('.app')).toBeVisible();await expect(page.locator('.award-toast')).not.toBeVisible();
  await page.evaluate(async()=>{await navigator.serviceWorker.ready;});
  await page.waitForFunction(()=>!!navigator.serviceWorker.controller);
  await context.setOffline(true);await page.reload();await expect(page.locator('.profile-era-stop')).toHaveCount(3);
  await page.locator('.profile-recent-awards .profile-section-heading button').click();await expect(dialog.locator('.award-tile')).toHaveCount(51);
  await expect(dialog.locator('.award-vector')).toHaveCount(51);
  expect(errors).toEqual([]);
});

test('new unlock queues behind the reader and toast opens its achievement',async({page})=>{
  await page.goto('/');await expect(page.locator('.app')).toBeVisible();
  await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();
  await page.getByRole('button',{name:/Загрузить комикс/}).click();
  await page.locator('[data-testid="comic-file-input"]').setInputFiles('tests/fixtures/sample.cbz');
  await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();
  
  await page.getByLabel('Название',{exact:true}).fill('Award reader');
  await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();
  await expect(page.locator('.award-toast')).toContainText('Первый файл');
  await page.getByRole('button',{name:'Скрыть уведомление о достижении'}).click();
  await page.getByRole('button',{name:/^Читать: Award reader/}).click();
  await expect(page.locator('.reader canvas')).toBeVisible();
  await page.evaluate(async()=>{
    const q=indexedDB.open('batcave-reader'),db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
    const tx=db.transaction('config','readwrite'),store=tx.objectStore('config');
    const state=await new Promise<any>(r=>{const req=store.get('achievements-v2');req.onsuccess=()=>r(req.result);});
    state.earned.push({id:'first',at:Date.now()});state.pending.push(['first']);store.put(state,'achievements-v2');
    await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();window.dispatchEvent(new Event('batcave-achievements'));
  });
  await expect(page.locator('.award-toast')).not.toBeVisible();
  await page.evaluate(()=>{location.hash='/profile';});
  await expect(page.locator('.award-toast')).toContainText('Первый патруль');
  await page.getByRole('button',{name:'Открыть достижение: Первый патруль',exact:true}).click();
  await expect(page.locator('[data-achievement-detail="first"]')).toContainText('Достижение получено');
  await page.getByRole('dialog',{name:'Достижения',exact:true}).evaluate(el=>Promise.all(el.getAnimations({subtree:true}).map(a=>a.finished)));
  await page.screenshot({path:'test-results/achievements-notification-detail.png'});
});


test('era route is fixed explicitly and unlocking waits until its dialog closes',async({page})=>{
  await seed(page);
  await expect(page.locator('.award-toast')).toBeVisible();
  await page.getByRole('button',{name:'Скрыть уведомление о достижении'}).click();
  await expect(page.locator('.profile-section-heading').filter({hasText:'Путь Бэтмена'})).toContainText('0 / 11');
  await page.getByRole('button',{name:'Эра: Ранние годы',exact:true}).click();
  const dialog=page.getByRole('dialog',{name:'Путь Бэтмена',exact:true});
  await expect(dialog.locator('.era-plan-books li')).toHaveCount(5);
  await dialog.getByRole('button',{name:'Закрепить маршрут эры',exact:true}).click();
  await expect(dialog.locator('.era-plan-earned')).toContainText('Награда за эру получена');
  await expect(page.locator('.award-toast')).not.toBeVisible();
  await dialog.evaluate(el=>Promise.all(el.getAnimations({subtree:true}).map(a=>a.finished)));
  await page.screenshot({path:'test-results/era-route.png'});
  await dialog.getByRole('button',{name:'Все эры',exact:true}).click();
  await expect(dialog.locator('[data-era]')).toHaveCount(11);
  await expect(dialog.locator('[data-era="early"]')).toContainText('Эра пройдена');
  await dialog.getByRole('button',{name:'Закрыть',exact:true}).click();
  await expect(page.locator('.award-toast')).toContainText('Ранние годы');
  await page.getByRole('button',{name:'Скрыть уведомление о достижении'}).click();
  await expect(page.locator('.profile-section-heading').filter({hasText:'Путь Бэтмена'})).toContainText('1 / 11');
  await page.getByRole('button',{name:'Продолжить путь',exact:true}).click();
  await expect(page.locator('.app')).toHaveClass(/tab-library/);
});
