import {test,expect,type Page} from './runtime';
import {seedSeries,record} from './series-fixture';
import {mkdirSync} from 'node:fs';

async function seed(page:Page){
 await seedSeries(page);
 await page.evaluate(async()=>{
  const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const tx=db.transaction(['comics','config'],'readwrite');
  const c=tx.objectStore('comics'),config=tx.objectStore('config');
  // One collected comic next to a six-issue group; include an empty section.
  const req=c.get('c0');req.onsuccess=()=>c.put({...req.result,id:'volume',era:'b',title:'Том целиком',rating:4});
  config.put([],'route-full-issue-lists-v1:twd');config.put([],'route-disclosures-v1:twd');
  await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();
 });await page.reload();await expect(page.locator('.route-volume')).toHaveCount(3);
}
const tile=(page:Page,id:string)=>page.locator(`[data-route-section="${id}"]`);
const issues=(page:Page,id:string)=>page.locator(`[data-route-issue-section="${id}"]`);
async function move(page:Page,id:string,era:string){
 await page.locator(`[data-comic-id="${id}"]`).getByRole('button',{name:/Меню выпуска/}).click();await page.getByRole('button',{name:'Переместить',exact:true}).click();
 await page.getByLabel('Раздел назначения').selectOption(era);await page.getByRole('dialog').getByRole('button',{name:'Переместить',exact:true}).click();
}

test('two-column layout, full-width compact preview, complete lists, search and offline disclosures',async({page,context})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await seed(page);const before=await record(page);
 await expect(issues(page,'a').locator('.series-timeline-entry')).toHaveCount(3);
 const a=await tile(page,'a').boundingBox(),b=await tile(page,'b').boundingBox(),body=await issues(page,'a').boundingBox();
 expect(Math.abs(a!.y-b!.y)).toBeLessThan(1);expect(b!.x).toBeGreaterThan(a!.x+a!.width);expect(body!.width).toBeGreaterThan(a!.width*1.9);expect(body!.y).toBeGreaterThan(b!.y+b!.height-1);
 await expect(page.getByText('Добавить ещё',{exact:true})).toHaveCount(0);
 await expect(tile(page,'b').getByRole('img',{name:'Оценка: 4 из 5'})).toBeVisible();
 await issues(page,'a').getByRole('button',{name:'Все выпуски (6)',exact:true}).click();await expect(issues(page,'a').locator('.series-timeline-entry')).toHaveCount(6);
 await expect.poll(()=>page.evaluate(async()=>{const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const req=db.transaction('config').objectStore('config').get('route-full-issue-lists-v1:twd');return await new Promise(r=>req.onsuccess=()=>{db.close();r(req.result);});})).toEqual(['a']);
 await page.reload();await expect(issues(page,'a').locator('.series-timeline-entry')).toHaveCount(6);
 await tile(page,'a').getByRole('button',{name:/Свернуть раздел/}).click();await expect(issues(page,'a')).toBeHidden();
 await page.getByRole('button',{name:'Меню серии',exact:true}).click();await page.getByRole('button',{name:'Открыть поиск',exact:true}).click();await page.getByRole('searchbox').fill('Выпуск 6');
 await expect(issues(page,'a').locator('[data-comic-id="c5"]')).toBeVisible();await expect(issues(page,'a').locator('.series-timeline-entry')).toHaveCount(1);
 await page.getByRole('button',{name:'Закрыть поиск',exact:true}).click();await expect(issues(page,'a')).toBeHidden();
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();await expect(tile(page,'a').getByRole('button',{name:/Раскрыть раздел/})).toHaveAttribute('aria-expanded','false');
 expect(await record(page)).toEqual(before);expect(errors).toEqual([]);
});

test('single opens the saved result, adding via menu preserves section, moving changes the tile type, deletion is explicit',async({page})=>{
 await seed(page);const original=await record(page,'volume');
 await tile(page,'b').getByRole('button',{name:'Читать: Том целиком',exact:true}).click();await expect(page.locator('.reading-summary')).toBeVisible();await page.getByRole('button',{name:'Вернуться в библиотеку',exact:true}).click();
 await tile(page,'b').getByRole('button',{name:'Меню выпуска: Том целиком',exact:true}).click();await page.getByRole('button',{name:'Добавить комикс в раздел',exact:true}).click();await page.getByRole('button',{name:/Создать карточку/}).click();await expect(page.getByLabel('Эра комикса')).toHaveValue('b');await page.getByRole('button',{name:'Закрыть',exact:true}).click();
 await move(page,'c0','b');await expect(tile(page,'b').getByRole('button',{name:/Свернуть раздел/})).toBeVisible();await expect(issues(page,'b').locator('.series-timeline-entry')).toHaveCount(2);
 await move(page,'c0','a');await expect(tile(page,'b').getByRole('button',{name:'Читать: Том целиком',exact:true})).toBeVisible();await expect(issues(page,'b')).toHaveCount(0);
 const after=await record(page,'volume');for(const key of ['visited','seconds','rating','page','completed','digital','coverId'])expect(after[key]).toEqual(original[key]);
 await tile(page,'b').getByRole('button',{name:/Меню выпуска/}).click();await page.getByRole('button',{name:'Удалить комикс',exact:true}).click();await page.getByRole('button',{name:'Отмена',exact:true}).click();expect(await record(page,'volume')).toEqual(after);
 await tile(page,'c').getByRole('button',{name:/Добавить комикс/}).click();await expect(page.getByRole('dialog')).toBeVisible();
});

test('small screens, long titles, keyboard disclosures and the existing series header stay usable',async({page})=>{
 await seed(page);mkdirSync('../gallery-qa',{recursive:true});
 for(const [width,height] of [[320,568],[375,812],[430,932],[812,375]]){
  await page.setViewportSize({width,height});await page.locator('.screen').evaluate(el=>el.scrollTop=0);
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  const a=await tile(page,'a').boundingBox(),b=await tile(page,'b').boundingBox();expect(Math.abs(a!.y-b!.y)).toBeLessThan(1);
  const ac=await tile(page,'a').locator('.cover').boundingBox(),bc=await tile(page,'b').locator('.cover').boundingBox();expect(ac!.width).toBeCloseTo(bc!.width,0);expect(ac!.height).toBeCloseTo(bc!.height,0);
  expect(await tile(page,'a').locator('.cover').evaluate(el=>el.getBoundingClientRect().width)).toBeLessThanOrEqual(118.1);
  await expect(page.locator('.app-nav')).toBeInViewport();
  await page.screenshot({path:`../gallery-qa/gallery-${width}.png`});
 }
 await page.setViewportSize({width:375,height:812});const open=tile(page,'a').getByRole('button',{name:/Свернуть раздел/});await open.focus();await page.keyboard.press('Space');await expect(issues(page,'a')).toBeHidden();await page.keyboard.press('Enter');await expect(issues(page,'a')).toBeVisible();
 expect(await page.locator('.app-header').evaluate(el=>getComputedStyle(el).backdropFilter)).toBe('none');
});

test('cover drag reorders inside a compact group and moves to a single volume without opening it',async({page,context,browserName})=>{
 test.skip(browserName!=='chromium','Native touch via CDP.');await seed(page);const before=await record(page,'c1');
 const cdp=await context.newCDPSession(page);await page.locator('[data-comic-id="c1"]').scrollIntoViewIfNeeded();
 const from=await page.locator('[data-comic-id="c1"] .series-cover-handle').boundingBox();
 await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{id:1,x:from!.x+10,y:from!.y+15}]});await expect(page.locator('[data-route-ghost]')).toBeVisible();
 const dest=await page.locator('[data-comic-id="c0"]').boundingBox();await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{id:1,x:dest!.x+60,y:dest!.y+8}]});await expect(page.locator('[data-comic-id="c0"]')).toHaveClass(/is-drop-before/);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
 await expect(issues(page,'a').locator('[data-comic-id]').first()).toHaveAttribute('data-comic-id','c1');await expect(page.getByRole('dialog')).toHaveCount(0);
 const after=await record(page,'c1');for(const key of ['visited','seconds','rating','page','completed','digital'])expect(after[key]).toEqual(before[key]);
});
