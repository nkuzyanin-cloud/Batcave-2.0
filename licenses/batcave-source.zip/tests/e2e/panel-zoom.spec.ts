import {test,expect,type Page} from './runtime';

async function open(page:Page){
 await page.goto('/');await expect(page.locator('.app')).toBeVisible();
 await page.evaluate(async()=>{
  const req=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>req.onsuccess=()=>r(req.result));
  const tx=db.transaction('config','readwrite'),settings=tx.objectStore('config').get('settings');
  settings.onsuccess=()=>tx.objectStore('config').put({...settings.result,mode:'panels',motion:'off',doubleTap:true,panelPageFirst:false,panelPageLast:false},'settings');
  await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();
 });await page.reload();
 await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Загрузить комикс/}).click();
 await page.getByTestId('comic-file-input').setInputFiles('tests/fixtures/tall-panel-zoom.cbz');
 await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();await page.getByLabel('Название',{exact:true}).fill('Высокие кадры');
 await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();await expect(page.locator('.modal')).not.toBeVisible();
 await page.getByRole('button',{name:/Все комиксы/}).click();await page.getByRole('button',{name:'Читать: Высокие кадры',exact:true}).click();
 await expect(page.getByTestId('panel-stage')).toHaveAttribute('aria-busy','false');
}
const scale=(page:Page)=>page.getByTestId('panel-camera').evaluate(el=>new DOMMatrixReadOnly(getComputedStyle(el).transform).a);
async function doubleTap(page:Page){const node=page.getByTestId('panel-scroll');const b=await node.boundingBox();const position={x:b!.width/2,y:b!.height/2};await node.tap({position});await node.tap({position});}

for(const size of [{width:375,height:812},{width:812,height:375}]){
 test(`tall frames really enlarge before and after a page change (${size.width}x${size.height})`,async({page})=>{
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await page.setViewportSize(size);await open(page);
  const before=await scale(page);await doubleTap(page);
  await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-zoom','1.7');
  await expect.poll(()=>scale(page)).toBeGreaterThan(before*1.6);
  await doubleTap(page);await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-zoom','1');
  await page.keyboard.press('ArrowRight');await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-panel','1');
  await page.keyboard.press('ArrowRight');await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-page','1');
  await expect(page.getByTestId('panel-stage')).toHaveAttribute('aria-busy','false');
  const next=await scale(page);await doubleTap(page);await expect(page.getByTestId('panel-stage')).toHaveAttribute('data-zoom','1.7');
  await expect.poll(()=>scale(page)).toBeGreaterThan(next*1.6);
  expect(await page.evaluate(()=>visualViewport?.scale)).toBe(1);expect(errors).toEqual([]);
 });
}

test('native touch drags vertically while zoomed, preserves the stop, and restores both coordinates',async({page,context,browserName})=>{
 test.skip(browserName!=='chromium','Multi-touch driven through Chromium CDP.');await page.setViewportSize({width:812,height:375});await open(page);
 const cdp=await context.newCDPSession(page),frame=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 const touch=async(type:string,points:any[])=>{await cdp.send('Input.dispatchTouchEvent',{type,touchPoints:points});await frame();};
 await doubleTap(page);const stage=page.getByTestId('panel-stage');
 await touch('touchStart',[{x:410,y:190,id:1}]);await touch('touchMove',[{x:410,y:240,id:1}]);await touch('touchEnd',[]);
 await expect.poll(async()=>Number(await stage.getAttribute('data-pan-y'))).toBeGreaterThan(40);
 await expect(stage).toHaveAttribute('data-page','0');await expect(stage).toHaveAttribute('data-panel','0');
 const before=Number(await stage.getAttribute('data-pan-y'));
 // Leave and reopen the book: vertical offsets must not disappear from bookmarks.
 await expect.poll(()=>page.evaluate(async()=>{
  const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
  const req=db.transaction('comics').objectStore('comics').getAll();const rows=await new Promise<any[]>(r=>req.onsuccess=()=>r(req.result));db.close();return rows[0].readerView?.zoom;
 })).toBe(1.7);
 await page.reload();await expect(page.getByTestId('panel-stage')).toHaveAttribute('aria-busy','false');
 await expect(stage).toHaveAttribute('data-zoom','1.7');await expect.poll(async()=>Number(await stage.getAttribute('data-pan-y'))).toBeCloseTo(before,0);
 // Pinch after reload must still increase the actual scale, not only its state.
 const old=await scale(page);await touch('touchStart',[{x:375,y:185,id:2},{x:435,y:185,id:3}]);
 await touch('touchMove',[{x:360,y:185,id:2},{x:450,y:185,id:3}]);await touch('touchEnd',[]);
 await expect.poll(()=>scale(page)).toBeGreaterThan(old*1.3);await expect(stage).toHaveAttribute('data-panel','0');
});
