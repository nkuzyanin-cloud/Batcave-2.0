import {test,expect} from './runtime';
import {readFileSync} from 'node:fs';
import {ZipReader,BlobReader,TextWriter,Uint8ArrayWriter,configure} from '@zip.js/zip.js';
configure({useWebWorkers:false});

test('raw CBZ imports without model requests and explains missing Studio metadata',async({page})=>{
 const failed:string[]=[],ai:string[]=[];page.on('pageerror',e=>failed.push(e.message));page.on('request',r=>{if(/panel-ai|auto-panels/.test(r.url()))ai.push(r.url())});
 await page.goto('/');await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Загрузить комикс/}).click();
 const path=process.env.QA_RAW_CBZ??'tests/fixtures/sample.cbz';await page.locator('[data-testid="comic-file-input"]').setInputFiles(path);await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();
 await expect(page.getByLabel('Автоматически распознать кадры',{exact:true})).toHaveCount(0);await expect(page.getByText(/В этом CBZ нет разметки BATCAVE Studio/)).toBeVisible();await page.getByLabel('Название',{exact:true}).fill('Raw import without AI');
 const before=ai.length;await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();await expect(page.locator('.modal')).not.toBeVisible();expect(ai.length).toBe(before);
 await page.getByRole('button',{name:/^Читать: Raw import without AI/}).click();await expect(page.locator('.reader canvas')).toBeVisible();await expect(page.locator('.page-spinner')).not.toBeVisible();await expect(page.locator('.reader .error')).toHaveCount(0);expect(ai.filter(url=>/assets\/auto-panels/.test(url))).toEqual([]);expect(failed).toEqual([]);
});

test('model is complete and the deployed release pins its hash',async({request})=>{
 const release=await(await request.get('/release.json')).json();const response=await request.get('/panel-ai/best.onnx');expect(response.ok()).toBe(true);const bytes=await response.body();expect(bytes.byteLength).toBe(12256396);const {createHash}=await import('node:crypto');expect(createHash('sha256').update(bytes).digest('hex')).toBe(release.sha256['panel-ai/best.onnx']);
});
