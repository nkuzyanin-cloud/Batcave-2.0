import {test,expect,type Page} from './runtime';
import {mkdirSync,readFileSync} from 'node:fs';
import {seedSeries,record} from './series-fixture';

async function geometry(page:Page,bottom:number){
  const nav=page.getByRole('navigation',{name:'Разделы приложения',exact:true});
  await expect(nav).toBeInViewport();
  const g=await nav.evaluate(el=>{
    const box=el.getBoundingClientRect(),app=el.closest('.app')!.getBoundingClientRect(),main=el.closest('.app')!.querySelector('main')!.getBoundingClientRect();
    return {top:box.top,bottom:box.bottom,appBottom:app.bottom,mainBottom:main.bottom,width:innerWidth,scroll:document.documentElement.scrollWidth,viewport:innerHeight,
      controls:Array.from(el.children).map(c=>{const r=c.getBoundingClientRect();return {top:r.top,bottom:r.bottom,left:r.left,right:r.right};}),
      icons:Array.from(el.querySelectorAll('svg')).map(svg=>({viewBox:svg.getAttribute('viewBox'),width:svg.getBoundingClientRect().width,weight:getComputedStyle(svg).strokeWidth}))};
  });
  expect(g.scroll).toBeLessThanOrEqual(g.width);expect(g.bottom).toBeLessThanOrEqual(g.viewport+.5);
  expect(Math.abs(g.bottom-g.appBottom)).toBeLessThan(1);expect(Math.abs(g.mainBottom-g.top)).toBeLessThan(1);
  for(const c of g.controls){expect(c.top).toBeGreaterThanOrEqual(g.top);expect(c.bottom).toBeLessThanOrEqual(g.bottom-bottom+.5);expect(c.left).toBeGreaterThanOrEqual(0);expect(c.right).toBeLessThanOrEqual(g.width);}
  expect(g.icons).toEqual(Array.from({length:3},()=>({viewBox:'0 0 24 24',width:24,weight:'1.8px'})));
}
async function noBlur(page:Page){
  const offenders=await page.evaluate(()=>Array.from(document.querySelectorAll('*')).flatMap(el=>['','::before','::after'].flatMap(pseudo=>{
    const s=getComputedStyle(el,pseudo||null),filter=s.backdropFilter||s.getPropertyValue('-webkit-backdrop-filter');
    return /blur\(/.test(`${filter} ${s.filter}`)?[`${el.tagName}.${el.className} ${pseudo}`]:[];
  })));
  expect(offenders).toEqual([]);
}

test('approved shelf and series layout; safe-area navigation fits portrait, short screens and landscape',async({page})=>{
  await seedSeries(page);await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();
  await expect(page.locator('.series-shelf>.library-series')).toHaveCount(2);
  mkdirSync('../qa-1.20',{recursive:true});
  await page.evaluate(()=>{document.documentElement.style.setProperty('--safe-top','44px');document.documentElement.style.setProperty('--safe-bottom','34px');});
  for(const [width,height] of [[375,812],[320,568],[390,844],[812,375]]){
    await page.setViewportSize({width,height});await geometry(page,34);
    await page.locator('.screen').evaluate(el=>el.scrollTop=el.scrollHeight);await geometry(page,34);
    await page.locator('.screen').evaluate(el=>el.scrollTop=0);
  }
  await page.setViewportSize({width:375,height:812});await noBlur(page);await page.screenshot({path:'../qa-1.20/home.png'});
  await page.getByRole('button',{name:/Открыть серию: Ходячие/}).click();
  await expect(page.locator('.app-header button')).toHaveCount(2);await expect(page.getByRole('button',{name:'Меню серии'})).toBeVisible();
  await expect(page.locator('[data-comic-id="c0"] strong')).toHaveText('Выпуск 1');expect((await record(page)).title).toBe('Ходячие мертвецы. Делюкс. Выпуск 1');
  await geometry(page,34);await noBlur(page);await page.screenshot({path:'../qa-1.20/series.png'});
  await page.locator('.screen').evaluate(el=>el.scrollTop=el.scrollHeight);await geometry(page,34);
  await expect(page.getByRole('button',{name:/Все комиксы серии/})).toBeInViewport();await page.screenshot({path:'../qa-1.20/series-bottom.png'});
});

test('navigation, series editing, search, chapter additions and archived records remain reachable',async({page})=>{
  await seedSeries(page);
  await page.getByRole('button',{name:'Меню серии'}).click();await page.getByRole('button',{name:'Изменить серию',exact:true}).click();
  await expect(page.getByRole('dialog',{name:'Изменить серию'})).toBeVisible();await noBlur(page);await page.getByRole('button',{name:'Закрыть',exact:true}).click();
  await page.getByRole('button',{name:'Меню серии'}).click();await page.getByRole('button',{name:'Открыть поиск',exact:true}).click();
  await page.getByRole('searchbox').fill('Выпуск 2');await expect(page.locator('.series-timeline-entry')).toHaveCount(1);await page.getByRole('button',{name:'Закрыть поиск'}).click();
  await page.getByRole('button',{name:'Свернуть раздел «Мили позади»',exact:true}).click();await noBlur(page);await page.getByRole('button',{name:'Раскрыть раздел «Мили позади»',exact:true}).click();
  await page.getByRole('button',{name:'Добавить комикс в раздел «Мили позади»',exact:true}).click();await page.getByRole('button',{name:/Создать карточку/}).click();
  await expect(page.getByLabel('Эра комикса')).toHaveValue('b');await page.getByLabel('Название',{exact:true}).fill('Новая история');await page.getByRole('dialog').getByRole('button',{name:'Добавить комикс',exact:true}).click();
  await expect(page.locator('[data-route-section="b"] .series-timeline-entry')).toHaveCount(1);
  await page.getByRole('button',{name:'Меню серии'}).click();await page.getByRole('button',{name:'Все комиксы серии',exact:true}).click();await expect(page.locator('.comic-card')).toHaveCount(7);
  await page.getByRole('button',{name:'Открыть настройки',exact:true}).click();await expect(page.getByRole('heading',{name:'Настройки',exact:true})).toBeVisible();await geometry(page,0);await noBlur(page);
  await page.getByRole('button',{name:'Назад',exact:true}).click();await expect(page.locator('.comic-card')).toHaveCount(7);
  await page.getByRole('button',{name:'Открыть достижения',exact:true}).click();await expect(page.getByRole('dialog',{name:'Достижения',exact:true})).toBeVisible();await noBlur(page);
  await page.getByRole('button',{name:'Закрыть',exact:true}).click();await expect(page.getByRole('navigation',{name:'Разделы приложения'})).toBeVisible();
});

test('final list item stays above navigation after offline restart; modal form cannot pan sideways',async({page,context})=>{
  await seedSeries(page);await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();
  await expect(page.locator('.series-timeline-entry')).toHaveCount(6);await geometry(page,0);
  await page.locator('[data-comic-id="c5"]').scrollIntoViewIfNeeded();await expect(page.locator('[data-comic-id="c5"] .cover')).toBeInViewport();
  const bottom=await page.locator('[data-comic-id="c5"]').evaluate(el=>el.getBoundingClientRect().bottom),navTop=await page.locator('.app-nav').evaluate(el=>el.getBoundingClientRect().top);expect(bottom).toBeLessThanOrEqual(navTop);
  await page.getByRole('button',{name:'Меню выпуска: Ходячие мертвецы. Делюкс. Выпуск 6',exact:true}).click();await page.getByRole('button',{name:'Редактировать',exact:true}).click();
  await page.getByLabel('Название',{exact:true}).focus();expect(await page.getByRole('dialog').evaluate(el=>el.scrollWidth-el.clientWidth)).toBe(0);await noBlur(page);
  await page.getByRole('button',{name:'Закрыть',exact:true}).click();await geometry(page,0);
});

// WebKit supplies the keyboard signal; keep navigation either wholly visible
// or wholly hidden, rather than clipping it into a short editing viewport.
test('keyboard state hides navigation for in-page search and keeps the background stable under a modal',async({page})=>{
  await seedSeries(page);await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();
  await page.getByRole('button',{name:'Открыть поиск',exact:true}).click();
  await page.evaluate(()=>{document.documentElement.setAttribute('data-keyboard-open','');document.documentElement.style.setProperty('--keyboard-height','320px');});
  await expect(page.locator('.app-nav')).toBeHidden();await expect(page.getByRole('searchbox')).toBeVisible();
  await page.evaluate(()=>{document.documentElement.removeAttribute('data-keyboard-open');document.documentElement.style.removeProperty('--keyboard-height');});
  await page.getByRole('button',{name:'Закрыть поиск',exact:true}).click();await geometry(page,0);
  await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();
  await page.evaluate(()=>document.documentElement.setAttribute('data-keyboard-open',''));
  expect(await page.locator('.app-nav').evaluate(el=>getComputedStyle(el).display)).toBe('grid');
  await page.getByRole('button',{name:'Закрыть',exact:true}).click();await page.evaluate(()=>document.documentElement.removeAttribute('data-keyboard-open'));await geometry(page,0);
});
