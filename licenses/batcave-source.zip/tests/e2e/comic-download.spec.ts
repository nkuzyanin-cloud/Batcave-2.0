import {test,expect} from '@playwright/test';
import {readFile} from 'node:fs/promises';

test('storage downloads original CBZ and PDF offline without changing comics',async({page,context})=>{
  await page.goto('/');await expect(page.locator('.app')).toBeVisible();
  const files=await Promise.all(['sample.cbz','sample.pdf'].map(async name=>({name,bytes:Array.from(await readFile(`tests/fixtures/${name}`))})));
  await page.evaluate(async files=>{
    const request=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>request.onsuccess=()=>r(request.result));
    const tx=db.transaction(['comics','assets'],'readwrite');
    for(const [i,f] of files.entries()){
      const id=`download-${i}`,blob=new Blob([new Uint8Array(f.bytes)],{type:i?'application/pdf':'application/zip'});
      tx.objectStore('assets').put({id,blob});
      tx.objectStore('comics').put({id,title:`Скачать ${i}`,series:'DC',authors:'',year:2000,addedAt:100,updatedAt:200,physical:'no',edition:'',publisher:'',editionYear:null,note:'',rating:4,completed:false,inRoadmap:true,page:1,pageCount:3,visited:[0,1],seconds:100,lastOpened:1,tone:'#79a9be',digital:{assetId:id,name:`Оригинал ${i}.${i?'pdf':'cbz'}`,format:i?'pdf':'cbz',size:blob.size,fingerprint:String(i+1).repeat(64)},digitalFingerprint:String(i+1).repeat(64)});
    }
    await new Promise<void>((r,j)=>{tx.oncomplete=()=>r();tx.onerror=()=>j(tx.error)});db.close();
  },files);
  await page.goto('/#/settings');await page.reload();
  await page.getByRole('button',{name:/Хранилище.*На устройстве/}).click();
  if(await page.getByRole('button',{name:'Скрыть уведомление о достижении'}).isVisible())await page.getByRole('button',{name:'Скрыть уведомление о достижении'}).click();
  await page.evaluate(async()=>{await navigator.serviceWorker.ready});await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);
  for(let i=0;i<2;i++){
    const pending=page.waitForEvent('download');await page.getByRole('button',{name:`Скачать файл Скачать ${i}`,exact:true}).click();const result=await pending;
    expect(result.suggestedFilename()).toBe(`Оригинал ${i}.${i?'pdf':'cbz'}`);
    expect(await readFile((await result.path())!)).toEqual(Buffer.from(files[i].bytes));
    await expect(page.getByRole('button',{name:'Скачать ещё раз',exact:true})).toBeVisible();
  }
  const repeat=page.waitForEvent('download');await page.getByRole('button',{name:'Скачать ещё раз',exact:true}).click();expect((await repeat).suggestedFilename()).toBe('Оригинал 1.pdf');
  await page.setViewportSize({width:320,height:568});expect(await page.locator('.file-list').evaluate(el=>el.scrollWidth<=el.clientWidth+1)).toBe(true);
  await page.screenshot({path:'test-results/comic-download.png'});
  const comic=await page.evaluate(async()=>{
    const q=indexedDB.open('batcave-reader'),db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const tx=db.transaction(['comics','assets'],'readwrite');const c=await new Promise<any>(r=>{const req=tx.objectStore('comics').get('download-0');req.onsuccess=()=>r(req.result)});tx.objectStore('assets').delete('download-0');await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();return c;
  });
  expect(comic.page).toBe(1);expect(comic.visited).toEqual([0,1]);expect(comic.seconds).toBe(100);expect(comic.digital.name).toBe('Оригинал 0.cbz');
  await page.getByRole('button',{name:'Скачать файл Скачать 0',exact:true}).click();await expect(page.getByText('Исходный файл недоступен или повреждён. Добавьте его в комикс повторно.',{exact:true})).toBeVisible();
});
