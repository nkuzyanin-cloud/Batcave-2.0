import {test,expect} from './runtime';
test('replace a changed archive while retaining bookmark, visits, time and card identity',async({page})=>{
 await page.goto('/');await expect(page.locator('.app')).toBeVisible();
 await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Загрузить комикс/}).click();
 await page.locator('[data-testid="comic-file-input"]').setInputFiles('tests/fixtures/sample.cbz');await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();
 await page.getByLabel('Название',{exact:true}).fill('Keep my progress');
 await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();await expect(page.locator('.modal')).not.toBeVisible();
 const before=await page.evaluate(async()=>{const req=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>req.onsuccess=()=>r(req.result));const tx=db.transaction('comics','readwrite');const s=tx.objectStore('comics'),q=s.getAll();const c=await new Promise<any>(r=>q.onsuccess=()=>r(q.result[0]));s.put({...c,page:1,visited:[0,1],seconds:321,rating:4,lastOpened:123});await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();return c;});
 await page.reload();const cover=page.getByRole('button',{name:/^(Читать|Открыть): Keep my progress\./});await cover.scrollIntoViewIfNeeded();const b=await cover.boundingBox();if(!b)throw Error('Cover absent');await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await page.mouse.down();await page.waitForTimeout(1100);await page.mouse.up();
 await page.getByRole('button',{name:'Действия с комиксом',exact:true}).click();await page.getByRole('menuitem',{name:'Заменить файл',exact:true}).click();
 await page.locator('[data-testid="comic-file-input"]').setInputFiles('tests/fixtures/replacement.cbz');
 await expect(page.getByRole('dialog',{name:'Заменить файл комикса',exact:true})).toBeVisible();
 await expect(page.getByLabel('Сохранить прогресс и время чтения',{exact:true})).toBeChecked();
 await page.getByRole('button',{name:'Прикрепить к комиксу',exact:true}).click();await expect(page.locator('.modal')).not.toBeVisible();
 const after=await page.evaluate(async()=>{const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const a=db.transaction('comics').objectStore('comics').getAll();const records=await new Promise<any[]>(r=>a.onsuccess=()=>r(a.result));db.close();return records;});
 expect(after).toHaveLength(1);expect(after[0]).toMatchObject({id:before.id,page:1,visited:[0,1],seconds:321,rating:4,lastOpened:123});expect(after[0].digital.fingerprint).not.toBe(before.digital.fingerprint);
});
