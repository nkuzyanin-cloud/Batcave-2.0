import {test,expect} from './runtime';
import {seedSeries,record} from './series-fixture';
import {mkdirSync,readFileSync} from 'node:fs';

test('1.30 library fits phones, resumes the saved page, searches and works offline',async({page,context})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await seedSeries(page);
 const cover='data:image/webp;base64,'+readFileSync('tests/fixtures/cover-batman.webp').toString('base64');
 await page.evaluate(async cover=>{
  const q=indexedDB.open('batcave-reader'),db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
  const tx=db.transaction(['comics','config'],'readwrite'),comics=tx.objectStore('comics'),req=comics.get('c1');
  req.onsuccess=()=>comics.put({...req.result,title:'Ходячие мертвецы. Делюкс',page:1,visited:[0,1],lastOpened:Date.now()});
  const config=tx.objectStore('config'),universes=config.get('reading-universes-v1');
  universes.onsuccess=()=>config.put(universes.result.map((u:any)=>u.id==='batman'?{...u,cover}:u),'reading-universes-v1');
  await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();
 },cover);
 await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();await page.reload();
 const before=await record(page,'c1'),resume=page.getByRole('button',{name:'Продолжить чтение: Ходячие мертвецы. Делюкс',exact:true});
 await expect(resume).toHaveText('Продолжить');
 await expect(page.getByRole('progressbar',{name:'Прогресс текущего комикса',exact:true})).toHaveAttribute('aria-valuenow','67');
 await expect(page.locator('.resume-page')).toContainText('2 из 3');
 await expect(page.locator('.library-resume button')).toHaveCount(1);
 await expect(page.locator('.library-resume')).not.toContainText('Читать');
 mkdirSync('../release-1.30-qa',{recursive:true});
 for(const [width,height] of [[320,568],[375,812],[430,932],[812,375]]){
  await page.setViewportSize({width,height});
  await page.locator('main.screen').evaluate(el=>el.scrollTop=0);
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  const box=await resume.boundingBox(),card=await page.locator('.library-resume').boundingBox();
  expect(box!.height).toBeGreaterThanOrEqual(44);expect(box!.x+box!.width).toBeLessThanOrEqual(card!.x+card!.width);
  const ring=await page.locator('.resume-ring').boundingBox();expect(ring!.width).toBeLessThanOrEqual(44);
  const styles=await page.locator('.app-header,.app-nav').evaluateAll(nodes=>nodes.map(n=>({blur:getComputedStyle(n).backdropFilter,filter:getComputedStyle(n).filter})));
  expect(styles.every(s=>s.blur==='none'&&s.filter==='none')).toBe(true);
  await page.screenshot({path:`../release-1.30-qa/home-${width}.png`});
 }
 await page.setViewportSize({width:375,height:812});
 await page.getByRole('button',{name:'Открыть поиск',exact:true}).click();
 await page.getByRole('searchbox',{name:'Поиск комиксов',exact:true}).fill('Делюкс');
 await expect(page.locator('.comic-card')).toHaveCount(6);await expect(page.locator('.library-resume')).toHaveCount(0);
 await page.getByRole('button',{name:'Закрыть поиск',exact:true}).click();
 await page.getByRole('link',{name:'Открыть профиль',exact:true}).click();await expect(page.locator('.rank-goal')).toHaveCount(3);
 await page.getByRole('button',{name:'Открыть настройки',exact:true}).click();await expect(page.getByRole('heading',{name:'Настройки',exact:true})).toBeVisible();
 await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();expect(await record(page,'c1')).toEqual(before);
 await resume.click();await expect(page.locator('.reader canvas').first()).toBeVisible();
 const reader=page.locator('.reader');if(await reader.evaluate(el=>el.classList.contains('ui-hidden')))await page.locator('.free-page-stage,.panel-scroll').first().tap({position:{x:170,y:260}});
 await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();
 expect((await record(page,'c1')).page).toBe(1);
 await expect(page.locator('.resume-page')).toContainText('2 из 3');
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();
 await expect(resume).toBeVisible();await expect(page.locator('.resume-ring')).toHaveAttribute('aria-valuenow','67');
 expect((await record(page,'c1')).page).toBe(1);expect(errors).toEqual([]);
});
