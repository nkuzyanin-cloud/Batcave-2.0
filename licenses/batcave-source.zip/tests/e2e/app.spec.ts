import { test, expect, type Page } from '@playwright/test';
import { readFileSync } from 'node:fs';

async function records(page: Page) {
  return page.evaluate(async () => {
    const q = indexedDB.open('batcave-reader');
    const db = await new Promise<IDBDatabase>((resolve, reject) => { q.onsuccess = () => resolve(q.result); q.onerror = () => reject(q.error); });
    try { return await new Promise<any[]>((resolve, reject) => {
      const r = db.transaction('comics').objectStore('comics').getAll(); r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error);
    }); } finally { db.close(); }
  });
}
async function upload(page: Page, name: string) {
  const bytes = [...readFileSync(`tests/fixtures/${name}`)];
  // In-memory selection exercises the real input handler without a runner's temporary file handles.
  await page.locator('[data-testid="comic-file-input"]').evaluate((input, { bytes, name }) => {
    const file = new File([new Uint8Array(bytes)], name), transfer = new DataTransfer(); transfer.items.add(file);
    (input as HTMLInputElement).files = transfer.files; input.dispatchEvent(new Event('change', { bubbles: true }));
  }, { bytes, name });
  await expect(page.getByText('Файл проверен', { exact: true })).toBeVisible();
}
async function newUpload(page: Page, name: string) {
  await page.getByRole('button', { name: 'Добавить комикс', exact: true }).click();
  await page.getByRole('button', { name: /Загрузить комикс/ }).click(); await upload(page, name);
}
async function holdCover(page:Page,title:string) {
  const target=page.getByRole('button',{name:new RegExp(`^(Читать|Открыть): ${title}\\.`)});
  await target.scrollIntoViewIfNeeded();const box=await target.boundingBox();if(!box)throw Error('Cover missing');
  await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();
  await page.waitForTimeout(1100);await page.mouse.up();
  await expect(page.getByRole('dialog',{name:'Редактирование',exact:true})).toBeVisible();
}
test.beforeEach(async ({ page }) => { await page.goto('/'); await expect(page.locator('.app')).toBeVisible(); });

test('neutral focus, modal keyboard navigation and consistent scrolling across 24 field switches', async ({ page }) => {
  await page.addInitScript(() => {
    Object.defineProperty(navigator, 'standalone', { value: true, configurable: true });
    const v = new EventTarget();
    Object.assign(v, { height: 762, width: 375, offsetTop: 0, offsetLeft: 0, pageTop: 0, scale: 1 });
    Object.defineProperty(window, 'visualViewport', { value: v, configurable: true });
    (window as any).qaKeyboard = (height: number, pan: number) => {
      Object.assign(v, { height, offsetTop: pan, pageTop: pan }); v.dispatchEvent(new Event('resize')); v.dispatchEvent(new Event('scroll'));
    };
  });
  await page.reload(); await expect(page.locator('.app')).toBeVisible();
  await page.getByRole('button', { name: 'Открыть поиск', exact: true }).click();
  await page.getByRole('button', { name: 'Добавить комикс', exact: true }).click();
  await page.getByRole('button', { name: /Сначала обложка/ }).click();
  const modal = page.getByRole('dialog', { name: 'Добавить комикс', exact: true });
  await expect(modal.getByRole('button', { name: 'Закрыть', exact: true })).toBeFocused();
  await expect(page.locator('#root')).toHaveAttribute('inert');
  await page.keyboard.press('Shift+Tab'); expect(await page.evaluate(() => !!document.activeElement?.closest('.modal'))).toBe(true);
  await page.addStyleTag({ content: '.modal-backdrop{padding-top:50px}.app-header{height:118px;padding-top:50px}' });
  const names = ['Название', 'Серия', 'Авторы', 'Год произведения'];
  for (let i = 0; i < 24; i++) {
    await page.getByLabel(names[i % names.length], { exact: true }).focus();
    await page.evaluate(pan => (window as any).qaKeyboard(420, pan), (i % 10) * 17);
    await expect(page.locator('html')).toHaveAttribute('data-keyboard-open');
    await page.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))));
    const box = await page.evaluate(() => {
      const m = document.querySelector('.modal')!, h = m.querySelector(':scope > header')!, f = document.activeElement!;
      return { top: m.getBoundingClientRect().top, bottom: m.getBoundingClientRect().bottom,
        header: h.getBoundingClientRect().bottom, fieldTop: f.getBoundingClientRect().top, fieldBottom: f.getBoundingClientRect().bottom,
        outerScroll: scrollY, appHeight: document.querySelector('.app')!.getBoundingClientRect().height };
    });
    expect(box.top).toBeCloseTo(50 + (i % 10) * 17, 0); expect(box.bottom).toBeLessThanOrEqual(420 + (i % 10) * 17);
    expect(box.fieldTop).toBeGreaterThanOrEqual(box.header + 10); expect(box.fieldBottom).toBeLessThanOrEqual(box.bottom - 14);
    expect(box.outerScroll).toBe(0); expect(box.appHeight).toBe(812);
    expect(await page.getByLabel(names[i % names.length], { exact: true }).evaluate(e => getComputedStyle(e).opacity)).toBe('1');
  }
  await page.getByLabel('Название', { exact: true }).fill('New title');
  await page.getByRole('button', { name: 'Закрыть', exact: true }).click(); await expect(modal).not.toBeVisible();
  await expect(page.locator('#root')).not.toHaveAttribute('inert');
  expect(await page.getByRole('textbox', { name: 'Поиск комиксов', exact: true }).evaluate(e => document.activeElement === e)).toBe(false);
  expect(await page.evaluate(() => document.body.style.position)).toBe('');
});

test('blank import is rejected, valid CBZ reads to summary, rating persists offline and same-file reattachment keeps time', async ({ page, context, browserName }) => {
  test.skip(browserName === 'webkit' && process.env.QA_WEBKIT_NO_BLOBS === '1', 'This restricted WebKit runner cannot persist even a standalone Blob in IndexedDB.');
  const errors: string[] = []; page.on('pageerror', e => errors.push(e.message));
  await newUpload(page, 'sample.cbz'); await page.getByLabel('Автоматически распознать кадры', { exact: true }).uncheck();
  await page.getByLabel('Название', { exact: true }).fill('   '); await page.getByRole('button', { name: 'Сохранить в библиотеку', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('Укажите название'); expect(await records(page)).toEqual([]);
  await page.getByLabel('Название', { exact: true }).fill('My comic'); await page.getByRole('button', { name: 'Сохранить в библиотеку', exact: true }).click();
  await expect(page.locator('.modal')).not.toBeVisible(); await page.getByRole('button', { name: /^Читать: My comic/ }).click();
  await expect(page.locator('.reader canvas')).toBeVisible(); await expect(page.locator('.page-spinner')).not.toBeVisible();
  await page.waitForTimeout(1200); await page.evaluate(() => { Object.defineProperty(document, 'hidden', { value: true, configurable: true }); document.dispatchEvent(new Event('visibilitychange')); });
  await expect.poll(async () => (await records(page))[0].seconds).toBeGreaterThan(1);
  const paused = (await records(page))[0].seconds; await page.waitForTimeout(1200); expect((await records(page))[0].seconds).toBe(paused);
  await page.evaluate(() => { Object.defineProperty(document, 'hidden', { value: false, configurable: true }); document.dispatchEvent(new Event('visibilitychange')); });
  for (let i = 0; i < 3; i++) { await page.getByRole('button', { name: 'Следующая страница', exact: true }).click(); await expect(page.locator('.page-spinner')).not.toBeVisible(); }
  await expect(page.locator('.summary-stars')).toBeVisible(); await page.getByRole('button', { name: 'Оценка 4', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Оценка 4', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: 'Вернуться в библиотеку', exact: true }).click();
  const before = (await records(page))[0]; expect(before.visited).toEqual([0, 1, 2]); expect(before.rating).toBe(4);
  await holdCover(page,'My comic');
  await page.getByRole('button', { name: 'Действия с комиксом', exact: true }).click(); await page.getByRole('menuitem', { name: 'Удалить цифровой файл', exact: true }).click(); await page.getByRole('button', { name: 'Удалить', exact: true }).click();
  await expect(page.locator('.modal')).not.toBeVisible(); await holdCover(page,'My comic');
  await page.getByRole('button', { name: 'Добавить файл', exact: true }).click(); await upload(page, 'sample.cbz');
  await page.getByLabel('Автоматически распознать кадры', { exact: true }).uncheck(); await page.getByRole('button', { name: 'Прикрепить к комиксу', exact: true }).click();
  await expect(page.locator('.modal')).not.toBeVisible(); expect((await records(page))[0]).toMatchObject({ visited: before.visited, seconds: before.seconds, rating: 4 });
  await page.waitForFunction(() => !!navigator.serviceWorker.controller); await context.setOffline(true); await page.reload();
  await expect(page.locator('.app')).toBeVisible(); expect((await records(page))[0].rating).toBe(4); expect(errors).toEqual([]);
});

test('PDF renders without missing individual font requests', async ({ page, browserName }, testInfo) => {
  const failed: string[] = [], directFonts: string[] = [];
  page.on('response', r => { if (r.status() >= 400) failed.push(r.url()); });
  page.on('request', r => { if (r.url().includes('/pdf/standard_fonts/')) directFonts.push(r.url()); });
  await newUpload(page, 'sample.pdf'); await page.getByLabel('Автоматически распознать кадры', { exact: true }).uncheck();
  if (browserName === 'webkit' && process.env.QA_WEBKIT_NO_BLOBS === '1') {
    testInfo.annotations.push({ type: 'scope', description: 'PDF preview rendered; saving is unavailable in this restricted runner.' });
    expect(failed).toEqual([]); expect(directFonts).toEqual([]); return;
  }
  await page.getByRole('button', { name: 'Сохранить в библиотеку', exact: true }).click(); await expect(page.locator('.modal')).not.toBeVisible();
  await page.getByRole('button', { name: /^Читать: sample/ }).click(); await expect(page.locator('.reader canvas')).toBeVisible();
  await expect(page.locator('.page-spinner')).not.toBeVisible(); expect(failed).toEqual([]); expect(directFonts).toEqual([]);
});

test('bundled panel model and WASM recognize an imported CBZ', async ({ page, browserName }) => {
  test.skip(browserName !== 'chromium', 'The model smoke test runs once; UI is checked in both engines.'); test.setTimeout(120000);
  await newUpload(page, 'sample.cbz'); await page.getByRole('button', { name: 'Сохранить в библиотеку', exact: true }).click();
  await expect(page.locator('.modal')).not.toBeVisible({ timeout: 90000 });
  const c = (await records(page))[0]; expect(c.autoPanels.pageCount).toBe(3); expect(c.autoPanels.pages).toHaveLength(3);
});

test('repairs a mismatched cached index and still opens offline', async ({ page, context }) => {
  await page.waitForFunction(() => !!navigator.serviceWorker.controller);
  const build = await page.locator('meta[name="batcave-build"]').getAttribute('content');
  await page.evaluate(async build => {
    const name = (await caches.keys()).find(k => k.endsWith(build!));
    if (!name) throw Error('Installed cache missing');
    await (await caches.open(name)).put(new URL('./index.html', location.href),
      new Response('<!doctype html><title>Wrong cached page</title>', { headers: { 'content-type': 'text/html' } }));
  }, build);
  await page.reload(); await expect(page.locator('.app')).toBeVisible();
  await expect(page.locator('meta[name="batcave-build"]')).toHaveAttribute('content', build!);
  await context.setOffline(true); await page.reload(); await expect(page.locator('.app')).toBeVisible();
});


test('compact editor retains paper reading and settings open as separate sections', async ({ page }) => {
  await page.getByRole('button', {name:'Добавить комикс',exact:true}).click();
  await page.getByRole('button', {name:/Сначала обложка/}).click();
  const modal=page.getByRole('dialog',{name:'Добавить комикс',exact:true});
  await expect(modal.getByText('Дополнительно',{exact:true})).toHaveCount(0);
  await expect(modal.getByLabel('Эра комикса')).toBeVisible();
  await modal.getByLabel('Название',{exact:true}).fill('Paper edition');
  await modal.getByRole('button',{name:'Бумажная версия',exact:true}).click();
  await modal.getByLabel('Количество страниц',{exact:true}).fill('100');
  await expect(modal.getByRole('button',{name:'Старт',exact:true})).toBeDisabled();
  await modal.getByRole('button',{name:'Добавить комикс',exact:true}).click();
  await expect(modal).not.toBeVisible();
  await holdCover(page,'Paper edition');
  await expect(page.getByRole('button',{name:'Старт',exact:true})).toBeEnabled();
  await expect(page.getByRole('button',{name:'Добавить файл',exact:true})).toBeVisible();
  await page.getByRole('button',{name:'Закрыть',exact:true}).click();
  await page.getByRole('button',{name:'Открыть профиль',exact:true}).click();
  await expect(page.getByRole('button',{name:'Экспорт всей библиотеки',exact:true})).toHaveCount(0);
  await page.getByRole('button',{name:'Открыть настройки',exact:true}).click();
  await expect(page.locator('.settings-home > button')).toHaveCount(4);
  await page.getByRole('button',{name:/Резервные копии.*Сохранить и восстановить/}).click();
  await page.getByRole('button',{name:'Экспорт всей библиотеки',exact:true}).click();
  await expect(page.getByRole('button',{name:/Скачать часть 1 из 1/})).toBeVisible();
  await page.getByRole('button',{name:'Назад к настройкам',exact:true}).click();
  await page.getByRole('button',{name:/Чтение.*Режим, масштаб/}).click();
  await expect(page.getByLabel('Обрезать поля',{exact:true})).toBeVisible();
  await expect(page.getByRole('button',{name:'Экспорт всей библиотеки',exact:true})).toHaveCount(0);
});


test('real scanner-bordered WebP is cropped only when the setting is enabled', async ({ page }) => {
  test.skip(!process.env.QA_CROP_IMAGE,'Supply a private scanner image for this integration check.');
  await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();
  await page.getByRole('button',{name:/Загрузить комикс/}).click();
  const bytes=[...readFileSync(process.env.QA_CROP_IMAGE!)];
  await page.locator('[data-testid="comic-file-input"]').evaluate((input,bytes)=>{
    const transfer=new DataTransfer();transfer.items.add(new File([new Uint8Array(bytes)],'Scanner.webp',{type:'image/webp'}));
    (input as HTMLInputElement).files=transfer.files;input.dispatchEvent(new Event('change',{bubbles:true}));
  },bytes);
  await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();
  await page.getByLabel('Автоматически распознать кадры',{exact:true}).uncheck();
  await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();
  await expect(page.locator('.modal')).not.toBeVisible();
  await page.getByRole('button',{name:/^Читать: Scanner/}).click();
  await expect(page.locator('.page-spinner')).not.toBeVisible();
  const size=()=>page.locator('canvas.reader-canvas').first().evaluate((e:HTMLCanvasElement)=>({w:e.width,h:e.height}));
  await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();
  await page.getByLabel('Обрезать поля',{exact:true}).check();
  await page.getByRole('button',{name:'Закрыть',exact:true}).click();
  await expect(page.locator('.page-spinner')).not.toBeVisible();
  const cropped=await size();
  await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();
  await page.getByLabel('Обрезать поля',{exact:true}).uncheck();
  await page.getByRole('button',{name:'Закрыть',exact:true}).click();
  await expect(page.locator('.page-spinner')).not.toBeVisible();
  const full=await size();expect(cropped.w).toBeLessThan(full.w*.94);expect(cropped.h).toBeLessThan(full.h*.96);
  await page.screenshot({path:'../qa-reader-uncropped.png'});
  await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();
  await page.getByLabel('Обрезать поля',{exact:true}).check();
  await page.getByRole('button',{name:'Закрыть',exact:true}).click();
  await expect(page.locator('.page-spinner')).not.toBeVisible();expect(await size()).toEqual(cropped);
  await page.screenshot({path:'../qa-reader-cropped.png'});
});


test('roadmap hides titles and menus; long hold edits, canceled touch does nothing, short tap reads',async({page})=>{
  await newUpload(page,'sample.cbz');await page.getByLabel('Автоматически распознать кадры',{exact:true}).uncheck();
  await page.getByLabel('Название',{exact:true}).fill('Gesture comic');await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();
  await expect(page.locator('.modal')).not.toBeVisible();
  await expect(page.locator('.road-meta,.road-menu,.road-node h3')).toHaveCount(0);
  const button=page.getByRole('button',{name:/^Читать: Gesture comic/});
  await holdCover(page,'Gesture comic');await expect(page.locator('.reader')).toHaveCount(0);
  await expect(page.getByLabel('Название',{exact:true})).toHaveValue('Gesture comic');
  await page.getByRole('button',{name:'Закрыть',exact:true}).click();
  // A finger moving more than the threshold and native scroll cancellation
  // must cancel the hold, even if Safari later emits a synthesized click.
  for(const action of ['move','cancel','scroll']){
    await button.dispatchEvent('pointerdown',{pointerId:9,isPrimary:true,button:0,clientX:60,clientY:200,pointerType:'touch'});
    if(action==='move')await button.dispatchEvent('pointermove',{pointerId:9,clientX:60,clientY:225,pointerType:'touch'});
    if(action==='cancel')await button.dispatchEvent('pointercancel',{pointerId:9,pointerType:'touch'});
    if(action==='scroll')await page.locator('.screen').dispatchEvent('scroll');
    await page.waitForTimeout(1100);await button.dispatchEvent('pointerup',{pointerId:9});await button.dispatchEvent('click');
    await expect(page.locator('.modal,.reader')).toHaveCount(0);
  }
  await button.focus();await page.keyboard.press('F2');await expect(page.getByRole('dialog',{name:'Редактирование',exact:true})).toBeVisible();
  await page.getByRole('button',{name:'Закрыть',exact:true}).click();
  await button.click();await expect(page.locator('.reader canvas')).toBeVisible();
});


test('backup notices auto-dismiss after three seconds and can be swiped or closed',async({page})=>{
  await page.getByRole('button',{name:'Открыть профиль',exact:true}).click();
  await page.getByRole('button',{name:'Открыть настройки',exact:true}).click();
  await page.getByRole('button',{name:/Резервные копии.*Сохранить и восстановить/}).click();
  const toast=page.locator('.dismissible-toast');const exportButton=page.getByRole('button',{name:'Экспорт JSON',exact:true});
  await exportButton.click();await expect(toast).toBeVisible();await expect(toast).not.toBeVisible({timeout:4500});
  await exportButton.click();await expect(toast).toBeVisible();
  await toast.dispatchEvent('pointerdown',{pointerId:1,isPrimary:true,button:0,clientX:100,clientY:700});
  await toast.dispatchEvent('pointermove',{pointerId:1,clientX:160,clientY:702});
  await toast.dispatchEvent('pointerup',{pointerId:1,clientX:160,clientY:702});await expect(toast).not.toBeVisible();
  await exportButton.click();await expect(toast).toBeVisible();
  await page.getByRole('button',{name:'Закрыть уведомление',exact:true}).click();await expect(toast).not.toBeVisible();
});

test('Studio CBZ imports authored frames without AI and uses its page crop',async({page})=>{
  test.skip(!process.env.QA_PREPARED_CBZ,'A Studio export is required.');
  await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Загрузить комикс/}).click();
  await page.locator('[data-testid="comic-file-input"]').setInputFiles(process.env.QA_PREPARED_CBZ!);
  await expect(page.getByText('Разметка BATCAVE Studio найдена. Кадры и обрезка готовы.',{exact:true})).toBeVisible();
  await expect(page.getByLabel('Автоматически распознать кадры',{exact:true})).toBeDisabled();
  await page.getByLabel('Название',{exact:true}).fill('Prepared book');await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();
  await expect(page.locator('.modal')).not.toBeVisible();await page.getByRole('button',{name:/^Читать: Prepared book/}).click();
  await expect(page.locator('.reader canvas')).toBeVisible();await expect(page.locator('.page-spinner')).not.toBeVisible();
  await expect(page.locator('.reader .error')).toHaveCount(0);
  const dims=await page.locator('.reader canvas').first().evaluate((e:HTMLCanvasElement)=>({w:e.width,h:e.height}));expect(dims.w).toBeGreaterThan(0);expect(dims.h).toBeGreaterThan(0);
  await page.screenshot({path:'../prepared-reader-qa.png'});
});

test('authored frame uses exact hard shade edges and 100 percent persists',async({page})=>{
 test.skip(!process.env.QA_EXACT_FRAME,'An authored frame fixture is required.');
 await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Загрузить комикс/}).click();await page.locator('[data-testid="comic-file-input"]').setInputFiles(process.env.QA_EXACT_FRAME!);
 await expect(page.getByText('Разметка BATCAVE Studio найдена. Кадры и обрезка готовы.',{exact:true})).toBeVisible();await page.getByLabel('Название',{exact:true}).fill('Exact frame');await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();await expect(page.locator('.modal')).not.toBeVisible();await page.getByRole('button',{name:/^Читать: Exact frame/}).click();await expect(page.locator('.reader canvas')).toBeVisible();await expect(page.locator('.page-spinner')).not.toBeVisible();
 await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();await page.getByLabel('Режим чтения').selectOption('panels');const slider=page.getByRole('slider',{name:'Затемнение вне кадра'});await expect(slider).toHaveAttribute('max','100');await slider.fill('100');await page.getByLabel('Обрезать поля',{exact:true}).check();await page.getByRole('dialog',{name:'Настройки чтения'}).getByRole('button',{name:'Закрыть',exact:true}).click();
 const camera=page.getByTestId('panel-camera');await expect(camera).toBeVisible();await expect(camera.locator('.panel-dim')).toHaveCount(4);await expect.poll(async()=>camera.locator('.panel-dim.left').evaluate(el=>Number(getComputedStyle(el).opacity))).toBe(1);
 const geom=await camera.evaluate(el=>{const left=new DOMMatrixReadOnly(getComputedStyle(el.querySelector('.panel-dim.left')!).transform),right=new DOMMatrixReadOnly(getComputedStyle(el.querySelector('.panel-dim.right')!).transform),c=new DOMMatrixReadOnly(getComputedStyle(el).transform);return{w:(right.e-left.e-left.a*64)*c.a,h:left.d*64*c.a,clip:(el.querySelector('.panel-paper') as HTMLElement).style.clipPath};});expect(geom.w/geom.h).toBeCloseTo(3.804148168,3);expect(geom.clip).toBe('');
 await page.screenshot({path:'../exact-frame-1110.png'});
 await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();await expect(page.getByRole('slider',{name:'Затемнение вне кадра'})).toHaveValue('100');await page.getByRole('slider',{name:'Затемнение вне кадра'}).fill('75');await page.getByRole('dialog',{name:'Настройки чтения'}).getByRole('button',{name:'Закрыть',exact:true}).click();await expect.poll(async()=>camera.locator('.panel-dim.left').evaluate(el=>Number(getComputedStyle(el).opacity))).toBe(.75);
});

test('Studio contours import as v2 and shade only outside quad and ellipse',async({page})=>{
 test.skip(!process.env.QA_SHAPED_CBZ,'A shaped Studio export is required.');
 await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Загрузить комикс/}).click();await page.locator('[data-testid="comic-file-input"]').setInputFiles(process.env.QA_SHAPED_CBZ!);await expect(page.getByText('Разметка BATCAVE Studio найдена. Кадры и обрезка готовы.',{exact:true})).toBeVisible();await page.getByLabel('Название',{exact:true}).fill('Contours');await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();await expect(page.locator('.modal')).not.toBeVisible();await page.getByRole('button',{name:/^Читать: Contours/}).click();await expect(page.locator('.reader canvas')).toBeVisible();await expect(page.locator('.page-spinner')).not.toBeVisible();
 await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();await page.getByLabel('Режим чтения').selectOption('panels');await page.getByRole('slider',{name:'Затемнение вне кадра'}).fill('100');await page.getByLabel('Анимации').selectOption('off');await page.getByRole('dialog',{name:'Настройки чтения'}).getByRole('button',{name:'Закрыть',exact:true}).click();const contour=page.getByTestId('panel-camera').locator('[data-shape]');await expect(contour).toHaveAttribute('data-shape','polygon');await expect(contour).toHaveCSS('opacity','1');const d=await contour.getAttribute('d');expect(d).toContain('L');await page.screenshot({path:'../quad-reader-1111.png'});
 await page.getByRole('button',{name:'Следующий кадр',exact:true}).click();await expect(contour).toHaveAttribute('data-shape','ellipse');expect(await contour.getAttribute('d')).toContain('A');await page.screenshot({path:'../ellipse-reader-1111.png'});
 await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();await page.getByRole('slider',{name:'Затемнение вне кадра'}).fill('75');await page.getByRole('dialog',{name:'Настройки чтения'}).getByRole('button',{name:'Закрыть',exact:true}).click();await expect(contour).toHaveCSS('opacity','0.75');await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();await page.getByLabel('Вся страница перед кадрами',{exact:true}).check();await page.getByRole('dialog',{name:'Настройки чтения'}).getByRole('button',{name:'Закрыть',exact:true}).click();await page.getByRole('button',{name:'Предыдущий кадр',exact:true}).click();await page.getByRole('button',{name:'Предыдущий кадр',exact:true}).click();await expect(contour).toHaveCSS('opacity','0');
 await expect(page.locator('.reader .error')).toHaveCount(0);
});
