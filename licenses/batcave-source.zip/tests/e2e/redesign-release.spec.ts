import {test,expect} from './runtime';
import {seedSeries,record} from './series-fixture';
import {mkdirSync} from 'node:fs';
test('approved home, completed disclosures, unique artwork and offline collection preserve records',async({page,context})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await seedSeries(page);const before=await record(page);
 await page.evaluate(async()=>{const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const tx=db.transaction('comics','readwrite'),s=tx.objectStore('comics'),get=s.get('c1');get.onsuccess=()=>s.put({...get.result,completed:true,visited:[0,1,2]});await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();});
 await page.reload();const done=page.locator('.route-section.is-complete');await expect(done).toHaveCount(1);await expect(done).toContainText('Раздел прочитан');
 await expect(page.locator('.route-section-vacant.is-complete')).toHaveCount(0);await done.locator('.route-section-toggle').click();await page.reload();await expect(done.locator('.route-section-toggle')).toHaveAttribute('aria-expanded','false');await expect(page.getByRole('dialog')).toHaveCount(0);
 mkdirSync('../reader-redesign-qa',{recursive:true});await page.screenshot({path:'../reader-redesign-qa/sections.png'});
 await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();await expect(page.locator('.library-statistics')).toContainText('Ваш прогресс');
 await page.screenshot({path:'../reader-redesign-qa/home.png'});
 await page.getByRole('link',{name:'Открыть достижения',exact:true}).click();await expect(page.locator('.award-tile')).toHaveCount(46);await expect(page.locator('.award-overview')).toBeVisible();await expect(page.locator('.award-nearest')).toBeVisible();
 for(const img of await page.locator('.award-tile img').all()){await img.scrollIntoViewIfNeeded();await expect.poll(()=>img.evaluate((i:HTMLImageElement)=>i.complete&&i.naturalWidth>0)).toBe(true);}
 const urls=await page.locator('.award-tile img').evaluateAll(nodes=>nodes.map(n=>(n as HTMLImageElement).src));expect(new Set(urls).size).toBe(46);
 await page.locator('main').evaluate(el=>el.scrollTop=0);await page.screenshot({path:'../reader-redesign-qa/awards.png'});
 for(const [width,height] of [[320,568],[375,812],[812,375]]){await page.setViewportSize({width,height});await page.locator('.award-tile').last().scrollIntoViewIfNeeded();const nav=await page.locator('.app-nav').boundingBox(),last=await page.locator('.award-tile').last().boundingBox();expect(last!.y+last!.height).toBeLessThanOrEqual(nav!.y);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);}
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();await expect(page.locator('.award-tile')).toHaveCount(46);
 await page.locator('[data-achievement="first"]').click();await expect(page.locator('.award-detail img')).toBeVisible();await expect.poll(()=>page.locator('.award-detail img').evaluate((i:HTMLImageElement)=>i.complete&&i.naturalWidth>0)).toBe(true);
 expect(await record(page)).toEqual(before);expect(errors).toEqual([]);
});
