import {test,expect,type Page} from './runtime';

async function open(page:Page,file='sample.cbz'){
 await page.goto('/');await expect(page.locator('.app')).toBeVisible();
 await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Загрузить комикс/}).click();await page.locator('[data-testid=comic-file-input]').setInputFiles('tests/fixtures/'+file);await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();await page.getByLabel('Название',{exact:true}).fill('Свободная страница');await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();await expect(page.locator('.modal')).not.toBeVisible();await page.getByRole('button',{name:/Все комиксы/}).click();await page.getByRole('button',{name:/^Читать: Свободная страница/}).click();
 await expect(page.locator('.reader canvas').first()).toBeVisible();await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();await page.getByLabel('Режим чтения',{exact:true}).selectOption('single');await page.getByRole('dialog',{name:'Настройки чтения',exact:true}).getByRole('button',{name:'Закрыть',exact:true}).click();await expect(page.getByTestId('reader-stage')).toHaveAttribute('data-zoom','1');
 const notice=page.getByRole('button',{name:'Скрыть уведомление о достижении'});for(let i=0;i<3&&await notice.count();i++)await notice.first().click();
}
const view=(page:Page)=>page.getByTestId('reader-stage').evaluate(e=>({zoom:Number((e as HTMLElement).dataset.zoom),x:Number((e as HTMLElement).dataset.panX),y:Number((e as HTMLElement).dataset.panY)}));
const frame=(page:Page)=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));

test('real touch pinch anchors the page, remaining finger pans, inertia and resume work',async({page,context,browserName})=>{
 test.skip(browserName!=='chromium','Native multi-touch is driven through Chromium CDP.');await open(page);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 const cdp=await context.newCDPSession(page),touch=async(type:string,points:any[])=>{await cdp.send('Input.dispatchTouchEvent',{type,touchPoints:points});await frame(page);};

 const a={x:130,y:350,id:0},b={x:245,y:350,id:1};await touch('touchStart',[a,b]);await touch('touchMove',[{...a,x:75},{...b,x:300}]);const pinched=await view(page);expect(pinched.zoom).toBeGreaterThan(1.9);expect(pinched.zoom).toBeLessThan(2.1);
 const stage=await page.getByTestId('reader-stage').boundingBox();const localY=350-stage!.y-stage!.height/2;expect(pinched.y).toBeCloseTo(localY*(1-pinched.zoom),0);
 await touch('touchEnd',[{...b,x:300}]);await touch('touchMove',[{...a,x:95,y:385}]);const continued=await view(page);expect(continued.x-pinched.x).toBeCloseTo(20,0);expect(continued.y-pinched.y).toBeCloseTo(35,0);await touch('touchEnd',[]);await expect(page.getByTestId('reader-stage')).toHaveAttribute('data-moving','false',{timeout:2500});
 expect(await page.locator('.reader canvas').getAttribute('data-page')).toBe('0');expect(await page.evaluate(()=>visualViewport?.scale)).toBe(1);await expect(page.getByRole('button',{name:'Настройки чтения',exact:true})).toBeVisible();
 // A one-finger drag is displayed before release, and continues briefly afterwards.
 await touch('touchStart',[{x:240,y:450,id:3}]);await touch('touchMove',[{x:210,y:430,id:3}]);await touch('touchMove',[{x:180,y:410,id:3}]);const during=await view(page);await touch('touchEnd',[]);await expect.poll(async()=>(await view(page)).x).toBeLessThan(during.x-1);await expect(page.getByTestId('reader-stage')).toHaveAttribute('data-moving','false',{timeout:2500});
 const saved=await view(page);await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();await page.getByRole('button',{name:/^Читать: Свободная страница/}).click();await expect.poll(async()=>(await view(page)).zoom).toBeCloseTo(saved.zoom,2);const restored=await view(page);expect(restored.x).toBeCloseTo(saved.x,0);expect(restored.y).toBeCloseTo(saved.y,0);
 await page.setViewportSize({width:812,height:375});await frame(page);expect((await view(page)).zoom).toBeCloseTo(saved.zoom,2);expect(errors).toEqual([]);
});

test('reset enables page swipes; cancelled gestures do not turn or toggle; PDF zoom works',async({page,context,browserName})=>{
 test.skip(browserName!=='chromium','Native touch cancellation is driven through Chromium CDP.');await open(page,'sample.pdf');await page.getByRole('button',{name:'Инструменты чтения',exact:true}).click();await page.getByRole('button',{name:'Увеличить масштаб',exact:true}).click();await expect.poll(async()=>(await view(page)).zoom).toBeCloseTo(1.5,2);await page.getByRole('button',{name:'Сбросить масштаб',exact:true}).click();await expect.poll(async()=>(await view(page)).zoom).toBeCloseTo(1,3);
 const cdp=await context.newCDPSession(page);await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:280,y:350,id:1}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:170,y:350,id:1}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});await frame(page);expect(await page.locator('.reader canvas').getAttribute('data-page')).toBe('0');await expect(page.getByRole('button',{name:'Настройки чтения',exact:true})).toBeVisible();
 await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:280,y:350,id:2}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:80,y:350,id:2}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await expect(page.locator('.reader canvas')).toHaveAttribute('data-page','1');await expect(page.getByTestId('reader-stage')).toHaveAttribute('data-zoom','1');
});

test('double tap zooms at the tap, and Ctrl-wheel zoom never scales the browser',async({page,context,browserName})=>{
 test.skip(browserName!=='chromium','Native taps are driven through Chromium CDP.');await open(page);const cdp=await context.newCDPSession(page);
 for(let i=0;i<2;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:100,y:350,id:1}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await frame(page);}
 await expect.poll(async()=>(await view(page)).zoom).toBeCloseTo(2.5,2);await expect(page.getByRole('button',{name:'Настройки чтения',exact:true})).toBeVisible();
 await page.mouse.move(160,400);await page.keyboard.down('Control');await page.mouse.wheel(0,-100);await page.keyboard.up('Control');await expect.poll(async()=>(await view(page)).zoom).toBeGreaterThan(2.6);expect(await page.evaluate(()=>visualViewport?.scale)).toBe(1);
});
