import {test,expect,type Page} from './runtime';
import {readFileSync,mkdirSync} from 'node:fs';

async function seed(page:Page, count=7){
 await page.goto('/');await expect(page.getByRole('heading',{name:'Моя библиотека',exact:true})).toBeVisible();
 const cover='data:image/webp;base64,'+readFileSync('tests/fixtures/cover-batman.webp').toString('base64');
 const file=readFileSync('tests/fixtures/sample.cbz').toString('base64');
 await page.evaluate(async({count,cover,file})=>{
  const request=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>((r,j)=>{request.onsuccess=()=>r(request.result);request.onerror=()=>j(request.error);});
  const tx=db.transaction(['comics','config','assets'],'readwrite');
  tx.objectStore('config').put([{id:'batman',title:'Бэтмен',chapters:[{id:'early',title:'Ранние годы'},{id:'empty',title:'Новая глава с очень длинным названием, которую пока не начали'}],updatedAt:1}],'reading-universes-v1');
  tx.objectStore('config').put({mode:'single',direction:'ltr',motion:'off',readerTheme:'black',doubleTap:true,showPage:true,cropMargins:false,panelOpacity:.75,panelPageFirst:false,panelPageLast:false,groupSeries:false,sort:'added',roadmapEra:'early'},'settings');
  const titles=['Бэтмен. Год первый','Бэтмен. Человек, который смеётся','Бэтмен. Долгий Хэллоуин','Бэтмен. Тёмная победа','Женщина-кошка. Когда в Риме — очень длинное название отдельной истории без обложки','Бэтмен. Хэллоуин: Специальный выпуск','Бэтмен. Эго'];
  for(let i=count-1;i>=0;i--)tx.objectStore('comics').put({id:'c'+i,title:titles[i]??'Комикс '+i,series:'',authors:'',year:null,addedAt:i+1,updatedAt:i+1,physical:'unknown',edition:'',publisher:'',editionYear:null,note:'',rating:0,completed:i<2,page:i===2?1:0,pageCount:3,visited:i<2?[0,1,2]:i===2?[0,1]:[],seconds:i<2?60:0,lastOpened:i===2?10:0,tone:'#52616b',universeId:'batman',era:i===1?'empty':'early',inRoadmap:true,...(i===1?{sideStoryAfter:'c0'}:{}),digital:{assetId:'test-file',format:'cbz',name:'test.cbz',size:100,fingerprint:'test'},...(i!==4?{coverId:'test-cover'}:{})});
  for(const [id,base64,type] of [['test-cover',cover.split(',')[1],'image/webp'],['test-file',file,'application/zip']])tx.objectStore('assets').put({id,blob:new Blob([Uint8Array.from(atob(base64),c=>c.charCodeAt(0))],{type})});
  await new Promise<void>((r,j)=>{tx.oncomplete=()=>r();tx.onerror=()=>j(tx.error);});db.close();
 },{count,cover,file});
 await page.goto('/#/library/batman');await page.reload();await expect(page.locator('.series-heading')).toContainText('Бэтмен');
 for(let n=0;n<20;n++){const close=page.getByRole('button',{name:'Скрыть уведомление о достижении'});try{await close.waitFor({state:'visible',timeout:200});await close.click();}catch{break;}}
}
async function records(page:Page){return page.evaluate(async()=>{const r=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(resolve=>{r.onsuccess=()=>resolve(r.result);});const q=db.transaction('comics').objectStore('comics').getAll();return await new Promise<any[]>(resolve=>{q.onsuccess=()=>{db.close();resolve(q.result);};});});}

test('flat addition order, linked stories, long titles, current position and compact mobile layout',async({page})=>{
 await seed(page);const before=await records(page);
 const rows=page.locator('.series-timeline-entry');await expect(rows).toHaveCount(7);
 expect(await rows.evaluateAll(els=>els.map(el=>el.getAttribute('data-comic-id')))).toEqual(['c0','c1','c2','c3','c4','c5','c6']);
 await expect(page.locator('.series-route-summary')).toHaveText('2 из 7 комиксов прочитано');
 await expect(page.locator('[data-comic-id="c2"]')).toContainText('Страница 2 из 3');
 await expect(page.locator('[data-comic-id="c2"] [role="progressbar"]')).toHaveAttribute('aria-valuenow','67');
 await expect(page.locator('.road-connector')).toHaveCount(0);await expect(page.getByText(/Дополнительн/)).toHaveCount(0);
 const geometry=await page.evaluate(()=>({width:innerWidth,overflow:document.documentElement.scrollWidth,third:document.querySelector('[data-comic-id="c2"]')!.getBoundingClientRect().bottom,cover:document.querySelector('.series-comic-row .cover')!.getBoundingClientRect().width}));
 expect(geometry.overflow).toBeLessThanOrEqual(geometry.width);expect(geometry.third).toBeLessThan(700);expect(geometry.cover).toBeLessThan(70);
 mkdirSync('../screenshots',{recursive:true});await page.screenshot({path:'../screenshots/COMICS-series-iPhone-mini.png'});
 await page.setViewportSize({width:320,height:568});await page.locator('[data-comic-id="c4"]').scrollIntoViewIfNeeded();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await expect(page.locator('[data-comic-id="c4"] .cover-art')).toBeVisible();
 await page.screenshot({path:'../screenshots/COMICS-series-small-screen.png'});expect(await records(page)).toEqual(before);
 await page.getByRole('button',{name:'Открыть поиск',exact:true}).click();await page.getByRole('searchbox').fill('Когда в Риме');await expect(rows).toHaveCount(1);await expect(page.locator('.series-step')).toHaveText('05');await page.getByRole('button',{name:'Закрыть поиск',exact:true}).click();
 await page.getByRole('button',{name:'Выбрать раздел',exact:true}).click();await page.getByRole('option',{name:/Новая глава/}).click();await expect(page.getByRole('heading',{name:'Ваш первый комикс',exact:true})).toBeVisible();await expect(rows).toHaveCount(0);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
});

test('whole row opens saved reading position, returns to series, editing preserves legacy links, works offline',async({page,context})=>{
 await seed(page);await page.locator('[data-comic-id="c2"] .series-comic-copy').click();await expect(page.locator('.reader canvas').first()).toBeVisible();await expect(page.locator('.reader')).toContainText('2 / 3');
 await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();await expect(page.locator('.series-timeline-entry')).toHaveCount(7);
 await page.locator('[data-comic-id="c1"] button').focus();await page.keyboard.press('F2');await expect(page.getByRole('dialog')).toBeVisible();await expect(page.getByLabel('Эра комикса')).toHaveValue('early');
 await page.getByLabel('Название',{exact:true}).fill('Переименованный спецвыпуск');await page.getByRole('button',{name:'Сохранить',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('[data-comic-id="c1"]')).toContainText('Переименованный спецвыпуск');
 let saved=(await records(page)).find(c=>c.id==='c1');expect(saved).toMatchObject({sideStoryAfter:'c0',addedAt:2,completed:true,coverId:'test-cover'});
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();await expect(page.locator('.series-timeline-entry')).toHaveCount(7);await expect(page.locator('[data-comic-id="c1"]')).toContainText('Переименованный спецвыпуск');
 await context.setOffline(false);await page.locator('[data-comic-id="c1"] button').focus();await page.keyboard.press('F2');await page.getByLabel('Эра комикса').selectOption('empty');await page.getByRole('button',{name:'Сохранить',exact:true}).click();await expect(page.locator('.series-timeline-entry')).toHaveCount(6);
 saved=(await records(page)).find(c=>c.id==='c1');expect(saved.sideStoryAfter).toBeUndefined();expect(saved.era).toBe('empty');expect(saved.coverId).toBe('test-cover');
});

test('single entry, new entries append and long series remain scrollable',async({page})=>{
 await seed(page,1);await expect(page.locator('.series-timeline-entry')).toHaveCount(1);
 await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Создать карточку/}).click();await page.getByLabel('Название',{exact:true}).fill('Новый комикс');await page.getByRole('button',{name:'Добавить комикс',exact:true}).last().click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('.series-timeline-entry')).toHaveCount(2);await expect(page.locator('.series-timeline-entry').last()).toContainText('Новый комикс');
 await page.evaluate(async()=>{const r=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(resolve=>r.onsuccess=()=>resolve(r.result));const tx=db.transaction('comics','readwrite'),q=tx.objectStore('comics').get('c0');q.onsuccess=()=>{for(let i=1;i<60;i++)tx.objectStore('comics').put({...q.result,id:'many'+i,title:'Комикс '+i,addedAt:100+i,completed:false});};await new Promise<void>(resolve=>tx.oncomplete=()=>resolve());db.close();});await page.reload();await expect(page.locator('.series-timeline-entry')).toHaveCount(61);await page.locator('.series-timeline-entry').last().scrollIntoViewIfNeeded();await expect(page.getByRole('button',{name:/^Все комиксы серии/})).toBeVisible();await page.getByRole('button',{name:/^Все комиксы серии/}).click();await expect(page.locator('.comic-card')).toHaveCount(61);
});
