import {test,expect,type Page} from './runtime';
import {seedSeries} from './series-fixture';
import {mkdirSync} from 'node:fs';

async function setRank(page:Page,tier:string){
 await page.evaluate(async(tier)=>{
  const q=indexedDB.open('batcave-reader'),db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
  const tx=db.transaction('config','readwrite');
  tx.objectStore('config').put({version:2,initializedAt:1,earned:[{id:`rank-${tier}`,at:123}],pending:[]},'achievements-v2');
  await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();window.dispatchEvent(new Event('batcave-achievements'));
 },tier);
}

test('ring goals show accurate current totals and fit phones without shrinking completed conditions',async({page})=>{
 await seedSeries(page);await page.getByRole('link',{name:'Открыть профиль',exact:true}).click();
 await page.evaluate(async()=>{
  const q=indexedDB.open('batcave-reader'),db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));
  const tx=db.transaction('comics','readwrite'),store=tx.objectStore('comics'),req=store.get('c0');
  req.onsuccess=()=>{const c=req.result;store.clear();for(let i=0;i<34;i++)store.put({...c,id:`r${i}`,completed:true,pageCount:i?0:2403,visited:i?[]:Array.from({length:2403},(_,j)=>j),seconds:i?0:(19*60+8)*60});};
  await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();
 });
 await setRank(page,'bronze');await page.reload();
 const before=await page.evaluate(async()=>{const q=indexedDB.open('batcave-reader'),db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const req=db.transaction('comics').objectStore('comics').getAll();return new Promise(r=>req.onsuccess=()=>{db.close();r(req.result);});});
 await expect(page.locator('.rank-goal-heading strong')).toHaveText(['2 403 / 3 000','34 / 20','19 ч 8 м / 25 ч']);
 await expect(page.locator('.rank-goal-copy>small')).toHaveText(['Осталось 597 страниц','Выполнено','Осталось 5 ч 52 м']);
 await expect(page.getByRole('progressbar',{name:'Время',exact:true})).toHaveAttribute('aria-valuemax','90000');
 await expect(page.locator('.rank-ring>span').first()).toHaveText('80%');await expect(page.locator('.rank-ring>span').last()).toHaveText('77%');
 await expect(page.locator('.rank-goal.is-done .rank-ring>span>svg')).toHaveCount(1);
 mkdirSync('../rings-qa',{recursive:true});
 for(const [width,height] of [[320,568],[375,812],[430,932],[812,375]]){
  await page.setViewportSize({width,height});await page.locator('.rank-goal').last().scrollIntoViewIfNeeded();
  const rows=await page.locator('.rank-goal').evaluateAll(els=>els.map(e=>e.getBoundingClientRect().height));
  expect(Math.max(...rows)-Math.min(...rows)).toBeLessThanOrEqual(1);
  for(const row of await page.locator('.rank-goal').all()){
   const copy=await row.locator('.rank-goal-copy').boundingBox(),value=await row.locator('strong').boundingBox();
   expect(value!.x+value!.width).toBeLessThanOrEqual(copy!.x+copy!.width+1);
  }
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  const bottom=await page.locator('.rank-goal').last().boundingBox(),nav=await page.locator('.app-nav').boundingBox();
  expect(bottom!.y+bottom!.height).toBeLessThanOrEqual(nav!.y+1);
  await page.screenshot({path:`../rings-qa/progress-${width}.png`});
 }
 const after=await page.evaluate(async()=>{const q=indexedDB.open('batcave-reader'),db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const req=db.transaction('comics').objectStore('comics').getAll();return new Promise(r=>req.onsuccess=()=>{db.close();r(req.result);});});
 expect(after).toEqual(before);
});

test('ring follows current rank while the next-rank title uses its own metal colour',async({page})=>{
 await seedSeries(page);await page.getByRole('link',{name:'Открыть профиль',exact:true}).click();
 for(const [tier,next,currentColor,nextColor] of [
  ['bronze','серебро','rgb(199, 152, 120)','rgb(187, 198, 207)'],
  ['silver','золото','rgb(187, 198, 207)','rgb(217, 187, 122)'],
  ['gold','платина','rgb(217, 187, 122)','rgb(187, 223, 234)'],
 ]){
  await setRank(page,tier);await expect(page.locator('#rank-next-title>span')).toHaveText(next);
  await expect(page.locator('#rank-next-title>span')).toHaveCSS('color',nextColor);
  await expect(page.locator('.rank-ring-fill').first()).toHaveCSS('stroke',currentColor);
 }
 await setRank(page,'platinum');await expect(page.locator('.rank-finale')).toContainText('Платина заслужена');await expect(page.locator('.rank-goal')).toHaveCount(0);
});
