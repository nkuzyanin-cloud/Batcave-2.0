import {test,expect,type Page} from './runtime';
import {readFileSync,mkdirSync} from 'node:fs';

async function showControls(page:Page){const reader=page.locator('.reader');if(await reader.evaluate(el=>el.classList.contains('ui-hidden')))await page.locator('.free-page-stage,.panel-scroll').first().tap({position:{x:170,y:260}});}
async function start(page:Page){await page.goto('/');await expect(page.getByRole('heading',{name:'Моя библиотека',exact:true})).toBeVisible();}
async function dismissNotices(page:Page){for(let n=0;n<20;n++){const close=page.getByRole('button',{name:'Скрыть уведомление о достижении'});try{await close.waitFor({state:'visible',timeout:350});await close.click();}catch{break;}}}
async function seed(page:Page,count=5){
 const coverA='data:image/webp;base64,'+readFileSync('tests/fixtures/cover-batman.webp').toString('base64');
 const coverB='data:image/webp;base64,'+readFileSync('tests/fixtures/cover-walking-dead.webp').toString('base64');
 await page.evaluate(async({count,coverA,coverB})=>{
  const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>((r,j)=>{q.onsuccess=()=>r(q.result);q.onerror=()=>j(q.error);});
  const tx=db.transaction(['comics','config','assets'],'readwrite');const now=Date.now();
  const universes=Array.from({length:count},(_,i)=>({id:i===0?'batman':'series-'+i,title:i===0?'Бэтмен':i===1?'Ходячие мертвецы':i===2?'Человек-паук':`Серия ${i}`,chapters:[{id:'main',title:'Основной маршрут'}],updatedAt:1,...(i===0?{cover:coverA}:i===1?{cover:coverB}:{})}));
  tx.objectStore('config').put(universes,'reading-universes-v1');tx.objectStore('config').put({...{mode:'single',direction:'ltr',motion:'off',readerTheme:'black',doubleTap:true,showPage:true,cropMargins:false,panelOpacity:.75,panelPageFirst:false,panelPageLast:false,groupSeries:false,sort:'added'},roadmapEra:'main'},'settings');
  const make=(id:string,patch:any={})=>({id,title:'История '+id,series:'',authors:'',year:null,addedAt:now,updatedAt:now,physical:'unknown',edition:'',publisher:'',editionYear:null,note:'',rating:0,completed:false,page:0,pageCount:100,visited:[],seconds:0,lastOpened:0,tone:'#52616b',universeId:'batman',era:'main',inRoadmap:true,...patch});
  const entries=[make('resume',{title:'Бэтмен. Долгий Хэллоуин',series:'Специальный выпуск',page:47,pageCount:160,visited:Array.from({length:48},(_,i)=>i),seconds:32160,lastOpened:now,digital:{assetId:'test-file',format:'cbz',name:'test.cbz',size:10,fingerprint:'test'},coverId:'test-cover'}),make('done',{completed:true,visited:[0,1,2]}),make('paper',{physical:'yes',universeId:'series-1',inRoadmap:false}),make('standalone',{title:'Очень длинное название самостоятельного комикса без обложки — проверка переноса текста на маленьком экране',universeId:'__unassigned__',era:'main'})];
  for(const c of entries)tx.objectStore('comics').put(c);
  tx.objectStore('assets').put({id:'test-cover',blob:new Blob([Uint8Array.from(atob(coverA.split(',')[1]),c=>c.charCodeAt(0))],{type:'image/webp'})});
  await new Promise<void>((r,j)=>{tx.oncomplete=()=>r();tx.onerror=()=>j(tx.error);});db.close();
 },{count,coverA,coverB});await page.reload();await expect(page.locator('.library-resume')).toBeVisible();await dismissNotices(page);
}
test('empty home, real add actions, settings and legacy links',async({page})=>{
 await start(page);await expect(page.getByRole('button',{name:'Открыть профиль'})).toHaveCount(0);await expect(page.getByText('Добавьте комикс, чтобы начать читать.')).toBeVisible();
 await page.getByRole('button',{name:'Открыть настройки',exact:true}).click();await expect(page.getByRole('heading',{name:'Настройки',exact:true})).toBeVisible();await page.getByRole('button',{name:'Назад',exact:true}).click();
 await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Создать карточку/}).click();await expect(page.getByRole('dialog')).toBeVisible();await expect(page.getByLabel('Серия комикса')).toHaveValue('__unassigned__');await page.getByRole('button',{name:'Закрыть',exact:true}).click();
 await page.goto('/#/profile');await expect(page.getByRole('heading',{name:'Моя библиотека',exact:true})).toBeVisible();await page.goto('/#/collection');await expect(page.getByRole('heading',{name:'Все комиксы',exact:true})).toBeVisible();
});
test('compact phone home, complete series list, metadata search, achievements and existing paper cards',async({page},info)=>{
 await start(page);await seed(page);
 await expect(page.locator('.library-series')).toHaveCount(5);await expect(page.locator('.library-resume')).toContainText('Страница 48 из 160');await expect(page.locator('.library-stats')).toContainText('8');
 const dimensions=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,seriesTop:document.querySelector('.library-series')!.getBoundingClientRect().top,headerHeight:document.querySelector('.app-header')!.getBoundingClientRect().height}));expect(dimensions.scroll).toBeLessThanOrEqual(dimensions.width);expect(dimensions.seriesTop).toBeLessThan(650);expect(dimensions.headerHeight).toBeLessThan(70);
 mkdirSync('../screenshots',{recursive:true});await page.screenshot({path:'../screenshots/COMICS-library-iPhone-mini.png'});await page.locator('main.screen').evaluate(el=>el.scrollTop=el.scrollHeight);await page.screenshot({path:'../screenshots/COMICS-library-statistics.png'});await page.locator('main.screen').evaluate(el=>el.scrollTop=0);
 await page.getByRole('button',{name:/Все серии/}).click();const modal=page.getByRole('dialog',{name:'Все серии',exact:true});await expect(modal.locator('.library-series')).toHaveCount(5);await modal.getByRole('button',{name:'Открыть серию: Бэтмен',exact:true}).click();await expect(page.locator('.app-heading')).toContainText('Бэтмен');await page.getByRole('button',{name:'Все комиксы серии'}).click();await expect(page.locator('.comic-card')).not.toHaveCount(0);await page.getByRole('button',{name:'Назад',exact:true}).click();await expect(page.locator('.app-heading')).toBeVisible();await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();
 await page.getByRole('button',{name:'Открыть поиск',exact:true}).click();await page.getByRole('searchbox',{name:'Поиск комиксов',exact:true}).fill('самостоятельного');await expect(page.getByRole('button',{name:/^Открыть: Очень длинное/})).toBeVisible();await page.getByRole('button',{name:'Закрыть поиск',exact:true}).click();
 await page.getByRole('link',{name:'Открыть достижения',exact:true}).click();await expect(page.getByRole('heading',{name:'Достижения',exact:true})).toBeVisible();await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();
 await page.getByRole('button',{name:/Без серии/}).click();await expect(page.getByRole('heading',{name:'Без серии',exact:true})).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
 await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();await page.setViewportSize({width:320,height:568});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await page.screenshot({path:'../screenshots/COMICS-library-small-screen.png'});
});
test('many series stay searchable and a series editor retains its chapters',async({page})=>{
 await start(page);await seed(page,120);await page.getByRole('button',{name:/Все серии/}).click();const modal=page.getByRole('dialog',{name:'Все серии',exact:true});await expect(modal.locator('.library-series')).toHaveCount(120);await modal.getByRole('searchbox',{name:'Найти серию'}).fill('Серия 119');await expect(modal.locator('.library-series')).toHaveCount(1);await modal.locator('.library-series').click();await page.getByRole('button',{name:'Меню серии',exact:true}).click();await page.getByRole('button',{name:'Изменить серию',exact:true}).click();await expect(page.getByRole('dialog',{name:'Изменить серию',exact:true})).toBeVisible();await expect(page.getByLabel('Название раздела 1')).toHaveValue('Основной маршрут');
});
test('import CBZ, reader position, return to the originating screen and offline reload',async({page,context})=>{
 await start(page);await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Загрузить комикс/}).click();await page.locator('[data-testid="comic-file-input"]').setInputFiles('tests/fixtures/sample.cbz');await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();await page.getByLabel('Название',{exact:true}).fill('Проверка чтения');await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();await expect(page.locator('.modal')).not.toBeVisible();
 await page.getByRole('button',{name:/Все комиксы/}).click();await page.getByRole('button',{name:/^Читать: Проверка чтения/}).click();await expect(page.locator('.reader canvas').first()).toBeVisible();await showControls(page);await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();await expect(page.getByRole('heading',{name:'Все комиксы',exact:true})).toBeVisible();
 await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();await expect(page.getByRole('button',{name:'Продолжить чтение: Проверка чтения',exact:true})).toBeVisible();await page.getByRole('button',{name:'Продолжить чтение: Проверка чтения',exact:true}).click();await expect(page.locator('.reader canvas').first()).toBeVisible();await showControls(page);await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();await expect(page.getByRole('heading',{name:'Моя библиотека',exact:true})).toBeVisible();
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();await expect(page.getByRole('heading',{name:'Моя библиотека',exact:true})).toBeVisible();await expect(page.locator('.library-resume')).toBeVisible();
});

test('PDF, images and prepared CBZ still open in the real reader',async({page})=>{
 for(const [file,name] of [['sample.pdf','PDF-проверка'],['page.webp','Изображение-проверка'],['prepared-ui.cbz','Кадры-проверка']]){
  await start(page);await page.getByRole('button',{name:'Добавить комикс',exact:true}).click();await page.getByRole('button',{name:/Загрузить комикс/}).click();await page.locator('[data-testid="comic-file-input"]').setInputFiles('tests/fixtures/'+file);await expect(page.getByText('Файл проверен',{exact:true})).toBeVisible();await page.getByLabel('Название',{exact:true}).fill(name);await page.getByRole('button',{name:'Сохранить в библиотеку',exact:true}).click();await expect(page.locator('.modal')).not.toBeVisible();await page.getByRole('button',{name:/Все комиксы/}).click();await page.getByRole('button',{name:new RegExp('^Читать: '+name)}).click();await expect(page.locator('.reader canvas').first()).toBeVisible();await showControls(page);
  if(file==='prepared-ui.cbz'){await page.getByRole('button',{name:'Настройки чтения',exact:true}).click();const dialog=page.getByRole('dialog',{name:'Настройки чтения',exact:true});await dialog.getByLabel('Режим чтения',{exact:true}).selectOption('panels');await dialog.getByRole('button',{name:'Закрыть',exact:true}).click();await expect(page.getByTestId('panel-stage')).toBeVisible();await expect(page.getByTestId('panel-stage')).toHaveAttribute('aria-busy','false');}
  await page.getByRole('button',{name:'Вернуться к комиксам',exact:true}).click();await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();
 }
});

test('home includes the third series and reveals later series in batches of six',async({page})=>{
 await start(page);
 for(const total of [3,6,7,13]){
  await seed(page,total);
  const cards=page.locator('.series-shelf>.library-series'),more=page.getByRole('button',{name:'Ещё серии — показать следующие 6',exact:true});
  await expect(cards).toHaveCount(Math.min(total,6));
  if(total<=6){await expect(more).toHaveCount(0);continue;}
  await expect(more).toBeVisible();await more.click();await expect(cards).toHaveCount(Math.min(total,12));
  if(total>12){await more.click();await expect(cards).toHaveCount(total);}
  await expect(more).toHaveCount(0);
  expect(await cards.evaluateAll(els=>new Set(els.map(el=>el.getAttribute('aria-label'))).size)).toBe(total);
  await page.getByRole('button',{name:'Открыть поиск',exact:true}).click();
  await page.getByRole('searchbox',{name:'Поиск комиксов',exact:true}).fill(total===7?'Серия 6':'Серия 12');
  await expect(cards).toHaveCount(1);await expect(more).toHaveCount(0);
  await page.getByRole('button',{name:'Закрыть поиск',exact:true}).click();await expect(cards).toHaveCount(total);
 }
});
