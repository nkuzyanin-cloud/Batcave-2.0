import {test,expect} from './runtime';
import {seedSeries,record} from './series-fixture';
import {mkdirSync} from 'node:fs';
test('profile migration, independent goals, responsive footer, offline and unchanged comics',async({page,context})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await seedSeries(page);const before=await record(page);
 await page.getByRole('link',{name:'Моя библиотека',exact:true}).click();
 await expect(page.locator('.library-statistics')).toHaveCount(0);await expect(page.locator('.reader-shelf')).toHaveCount(0);await expect(page.getByRole('heading',{name:'Продолжить чтение',exact:true})).toBeVisible();
 await page.getByRole('link',{name:'Открыть профиль',exact:true}).click();await expect(page.getByRole('heading',{name:'Профиль',exact:true})).toBeVisible();await expect(page.locator('.rank-next')).toContainText('Следующий ранг — бронза');await expect(page.locator('.rank-goal')).toHaveCount(3);await expect(page.locator('.rank-book')).toHaveCount(0);
 await page.evaluate(async()=>{const q=indexedDB.open('batcave-reader');const db=await new Promise<IDBDatabase>(r=>q.onsuccess=()=>r(q.result));const tx=db.transaction('config','readwrite');tx.objectStore('config').put({version:2,initializedAt:0,earned:[{id:'first',at:1},{id:'rank-bronze',at:2}],pending:[]},'achievements-v2');await new Promise<void>(r=>tx.oncomplete=()=>r());db.close();});
 await page.reload();await expect(page.locator('.rank-hero h2')).toHaveText('Бронза');await expect(page.locator('.rank-next')).toContainText('Следующий ранг — серебро');await expect(page.locator('.reader-profile img')).toHaveCount(1);await expect.poll(()=>page.locator('.rank-book').evaluate((i:HTMLImageElement)=>i.complete&&i.naturalWidth>0)).toBe(true);
 mkdirSync('../reader-profile-qa',{recursive:true});await page.screenshot({path:'../reader-profile-qa/profile.png'});
 for(const [width,height] of [[320,568],[375,812],[812,375]]){await page.setViewportSize({width,height});await page.locator('.rank-goal').last().scrollIntoViewIfNeeded();const nav=await page.locator('.app-nav').boundingBox(),last=await page.locator('.rank-goal').last().boundingBox();expect(last!.y+last!.height).toBeLessThanOrEqual(nav!.y+1);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);}
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);await context.setOffline(true);await page.reload();await expect(page.locator('.rank-hero h2')).toHaveText('Бронза');await expect.poll(()=>page.locator('.rank-book').evaluate((i:HTMLImageElement)=>i.complete&&i.naturalWidth>0)).toBe(true);expect(await record(page)).toEqual(before);expect(errors).toEqual([]);
});
