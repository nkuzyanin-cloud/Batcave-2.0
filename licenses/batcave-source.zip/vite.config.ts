import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
const walk = (p: string): string[] => readdirSync(p, { withFileTypes: true })
  .flatMap(e => e.isDirectory() ? walk(`${p}/${e.name}`) : [`${p}/${e.name}`]);
const version = JSON.parse(readFileSync('package.json', 'utf8')).version as string;
const hash = createHash('sha256');
const inputs = ['package.json', 'package-lock.json', 'index.html', 'vite.config.ts',
  ...walk('src'), ...walk('scripts'), ...walk('public').filter(p => !p.startsWith('public/pdf/') && !/\.(zip|wasm|mjs)$/.test(p))];
for (const file of inputs.sort()) hash.update(file).update('\0').update(readFileSync(file));
const build = hash.digest('hex').slice(0, 16);
export default defineConfig({
  base: './',
  plugins: [react(), { name: 'batcave-build', transformIndexHtml: () => [
    { tag: 'meta', attrs: { name: 'batcave-build', content: build }, injectTo: 'head' },
  ] }],
  define: { __APP_VERSION__: JSON.stringify(version), __APP_BUILD__: JSON.stringify(build) },
  resolve: { conditions: ['onnxruntime-web-use-extern-wasm','module','browser','development|production'] },
  worker: { format: 'es' },
  build: { target: 'es2022', chunkSizeWarningLimit: 900 },
  server: { host: '0.0.0.0' },
});
