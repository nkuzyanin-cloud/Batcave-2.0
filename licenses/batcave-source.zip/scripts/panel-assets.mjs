import {createHash} from 'node:crypto';
import {copyFileSync,mkdirSync,existsSync,readFileSync} from 'node:fs';
mkdirSync('public/panel-ai',{recursive:true});
for(const name of ['ort-wasm-simd-threaded.mjs','ort-wasm-simd-threaded.wasm'])
  copyFileSync(`node_modules/onnxruntime-web/dist/${name}`,`public/panel-ai/${name}`);
if(!existsSync('public/panel-ai/best.onnx')) throw Error('Missing bundled Inkwell panel model');

// Pin the complete bundled model: an interrupted copy must fail the build,
// rather than producing an installable PWA with an unreadable ONNX payload.
const model=readFileSync('public/panel-ai/best.onnx');
if(model.length!==12256396||createHash('sha256').update(model).digest('hex')!=='f240e1296efd048126b26ea4ffeddc97d7c3aa667a37e3127c2afc6d5e9b9578')
  throw Error('Bundled Inkwell model is incomplete or differs from the validated model.');
