import { cpSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';

// Keep all PDF character maps and standard fonts, without hundreds of uploads.
// Format: uint32 LE index size, UTF-8 JSON index, concatenated original bytes.
rmSync('dist', { recursive: true, force: true });
rmSync('public/pdf', { recursive: true, force: true });
mkdirSync('public/pdf', { recursive: true });
const index = {};
const parts = [];
const notices = [];
for (const file of readdirSync('docs/licenses').sort())
  notices.push(`${file}\n\n${readFileSync(`docs/licenses/${file}`, 'utf8')}`);
let offset = 0;
for (const dir of ['cmaps', 'standard_fonts', 'wasm', 'iccs']) {
  for (const file of readdirSync(`node_modules/pdfjs-dist/${dir}`).sort()) {
    const path = `node_modules/pdfjs-dist/${dir}/${file}`;
    const bytes = readFileSync(path);
    if (file.startsWith('LICENSE')) {
      notices.push(`PDF.js / ${dir} / ${file}\n\n${bytes.toString('utf8')}`);
    } else if (dir === 'cmaps' || dir === 'standard_fonts') {
      index[`${dir}/${file}`] = [offset, bytes.length];
      parts.push(bytes);
      offset += bytes.length;
    } else {
      mkdirSync(`public/pdf/${dir}`, { recursive: true });
      cpSync(path, `public/pdf/${dir}/${file}`);
    }
  }
}
const header = Buffer.from(JSON.stringify(index));
const size = Buffer.alloc(4);
size.writeUInt32LE(header.length);
writeFileSync('public/pdf/resources.bin', Buffer.concat([size, header, ...parts]));
writeFileSync('public/pdf/LICENSES.txt', notices.join('\n\n' + '='.repeat(72) + '\n\n'));
