import { readdirSync, writeFileSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
function walk(p) {
  return readdirSync(p, { withFileTypes: true }).flatMap((x) =>
    x.isDirectory() ? walk(`${p}/${x.name}`) : [`${p}/${x.name}`],
  );
}
const files = walk('dist')
  // GitHub Pages uses .nojekyll as a publishing marker but does not serve it.
  // Hidden deployment files must never be required for offline installation.
  .filter((x) => !x.endsWith('/sw.js') && !x.endsWith('/batcave-source.zip') && !x.slice(5).split('/').some((part) => part.startsWith('.')))
  .map((x) => x.slice(5));
const hash = createHash('sha256');
for (const file of files) hash.update(file).update('\0').update(readFileSync(`dist/${file}`));
const version = hash.digest('hex').slice(0, 16);
const release = JSON.parse(readFileSync('package.json', 'utf8')).version;
writeFileSync(
  'dist/sw.js',
  `const PREFIX='batcave-'+self.registration.scope;const CACHE=PREFIX+'${version}';const RELEASE=${JSON.stringify(release)};const FILES=${JSON.stringify(files)};const ROOT=new URL('./',self.location.href).href;const versions=new Map();const owned=k=>k.startsWith(PREFIX)&&/^[a-f0-9]{16}$/.test(k.slice(PREFIX.length));
// Activate a complete download, but never reload a window from the worker.
// This also lets legacy 1.6 clients pick up the fix on their next launch.
self.addEventListener('install',e=>e.waitUntil((async()=>{const c=await caches.open(CACHE);for(let i=0;i<FILES.length;i+=12)await c.addAll(FILES.slice(i,i+12).map(f=>new Request(new URL(f,ROOT),{cache:'reload'})));await self.skipWaiting();})()));
async function cleanup(){const clients=(await self.clients.matchAll({type:'window',includeUncontrolled:true})).filter(c=>c.url.startsWith(ROOT));for(const c of clients)if(!versions.has(c.id))c.postMessage({type:'VERSION_REQUEST'});if(!clients.length||clients.some(c=>versions.get(c.id)!==RELEASE))return;const keys=await caches.keys(),at=keys.indexOf(CACHE);if(at<0)return;for(const k of keys.slice(0,at))if(owned(k))await caches.delete(k);}
self.addEventListener('message',e=>{if(e.data==='ACTIVATE')e.waitUntil(self.skipWaiting());else if(e.data?.type==='CLIENT_VERSION'&&e.source){versions.set(e.source.id,e.data.version);e.waitUntil(cleanup());}});
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
// Keep previous hashed modules usable while an old window is still open.
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||!u.href.startsWith(ROOT))return;e.respondWith((async()=>{const c=await caches.open(CACHE);const hit=await c.match(e.request,{ignoreSearch:true});if(hit)return hit;if(e.request.mode==='navigate')return (await c.match(new URL('index.html',ROOT)))||fetch(e.request);for(const k of await caches.keys())if(owned(k)&&k!==CACHE){const old=await (await caches.open(k)).match(e.request,{ignoreSearch:true});if(old)return old;}return fetch(e.request);})());});`,
);
console.log(`Offline cache: ${files.length} resources, version ${version}`);
