import { readdirSync, readFileSync, existsSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';
import { createHash } from 'node:crypto';
import { ZipWriter, BlobWriter, Uint8ArrayReader } from '@zip.js/zip.js';

// This user's deployment replaces assets/ as a whole. ALWAYS include every
// current asset, including unchanged background art and PDF / panel workers.
// Never ship an assets delta, and never carry forward obsolete hashed chunks.
// Other paths are a normal overlay: overwrite the included files, keep the rest.
const [baseline, output] = process.argv.slice(2);
if (!baseline || !output) throw Error('Usage: node scripts/package-update.mjs PREVIOUS_DEPLOYMENT OUTPUT.zip');
const walk = p => readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(p,e.name)):[join(p,e.name)]);
// Use the release inventory as authority even if an interrupted build left
// obsolete files in dist. The complete active assets set is always included.
const release=JSON.parse(readFileSync('dist/release.json','utf8'));
const active=new Set([...Object.keys(release.sha256),release.source.path,'release.json','sw.js']);
const previous=existsSync(join(baseline,'release.json'))?JSON.parse(readFileSync(join(baseline,'release.json'),'utf8')):null;
const previousHashes={...previous?.sha256,...(previous?.source?{[previous.source.path]:previous.source.sha256}:{})};
const files = walk('dist').filter(p=>{
  const name=relative('dist',p),old=join(baseline,name);
  const oldHash=previousHashes[name];
  const changed=oldHash?createHash('sha256').update(readFileSync(p)).digest('hex')!==oldHash:!existsSync(old)||!readFileSync(p).equals(readFileSync(old));
  return active.has(name) && (name.startsWith('assets/') || changed);
}).sort();
const writer=new ZipWriter(new BlobWriter('application/zip'));
for (const p of files) await writer.add(relative('dist',p),new Uint8ArrayReader(readFileSync(p)),{level:6});
writeFileSync(output,new Uint8Array(await(await writer.close()).arrayBuffer()));
console.log(`Update: ${files.length} files; complete assets folder. ${output}`);
