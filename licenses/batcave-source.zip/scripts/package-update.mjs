import { readdirSync, readFileSync, existsSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';
import { ZipWriter, BlobWriter, Uint8ArrayReader } from '@zip.js/zip.js';

// This user's deployment replaces assets/ as a whole. ALWAYS include every
// current asset, including unchanged background art and PDF / panel workers.
// Never ship an assets delta, and never carry forward obsolete hashed chunks.
// Other paths are a normal overlay: overwrite the included files, keep the rest.
const [baseline, output] = process.argv.slice(2);
if (!baseline || !output) throw Error('Usage: node scripts/package-update.mjs PREVIOUS_DEPLOYMENT OUTPUT.zip');
const walk = p => readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(p,e.name)):[join(p,e.name)]);
const files = walk('dist').filter(p=>{
  const name=relative('dist',p),old=join(baseline,name);
  return name.startsWith('assets/') || !existsSync(old) || !readFileSync(p).equals(readFileSync(old));
}).sort();
const writer=new ZipWriter(new BlobWriter('application/zip'));
for (const p of files) await writer.add(relative('dist',p),new Uint8ArrayReader(readFileSync(p)),{level:6});
writeFileSync(output,new Uint8Array(await(await writer.close()).arrayBuffer()));
console.log(`Update: ${files.length} files; complete assets folder. ${output}`);
