import {readdirSync,readFileSync,writeFileSync} from 'node:fs';
import {ZipWriter,BlobWriter,Uint8ArrayReader,TextReader,configure} from '@zip.js/zip.js';
configure({useWebWorkers:false});
const walk=p=>readdirSync(p,{withFileTypes:true}).filter(e=>!e.name.startsWith('.')).flatMap(e=>e.isDirectory()?walk(`${p}/${e.name}`):[`${p}/${e.name}`]);
const files=[...'package.json package-lock.json tsconfig.json vite.config.ts playwright.config.ts index.html LICENSE'.split(' '),
 ...walk('src'), ...walk('tests/unit'), ...walk('tests/e2e'), ...walk('tests/fixtures').filter(p=>!p.endsWith('/large.cbz')), ...walk('docs/licenses'),...walk('scripts'),
 ...walk('public').filter(p=>!p.startsWith('public/pdf/')&&!/\.(wasm|mjs|zip)$/.test(p))];
const writer=new ZipWriter(new BlobWriter('application/zip'));
for(const file of [...new Set(files)].sort()) await writer.add(file,new Uint8ArrayReader(readFileSync(file)),{lastModDate:new Date('2026-10-12T00:00:00Z'),level:6});
const release=JSON.parse(readFileSync('package.json','utf8')).version;
await writer.add('BUILD.txt',new TextReader(`BATCAVE ${release}: AGPL-3.0-only. Node.js 24+: npm ci; npm run check; npm test; npm run build. Output: dist/.\nUI tests: npx playwright install chromium webkit; npm run test:e2e.\nThe original detector weights are bundled in public/panel-ai/. Model attribution and licenses: public/licenses/.\nPinned npm dependencies provide the ONNX runtime and PDF resources, copied by build scripts.\nPublish the complete dist/ together. Service Worker validates its files before activation.\nNo comic files or personal data are included.\n`),{lastModDate:new Date('2026-10-12T00:00:00Z')});
writeFileSync('public/licenses/batcave-source.zip',new Uint8Array(await (await writer.close()).arrayBuffer()));
